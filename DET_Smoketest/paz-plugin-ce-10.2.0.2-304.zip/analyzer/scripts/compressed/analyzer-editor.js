define("pentaho/analyzer/cv_base",["dojo/_base/declare","dojo/on","dojo/query",
"dijit/Menu","dijit/Dialog","dojo/ready","dojo/_base/lang","dojo/html",
"dojo/dom"],function(e,o,n,t,d,i,a,s,l){a.mixin(window.cv,{prefs:{
suppressMsg:{},fadeTime:250,wipeTime:250,isDebug:0,skipDirtyAlert:!1},
defaultNS:"http://www.pentaho.com",contextPath:"",dojoWidgets:{},helpTopics:{},
helpWin:null,securityToken:null,nsResolver:function(e){
return"http://www.pentaho.com"},getFieldHelp:null,getActiveReport:null,
init:function(){var e=!1;try{e=window.parent&&window.parent.PentahoMobile}catch(
e){}console_enabled||e||document.getElementsByTagName("body")[0].classList.add(
"pentaho-page-background")}}),cv.extension=cv.extension||{},i(cv.init),
dojoConfig.bindEncoding="utf8";a=window.cvConst={dndObjectTypes:{gem:"G"},
dndSourceTypes:{fieldList:"F",layoutPanel:"B",reportArea:"R"}};a.dndTypes={
gemFromFieldList:a.dndObjectTypes.gem+a.dndSourceTypes.fieldList,
gemFromLayoutPanel:a.dndObjectTypes.gem+a.dndSourceTypes.layoutPanel,
gemFromReportArea:a.dndObjectTypes.gem+a.dndSourceTypes.reportArea}});define("pentaho/analyzer/cv_util",["dojo/_base/declare","dojo/_base/array",
"dojo/on","dojo/query","dojo/_base/lang","dijit/popup","dojo/dom-class",
"dojo/window","dojo/dom-style","dijit/registry","dojo/html","dojo/dom",
"dojo/topic","dojo/parser","dojox/fx","dojo/dnd/Manager","dojo/dnd/common",
"dojo/dom-geometry","dojox/xml/parser","dijit/MenuItem","dijit/MenuSeparator",
"dojo/dnd/Avatar","dijit/BackgroundIframe","dojo/has","dojo/sniff",
"dijit/PopupMenuItem","dijit/Tooltip","dijit/layout/TabController","dojo/cache",
"dojo/regexp","dijit/layout/_TabContainerBase","dijit/layout/TabContainer",
"dijit/DialogUnderlay","./visual/utils","pentaho/visual/util","dojo/string",
"dojo/request","pentaho/common/Messages","pentaho/csrf/service",
"common-ui/util/_a11y","common-ui/util/_focus","./cv_base"],(e,s,l,n,a,d,c,u,p,i
,t,h,r,o,g,v,m,f,b,y,C,A,w,N,S,k,P,F,W,I,E,L,B,R,T,x,D,H,_,M,j)=>{let O=null;
cv.util={initDojoWidget:null,getRestoreFocus(){return j.refreshElement(O)},
setRestoreFocus(e){O=e},bindRestoreFocus(t,e){const i="string"==typeof e?t[e]:e;
return(...e)=>(j.suspendFocusRing(),cv.util.restoreFocus(),i.apply(t,e))},
restoreFocus(){var e=this.getRestoreFocus();null!=e&&(e.focus(),O=null)},
createCompositeHandle(){const t=[];return{add(e){return t.push.apply(t,arguments
),this},remove(){return t.forEach(e=>{e.remove()}),t.length=0,this}}},
alertErrorOnPageOpen(e,t){alert(e),t&&(window.location=t)},delayThese(e,t,i,r){
e.length?(void 0===i&&"number"==typeof t?(i=t,t=()=>{}):t||(t=()=>{},i=i||0),
setTimeout(()=>{e.shift()(),t(),cv.util.delayThese(e,t,i,r)},i)
):"function"==typeof r&&r()},checkNumber(e){return""!==e&&!isNaN(Number(e))},
isValidInteractionEvent(e){var t=e.keyCode||e.which;
return"click"===e.type||t===cvConst.keyCodes.SPACE||t===cvConst.keyCodes.ENTER},
checkPositiveInteger(e){var t;return!!cv.util.checkNumber(e)&&0<(t=parseInt(e,10
))&&t===parseFloat(e)},escapeHtml(e,t){let i=e.replace(/&/gm,"&amp;").replace(
/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
return i=t?i:i.replace(/'/gm,"&#39;")},escapeJavaScript(e){return e.replace(
/(["'\f\b\n\t\r])/gm,"\\$1")},getAttribute(e,t){return e.getAttribute(t)},
isValidElementName(i,r,o){var t=['"',"\\"];if(void 0===r&&(r=!1),
null==i||void 0===i)return H.getString("dlgPropertiesBlankNameError");
var e=i=i.toLowerCase();if(""===(i=i.trim()))return H.getString(
"dlgPropertiesBlankNameError");i=e;e=cv.getFieldHelp();let n;if(
e.selectedMenuField&&(n=e.selectedMenuField.textContent.toLowerCase()),
0<o.length)for(let t=0;t<=o.length-1;t++){var s=o[t].getElementsByTagName(
"presentationFieldHelp")[0].getAttribute("displayLabel"),a=s.toLowerCase();
let e=o[t].getAttribute("measureName");var l=e;if(e=e&&e.toLowerCase(),(
i===a||i===e)&&(r||a!==n))return(a=o[t].getElementsByTagName(
"presentationFieldHelp")[0].getAttribute("hidden").toLowerCase()
)&&"true"===a?i===e?H.getString("dlgPropertiesHiddenDuplicateNameRenamedError",[
l,s]):H.getString("dlgPropertiesHiddenDuplicateNameError"):i===e?H.getString(
"dlgPropertiesDuplicateNameRenamedError",[l,s]):H.getString(
"dlgPropertiesDuplicateNameError")}for(let e=0;e<=i.length;e++)for(const d in t
)if(i.charAt(e)===t[d])return H.getString("dlgPropertiesInvalidCharacters");
return!0},isValidMeasureName(e,t){var i=cv.getFieldHelp();
return this.isValidElementName(e,t,i.getMeasureList())},isValidAttributeName(e,t
){var i=cv.getFieldHelp(),r=i.selectedMenuField.getAttribute("formula"),r=i.get(
r).getAttribute("hierarchy"),i=i.getHierarchyLevels(r);
return this.isValidElementName(e,t,i)},convertReportCalcMeasureToModel(t,e){
var i=`[Measures].[${e}]`,r=cv.getFieldHelp().manager["report"],o=r["reportDoc"]
for(const s of o.getMetrics("EXPRESSION"))if(s.getAttribute("id")===t){
let e="measures";null!==s.getAttribute("gembarId")&&(e=s.getAttribute("gembarId"
));var n=r.api.report.getLayoutFields(e).indexOf(t);-1!==n&&(
r.api.report.removeLayoutField(e,t),r.api.report.addLayoutField(e,i,n))}
this.updateMeasureReferences(t,e)},updateMeasureReferences(t,i){
i=`[Measures].[${i}]`;if(t!==i){var r=cv.getFieldHelp().manager["report"];
let e=b.innerXML(r.reportDoc.getReportNode());e=e.replace(new RegExp(
I.escapeString(t),"g"),i);t=cv.parseXML(e);try{r.openReport(t.documentElement)
}catch(e){r.history.current().exec(!0)}}},xmlToJson(t){var i={};if(
t.nodeType===Node.ELEMENT_NODE){if(0<t.attributes.length){i.attributes={};for(
let e=0;e<t.attributes.length;e++){var r=t.attributes.item(e);i.attributes[
r.nodeName]=r.nodeValue}}for(let e=0;e<t.childNodes.length;e++){var o,
n=t.childNodes.item(e),s=n["nodeName"];"#text"!==s?void 0===i[s]?i[s
]=this.xmlToJson(n):(Array.isArray(i[s])||(o=i[s],i[s]=[],i[s].push(o)),i[s
].push(this.xmlToJson(n))):i._text=n.textContent.trim()}}return i},
createCalcMeasureAnnotation(e,t,i,r,o,n,s){
this._createGenericCalcMeasureAnnotation({name:e,caption:i,description:r,
formatCategory:o,formatScale:n,calculateSubtotals:s,formula:t,
dimension:"Measures",createdInline:!0},"CREATE_CALCULATED_MEMBER")},
createUpdateCalcMeasureAnnotation(e,t,i,r,o,n,s,a){
this._createGenericCalcMeasureAnnotation({originalName:e,name:t,caption:r,
description:o,formatCategory:n,formatScale:s,calculateSubtotals:a,formula:i,
dimension:"Measures",createdInline:!0},"UPDATE_CALCULATED_MEMBER")},
_findNextNonHiddenSibling(e){e=e.nextSibling;return e&&this._isHiddenChild(e
)?this._findNextNonHiddenSibling(e):e},_findPreviousNonHiddenSibling(e){
e=e.previousSibling;return e&&this._isHiddenChild(e
)?this._findPreviousNonHiddenSibling(e):e},_findNextNonHiddenHeader(e){
e=e&&e.nextSibling;return e&&this._isHiddenHeader(e
)?this._findNextNonHiddenHeader(e.nextSibling):e},_findPreviousNonHiddenHeader(e
){e=e&&e.previousSibling;return e&&this._isHiddenHeader(e
)?this._findPreviousNonHiddenHeader(e.previousSibling):e},_isHiddenHeader(e){
return e.classList.contains("hidden")},_isHiddenChild(e){
return this._isHiddenHeader(e)||e.classList.contains("hiddenField")},
_createGenericCalcMeasureAnnotation(e,t){var i=cv.getFieldHelp().manager[
"report"],e={properties:e,source:{cube:i.cube},type:t};i.modelAnnotations.push(e
)},createShowHideFieldAnnotation(t){var i=cv.getFieldHelp().manager["report"],
r=!this.isHiddenField(t),e=t.getAttribute("formula"),t=cv.getFieldHelp().get(e),
o=i.api.util.parseMDXExpression(e);let n;if("attributeHelp"===t.nodeName){
let e=t.getAttribute("hierarchy").replace(/[[\]]/g,"");t=t.getAttribute(
"dimension").replace(/[[\]]/g,"");0===e.indexOf(t+".")&&(e=e.substring(
t.length+1)),n={properties:{name:o,visible:!r,hierarchy:e,dimension:t},source:{
cube:i.cube},type:"SHOW_HIDE_ATTRIBUTE"}}else n={properties:{name:o,visible:!r},
source:{cube:i.cube},type:"SHOW_HIDE_MEASURE"};i.modelAnnotations.push(n);
t=i.manager.updateCatalog(!0);if(void 0!==t)i.modelAnnotations.pop(),
console.log(t);else{var s=[];for(const l of cv.getActiveReport(
).reportDoc.getDrillColumns()){var a=cv.textContent(l);s[a
]=a!==e?"true"!==cv.util.getAttribute(l,"hidden"):!r}cv.getActiveReport(
).reportDoc.replaceDrillColumns(s),r?(null!==(o=this.findContainingGemBar(i,e)
)&&i.api.report.removeLayoutField(o,e),i.history.add(new cv.ReportState(
"actionHideField",e))):i.history.add(new cv.ReportState("actionShowField",e)),
i.api.operation.refreshReport()}},substituteParams(e,t){
const i="object"==typeof t?t:cv.util.toArray(arguments,1);return e.replace(
/%\{(\w+)}/g,(e,t)=>{if(void 0!==i[t]&&null!=i[t])return i[t];
throw"Substitution not found: "+t})},toArray(t,i){var r=[];for(
let e=i||0;e<t.length;e++)r.push(t[e]);return r},summary(e,t){var i;
return!t||e.length<=t?e:(i=new RegExp(`\\.{1,${t}}$`),e.substring(0,t).replace(i
,"")+"...")},sanitizeJSONString(e){if(!e)return null;let t=e;return t=t.replace(
/\/\*[\s\S]*\*\//,"")},connectPopupMenu(r,e){const o=[];
return null!=e&&e.forEach(e=>{var t,i=this.getDojoWidget(e.id);i&&(
t=cv.util.bindRestoreFocus(e.src||r,e.handler),o.push(l(i,"click",t)),o.push(l(i
,"click",()=>{d.close()})),e.disabled)&&i.setDisabled(!0)}),{remove(){o.forEach(
e=>{e.remove()})}}},showPopupMenu(e,t,i,r){t+=7,i+=7;var o=u.getBox()["h"];if(
cv.api.event._emitBuildMenu(e,t,i)){const n=O,s=(O=r||null,d.open({popup:e,x:t,
y:i}),i+e.domNode.offsetHeight>o&&(i=o-e.domNode.offsetHeight-30,d.open({
popup:e,x:t,y:i})),l(e,"keypress",e=>{e=e.keyCode||e.which;
e!==cvConst.keyCodes.ESCAPE&&e!==cvConst.keyCodes.TAB||(d.close(),s.remove(),
r&&r.focus(),O=n)})),a=l(e,"blur",()=>{r&&c.remove(r,"selected-menu-field"),
d.close(),a.remove(),O=n});e.focus()}},disableMenuItems(e,t){
this.resetContextMenuItems(e);var i=cv.getFieldHelp(),r=t.getAttribute("formula"
),o=this.isHiddenField(t);let n=e.getChildren();for(let e=0;e<n.length;e++){var{
[e]:{id:s}}=n;"cmdHideField"===s?cv.util.setMenuItem(n[e],o?"checked":"none"
):"cmdFieldAbout"!==s&&o?cv.util.setMenuItem(n[e],null,"disabled"
):cv.util.setMenuItem(n[e],null,"active")}let a=i.getModelInfoValue(r,
"InlineCreatedInline");if(a=a&&"true"===a.trim(),t.classList.contains("measure")
){var l="true"===i.get(r,"calculated");n=e.getChildren();for(
let e=0;e<n.length;e++){var{[e]:{id:d}}=n;l?this._doesMenuItemApply(n[e],[
"calculated measure"])||this.hide(d):a||this._doesMenuItemApply(n[e],["measure"]
)||this.hide(d)}}else for(const c of n=e.getChildren())this._doesMenuItemApply(c
,["level"])||this.hide(c.id)},_doesMenuItemApply(e,t){let i=!1;if(e&&e.appliesTo
){t.push("all");for(const r in t)i=i||0<=s.indexOf(e.appliesTo,t[r])}return i},
resetContextMenuItems(e){for(const t of e.getChildren())this.show(t.domNode)},
destroyDojoWidgets(){for(const e in cv.dojoWidgets)try{cv.dojoWidgets[e
]&&cv.dojoWidgets[e].destroy(!0)}catch(e){}},disconnectPopupMenu(e,t){if(null!=t
)for(const i of t)this.getDojoWidget(i.id)},displayWidget(e,t){
this.getDojoWidget(e)&&(e=this.getDojoWidget(e).domNode)&&(t?p.set(e,"display",
""):p.set(e,"display","none"))},getAncestorByClass(e,t){for(;e&&!c.contains(e,t
);)e=e.parentNode;return e},getFirstChildByClass(e,t){t=n(" ."+t,e);if(
void 0!==t&&0<t.length)return t[0]},getAncestorByTag(e,t){for(t=t.toLowerCase(
);e;){if(e.tagName&&e.tagName.toLowerCase()===t)return e;e=e.parentNode}
return null},getDojoWidget(e){if(cv.dojoWidgets[e])return cv.dojoWidgets[e];
let t=i.byId(e);if(!t){if(!(t=h.byId(e)))return null;t=(t=o.instantiate([t])
)&&0<t.length?t[0]:null}return t&&(this.initDojoWidget&&this.initDojoWidget(t),
cv.dojoWidgets[e]=t,p.set(t.domNode,{zIndex:1002})),t},stopDrag(){c.remove(
win.body(),["dojoDndCopy","dojoDndMove"]),s.forEach(this.events,e=>{e.remove()})
,this.events=[],this.avatar&&this.avatar.destroy(),this.avatar=null,
this.source=this.target=null,this.nodes=[],r.publish("/dnd/cancel")},
helpdialog:null,getHelp(e){var t;(e=a.isObject(e)&&e.target?e.target.id:e
)&&"null"!==e?e.indexOf(".html")<0&&(e=cv.helpTopics&&cv.helpTopics[e
]?cv.helpTopics[e]:""):e="",e=cv.contextPath+"help/topic.html?"+e,
window.location.search&&-1<window.location.search.indexOf("embeddedHelp=true")?(
null==this.helpDialog&&(this.helpDialog=new cv.HelpDialog,this.helpDialog.init()
),this.helpDialog.showDlg(e)):(t=u.getBox(),
cv.helpWin&&!cv.helpWin.closed&&cv.helpWin.close(),(e=window.open(e,"helpWnd",
`height=${.8*t.h},width=${.8*t.w},menubar=0,status=0,toolbar=0,location=0,resizable=1`
))&&(cv.helpWin=e).focus())},getSelectionList(e){var t=e.getElementsByTagName(
"INPUT");let i=[];var r=t.length;for(let e=0;e<r;++e)t[e].checked&&i.push(t[e
].name);return i=0===i.length?null:i},check(e,t){("string"==typeof e?h.byId(e):e
).checked=t},hide(){for(const e of arguments)c.add(h.byId(e),"hidden")},
disableTextSelection(e){e.onselectstart=()=>!1,p.set(e,{
"-moz-user-select":"-moz-none","-khtml-user-select":"none",
"-webkit-user-select":"none","user-select":"none"})},initDivButton(e,t,i){if(!(
e="string"==typeof e?h.byId(e):e))return{remove(){}};const r=[l(e,"mouseover",
a.hitch(this,"_divButtonActive")),l(e,"mousedown",a.hitch(this,
"_divButtonPressed")),l(e,"mouseout",a.hitch(this,"_divButtonInactive")),l(e,
"click",a.hitch(this,"_divButtonInactive"))];return t?r.push(l(e,"click",
a.hitch(t,i))):i&&r.push(l(e,"click",i)),cv.util.disableTextSelection(e),{
remove(){r.forEach(e=>{e.remove()})}}},isHidden(e){return c.contains(h.byId(e),
"hidden")},isHiddenField(e){return c.contains(e,"hiddenField")||c.contains(e,
"disabled")},gravity(e,t){e=h.byId(e);const i=t.clientY,r=t.clientX;
var t=f.position(e),e=t.x+t.w/2,t=t.y+t.h/2,o=cv.util.gravity;return(
r<e?o.WEST:o.EAST)|(i<t?o.NORTH:o.SOUTH)},overElement(e,t){if(!e)return!1;let i;
switch(t.type){case"mouseout":case"mouseleave":if(t.target==e)return!1;break;
default:if(t.target==e)return!0}"AREA"===e.tagName&&"RECT"===e.getAttribute(
"shape").toUpperCase()?(o=e.coords.split(","),r=n(
`img[usemap='#${e.parentNode.getAttribute("name")}']`)[0],(i=f.position(r,!0)
).x+=parseInt(o[0],10),i.y+=parseInt(o[1],10),i.h+=parseInt(o[4],10)-parseInt(o[
1],10),i.w+=parseInt(o[3],10)-parseInt(o[0],10)):i=f.position(e,!0);
var r=t.clientX,o=t.clientY;return!(r>i.x+i.w||r<i.x||o>i.y+i.h||o<i.y)},
setButtonDisabled(e,t){var i;e&&t!=e.disabled&&("IMG"===e.tagName?(
i=-1<e.src.indexOf(".png")?".png":".gif",e.src=t?e.src.replace(i,"_disabled"+i
):e.src.replace("_disabled"+i,i)):t?c.add(e,"disabled"):c.remove(e,"disabled"),
e.setAttribute("tabindex",t?"-1":"0"),e.disabled=t)},isDisabled(e){
return Array.from(e.classList).some(e=>e.includes("disabled"))},isEnabled(e){
return!cv.util.isDisabled(e)},_divButtonActive(e){e.target.disabled||c.add(
this.getAncestorByClass(e.target,"reportBtn"),"btnActive")},_divButtonInactive(e
){e=this.getAncestorByClass(e.target,"reportBtn");c.remove(e,"btnActive")},
_divButtonPressed(e){},onToggleSectionCheckbox(e){(e.target.checked?g.wipeIn({
duration:cv.prefs.wipeTime,node:e.target.id+"DIV"}):g.wipeOut({
duration:cv.prefs.wipeTime,node:e.target.id+"DIV"})).play()},parseMDXExpression(
e,t){var i=e.lastIndexOf("].[");if(-1===i)return"";e=e.substring(i);
i=/\]\.\[(.+)\]$/.exec(e);if(!i)return"";let r=i[1];return"#null"===(
r=r.replace("]]","]"))?cvCatalog.attributeNullValue:r.search(/\S/
)<0?cvCatalog.attributeBlankValue:t?cv.util.escapeHtml(r):r},parseAjaxMsg(t){if(
"string"==typeof t){if(0<t.indexOf('<form name="login"')){if(
console_enabled&&window.parent.authenticate)return window.parent.authenticate({
loginCallback(){cv.getActiveReport()&&cv.getActiveReport().refreshReport()}}),
"sessionExpired";cv.getActiveReport()&&(cv.getActiveReport(
).setReportPropsDirty(!1),cv.getActiveReport().history.setSaved()),
window.location.reload()}var i=t.indexOf("<message");if(i<0)return;
let e=t.indexOf("</message>");if(e<0){if((e=t.indexOf("/>",i))<0)return;e+=2
}else e+=10;t=cv.parseXML(t.substring(i,e)),cv.setDomDefaultNamespace(t)}if(
a.isObject(t)&&t.documentElement&&"message"===t.documentElement.tagName){
var r=t.documentElement.attributes,o={};for(let e=0;e<r.length;++e){
var n=r.item(e);n.name&&(o[n.name]=n.value)}
i=t.documentElement.selectSingleNode("cv:selectionItems");
return null!=i&&cv.getActiveReport().reportDoc.replaceSelectionItems(
i.cloneNode(!0)),o}return null},_findKeyInQuery(e,t){if(0!==n.length)for(
const r of t.substring(1).split("&")){var i=r.indexOf("=");if(0<i)if(
r.substring(0,i)===e)return decodeURIComponent(r.substring(i+1).replace(/\+/g,
" "))}return null},getURLQueryValue(e,t){var i=this._findKeyInQuery(e,
window.location.search);
return i||""===i?i:t&&window.parent?this._findKeyInQuery(e,
window.parent.location.search):null},removeNode(e){
e&&e.parentNode&&e.parentNode.removeChild(e)},setCommonMsgTooltip(e){var t;e&&(
t=this.getDojoWidget("commonMsgTooltip"))&&(t.domNode.innerHTML=e)},
setDivActive(e,t){t?c.add(e,"active"):c.remove(e,"active")},setHelpTopics(t){
for(let e=0;e<t.length;++e){var i="string"==typeof t[e]?h.byId(t[e]):t[e];i&&(l(
i,"click",a.hitch(this,"getHelp")),M.makeAccessibleActionButton(i),
cv.helpTopics[t[e]]=t[++e])}},setMenuItem(e,t,i,r){var o;(
e="string"==typeof e?this.getDojoWidget(e):e)&&(t&&(o=e["iconNode"],
"checked"===t?(c.remove(o,"dijitNoIcon unchecked"),c.add(o,"checked")):(
c.remove(o,"dijitNoIcon checked"),c.add(o,"unchecked"))),
i&&e.setDisabled&&e.set("disabled","disabled"==i),r)&&(e.domNode.title=r)},
setVizMenuItemSelected(e,t){(e="string"==typeof e?this.getDojoWidget(e):e)&&(
e=e["domNode"],t?c.add(e,"selected"):c.remove(e,"selected"))},
setSectionCollapsed(e){let t=!0;var i=h.byId(e);i&&(
"checkbox"===i.type?i.checked=!1:"IMG"===i.tagName&&(this.hide(i.id+"DIV"),
i.name="closed",i.src=i.src.replace(/opened\./,"closed."),t=!1)),
t&&dojox.fx.wipeOut({duration:0,node:h.byId(e+"DIV")}).play()},show(){for(
const e of arguments)e.tagName?c.remove(e,"hidden"):c.remove(h.byId(e),"hidden")
},updateMenuItemCaption(e,t,i){e=this.getDojoWidget(e);e&&(t=cvCatalog[t],i&&(
t=cv.util.substituteParams(t,i)),e.setLabel(t))},TRACE(e){if(!(
cv.prefs.isDebug<2))try{var t;"_INIT"===e?(this.TRACEWIN=window.open("",
"cvtrace","resizable=1,scrollbars=1"),this.TRACEWIN.document.open(),
this.TRACEWIN.document.writeln("<b>INITIALIZE ClearView JS Trace</b><p>")
):"_EXIT"===e?(this.TRACEWIN.document.writeln("<b>EXIT ClearView JS Trace</b>"),
this.TRACEWIN.document.close(),this.TRACEWIN.close()):"_START"===e?(
this.TSBASE=this.TSSTART=new Date,this.TRACEWIN.document.writeln(
`<b>Start Profiling at: ${this.TSSTART}</b><br>`)
):"_END"===e?this.TRACEWIN.document.writeln(
`<b>Finish Profiling - Total: ${new Date-this.TSSTART} ms</b><p>`
):"_CLEAR"===e?this.TRACEWIN.document.clear():(t=new Date,
this.TRACEWIN.document.writeln(
`&nbsp;&nbsp;&nbsp;&nbsp;${e}: ${t-this.TSBASE} ms<br>`),this.TSBASE=new Date)
}catch(e){}},createEvent(e){return{target:e,clientX:0,clientY:0,stopPropagation(
){},preventDefault(){}}},convertStringtoDate(e){return new Date(Date.parse(e))},
formatDateString(e){var e=this.convertStringtoDate(e),t=["Jan","Feb","Mar","Apr"
,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][e.getMonth()],i=e.getDate(),
r=e.getFullYear();let o=e.toLocaleTimeString();return t+` ${i}, ${r} `+(
o=0===o.indexOf("0")?o.substring(1):o)},goToURL(e){try{var t=e.href.lastIndexOf(
"#");-1!==t&&(e.href=e.href.substring(0,t)),window.location=e}catch(e){if(!(N(
"ie")&&-1<e.message.indexOf("Unspecified error")))throw e}},selectByValue(t,i){
for(let e=0;e<t.length;e++)t.options[e].selected=t.options[e].value==i},
addChartMenuItems(s){const a=this;
var e=cv.api.ui._visualRegistry.getAllByCategory();const l=cv["vizApiVersion"],
d=[];let t=0;return e.forEach(e=>{e=e.models;0<t&&0<e.length&&s.addChild(new C({
id:"menu-item100000"+t})),t++,e.forEach(e=>{var e=e.type,t=null!=e.v2Spec,
i=R.getVizOptionsAnnotation(e.id),i=i&&i.isStockVisualization,r=t&&2===l,
o=!t&&3<=l,n=""+(t?e.v2Id:e.id),t=t?n.toUpperCase():T.getCssClasses(n),
e=""+e.label;!r&&!o&&i||d.push(a._createChartMenuItem(s,t,n,e))})}),d},
_createChartMenuItem(e,t,i,r){t+=" component-icon-menu",i=new y({id:i,label:r,
customType:!0});return c.remove(i.iconNode,"dijitNoIcon"),c.add(i.iconNode,t),
e.addChild(i),i},clearCache(e,t,i,r){const o=this;
var n=cv.contextPath+"service/ajax/clearCache",s={},n=_.getToken(n);null!==n&&(
s[n.header]=n.token),D(cv.contextPath+"service/ajax/clearCache",{method:"POST",
data:{catalog:h.byId("REPORT_catalog").value,time:(new Date).getTime()},sync:!0,
headers:s}).then(e=>{"true"===e?(r||o.showStatus("infoCacheCleared","INFO"),
t&&t()):(r||o.showStatus("errorClearCache","ERROR"),i&&i())},()=>{
r||o.showStatus("errorClearCache","ERROR"),i&&i()},()=>{})},showStatus(e,t){
var i=cv.getActiveReport();let r=cvCatalog[e],o=(r=r||e,t);
"ERROR"===t?o=cvCatalog.dlgTitleError:"INFO"===t?o=cvCatalog.dlgTitleInfo:"WARNING"===t&&(
o=cvCatalog.dlgTitleWarning),cv.isMobile()?i.rptDlg.showConfirm(r
):console_enabled&&window.parent.mantle_showMessage?window.parent.mantle_showMessage(
o,r):("ERROR"===t?i.rptDlg.showError(r):"WARNING"===t?i.rptDlg.showWarning(r
):i.rptDlg.showConfirm(r),i.rptDlg.noHide=!0)},isShowing(e){e=h.byId(e);
return!!e&&!(0===parseInt(e.style.width,10
)||"none"===e.style.display||"none"===p.getComputedStyle(e).display)},
_sendRequest(e,t){return D(e,t)},saveReport(t,e,i,r,o,n){if(
void 0!==n&&null!=n||(n=!1),t.modelAnnotations.length
)return t.pendingSaveParams.reportAction=e,t.pendingSaveParams.reportName=i,
t.pendingSaveParams.reportPath=r,t.pendingSaveParams.reportErrorCallback=o,
t.pendingSaveParams.suppressSuccessNotification=n,
cv.rptEditor.saveModifiedModel(),!1;console.log("now saving report");let s=!0;
var e={action:e,name:x.trim(i),path:r},i=(t.saveUIAttributes(),
t.reportDoc.getUIAttributes()),r=(i.setAttribute("showFieldList",this.isShowing(
"fieldListWrapper")?"true":"false"),i.setAttribute("showFieldLayout",
this.isShowing("layoutPanelWrapper")?"true":"false"),i.setAttribute(
"showFilterPanel","filterPane"===t.topPaneId?"true":"false"),i.setAttribute(
"fieldListView",t.manager.fieldHelp.currentView),e.reportXML=t.getReportXml(),
e.time=(new Date).getTime(),cv.contextPath+"service/ajax/saveReport"),i={},
a=_.getToken(r);return null!==a&&(i[a.header]=a.token),this._sendRequest(r,{
data:e,sync:!0,headers:i,method:"POST"}).then(e=>{e=cv.parseXML(e),
cv.setDomDefaultNamespace(e);var e=e.documentElement;"success"!==e.getAttribute(
"type")?(s=!1,"function"==typeof o?o():"object"==typeof o&&o.error()):(
t.reportDoc.replaceStorageNode(e.selectSingleNode("cv:commonStorageAttributes"))
,e=t.reportDoc.getReportProperty("name"),t.setReportName(e),document.title=e,
t.setReportPropsDirty(!1),t.history.setSaved(),
console_enabled&&window.parent.mantle_showMessage||n||cv.util.showStatus(
"successSaveReport","INFO"),"object"==typeof o&&o.success())},()=>{
cv.util.showStatus("errorSaveReport","ERROR")},()=>{}),s},updateCatalog(e,t,i,r
){let o=cv.io.getFieldHelpXml(t.catalog,t.cube,r);try{o=dojo.fromJson(o)}catch(e
){o={status:"EXCEPTION"}}if("SUCCESS"!==o.status)return e||this.showStatus(
o.message,"ERROR"),null==o.message?"":o.message;i.updateXml(o.fieldHelpXml)},
onToggleAutoRefresh(e,t,i){e&&!cv.util.isValidInteractionEvent(e)||(
e=!cv.prefs.autoRefresh,t.setAutoRefresh(e,i),e&&!t.history.isStateRefreshed(
)&&t.refreshReport(!0))},findContainingGemBar(e,t){var i=e.api.ui.listGembarIds(
);for(const n in i){var r=i[n],o=e.api.report.getLayoutFields(r);if(
-1!==s.indexOf(o,t))return r}return null},safeHtmlTemplate(e){
return e?.length?e.trim().replace(/>(?:\n\s*)?(.*?)(?:\n\s*)?<(\/?\w+)/g,
">$1<$2"):""}},cv.util.gravity.NORTH=1,cv.util.gravity.SOUTH=2,
cv.util.gravity.EAST=4,cv.util.gravity.WEST=8,e("cv.Collapsible",null,{
constructor(e,t,i,r,o){this.header=e,this.body=t,this.cssOpen=r||"folderClose",
this.cssClose=o||"folderOpen",this.isOpen=!0===i,this.setState(this.isOpen,!0),
cv.util.disableTextSelection(e),l(e,"click",a.hitch(this,"onClickHeader")),l(e,
"keydown",a.hitch(this,"onKeydownHeader"))},onClickHeader(e){
this.animation&&"playing"===this.animation.status()||(this.isOpen=!this.isOpen,
this.setState(this.isOpen,!0)),e&&e.stopPropagation()},onKeydownHeader(i){
var e=i.keyCode||i.which;if(e===cvConst.keyCodes.ARROW_DOWN){i.preventDefault();
let e;if(this.isOpen){var r=this.body["children"];for(const t of r)if(
!cv.util._isHiddenChild(t)){e=t;break}}this.header.setAttribute("tabindex","-1")
,e?(e.setAttribute("tabindex","0"),e.focus()):(
r=cv.util._findNextNonHiddenHeader(this.header.nextSibling))&&(r.setAttribute(
"tabindex","0"),r.focus())}else if(e===cvConst.keyCodes.ARROW_UP){
i.preventDefault();r=this.header["previousSibling"];if(r&&r.previousSibling){
let t;i=cv.util._findPreviousNonHiddenHeader(r);if(i.classList.contains(
"folderOpen")){var o=i.nextSibling["children"];for(let e=o.length-1;-1<e;e--)if(
!cv.util._isHiddenChild(o[e])){t=o[e];break}}this.header.setAttribute("tabindex"
,"-1"),(t?(t.setAttribute("tabindex","0"),t):(i.setAttribute("tabindex","0"),i)
).focus()}}else e===cvConst.keyCodes.ARROW_LEFT?(this.isOpen=!1,this.setState(
this.isOpen,!1)):e===cvConst.keyCodes.ARROW_RIGHT&&(this.isOpen=!0,
this.setState(this.isOpen,!0))},setState(e,t){e?(c.remove(this.header,
this.cssOpen),c.add(this.header,this.cssClose),t?(
this.body.style.display="block",this.animation=null):this.animation=g.wipeIn({
duration:cv.prefs.wipeTime,node:this.body}).play()):(c.remove(this.header,
this.cssClose),c.add(this.header,this.cssOpen),t?(this.body.style.display="none"
,this.animation=null):this.animation=g.wipeOut({duration:cv.prefs.wipeTime,
node:this.body}).play())}}),cv.Collapsible.moveFocus=(e,t)=>{var i,r;"Up"===t?(
i=cv.util._findPreviousNonHiddenSibling(e),r=e.parentNode.previousSibling,i?(
i.setAttribute("tabindex","0"),e.setAttribute("tabindex","-1"),i.focus()):r&&(
r.setAttribute("tabindex","0"),e.setAttribute("tabindex","-1"),r.focus())
):"Down"===t&&((i=cv.util._findNextNonHiddenSibling(e))?(i.setAttribute(
"tabindex","0"),e.setAttribute("tabindex","-1"),i.focus()):(
r=cv.util._findNextNonHiddenHeader(e.parentNode))&&(r.setAttribute("tabindex",
"0"),e.setAttribute("tabindex","-1"),r.focus()))},e("cv.dnd.Avatar",[A],{
constructor(e,t){this.manager=e,this.node=t},update(){}}),e("cv.dnd.Manager",[v]
,{opacity:.8,startDrag(e,t,i){!t||0===t.length||cv.util.isHiddenField(t[0]
)||cv.getActiveReport().isResizing||cv.api.event.isEventDisabled("dragAndDrop"
)||cv.getActiveReport().isEditDisabled()||this.inherited(arguments)},makeAvatar(
){var t=this.nodes[0].getAttribute("formula");let i;if(t){
i=document.createElement("DIV");let e;c.contains(this.nodes[0],"filterItem"
)||c.contains(this.nodes[0],"filterGroup")?(e="filterDragObject",0===this.nodes[
0].id.indexOf("filter_metric")?i.innerHTML=cvCatalog.filterMetric:(r=this.nodes[
0].getElementsByTagName("span"),i.innerHTML=cv.textContent(r[0])),
i.setAttribute("formula",this.nodes[0].id)):(e=cv.getFieldHelp().isAttribute(t
)?"attributeDragObject":"metricDragObject",i.innerHTML=cv.util.escapeHtml(
cv.textContent(this.nodes[0])),i.setAttribute("formula",t)),c.add(i,
"commonDragObject"),e&&c.add(i,e),this.opacity<1&&p.set(i,"opacity",this.opacity
)}else if("DB"===this.type){i=document.createElement("DIV");var r=f.position(
this.nodes[0]);p.set(i,{border:"2px dashed black",height:r.h+"px",
width:r.w+"px",backgroundColor:"silver"}),this.opacity<1&&p.set(i,"opacity",
this.opacity)}else{i=this.nodes[0].cloneNode(!0),this.dragClass&&c.add(i,
this.dragClass),this.opacity<1&&p.set(i,"opacity",this.opacity);
var t=i.tagName.toLowerCase(),r="tr"===t;if(r||"tbody"===t){var t=this.nodes[0
].ownerDocument,e=t.createElement("table"),t=((r?(t=t.createElement("tbody"),
e.appendChild(t),t):e).appendChild(i),r?i:i.firstChild),o=tdp.childNodes,
n=t.childNodes;for(let e=0;e<o.length;e++){var{[e]:s}=n;s&&s.style&&(
s.style.width=f.getContentBox(o[e]).w+"px")}i=e}}return N("ie"
)<7&&this.createIframe&&(p.set(i,{top:"0px",left:"0px"}),(
r=document.createElement("div")).appendChild(i),this.bgIframe=new w(r),
r.appendChild(this.bgIframe.iframe),i=r),i.style.zIndex=999,
i.style.position="absolute",new cv.dnd.Avatar(m._manager,i)}}),
m._manager=new cv.dnd.Manager,a.extend(y,{onClick(){d.close()}}),a.extend(E,{
_setupChild(e){this.inherited("_setupChild",arguments)}})});define("pentaho/analyzer/cv_history",["dojo/_base/declare","dijit/_Widget",
"dijit/_Templated","dojo/on","dojo/query","dojox/collections/Stack",
"dojo/_base/lang","dojo/aspect","dojo/sniff","./cv_base","./cv_util"],function(t
,e,r,i,o,n,s,a,d){return t("cv.History",null,{constructor:function(t,e,r){
this.owner=t,this.undoStack=new n,this.redoStack=new n,this.savedState=null,
this.originalState=null,this.refreshedState=new Array,e&&r&&(a.after(this,"add",
s.hitch(e,r)),a.after(this,"undo",s.hitch(e,r)),a.after(this,"redo",s.hitch(e,r)
),a.after(this,"rewindTo",s.hitch(e,r)),a.after(this,"forwardTo",s.hitch(e,r)),
a.after(this,"setTo",s.hitch(e,r)),a.after(this,"setSaved",s.hitch(e,r)),
a.after(this,"setRefreshed",s.hitch(e,r)))},add:function(t){this.endCurrent(),
t.init(this.owner),this.originalState||0!=this.undoStack.count||(
this.originalState=t),this.undoStack.push(t),this.redoStack.clear(),
cv.api.event._emitActionEvent(t)||this.undo()},current:function(){
return this.undoStack.peek()},next:function(){return this.redoStack.peek()},
undo:function(){var t;this.hasUndo()&&(this.current().setPluginDataJSON(
cv.getActiveReport().getPluginDataJSON()),t=this.undoStack.pop())&&(
this.redoStack.push(t),(
t=this.owner.mode&&"VIEW"==this.owner.mode||this.owner.manager.cmdUndo.title.indexOf(
"Column Resize")<0?this.current():t).back())},redo:function(){var t;
this.hasRedo()&&(this.current().setPluginDataJSON(cv.getActiveReport(
).getPluginDataJSON()),t=this.redoStack.pop())&&(this.undoStack.push(t),
t.forward())},rewindTo:function(t,e){for(;this.hasUndo()&&(t!=this.current(
)||null==t);)this.redoStack.push(this.undoStack.pop());return this.hasUndo()?(
e&&this.current().back(),this.current()):null},forwardTo:function(t,e){for(
;this.hasRedo()&&t!=this.next();)this.undoStack.push(this.redoStack.pop());
return this.hasRedo()?(this.undoStack.push(this.redoStack.pop()),
e&&this.current().forward(),this.current()):null},setTo:function(t){if(!t
)return!1;if(this.undoStack.contains(t))for(;t!=this.current();
)this.redoStack.push(this.undoStack.pop());else{if(!this.redoStack.contains(t)
)return!1;for(;t!=this.next();)this.undoStack.push(this.redoStack.pop());
this.undoStack.push(this.redoStack.pop())}return!0},hasUndo:function(){
return 1<this.undoStack.count},hasRedo:function(){return 0<this.redoStack.count
},setSaved:function(){this.savedState=this.current()},getSaved:function(){
return this.savedState},setRefreshed:function(t){t||(
this.refreshedState=new Array),this.refreshedState[this.refreshedState.length
]=this.current()},isStateDirty:function(){return this.savedState!=this.current()
},isStateRefreshed:function(){for(var t=0;t<this.refreshedState.length;t++)if(
this.refreshedState[t]==this.current())return!0;return!1},isEmpty:function(){
return this.undoStack.count<=1&&this.redoStack.count<=0},endCurrent:function(){
var t=this.current();t&&t.end()},
updateReportUsingPreviousChartTypeState:function(t,e){this.endCurrent();for(
var r,i=this.undoStack.toArray(),o=i.length-1;0<=o;o--)if(i[o
].customChartType==e&&"JSON"==i[o].reportTypeEnum){r=i[o];break}if(r){
t.savePluginDataToXML(r.pluginDataJSON);var n,s=cv.parseXML(r.reportXml
).documentElement,a={};dojo.isIE||(n=navigator.userAgent.toLowerCase(),
n=/(msie\s|trident.*rv:)([\w.]+)/.exec(n),dojo.isIE=n?+n[2]:void 0);for(var u=d(
"ie")||"11"==dojo.isIE?s.selectNodes(
"//columnAttributes//attribute | //rowAttributes//attribute"):s.selectNodes(
"cv:columnAttributes/cv:attribute | cv:rowAttributes/cv:attribute"),
h=0;h<u.length;h++)u[h].getAttribute("gembarId")&&(a[u[h].getAttribute("formula"
)]=[u[h].getAttribute("gembarId"),u[h].getAttribute("gembarOrdinal")]);u=d("ie"
)||"11"==dojo.isIE?s.selectNodes("//measures//measure"):s.selectNodes(
"cv:measures/cv:measure");for(h=0;h<u.length;h++)u[h].getAttribute("gembarId"
)&&(a[u[h].getAttribute("id")]=[u[h].getAttribute("gembarId"),u[h].getAttribute(
"gembarOrdinal")]);u=t.reportDoc.getChildMembers("rowAttributes",
"columnAttributes");for(h=0;h<u.length;h++)(c=a[u[h].getAttribute("formula")])?(
u[h].setAttribute("gembarId",c[0]),u[h].setAttribute("gembarOrdinal",c[1])):(u[h
].removeAttribute("gembarId"),u[h].removeAttribute("gembarOrdinal"));
u=t.reportDoc.getChildMembers(["measures"]);for(var c,h=0;h<u.length;h++
)"true"!=u[h].getAttribute("hideInChart")&&((c=a[u[h].getAttribute("id")])?(u[h
].setAttribute("gembarId",c[0]),u[h].setAttribute("gembarOrdinal",c[1])):(u[h
].removeAttribute("gembarId"),u[h].removeAttribute("gembarOrdinal")));
t.reportDoc.setReportOption("reportTypeEnum",r.reportTypeEnum),
t.reportDoc.setChartOption("chartType",r.chartType),t.reportDoc.setChartOption(
"customChartType",r.customChartType),t._clearClientViz()}}})});define("pentaho/analyzer/cv_browser",["dojo/_base/declare","dojo/dom-style",
"dojo/on","dojo/query","dojo/html","dojox/xml/parser","./cv_base","./cv_util",
"./cv_history","dojo/has","dojo/sniff","dojo/_base/lang","dojo/dnd/Manager"],
function(e,t,n,o,i,a,r,s,d,c,u,h){function l(e,t,n,o){var t=t.changedTouches,
i=t[0].clientX,t=t[0].clientY,a=document.createEvent("MouseEvent");
a.initMouseEvent(e,!0,!0,window,1,i,t,i,t,!1,!1,!1,!1,0,void 0!==o?o:null),
n.dispatchEvent(a)}var m,w;cv.setDomDefaultNamespace=function(e){
"setProperty"in e&&e.setProperty("SelectionNamespaces",
"xmlns:cv='"+cv.defaultNS+"'")},cv.parseXML=function(e){var t;return c("ie")||c(
"trident")?((t=new ActiveXObject("Microsoft.XMLDOM")).async=!1,t.loadXML(e),t
):a.parse(e)},c("ie")?(Array.prototype.indexOf||(
Array.prototype.indexOf=function(e){"use strict";if(null==this
)throw new TypeError;var t=Object(this),n=t.length>>>0;if(0!=n){var o=0;if(
0<arguments.length&&((o=Number(arguments[1]))!=o?o=0:0!==o&&o!==1/0&&o!==-1/0&&(
o=(0<o||-1)*Math.floor(Math.abs(o)))),!(n<=o))for(var i=0<=o?o:Math.max(
n-Math.abs(o),0);i<n;i++)if(i in t&&t[i]===e)return i}return-1}),
cv.textContent=function(e,t){return null==t?a.textContent(e
):1!=e.nodeType?a.textContent(e,t):void(e.text=t)},cv.createNode=function(e,t,n
){return e.createNode(1,t,n||cv.defaultNS)},cv.addOption=function(e,t){e.add(t)}
,dojo.html.BackgroundIframe=function(e){this.iframe=dojo.doc().createElement(
"<iframe src=\"javascript:'<html><head></head><body></body></html>'\" style='position: absolute; left: 0px; top: 0px; width: 100%; height: 100%;z-index: -1; filter:Alpha(Opacity=\"0\");'>"
),this.iframe.tabIndex=-1,e?(e.appendChild(this.iframe),this.domNode=e):(
dojo.body().appendChild(this.iframe),this.iframe.style.display="none")},
h.extend(dojo.html.BackgroundIframe,{iframe:null,onResized:function(){var e;
this.iframe&&this.domNode&&this.domNode.parentNode&&(0==(e=dojo.marginBox(
this.domNode)).w||0==e.h?setTimeout(h.hitch(this,this.onResized),100):(
this.iframe.style.width=e.width+"px",this.iframe.style.height=e.height+"px"))},
size:function(e){this.iframe&&(e=geometry.position(e,!0),t.set(this.iframe,{
width:e.w+"px",height:e.h+"px",left:e.l+"px",top:e.t+"px"}))},
setZIndex:function(e){this.iframe&&(dojo.dom.isNode(e
)?this.iframe.style.zIndex=dojo.style(e,"z-index")-1:isNaN(e)||(
this.iframe.style.zIndex=e))},show:function(){this.iframe&&(
this.iframe.style.display="block")},hide:function(){this.iframe&&(
this.iframe.style.display="none")},remove:function(){this.iframe&&(
this.iframe.parentNode.removeChild(this.iframe),delete this.iframe,
this.iframe=null)}}),cv.contentMinWidth=750,cv.setMinWidth=function(){
var e=dojo.window.getBox().w;e<=cv.contentMinWidth?(
document.body.style.width=cv.contentMinWidth+"px",this.xScrolling=!0):(
document.body.style.width=e+"px",this.xScrolling=!1)}):(
Element.prototype.selectNodes=function(e){var t=this.ownerDocument.evaluate(e,
this,cv.nsResolver,XPathResult.ORDERED_NODE_ITERATOR_TYPE,null),n=[];if(t)for(
var o=t.iterateNext();o;)n.push(o),o=t.iterateNext();return n},
Element.prototype.selectSingleNode=function(e){e=this.ownerDocument.evaluate(e,
this,cv.nsResolver,XPathResult.FIRST_ORDERED_NODE_TYPE,null);
return e?e.singleNodeValue:null},cv.textContent=function(e,t){
return null==t?a.textContent(e):a.textContent(e,t)},cv.createNode=function(e,t,n
){return e.createElementNS?e.createElementNS(n||cv.defaultNS,t):e.createNode(1,t
,n||cv.defaultNS)},cv.addOption=function(e,t){e.appendChild(t)}),
cv.isMobile=function(){return cv.isMobileSafari()||void 0!==window.orientation},
cv.isMobileSafari=function(){return null!=navigator.userAgent.match(
/(iPad|iPod|iPhone)/)},cv.isMobile()&&(window.touchstartTime=0,
window.lastTouchstartTime=0,window.hasMoved=!1,m=function(e){try{if(
1<e.touches.length||1<e.changedTouches.length)window.contextMenuInPlay=!1;else{
var t=ManagerClass.manager(),n=e.changedTouches[0].target;if(
"INPUT"!=n.nodeName&&"BUTTON"!=n.nodeName&&"TEXTAREA"!=n.nodeName){
var o=e.changedTouches,i=o[0].screenX,a=o[0].screenY;switch(e.type){
case"touchstart":(new Date).getTime()-window.lastTouchstartTime<350?(l(
"dblclick",e,n),e.preventDefault(),window.hasMoved=!0):(
window.contextMenuInPlay=!0,window.touchstartTime=(new Date).getTime(),
window.touchstartX=e.changedTouches[0].screenX,
window.touchstartY=e.changedTouches[0].screenY,window.lastMoveEvent=e,
window.lastTouchstartTime=window.touchstartTime,l("mouseover",e,
window.lastOver=n),l("mousedown",e,n),e.preventDefault());break;case"touchmove":
window.hasMoved=!0,window.lastMoveEvent=e,
!t.source&&1!=e.touches.length||e.preventDefault(),l("mousemove",e,
n=document.elementFromPoint(i-cv.getOriginAdjustment().x,
a-cv.getOriginAdjustment().y)),window.lastOver&&n!=window.lastOver&&l("mouseout"
,e,window.lastOver,n),l("mouseover",e,n,window.lastOver),window.lastOver=n;break
case"touchend":
0<e.touches||!window.contextMenuInPlay||window.lastWasMultiTouch||((
!window.hasMoved||Math.abs(window.lastMoveEvent.changedTouches[0
].screenX-window.touchstartX)<10&&Math.abs(window.lastMoveEvent.changedTouches[0
].screenY-window.touchstartY)<10)&&200<(new Date).getTime(
)-window.touchstartTime?(l("contextmenu",e,n),e.preventDefault()):(l("mouseup",e
,computedTarget=document.elementFromPoint(i-cv.getOriginAdjustment().x,
a-cv.getOriginAdjustment().y)),l("click",e,computedTarget),n!=computedTarget&&(
l("mouseup",e,n),l("click",e,n))),window.lastOver&&l("mouseout",e,
window.lastOver,n),window.hasMoved=!1,window.lastMoveEvent=null);break;default:
return}}}}catch(e){console.log("error in touch handler: "+e)}},
document.addEventListener("touchstart",m,!0),document.addEventListener(
"touchmove",m,!0),document.addEventListener("touchend",m,!0),
cv.getOriginAdjustment=(window.addEventListener("orientationchange",function(){
w=null}),function(){return window.inMobile?w=w||getMyOriginOffset():{x:0,y:0}}))
});define("pentaho/analyzer/cv_dlg",["dojo/_base/declare","dojo/_base/lang",
"dojo/aspect","dojo/on","dojo/query","dijit/Dialog","dojox/fx","dojo/dom",
"dojo/dom-attr","dojo/dom-class","dojo/dom-style","dojo/request",
"dijit/registry","dojo/dom-geometry","common-ui/util/_a11y",
"common-ui/util/_focus","./cv_base","./cv_util","./cv_history","./cv_browser"],(
t,g,i,c,s,e,o,u,l,n,r,a,h,d,p,v)=>{cv.Dialog=function(){this.theForm=null,
this.type=null,this.dlgTemplate=null,this.prefix=null,this.cache={},
this.status=null,this.helpTopic=null,this.lastSaveTime=null,this.isShowing=!1,
this.defaultFocus=null,this._parentReport=null,this._widgetCss=null,
this._handles=cv.util.createCompositeHandle(),this._dialogId="theDialog",
this._dialogFormId="theDialogForm",this._dialogBannerId="dialogMessageBar"},
cv.Dialog.prototype={set dlgWidget(t){cv.dlgWidget=t},get dlgWidget(){
return cv.dlgWidget},show:null,save:null,prev:null,cancel(){this._hide().then((
)=>{null!=this._parentReport&&this._parentReport.refreshReport()})},next(){
this.save()},onSave(){var t=new Date;
this.lastSaveTime&&t-this.lastSaveTime<1e3||(this.save(),this.lastSaveTime=t)},
showError(t,e,i){return this.msgClass="error",this._showAlert(t,e).then(()=>{
i&&(u.byId("dlgTitle").innerText=i)})},showWarning(t,e,i,s,o,l,r){
return this.msgClass="warn",this._parentReport=l,this._showAlert(t,e,i,s,o,r)},
showConfirm(t,e,i,s,o){return this.msgClass="info",this._showAlert(t,e,i,s,o)},
_showAlert(t,e,i,s,o,l){t=this.__showAlert.bind(this,t,e,i,s,o,l);
return this._hide().then(t,t)},__showAlert(t,e,i,s,o,l){this.type="alertDlg",
this._widgetCss="responsive dw-sm dmh-content",this.dlgTemplate="alertDlg.html",
this._alertCallbacks={onOK:null!=i,onCancel:null!=s};
let r=`<span class="alertMsgIcon ${this.msgClass}"></span><div class="alertMsgText">`
if("string"==typeof t)cvCatalog[t]?r+=cvCatalog[t]:r+=t;else{if(!dojo.isArray(t)
)return;var[t,...a]=t;r+=cv.util.substituteParams.apply(this,[cvCatalog[t],...a]
)}if(r+="</div>",this.load(r)){t=u.byId("dlgHelp");t&&(e?(cv.util.setHelpTopics(
["dlgHelp",e]),cv.util.show(t),t.title=cvCatalog.btnTitleHelp):cv.util.hide(t));
const n=u.byId("alertDlgSuppressMsg");o?(cv.util.show(n.parentNode),n.onchange=(
)=>{cv.prefs.suppressMsg[o]=n.checked}):cv.util.hide(n.parentNode);a=u.byId(
"alertDlgOptionMsg"),e=(l?(u.byId("alertDlgOptionText").innerHTML=cvCatalog[l],
cv.util.show(a.parentNode)):cv.util.hide(a.parentNode),u.byId("dlgBtnSave")),
t=u.byId("dlgBtnCancel");if(i){var{srcObj:l,srcFunc:a}=i;const h=l?g.hitch(l,a
):a;c(e,"click",()=>this._hide().then(h,h)),"onSaveReport"===a&&(
e.innerHTML=cvCatalog.btnLabelSave),cv.util.show(e),
t.innerHTML=cvCatalog.btnLabelCancel}if(s){var{srcObj:i,srcFunc:l}=s;
const d=i?g.hitch(i,l):l;c(t,"click",()=>this._hide().then(d,d))}
this.showDialog()}},_centerDialog(){var t,e=u.byId("borderContainer");e&&(
e=d.position(e,!0),t=d.position(this.dlgWidget.domNode,!0),r.set(
this.dlgWidget.domNode,{top:Math.floor((e.h-t.h)/2)+"px",left:Math.floor((
e.w-t.w)/2)+"px"}))},_onHide(){this._destroyDisplay(),
this.report.banner.destroy(),null!=this._widgetCss&&n.remove(
this.dlgWidget.domNode,this._widgetCss)},_hide(){
var t=this.dlgWidget&&this.dlgWidget.hide();return null!=t?t:Promise.resolve()},
_onShow(){null!=this._widgetCss&&n.add(this.dlgWidget.domNode,this._widgetCss),
this.report.banner.show()},_show(){var t=this.dlgWidget&&this.dlgWidget.show();
return null!=t?t:Promise.resolve()},showDialog(){var t;
this.dlgWidget.animationInProgress&&this.dlgWidget.isShowing()?setTimeout(
this.showDialog.bind(this),250):(this.dlgWidget.setDialogOpener(
cv.util.getRestoreFocus()),t=v.suspendFocusRing({isAuto:!1}),this._show().then(t
,t),this._centerDialog(),this.isShowing=!0)},displayMsg(t,e){
this.report.banner.displayMsg(t,e)},displayInfo(t){
this.report.banner.displayInfo(t)},displayWarn(t){
this.report.banner.displayWarn(t)},displayError(t){
this.report.banner.displayError(t)},byId(t){return"string"==typeof t?u.byId(
this.prefix+t):u.byId(t)},_createDojoDialog(){var t=cv.util.getDojoWidget(
this._dialogId);return t.setElementRefresher(t=>v.refreshElement(t)),t},
_initDialogWidget(t){let e=this.dlgWidget;null==e&&(e=this._createDojoDialog(),
this.dlgWidget=e),this._destroyDisplay(),this._own(i.before(e,"onShow",
this._onShow.bind(this)),i.after(e,"onHide",this._onHide.bind(this)));
t=`<form id='${this._dialogFormId}' action='' onsubmit='return false'>${t}</form>`
,e.setContent(t),this.theForm=u.byId(this._dialogFormId),t=u.byId(
this._dialogBannerId);t&&(this.report.banner.node=t,this.report.banner.hide())},
_own(...t){return this._handles.add(...t),this},_destroyDisplay(){
this._handles.remove()},_loadTemplate(){this.cache[this.type]||a(
cv.contextPath+"service/templates/"+this.dlgTemplate,{method:"POST",
handleAs:"text",sync:!0}).then(t=>{cv.util.parseAjaxMsg(t
)?this.status="errorDlgLoad":this.cache[this.type]=t},()=>{
this.status="errorDlgLoad"})},load(...t){var e;return this._loadTemplate(),
null==this.status&&(e=this.cache[this.type],
t=0<t.length?cv.util.substituteParams(e,t):e,this._initDialogWidget(t),
this._own(c(this.theForm,"keydown",this._onFormKeyDown.bind(this))),
this.titleBar=this.dlgWidget.titleBar,this._own(c(this.titleBar,"mousedown",
this.onDragStart.bind(this)),c(document,"mouseup",this.onDragEnd.bind(this))),(
e=u.byId("dlgBtnSave"))&&"alertDlg"!==this.type&&this._own(c(e,"click",
this.onSave.bind(this))),(t=u.byId("dlgBtnNext"))&&this._own(c(t,"click",
this.next.bind(this))),(e=u.byId("dlgHelp"))&&(this.helpTopic?(this._own(c(e,
"click",this.showHelpWnd.bind(this)),p.makeAccessibleActionButton(e)),
e.title=cvCatalog.btnTitleHelp,cv.util.show(e)):cv.util.hide(e)),(t=u.byId(
"dlgHelpText"))&&(this.helpTopic?(this._own(c(t,"click",this.showHelpWnd.bind(
this)),p.makeAccessibleActionButton(t)),t.title=cvCatalog.btnTitleHelp,
cv.util.show(t)):cv.util.hide(t)),(e=u.byId("dlgBtnCancel"))&&this._own(c(e,
"click",this.cancel.bind(this))),(t=u.byId("dialogTitleBar"))&&this._own(c(t,
"mousedown",this.onDragStart.bind(this))),!0)},updateHtml(t,e){let i=this.byId(t
);!i&&0<(i=this.theForm[this.prefix+t])?.length&&"radio"===i[0
].type?this._updateRadioHtml(i,e):i&&(
"INPUT"===i.tagName||"SELECT"===i.tagName?"checkbox"===i.type?i.checked="true"===e:i.value=e:i.innerHTML=e
)},_updateRadioHtml(t,e){for(const i of t)i.value===e&&(i.checked=!0)},
updateXml(t,e){var i;t&&(i=this._attributeName(e.id))&&t.setAttribute(i,
this._getSrcValue(e))},_attributeName(t){return t.substr(t.indexOf(this.prefix
)+this.prefix.length)},_getSrcValue(t){
return"checkbox"===t.type?t.checked?"true":"false":t.value},getRadioGroupValue(t
){for(const e of this.theForm[t])if(e.checked)return e.value;return null},
showHelpWnd(t){var e=t.target["id"];cv.util.getHelp(
"dlgHelp"===e||"dlgHelpText"===e?this.helpTopic:t)},_onFormKeyDown(t){
var e=t.target;switch(t.code){case"Enter":e.matches(
"select, input:not([type='button'], [type='submit'])")&&t.preventDefault();break
case"Backspace":e.matches("input, textarea")||t.preventDefault()}},onDragStart(t
){var e=this.dlgWidget["domNode"];this.currentPos=d.position(e),this.cursorPos={
x:t.pageX,y:t.pageY},this.mouseMoveHandle=c(document,"mousemove",
this.onDragMove.bind(this))},onDragEnd(){this.mouseMoveHandle&&(
this.mouseMoveHandle.remove(),this.mouseMoveHandle=null)},onDragMove(t){
var e=this.currentPos.x+t.pageX-this.cursorPos.x,
i=this.currentPos.y+t.pageY-this.cursorPos.y,s=dojo.window.getBox();
e<s.w-100&&20<e&&(this.currentPos.x=e,this.cursorPos.x=t.pageX),
i<s.h-100&&20<i&&(this.currentPos.y=i,this.cursorPos.y=t.pageY),r.set(
this.dlgWidget.domNode,{left:this.currentPos.x+"px",top:this.currentPos.y+"px"})
},setInvalidInputField(t){this.invalidInputField&&n.remove(
this.invalidInputField,"invalid"),this.invalidInputField=t?u.byId(t):null,
this.invalidInputField&&n.add(this.invalidInputField,"invalid")},
trackFormChange(){u.byId("dlgBtnSave").setAttribute("disabled","");for(
const i of this.report.rptDlg.theForm.elements)if(!("false"===l.get(i,
"track-form-change"))||"dlgBtnCancel"!==i.id){let t="change";
var e=i.getAttribute("type");
"text"===e||"TEXTAREA"===i.tagName?t="keyup":"button"!==e&&"BUTTON"!==i.tagName||(
t="click"),c(i,t,this.enableOkButton)}s(".dijitComboBox",this.theForm).forEach(
t=>{t=h.byNode(t);if(t){const e=t.get("value");t.on("change",t=>{
t!==e&&this.enableOkButton()})}})},enableOkButton(){u.byId("dlgBtnSave"
).removeAttribute("disabled")},setTextAndTitle(t,e){this.byId(t).innerText=e,
this.byId(t).title=e},destroy(){this._destroyDisplay()},_resetToDefault(t){
this.report.getOptions(t)},_resetUpdateOptions(t,e){var i=t.getChartOptions(
).attributes;if(i&&("ALL"===e||"CHART"===e))for(let t=0,e=i.length;t<e;t++){
var s=i[t];this.updateHtml(s.name,s.value)}var o=t.getReportOptions();if(o&&(
"ALL"===e||"REPORT"===e))for(let t=0,e=o.length;t<e;t++){var l=o[t];
this.updateHtml(l.name,l.value)}t=t.getDrillColumns();if(t&&(
"ALL"===e||"DRILL"===e)){var r={};for(const a of t)r[a.innerHTML]=!0;
cv.getActiveReport().drillDlg.fieldHelp.resetToDefaultDrillFields(r)}n.remove(
this.dlgWidget.domNode,"resetting-to-default")}},t("cv.Dialog",cv.Dialog)});define("pentaho/analyzer/TabPanel",["dojo/_base/declare","dojo/on","dojo/query",
"dojo/_base/lang","dojo/dom-class","dijit/layout/TabContainer"],function(e,t,o,d
,n,a){return e("analyzer.TabPanel",[a],{_transition:function(e,t){n.add(
e.controlButton.domNode,"pentaho-tabWidget-selected"),n.remove(
t.controlButton.domNode,"pentaho-tabWidget-selected"),this.inherited(arguments)
},startup:function(){this._started||(this.inherited(arguments),n.add(
this.selectedChildWidget.controlButton.domNode,"pentaho-tabWidget-selected"))}})
});define("pentaho/analyzer/cv_tooltip",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dijit/Tooltip","dojo/dom-class","dijit/place",
"dojo/_base/array","dojo/topic","dojo/dom-style","dojo/html","dojo/dom",
"dojo/dnd/Manager","dojo/dom-geometry"],function(o,t,e,i,s,d,n,h,a,l,c,r,m,p){
var u=m.manager(),m=o("clearview.widget.CVTooltip",[s],{addConnectNode:function(
o,e){this.own(t(o,"mousemove",i.hitch(this,"mouseMove"))),this.addTarget(o)},
startup:function(){d.add(this.domNode,"cvTooltip"),a.subscribe("/dnd/start",
i.hitch(this,"close"))},mouseMove:function(o){this._mouse={x:o.pageX,y:o.pageY};
var e=o.target;this._connectNode=e,cv.formatTooltip?(cv.formatTooltip(
this.domNode,e),this.cancelShowing=!1
):this.domNode.innerHTML="Tooltip has not been initialized for this element",
"none"!=this.domNode.style.display&&this._connectNode!=this._lastTarget&&(
this.close(),this._onHover(o)),this._lastTarget=o.target},close:function(){
this.inherited(arguments),this.domNode.style.display="none"},
uninitialize:function(){this.close()},_onUnHover:function(o){
cv.util.overElement(this.domNode,o)?this.outHandle=t(this.domNode,"mouseout",
i.hitch(this,"closeDelayedTip")):(this.close(),this.domNode.style.display="none"
)},closeDelayedTip:function(o){pos=p.position(this.domNode,!0);var e=o.pageX,
t=o.pageY;(e>=pos.x+pos.w||e<=pos.x||t>=pos.y+pos.h||t<=pos.y)&&(
this._onUnHover(o),this.outHandle.remove())},open:function(o){var e,t;
u.source||(e=this._mouse.x+15,t=this._mouse.y-10,this.domNode.style.display="",
n.at(this.domNode,{x:e,y:t},["TL","TR","BL","BR"],{x:10,y:5}))}});return o(
"clearview.widget.CVTooltipRefresh",[s],{open:function(o){this._showTimer&&(
this._showTimer.remove(),delete this._showTimer),l.set(this.domNode,"display",
"block"),this._connectNode=o,n.around(this.domNode,o,["below"],!0)},
close:function(){this._connectNode&&(l.set(this.domNode,"display","none"),
delete this._connectNode),this._showTimer&&(this._showTimer.remove(),
delete this._showTimer)}}),m});define("pentaho/analyzer/common",["./cv_api","./cv_base","./cv_util",
"./cv_history","./cv_browser","./cv_dlg","./TabPanel","./cv_tooltip",
"dijit/layout/BorderContainer","dijit/layout/ContentPane",
"pentaho/common/Overrides"],function(){});define("pentaho/analyzer/report/cv_rptConst",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","../common"],(t,e,i,a)=>{var l=cvConst["dndTypes"
];return a.mixin(cvConst,{MAX_FILTER_EXPRESSIONS:10,dndAcceptedTypes:{report:[
l.gemFromFieldList,l.gemFromLayoutPanel,l.gemFromReportArea],trashcan:[
l.gemFromLayoutPanel,l.gemFromReportArea]},keyCodes:{BACKSPACE:8,TAB:9,ENTER:13,
SHIFT:16,ESCAPE:27,SPACE:32,PAGE_UP:33,PAGE_DOWN:34,END:35,HOME:36,
ARROW_LEFT:37,ARROW_UP:38,ARROW_RIGHT:39,ARROW_DOWN:40,DELETE:46},
TYPE_ATTRIBUTE:0,TYPE_METRIC:1,TYPE_FILTER:4,defaultGemTypes:{rowAttributes:0,
columnAttributes:0,measures:1,filters:4},
defaultFormatExp:"Case\nWhen [Measures].CurrentMember > 0\nThen '|#,##0|arrow=up'\nWhen [Measures].CurrentMember < 0\nThen '|#,##0|arrow=down'\nElse '|#,##0'\nEnd"
}),a.mixin(cv.prefs,{chartOption:"VERTICAL_BAR",autoRefresh:!0,
manyReportItems:8e3,maxReportItems:15e3,maxFilterValues:3e3,numProgressImg:1,
fieldListView:"CMDVIEWCATEGORY"}),cv.pentahoVisualizations=[],
cv.pentahoVisualizationHelpers={},a.mixin(cvCatalog,{
emptyReportAreaHTML:cv.util.safeHtmlTemplate(
`
      <div class="reportEmpty">
        %{3}<br><br>
        <div class="viz-image %{2}"><img src="%{4}" alt=""></div>
        <br>%{1}<br>
        <div style="padding-top: 5px; font-size: 0.7em;">${cvCatalog.emptyVizHelp}</div>
        <div id="help-footer" class="button-panel contrast-background pentaho-bottom-bar contrast-color"
             style="font-size: .7em; left: 0; position: absolute; bottom: 0; width: 100%;">
          <div style="float: right; padding: 6px 10px;">
            ${cvCatalog.reportHelpGettingStarted}
            <button id="%{0}GettingStarted" class="pentaho-button" style="margin-left: 10px;">
              ${cvCatalog.btnReportHelp}
            </button>
          </div>
        </div>
      </div>`),filterTemplateSingleLine:cv.util.safeHtmlTemplate(`
      <div id="%{1}" class="filterItem" formula="%{0}">
        <div class="filterIndent">
          <i id="remove_%{1}" title="${cvCatalog.ttRemoveFilder}"
             class="filterAction pentaho-deletebutton remove-filter-button icon-zoomable"></i>
          <i id="edit_%{1}" title="${cvCatalog.ttEditFilder}"
             class="filterAction EDIT_Only pentaho-editbutton edit-filter-button icon-zoomable"></i>
          &nbsp;
        </div>
        <div style="float:left;"><span><b>%{2}</b>&nbsp;%{3}</span></div>
        <div>
          <i id="prefilter_%{0}" title="${cvCatalog.ttPreFilter}"
             class="pentaho-prefilterbutton icon-zoomable hidden"></i>
        </div>
        <i class="lockImg" title="${cvCatalog.ttFilterLocked}"></i>
      </div>`),filterTemplateMultiLine:cv.util.safeHtmlTemplate(`
      <div class="filterItem filterLine">
        <div class="filterIndent">&nbsp;</div>
        <span><b>%{0}</b> ${cvCatalog.filterTemplateMultilineRestricted}</span>
        <i class="lockImg" title="${cvCatalog.ttFilterLocked}"></i>
      </div>`),filterTemplateAttr:cv.util.safeHtmlTemplate(`
      <div id="%{1}" class="filterItem" formula="%{0}">
        <div class="filterIndent2">
          <i id="remove_%{1}" title="${cvCatalog.ttRemoveFilder}"
             class="filterAction pentaho-deletebutton remove-filter-button icon-zoomable"></i>
          <i id="edit_%{1}" title="${cvCatalog.ttEditFilder}"
             class="filterAction EDIT_Only pentaho-editbutton edit-filter-button icon-zoomable"></i>
          &nbsp;
        </div>
        <div style="float:left;"><span>%{2}</span></div>
        <div>
          <i id="prefilter_%{0}" title="${cvCatalog.ttPreFilter}"
             class="pentaho-prefilterbutton icon-zoomable hidden"></i>
        </div>
      </div>`),filterTemplateSelection:cv.util.safeHtmlTemplate(`
      <div id="filter_selection" class="filterGroup">
        <div id="filter_selection_1" class="filterItem">
          <div class="filterIndent">
            <i title="${cvCatalog.ttRemoveFilder}"
               class="filterAction pentaho-deletebutton remove-filter-button icon-zoomable"></i>
            &nbsp;
          </div>
          <span>
            ${cvCatalog.filterSummarySelectionItems} (
            <a href="javascript:cv.getActiveReport().filterDlg.showSelectionFilter('INCLUDE')">
              ${cvCatalog.btnSelectionKeepOnly}
            </a> | <a href="javascript:cv.getActiveReport().filterDlg.showSelectionFilter('EXCLUDE')">
              ${cvCatalog.btnSelectionExclude}
            </a>)
          </span>
        </div>
      </div>`),filterTemplateMetric:cv.util.safeHtmlTemplate(`
      <div id="filter_metric_0" class="filterItem" formula="%{0}">
        <div class="filterIndent">
          <i id="remove_filter_metric" title="${cvCatalog.ttRemoveFilder}"
             class="pentaho-deletebutton remove-filter-button icon-zoomable"></i>
          <i id="edit_filter_metric" title="${cvCatalog.ttEditFilder}"
             class="EDIT_Only pentaho-editbutton edit-filter-button icon-zoomable"></i>
          &nbsp;
        </div>
        <div style="float:left;">%{1}</div>
        <div>
          <i id="prefilter_metric_%{0}" title="${cvCatalog.ttPreFilter}"
             class="pentaho-prefilterbutton icon-zoomable hidden"></i>
        </div>
      </div>`),filterConditionEdit:cv.util.safeHtmlTemplate(
`
      <td>
        <select id="FT_condMetric" class="height-auto"></select>
      </td>
      <td>
        <select id="FT_condOp" class="height-auto">
          <option value="GREATER_THAN" selected>%{GT}</option>
          <option value="LESS_THAN">%{LT}</option>
          <option value="GREATER_THAN_EQUAL">%{GTE}</option>
          <option value="LESS_THAN_EQUAL">%{LTE}</option>
          <option value="EQUAL">%{E}</option>
          <option value="NOT_EQUAL">%{NE}</option>
          <option value="BETWEEN">%{B}</option>
          <option value="IS_NOT_EMPTY">%{NN}</option>
        </select>
      </td>
      <td>
        <input id="FT_condOp1" type="text" class="inputNum">
        <span>and <input id="FT_condOp2" type="text" class="inputNum"></span>
      </td>
      <td class="filterConditionActions">
        <div class="flex-row">
          <input type="button" class="filterConditionEdit" title="${cvCatalog.ttEditCondition}">
          <input type="button" class="filterConditionDelete" title="${cvCatalog.ttDeleteCondition}">
        </div>
      </td>`),filterConditionStatic:cv.util.safeHtmlTemplate(
`
      <td>%{metric}</td>
      <td>%{op}</td>
      <td>
        <span>%{op1}</span>
        <span class="%{op2Css}"> and <span>%{op2}</span>
        </span>
      </td>
      <td class="filterConditionActions">
        <div class="flex-row">
          <input type="button" class="filterConditionEdit" title="${cvCatalog.ttEditCondition}">
          <input type="button" class="filterConditionDelete" title="${cvCatalog.ttDeleteCondition}">
        </div>
      </td>`),reportNoDataMsgHTML:cv.util.safeHtmlTemplate(`
      <div class="noData">
        <span class="noDataHeader">%{0}</span>
        <span class="noDataHint">${cv.util.substituteParams(
cvCatalog.filterNoData,{FIELDS:cv.util.substituteParams(
"<a class='appCmdLink' href='javascript:cv.getActiveReport().manager.toggleReportPane(\"cmdLayout\")'>%{0}</a>"
,cvCatalog["filterNoData.Fields"]),FILTERS:cv.util.substituteParams(
"<a class='appCmdLink' href='javascript:cv.getActiveReport().manager.toggleReportPane(\"cmdFilters\")'>%{0}</a>"
,cvCatalog["filterNoData.Filters"]),VIEW_HELP:cv.util.substituteParams(
"<a class='appCmdLink helpLinkReportNoData'>%{0}</a>",cvCatalog[
"filterNoData.ViewHelp"]),UNDO:cv.util.substituteParams(
"<a class='appCmdLink' href='javascript:cv.getActiveReport().history.undo()'>%{0}</a>"
,cvCatalog["filterNoData.Undo"])})}</span>
      </div>`),transformationReportNoDataMsgHTML:cv.util.safeHtmlTemplate(
`
      <div class="noData">
        <span class="noDataHeader">%{0}</span>
        <span class="noDataHint">${cvCatalog.transformationReportFieldsNoData}</span>
      </div>`),
reportSuccessMsgHTML:'<div class="noData"><span class="noDataHeader">%{0}</span></div>',
reportSuccessMsgChartHTML:cv.util.safeHtmlTemplate(`
      <div class="noData">
        <i class="icon-report-abstract"></i>
        <br>
        <div class="noDataHeader">%{0}</div>
      </div>`),
refreshPanelCancel:'<div class="refreshPaneCanceledMode">%{0}</div>',
refreshPanelComplete:'<div class="refreshPaneComplete">&nbsp;&nbsp;%{0}&nbsp;</div>'
}),t([])});define("pentaho/analyzer/report/cv_rptIO",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dojox/xml/parser","./cv_rptConst","dojo/request"
,"dojo/html","dojo/dom","dojo/json","pentaho/csrf/service"],(e,t,s,n,r,a,i,o,c,d
,m)=>{cv.io={maxConnectionTries:3,initAsyncRequestCount:0,ajaxLoad(e,t,s,r,a){
let n=null;t.time=(new Date).getTime();var e=cv.contextPath+e,o={};if(
a&&null!==(a=m.getToken(e))&&(o[a.header]=a.token),i(e,{data:t,sync:s,headers:o,
method:"POST"}).then(e=>{s?n=e:r&&r(e)},e=>{},e=>{}),s)return n},
initAsyncRequest(e,t){return null==e.prevId&&(e.prevId=""),this.ajaxLoad(
"service/ajax/initRequest",e,!1,t)},cancelAsyncRequest(e){e&&this.ajaxLoad(
"service/ajax/cancelRequest",{requestId:e},!1)},_sendRequest(e,t){return i(e,t)
},getOptions(t,s,e,r){this._sendRequest("service/ajax/getOptions",{data:{time:(
new Date).getTime(),catalog:e,cube:r},sync:!1,method:"POST"}).then(e=>{
t.showResetOptions(e,s)},e=>{t.handleReportMsg({type:"exception",
details:d.stringify({name:e.name,message:e.message,fileName:e.fileName})})},(
)=>{})},removeOptions(t,e,s,r){this._sendRequest("service/ajax/removeOptions",{
data:{time:(new Date).getTime(),catalog:s,cube:r},sync:!1,method:"POST"}).then(
e=>{e=cv.util.parseAjaxMsg(e);t.handleReportMsg(e)},e=>{t.handleReportMsg({
type:"exception",details:d.stringify({name:e.name,message:e.message,
fileName:e.fileName})})},()=>{})},setOptions(t,e){this._sendRequest(
"service/ajax/setOptions",{data:{reportXML:t.getReportXml(),time:(new Date
).getTime(),type:e},sync:!1,method:"POST"}).then(e=>{e=cv.util.parseAjaxMsg(e);
t.handleReportMsg(e)},e=>{t.handleReportMsg({type:"exception",
details:d.stringify({name:e.name,message:e.message,fileName:e.fileName})})},(
)=>{})},refreshReport(t){const s=(new Date).getTime(),r=(t.showProgressPane(),
t.refreshRequest&&t.refreshRequest.cancel(),t.refreshRequestErrorCounter=0,
this.initAsyncRequestCount++,this.initAsyncRequestCount);
var a=this.initAsyncRequest({reportXML:t.getReportXml(),
prevId:t.refreshRequestId,format:"HTML",action:"REFRESH",dirtyFlag:t.isDirty(),
annotations:t.getModelAnnotationsJson()},e=>{
return cv.io.initAsyncRequestCount>r?(-1!==e.indexOf("LECRYPTO:"
)&&cv.io.cancelAsyncRequest(e),!0):e?(e=t.handleReportMsg(e)
)&&s>=t.refreshTimeStamp?(t.refreshRequestId=e.text,t.refreshTimeStamp=s,
t.refreshPreFilters(),cv.io.getReportHTML(t),!0):void 0:(t.handleReportMsg({
type:"exception",initId:a}),!0)});return!1},getReportHTML(s,r,e){if(
s.refreshRequestId&&(!r||r==s.refreshRequestId)){r=r||s.refreshRequestId,
s.refreshRequest&&(s.refreshRequest.cancel(),s.refreshRequest=null);const a=this
s.refreshRequest=i("service/ajax/getReportHTML",{data:{requestId:r,
timeout:e=e||3,reportViewWidth:s.reportWidth,reportViewHeight:s.reportHeight,
time:(new Date).getTime(),sessionLocale:SESSION_LOCALE},sync:!1,method:"POST"}),
s.refreshRequest.then(e=>{let t=!0;e&&(t=!1,s.loadReportHTML(e)),t&&setTimeout(
n.hitch(a,"getReportHTML",s,r,1),3e3)},e=>{a._retryConnection(e,
s.refreshRequestErrorCounter)?s.refreshRequestErrorCounter++:(
"xhr cancelled"!==e.message&&"Request canceled"!==e.message&&s.handleReportMsg({
type:"exception",details:d.stringify({name:e.name,message:e.message,
fileName:e.fileName})}),retry=!1)},e=>{})}},getReportInFormat(e,t){
e.showProgressDownloadPane();var s=e.getReportXml();this.initAsyncRequest({
reportXML:s,action:"REFRESH",format:t,dirtyFlag:e.isDirty(),prevId:"",
annotations:e.getModelAnnotationsJson()},e=>{e&&(
e=`service/ajax/getReportInFormat?requestId=${e}&forceAttachment=true&format=`+t
,c.byId("downloadIframe").setAttribute("src",e))})},_retryConnection(e,t){if(
t<this.maxConnectionTries&&e&&e.message){e=e.message;
t=/XMLHttpTransport\sError:\s(12\d\d\d)/.exec(e);if(t&&t[1])switch(t[1]){
case"12002":case"12029":case"12030":case"12031":case"12152":return!0}}return!1},
getFieldHelpXml(e,t,s){var r={};return r.catalog=e,r.cube=t,r.annotations=s,
this.ajaxLoad("service/modeling/getFieldHelp",r,!0)},getOptionsSync(e,t){e={
time:(new Date).getTime(),catalog:e,cube:t};return this.ajaxLoad(
"service/ajax/getOptions",e,!0)}}});define("dojox/mvc/StatefulArray",["dojo/_base/lang","dojo/Stateful"],function(r,
i){function e(t){return t._watchElementCallbacks&&t._watchElementCallbacks(
void 0,[],[]),t}function h(t){return(t=r._toArray(t||[])).constructor=h,r.mixin(
t,{pop:function(){return this.splice(this.get("length")-1,1)[0]},push:function(
){return this.splice.apply(this,[this.get("length"),0].concat(r._toArray(
arguments))),this.get("length")},reverse:function(){return e([].reverse.apply(
this,r._toArray(arguments)))},shift:function(){return this.splice(0,1)[0]},
sort:function(){return e([].sort.apply(this,r._toArray(arguments)))},
splice:function(t,e){var n=this.get("length"),i=(t+=t<0?n:0,Math.min(t,n)),
s=this.slice(t,t+e),h=r._toArray(arguments).slice(2);[].splice.apply(this,[t,e
].concat(new Array(h.length)));for(var l=0;l<h.length;l++)this[i+l]=h[l];
return this._watchElementCallbacks&&this._watchElementCallbacks(t,s,h),
this._watchCallbacks&&this._watchCallbacks("length",n,n-s.length+h.length),s},
unshift:function(){return this.splice.apply(this,[0,0].concat(r._toArray(
arguments))),this.get("length")},concat:function(t){return new h([
].concat.apply(this,arguments))},join:function(t){for(var e=[],n=this.get(
"length"),i=0;i<n;i++)e.push(this.get(i));return e.join(t)},slice:function(t,e){
for(var n=this.get("length"),i=(e=(void 0===e?n:e)+(e<0?n:0),[]),s=(t+=t<0?n:0
)||0;s<Math.min(e,this.get("length"));s++)i.push(this.get(s));return new h(i)},
watchElements:function(n){var h=this._watchElementCallbacks,l=this,t=(h||((
h=this._watchElementCallbacks=function(t,e,n){for(var i=[].concat(h.list),
s=0;s<i.length;s++)i[s].call(l,t,e,n)}).list=[]),h.list.push(n),{});
return t.unwatch=t.remove=function(){for(var t=h.list,e=0;e<t.length;e++)if(t[e
]==n){t.splice(e,1);break}},t}},i.prototype,{set:function(t,e){var n;
return"length"==t?(n=this.get("length"))<e?this.splice.apply(this,[n,0].concat(
new Array(e-n))):e<n&&this.splice.apply(this,[e,n-e]):(n=this.length,
i.prototype.set.call(this,t,e),n!=this.length&&i.prototype.set.call(this,
"length",this.length)),this},isInstanceOf:function(t){
return i.prototype.isInstanceOf.apply(this,arguments)||t==h}})}return h._meta={
bases:[i]},r.setObject("dojox.mvc.StatefulArray",h)});define("dojox/mvc/equals",["dojo/_base/array","dojo/_base/lang","dojo/Stateful",
"./StatefulArray"],function(e,r,a,t){var u=function(e,t,n){var n=n||u,r=[
n.getType(e),n.getType(t)];return r[0]==r[1]&&n["equals"+r[0].replace(/^[a-z]/,
function(e){return e.toUpperCase()})](e,t)};return r.setObject(
"dojox.mvc.equals",r.mixin(u,{getType:function(e){return r.isArray(e
)?"array":r.isFunction((e||{}).getTime)?"date":null!=e&&(
"[object Object]"=={}.toString.call(e)||r.isFunction((e||{}).set)&&r.isFunction(
(e||{}).watch))?"object":"value"},equalsArray:function(e,t){for(var n=0,
r=Math.max(e.length,t.length);n<r;n++)if(!u(e[n],t[n]))return!1;return!0},
equalsDate:function(e,t){return e.getTime()==t.getTime()},equalsObject:function(
e,t){for(var n in r.mixin({},e,t))if(!(
n in a.prototype||"_watchCallbacks"==n||u(e[n],t[n])))return!1;return!0},
equalsValue:function(e,t){return e===t}}))});define("pentaho/analyzer/GemUI",["dojo/_base/declare","dojo/on","dojo/query",
"dojo/_base/lang","pentaho/common/propertiesPanel/Panel"],function(e,t,o,n,a){
return e(a.registeredTypes.gem,{className:"gem",postCreate:function(){
this.domNode.setAttribute("type",this.model.type),this.domNode.setAttribute(
"formula",this.model.formula);var e=o("div.gemMenuHandle",this.domNode)[0],e=((
e=e||o(".gemMenuHandle",this.domNode)[0]).className=e.className+" scalable",
cv.getActiveReport().getGem(this.model.formula));e&&this.setAnalyzerGemNode(e),
this.domNode.setAttribute("dndType",this.dndType+"B"),this.inherited(arguments)
},setAnalyzerGemNode:function(e){this.analyzerGem=e,
this.analyzerGem.domNode=this.domNode},getFormula:function(){
return this.model.formula},getName:function(){return this.model.value},
onContextMenu:function(e){var t=e.keyCode||e.which;
"keypress"===e.type&&t!==cvConst.keyCodes.ENTER||(this.analyzerGem||(
this.analyzerGem=cv.getActiveReport().getGem(this.model.formula)),
cv.util.popupSourceNode=this.domNode,this.analyzerGem.onContextMenu(e))},
destroy:function(){this.inherited(arguments),this.analyzerGem&&(
this.analyzerGem.domNode=null,this.analyzerGem=null)}})});define("pentaho/analyzer/LayoutPanel",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","pentaho/common/propertiesPanel/Configuration",
"pentaho/common/propertiesPanel/Panel","./GemUI","dijit/registry",
"dojo/_base/array","dojo/topic","dojo/aspect","pentaho/type/Simple",
"pentaho/type/action/Transaction","pentaho/visual/role/util",
"pentaho/visual/color/util","./visual/utils","pentaho/util/object",
"pentaho/util/fun"],function(e,t,o,l,r,n,i,a,s,u,p,c,d,m,h,f,g,y){var v=e(
"analyzer.LayoutPanel",[],{constructor:function(){this.handles=[],
this.panel=a.byId("layoutPanel"),this.own(p.after(this.panel,"onPropertyChange",
l.hitch(this,"onUIPropertyChange"),!0),t(this.panel,"UIEvent",l.hitch(this,
"onUIPropertyChange"))),this.topic=u.subscribe("/analyzer/reportDisplayed",
l.hitch(this,"updatePanel")),this._onModelEventHandle=null},own:function(){
var e=Array.prototype.slice.call(arguments);return this.handles.push.apply(
this.handles,e),e},destroy:function(){this.handles.forEach(function(e){e.remove(
)}),null!==this.panel&&(this.panel.destroy(),this.panel=null)},
onUIPropertyChange:function(e,t){
this.layoutConfig&&this.layoutConfig.onUIPropertyChange(e,t)},
onModelEvent:function(e,t,o){var e=this.layoutConfig.onModelEvent(
this.panel.configuration,e,t,o),r=this.layoutConfig.report;switch(e){
case v.modelEventActions.refreshReport:r.refreshReport();break;
case v.modelEventActions.refreshVisual:this.updatePanel(r),
r._vizModel&&r._vizModel.update().catch(function(){})}},updatePanel:function(e){
var t=this._getLayoutConfigClass(e);this.layoutConfig=t?new t(e):null,
cv.activeLayoutConfig=this.layoutConfig,this._onModelEventHandle&&(
this._onModelEventHandle.remove(),this._onModelEventHandle=null),
this.layoutConfig?(t=this.layoutConfig.getConfiguration(),
this.panel.setConfiguration(t),e.isClientSideViz()&&e.isLegacyViz()&&(
this.layoutConfig.updateConfiguration(this.panel.configuration),
this.panel.reload())):this.panel.setConfiguration(null),
this._onModelEventHandle=p.after(this.panel.configuration,"onModelEvent",
l.hitch(this,"onModelEvent"),!0)},_getLayoutConfigClass:function(e){var t,
o=e.getReportFormat(),r=o,n=("JSON"===o&&((t="CUSTOM"===(n=(t=e.reportDoc
).getChartOption("chartType"))?t.getChartOption("customChartType"):n)&&(r+="_"+t
),e.isLegacyViz())&&(o+="-LEGACY"),v.configurationManagers[r
]||v.configurationManagers[o]||null);return n||console.error(
"No configuration could be found for "+r),n}}),C=e(n.registeredTypes.gemBar,{
placeholderText:"",checkAcceptance:function(e,t,o,r){return!!this.inherited(
arguments)&&(void 0===o&&(o=!0),cv.activeLayoutConfig.checkAcceptance(
this.dropZone,t,o,r))}}),i=(n.registeredTypes.gem=i,n.registeredTypes.gemBar=C,
e("analyzer.LayoutPanel.Gem",[pentaho.common.propertiesPanel.Property],{
type:null,formula:null,measureId:null,gems:[],constructor:function(e){var t;
this.inherited(arguments),e.sourceNode?(t=e.sourceNode.getAttribute("formula"),
cv.getFieldHelp().isAttribute(t)?this.type="attribute":(this.type="measure",
this.measureId=cv.getActiveReport().reportDoc.getNextMetricId()),this.formula=t
):(l.mixin(this,e),this.formula||(this.formula=e.id))},postCreate:function(){}})
,r.registeredTypes.gem=v.Gem,e("analyzer.AbstractLayoutConfig",null,{
constructor:function(e){this.report=e,this.reportDoc=e.reportDoc},iconsForType:{
rowAttributes:"gem-bar-level",measures:"gem-bar-measure",
"attribute+measures":"gem-bar-filter"},getConfiguration:function(){function t(e
){e&&(e._index=o.length,o.push(e))}var o=[],r=this.report.vizModelAdapter,n=null
,i=(r.$type.eachVisualRole(function(e){t(this._createPropInfo(r,e,n))},this),
this.report.vizModel),a=i.$type,n=this.report._vizPropsImplied,e=(a.each(
function(e){a.isVisualRole(e)||t(this._createPropInfo(i,e,n))},this),
f.getVizOptionsAnnotation(a.id)),e=e&&e.showOptionsButton;return(
e=null==e?this.report._inferVizUsesChartOptions():e)&&t(
this._createOptionsButton(i)),this._sortPropInfos(o),{groups:{layout:{
id:"layout",title:cvCatalog.dropZoneLabels_LAYOUT},options:{id:"options",
title:cvCatalog.dropZoneLabels_PROPERTIES}},properties:o}},
_createOptionsButton:function(){return{id:"optionsBtn",dataType:"none",ui:{
group:"options",category:"optionsBtn",ordinal:1/0,type:"button",
label:cvCatalog.dropZoneLabels_CHART_OPTIONS}}},_sortPropInfos:function(e){
var n={};e.forEach(function(e){var e=e.ui,t=e._sectionKey=e.group+"|"+e.category
,e=e.ordinal,o=g.getOwn(n,t);(null==o||e<o)&&(n[t]=e)}),e.sort(function(e,t){
var o=e.ui,r=t.ui;return y.compare(o.group,r.group)||y.compare(n[o._sectionKey],
n[r._sectionKey])||y.compare(o.category,r.category)||y.compare(o.ordinal,
r.ordinal)||y.compare(o.caption||o.label,r.caption||r.label)||y.compare(e._index
,t._index)});var o=null;e.forEach(function(e){var t;"layout"!==e.ui.group&&(
t=e.ui.category||"",null==o?o=t:t!==o&&(o=t,e.ui.seperator=!0))})},
_createPropInfo:function(e,t,o){return t.isBrowsable&&e.isApplicableOf(t
)&&!g.hasOwn(o,t.name)?e.$type.isVisualRole(t)?this._createPropInfoRole(e,t
):this._createPropInfoGeneral(e,t):null},_createPropInfoRole:function(e,t){var o
,r=t.name,n=this.report,n=f.testAddKnownFieldKinds(n,e,r),i=[],i=(
n.stringAttribute&&i.push("string"),(n.numberMeasure||n.numberAttribute
)&&i.push("number"),n.dateAttribute&&i.push("time"),i.join(",")),a=(
n.attribute&&n.numberMeasure?o=this.iconsForType["attribute+measures"
]:n.attribute?o=this.iconsForType.rowAttributes:n.numberMeasure&&(
o=this.iconsForType.measures),[]),n=(n.attribute&&a.push("string"),
n.numberMeasure&&a.push("number"),cvCatalog["dropZonePlaceholder_"+a.join(",")])
,a=e.get(r),e=t.fields.countRangeOn(e,{ignoreCurrentMode:!0});return{id:r,
dataType:i,dataStructure:"column",caption:t.label,required:0<e.min,
allowMultiple:1<e.max,ui:{group:"layout",category:t.category,ordinal:t.ordinal,
type:"gemBar",dndType:cvConst.dndAcceptedTypes.report,caption:t.label,
captionIcon:o,showPlaceholder:!0,placeholderText:n},gems:a.fields.toArray(
this._createGemModelFromMappingField,this)}},
_createGemModelFromMappingField:function(e){e=this.report.getGem(e.name),
e=this.createGemModel(e);return e.postDrop={scope:this.report,
f:this.report.emitDropEvent},e},_createPropInfoGeneral:function(e,t){
var o=t.name;switch(o){case"data":case"selectionMode":return null}
var r=t.valueType;if(r.isList)return null;var n=t.domainOn(e),
r=this._getPropInfoGeneralDataType(r);if(null==r||"function"===r)return null;
var i,a=t.v2Spec;if(a)i=a.ui&&a.ui.type;else if(n)i="combo";else switch(r){
case"boolean":i="checkbox";break;case"number":
i=t.application.useSlider?"slider":"textbox";break;default:i="textbox"}
var s=a?l.clone(a):{},o=(s.id=o,s.dataType=r,e.getv(t)),r=(a&&null===o||(
s.value=o),s.ui);return r||(s.ui=r={}),r.group="options",r.category=t.category,
r.ordinal=t.ordinal,r.type=i,n&&(s.values=n.map(function(e){return e.$key}),
s.ui.labels=n.map(function(e){return e.toString()})),s.ui.caption=t.label,
"checkbox"===i&&(
t.application.checkedLabel?s.ui.label=t.application.checkedLabel:(
s.ui.label=t.label,s.ui.caption=void 0)),s},
_getPropInfoGeneralDataType:function(e){if(!e.isSimple)return null;var t,
o=c.type;if(e===o)return null;for(;(t=e.ancestor)!==o;)e=t;return e.shortId},
updateConfiguration:function(e){},createGemModel:function(e){return{
type:e.type==cvConst.TYPE_ATTRIBUTE?"attribute":"measure",id:e.getFormula(
).replace(/>/g,"&gt;"),formula:e.getFormula(),value:e.getDisplayLabel(),
dndType:cvConst.dndObjectTypes.gem}},onUIPropertyChange:function(e,t){},
onModelEvent:function(e,t,o,r){switch(o){case"value":
return this.onModelValueEvent(e,t,r);case"clicked":
return this.onModelClickedEvent(e,t);case"gems":case"removedGem":case"insertAt":
case"reorderedGems":return this.onModelGemEvent(e,t,o,r)}},
onModelValueEvent:function(e,t,o){return v.modelEventActions.none},
onModelGemEvent:function(e,t,o,r){return"insertAt"===o?(this.report.insertField(
t.id,r.idx,r.oldIdx,r.gem),v.modelEventActions.refreshReport
):v.modelEventActions.none},onModelClickedEvent:function(e,t){
return"optionsBtn"===t.id?(this.onShowOptions(),v.modelEventActions.none
):v.modelEventActions.refreshReport},onShowOptions:function(){
this.report.chartOptionsDlg.show()},checkAcceptance:function(e,t,o,r){try{if(!e
)return!1;var n=e.gemBar;if(!n)return!1;var i=t[0];if(!i)return!1;var a,
s=n.model.id,l=i.getAttribute("formula");if(!e.accept[i.getAttribute("dndtype")]
)return!1;var u=this.report.isReportFormatPivot(),p=null!==(
n.propPanel.getGemUIById(i.id)||null),c=this.report.getGemFromDomNode(i),
d=null!==c,h=d?c.getId():l;if(!p&&d&&(
u||!this.report.isGemMetricValueAndUnmapped(c))&&!(
a=this.report.checkDuplicateGem(h,o)))return a;if(u){
var f="columns"===s?"columnAttributes":"rowAttributes";if(
!this.report.checkColumnSelectionFilters(f,o))return!1}
var g=this.report.createSchemaDataTable(d?void 0:h),
y=this.report.vizModelAdapter,v=null==r?m.testAddFieldAtAutoPosition(y,s,h,{
alternateData:g}):m.testAddField(y,s,h,{alternateData:g,fieldPosition:r});
return null!==v}catch(e){throw alert(e),e}}}));return v.modelEventActions={
none:0,refreshVisual:1,refreshReport:2},e("analyzer.LayoutConfig",[i],{
getConfiguration:function(){var t,e=this.inherited(arguments),
o=this.report.visualization;return o&&(t=this.report._generateVizPropsImplied(),
s.forEach(e.properties,function(e){void 0!==t[e.id]?(e.value=t[e.id],
void 0!==o.args[e.id]&&(o.args[e.id]=t[e.id])):void 0!==o.args[e.id]&&(
e.value=o.args[e.id])},this)),e},onModelEvent:function(e,t,o,r){if(
"value"!=o&&"removedGem"!=o&&"gems"!=o){var n=r.gem;if("insertAt"==o
)this.report.insertField(t.id,r.idx,r.oldIdx,n);else if("optionsBtn"==t.id
)return void(this.report.isReportFormatPivot(
)?this.report.rptDlg.showReportOptions():this.report.chartOptionsDlg.show());
this.report.refreshReport()}}}),e("analyzer.PivotLayoutConfig",[i],{
_createOptionsButton:function(e){var t=this.inherited(arguments);
return t.ui.label=cvCatalog.dropZoneLabels_REPORT_OPTIONS,t},
updateConfiguration:function(e){throw new Error("Not supported")},
onShowOptions:function(){this.report.rptDlg.showReportOptions()}}),e(
"analyzer.JsonLayoutConfig",[i],{updateConfiguration:function(e){
throw new Error("Not supported")},onModelValueEvent:function(o,r,n){
return d.enter().using(function(e){var t=this._onModelValueEventCore(o,r,n);
return e.accept(),t},this)},_onModelValueEventCore:function(e,t,o){
var r=this.report;return r.history.endCurrent(),r.vizModel.set(t.id,o.newVal),
r.history.add(new cv.ReportState("actionChartProps")),r._syncVizModelFromReport(
),v.modelEventActions.refreshVisual}}),v.configurationManagers={
PIVOT:analyzer.PivotLayoutConfig,JSON:analyzer.JsonLayoutConfig,
"JSON-LEGACY":analyzer.LayoutConfig},e("analyzer.ColorConfiguration",[
analyzer.LayoutConfig],{palettes:{"ryg-3":["#FF0000","#FFFF00","#008000"],
"ryg-5":["#FF0000","#FFBF3F","#FFFF00","#BFDF3F","#008000"],"ryb-3":["#FF0000",
"#FFFF00","#4BB6E4"],"ryb-5":["#FF0000","#FFBF3F","#FFFF00","#DCDDDE","#4BB6E4"
],"blue-3":["#CCDFED","#6D85A4","#0F2B5B"],"blue-5":["#CCDFED","#9CB2C8",
"#6D85A4","#3E587F","#0F2B5B"],"gray-3":["#E6E6E6","#999999","#333333"],
"gray-5":["#E6E6E6","#CCCCCC","#999999","#666666","#333333"]},
onModelEvent:function(e,t,o,r){if("value"!==o)return this.inherited(arguments);
"colorSet"!=t.id&&"pattern"!=t.id&&"reverseColors"!=t.id||this.updateColorConfiguration(
e),this.report.history.add(new cv.ReportState("actionChartProps")),
this.report.refreshReport()},updateColorConfiguration:function(e){var t=e.byId(
"pattern").value,o=e.byId("colorSet").value,e=e.byId("reverseColors").value,
r="GRADIENT"===t?"linear":"discrete",o=h.buildPalette(o,t,e);
this._setScalingType(r),this._setColorRange(o)}}),v});define("pentaho/analyzer/report/cv_rptBanner",["dojo/_base/declare",
"dojo/dom-class","dojo/query","dojox/fx"],(e,s,t,n)=>{const a="dlgInfo",
d="banner-message",i="banner-fixed-message";e=e("cv.Banner",[],{_node:null,
set node(e){this._node=e},get node(){return this._node},_defaultMessage:null,
set defaultMessage(e){this._defaultMessage=e},get defaultMessage(){
return this._defaultMessage},_fixedMessage:null,set fixedMessage(e){
this._fixedMessage=e},get fixedMessage(){return this._fixedMessage},displayMsg(
e="",s=a){this.node&&(this.node.innerHTML="",0<e.length&&this.node.append(
this._createMessage(this._parseHtml(e,s))),this.show())},displayInfo(e){
this.displayMsg(e,a)},displayWarn(e){this.displayMsg(e,"dlgWarn")},displayError(
e){this.displayMsg(e,"dlgError")},show(){
this.node&&this.fixedMessage&&this.node.prepend(this._createMessage({
message:this.fixedMessage,fixed:!0})),this.node?.hasChildNodes()&&(s.add(
this.node,"flex-column"),cv.util.show(this.node),n.fadeIn({
duration:cv.prefs.fadeTime,node:this.node}).play())},hide(){if(this.node)if(
this.fixedMessage)for(const e of this._getBannerMessages())s.contains(e,i
)||this.node.removeChild(e);else cv.util.hide(this.node)},destroy(){
this.node=null,this.defaultMessage=null,this.fixedMessage=null},_createMessage({
message:e="",type:s=a,fixed:t=!1}){var n=document.createElement("div"),t=(
n.setAttribute("class",d+` ${t?i:""} flex-row flex-center-v`),
document.createElement("div"));return t.setAttribute("class",
`banner-icon ${s} icon-zoomable`),n.append(t),n.append(e),n},_parseHtml(e,s){
let t=e,n;e=/^<span class=['"](.+)['"]>(.+)<\/span>$/.exec(e);return null!=e&&([
,n,t]=e),{message:t??this.defaultMessage,type:n??s}},_getBannerMessages(){
return this.node?t("."+d,this.node):[]}});return cv.Banner=e});define("pentaho/analyzer/report/cv_rptReport",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dojox/collections/Dictionary","dojox/xml/parser"
,"dojox/fx","dojox/mvc/equals","dijit/layout/TabContainer",
"dijit/layout/ContentPane","../LayoutPanel",
"pentaho/common/propertiesPanel/Configuration","../TabPanel","dojo/_base/event",
"dojo/html","dojo/dom-class","dijit/registry","dojo/dnd/Manager",
"dojo/_base/array","dojo/dom-style","dojo/request","dojo/topic",
"dojo/dom-geometry","dojo/dom","dojo/_base/window","dojo/window",
"dojo/dom-construct","dojo/json","pentaho/visual/util","common-ui/util/_a11y",
"../API","./cv_rptIO","./cv_rptBanner"],(t,s,i,o,d,r,e,a,n,l,h,c,p,u,g,m,v,f,R,D
,b,T,y,C,F,w,I,S,_,P)=>{const A=f.manager();f=t("cv.Report",null,{constructor({
id:t,api:e,catalog:i,containerNode:r,cube:s,manager:o,mode:a,reportDoc:n,
reportXml:l,uiController:h}){if(this.id=t,this.mode=a,this.manager=o,
this.uiController=h,this.containerNode=r,this.handles=[],
this._extraFiltersHandles=cv.util.createCompositeHandle(),
this.history=new cv.History(this,o,h),this.modelAnnotations=[],
this.banner=new cv.Banner,this._constructViz(),n?this.reportDoc=n:(
this.reportDoc=new cv.ReportDocument,this.reportDoc.initialize(l)),s&&i?(
this.cube=s,this.catalog=i,this.reportDoc.setReportOption("cube",this.cube),
this.reportDoc.setReportOption("catalog",this.catalog)):(
this.cube=this.reportDoc.getReportOption("cube"),
this.catalog=this.reportDoc.getReportOption("catalog")),
this.currentSelection=null,this.gemList=new d,this.badFields=[],
this.badFilters=!1,this.wordWrap=!1,this.pendingSaveParams={reportAction:null,
reportName:null,reportPath:null,reportErrorCallback:null,
suppressSuccessNotification:!1},this.okTimeoutInterval=250,!e)throw new Error(
"Required argument 'api'.");(this.api=e).report._attachReport(this)},_query(t,e
){return i(t,e)},on(...t){return cv.api.event._on(...t)},emit(t,...e){
var i="init"===t?cv:cv.api;return cv.api.event._emit(t,i,...e)},emitDropEvent(t,
e){this.emit("drop",t,e)},MIN_REPORT_HEIGHT:100,HISTORY_ACTION_LIST:"",
reportBeCanceled:!1,byId(t){let e=t;return 0!==t.indexOf(this.id)&&(e=this.id+t)
,C.byId(e)},byClass(t){return cv.util.getFirstChildByClass(this.domNode,t)},
createNode(t,e,i,r){t=document.createElement(t);return e&&(t.id=this.id+e),i&&(
t.className=i),r&&r.appendChild(t),t},init(){return window.name="cvrpt"+this.id,
this._initDom(),this.timeUnlimited=!0,this.refreshRequestId="",
this.progressImgId=0,this.isReportPropsDirty=!1,this.actionLog=[],
this.pendingActionLen=0,this.topPaneId="",this.reportHeight=300,
this.reportWidth=500,this.refreshTimeStamp=null,this.downloadCount=0,
this.isInitialized=!1,this.pivotReportLoaded=!1,this.chartLoaded=!1,
this.rptDlg=new cv.ReportDialog(this),this.filterDlg=new cv.FilterDialog(this),
this.linkDlg=new cv.LinkDialog(this),this.drillDlg=new cv.DrillDialog(this),
this.chartOptionsDlg=new cv.ChartOptionsDialog(this),
this.pageSetupDlg=new cv.PageSetupDialog(this),
this.arithNumberDlg=new cv.ArithNumberDialog(this),
this.createMeasureDlg=new cv.CreateMeasureDialog(this),
this.measurePropertiesDlg=new cv.MeasurePropertiesDialog(this),
this.attributePropertiesDlg=new cv.AttributePropertiesDialog(this),
this.removeMeasureDlg=new cv.RemoveMeasureDialog(this),
this.resizer=new cv.ReportResizer,this.reportHeaders=null,this.isResizing=!1,
this.rowFieldWidths=[],this.actualRowFieldWidths=null,
this.columnDataFieldWidths=[],this.actualColumnFieldWidths=null,
A.nestedTargets=!0,this.dropTargets={reportArea:new cv.ReportDropTarget(
this.byId("ReportArea"),{accept:cvConst.dndAcceptedTypes.report,report:this}),
trashcan:new cv.TrashAreaDropTarget(this.byId("Trashcan"),{
accept:cvConst.dndAcceptedTypes.trashcan,report:this})},
"EDIT"!==this.mode&&"VIEW"!==this.mode||(m.add(this.byId("filters"),
"dojoDndItem"),this.dropTargets.filters=new cv.FilterPaneDropTarget(this.byId(
"filters").parentNode,{accept:cvConst.dndAcceptedTypes.report,report:this}),
this.dropTargets.filters.sync(),
this.dropTargets.filterPaneTitle=new cv.FilterPaneDropTarget(this.byId(
"FilterPaneTitle"),{accept:cvConst.dndAcceptedTypes.report,report:this}),
this.handles.push(s(this.nodeFilters,"dblclick",o.hitch(this,"showFilterDlg"))),
this.setAutoRefresh("true"===this.reportDoc.getReportOption("autoRefresh"))),
"VIEW"!==this.mode&&"MINI"!==this.mode||(this.handles.push(s(this.byId(
"CmdActions"),"click",o.hitch(this,"toggleActionsPopupMenu"))),
this.handles.push(P.makeAccessibleActionButton(this.byId("CmdActions")))),
this.handles.push(s(this.byId("ReportSummary"),"click",o.hitch(this,
"onToggleReportPane"))),this.handles.push(s(this.byId("HideFilterPane"),"click",
o.hitch(this,"onToggleReportPane"))),this.handles.push(
P.makeAccessibleActionButton(this.byId("FilterPaneToggle"))),this.handles.push(
P.makeAccessibleActionButton(this.byId("HideFilterPane"))),this.handles.push(s(
this.nodeFilters,"mousemove",o.hitch(this,"onMouseOverFilters"))),
this.handles.push(s(C.byId("closeRowTruncate"),"click",o.hitch(this,
"hideTruncateMessage"))),this.handles.push(s(C.byId("closeColTruncate"),"click",
o.hitch(this,"hideTruncateMessage"))),this.handles.push(s(C.byId(
"closeTransTruncate"),"click",o.hitch(this,"hideTruncateMessage"))),
this.handles.push(s(C.byId("closeChartInfo"),"click",o.hitch(this,
"hideTruncateMessage"))),"VIEW"===this.mode&&(cv.api.ui.removeHeaderBar(
cv.analyzerProperties["cv.api.ui.removeHeaderBar.viewer"]),
cv.api.ui.disableFilterPanel(cv.analyzerProperties[
"cv.api.ui.disableFilterPanel.viewer"]),cv.api.ui.removeReportActions(
cv.analyzerProperties["cv.api.ui.removeReportActions"]),
cv.api.ui.removeUndoButton(cv.analyzerProperties[
"cv.api.ui.removeUndoButton.viewer"]),cv.api.ui.removeRedoButton(
cv.analyzerProperties["cv.api.ui.removeRedoButton.viewer"])),
cv.api.util._applyUrlParameters(["removeHeaderBar","disableFilterPanel",
"removeReportActions","removeUndoButton","removeRedoButton"]),
cv.util.setHelpTopics([this.id+"HelpFilterPane",
"CV/Business_User/working_with_filters.html"]),cv.util.show(this.domNode),
this._initJSPlugins(),this._loadVizRegistryAsync()},_initDom(){
this.domNode=this.createNode("DIV","ReportMain",
"reportMain pentaho-panel-insetglow "+this.mode),this.containerNode.appendChild(
this.domNode);
let t=`
          <div class="filterSummary" id="${this.id}FilterPaneTitle">
            <div id="${this.id}FilterPaneToggle" class="filterPaneToggle" title="${cvCatalog.ttShowHideFilters}">
              &nbsp;
            </div>
            <span id="${this.id}FilterCountLabel" title="${cvCatalog.ttShowHideFilters}">No Filter in use</span>
          </div>
          <div class='titleLink reportName' id='${this.id}ReportName'></div>
          <div id="refreshSummary">
            <div id="${this.id}StatusBar" class="statusBar"></div>
            <div id="progressPane" class="progressPaneDiv hidden"></div>
          </div>`;"VIEW"===this.mode&&(
t=`
            ${t}
            <div id='${this.id}ReportFormatCmdDiv' class='reportFormatShowDiv' style='height:23px;'>
              <div title='Report Actions' id='${this.id}CmdActions' class='cmdActionsBtn'>
                <span>${cvCatalog.reportDashboardActions}</span>
              </div>
            </div>`),this.createNode("DIV","ReportSummary",
"reportSummary clearfix pentaho-titled-toolbar",this.domNode).innerHTML=t,
"EDIT"===this.mode&&(D.set("refreshSummary","position","absolute"),D.set(
"refreshSummary","right","0")),this.nodeFilter=this.createNode("DIV","Filter",
"reportFilter clearfix hidden",this.domNode),this.nodeFilter.innerHTML=`
          <div id="${this.id}filters" class="filters">
            <div class="filterPaneHint"></div>
          </div>
          <span
            id="${this.id}HelpFilterPane"
            class="helpIcon icon-zoomable"
            title="${cvCatalog.ttHelpOnFilters}"
          ></span>
          <span
            id="${this.id}HideFilterPane"
            class="closeBox pentaho-closebutton pentaho-imagebutton-hover flex-none"
            title="${cvCatalog.ttHideFilterPane}"
          ></span>`,this.nodeRowTruncate=this.createNode("DIV","RowTruncateInfo"
,"rowTruncate hidden",this.domNode),this.nodeRowTruncate.innerHTML=`
          <span class="button-close pull-right" id="closeRowTruncate"></span>
          <br>
          <span class="info-icon"></span>&nbsp;
          `+cv.util.substituteParams(cvCatalog.rowTruncate,
`<span id="${this.id}RowTruncateMsg"></span>`),
this.nodeColTruncate=this.createNode("DIV","ColTruncateInfo",
"colTruncate hidden",this.domNode),this.nodeColTruncate.innerHTML=`
          <span class="button-close pull-right" id="closeColTruncate"></span>
          <br>
          <span class="info-icon"></span>&nbsp;
          `+cv.util.substituteParams(cvCatalog.colTruncate,
`<span id="${this.id}ColTruncateMsg"></span>`),
this.nodeTransTruncate=this.createNode("DIV","TransTruncateInfo",
"transTruncate hidden",this.domNode),this.nodeTransTruncate.innerHTML=`
          <span class="button-close pull-right" id="closeTransTruncate"></span>
          <br>
          <span class="info-icon"></span>
          `+cvCatalog.transTruncate,this.nodeChartInfo=this.createNode("DIV",
"ChartInfo","chartTruncate hidden",this.domNode),
this.nodeChartInfo.innerHTML='<span class="button-close pull-right" id="closeChartInfo"></span><br><span class="info-icon"></span>'
,this.nodeChartMsg=this.createNode("span","ChartInfoMsg","",this.nodeChartInfo),
this.nodeReportRefresh=this.createNode("DIV","ReportRefresh","reportRefresh",
this.domNode),this.nodeReportRefresh.innerHTML=`
          <div class="pull-left">
            <span class="warn-icon vertical-align-middle"></span>
            ${cvCatalog.warnAutoRefreshPanel}
          </div>
          <button id="cmdRefreshBtn" style="margin-right: 10px;padding: 2px 5px 4px;" class="pentaho-button pull-right">
            ${cvCatalog.refreshButton}
          </button>`,s(C.byId("cmdRefreshBtn"),"click",()=>{cv.getActiveReport(
).history.isStateRefreshed()||cv.getActiveReport().refreshReport(!0)}),
cv.util.hide(this.nodeReportRefresh),this.nodeReportArea=this.createNode("DIV",
"ReportArea","reportArea",this.domNode),this.nodeTrash=this.createNode("DIV",
"Trashcan","trashcan hidden",this.domNode),this.nodeFilters=this.byId("filters")
,this.statusBar=this.byId("StatusBar"),this.closeTruncateStatus="None"},
_initJSPlugins(){"undefined"!=typeof analyzerPlugins&&R.forEach(analyzerPlugins,
(t,e)=>{try{t.init()}catch(t){
"undefined"!=typeof console&&console.log&&console.log(
`Error initializing Analyzer plugin #${e+1}: `+t)}})},postCreate(){let t="";
this.reportDoc.isEmpty()||(t="actionOpenReport"),this.openReport(),
cv.api.util._applyUrlParameters(),this.emit("init"),this.history.add(
new cv.ReportState(t)),this.refreshReport(!1,!0),this.history.setSaved(),
0<this.badFields.length&&(this.history.current().reportXml=r.innerXML(
this.reportDoc.getReportNode())),this.history.setRefreshed(!1),
this.successState=this.history.current(),this.isInitialized=!0},destroy(){
R.forEach(this.handles,t=>{t.remove()}),this.clearGemList(),
this._extraFiltersHandles.remove(),this.rptDlg.destroy(),this.filterDlg.destroy(
),this.resizer.destroy(),cv.util.destroyDojoWidgets(),this.rptDlg=null,
this.filterDlg=null,this.resizer=null,this.reportDoc=null,
this.reportHeaders=null,this.statusBar=null,this.nodeColTruncate=null,
this.nodeRowTruncate=null,this.nodeTransTruncate=null,this.nodeChartInfo=null,
this.nodeReportArea=null,this.containerNode=null,this.domNode=null,
this.nodeReportRefresh=null,this.nodeTrash=null,this.nodeLayout=null,
this.nodeFilter=null,this.nodeFilters=null,this._vizView&&this._disposeVizView()
,this.vizDiv=null,cv.util.TRACE("_EXIT")},setReportPropsDirty(t){
this.isReportPropsDirty=t},showReportDescription(t){t=t.currentTarget.id;C.byId(
t).setAttribute("title",this.getReportProperties().description)},openReport(t,e
){t&&(this.reportDoc.replaceReportNode(t),this.reportDoc.setReportOption(
"autoRefresh",cv.prefs.autoRefresh?"true":"false")),this._initDisplay(null,null,
null,e),this.cube=this.reportDoc.getReportOption("cube");
var e=this.reportDoc.getReportProperty("name");e?(this.setReportName(e),
document.title=e,"EDIT"===this.mode&&"true"===this.reportDoc.getUIAttributes(
).getAttribute("showFilterPanel")&&this.toggleReportPane("cmdFilters")):(
this.setReportName(cvCatalog.reportNewName),
document.title=cvCatalog.reportNewName,this.setReportPropsDirty(!0),
e=cv.util.getURLQueryValue("autoRefresh"),t||"false"!==e||this.setAutoRefresh(!1
))},setReportXML(t){b(cv.contextPath+t+"&::getReportXml=true",{data:{time:(
new Date).getTime()},sync:!1,headers:{}}).then(t=>{this.reportDoc.initialize(t),
this.openReport(),this.history.add(new cv.ReportState("actionEditFilter")),
this.refreshReport()},()=>{},()=>{})},destroyReport(){
this.refreshRequestId&&cv.io.cancelAsyncRequest(this.refreshRequestId),
this._removeSortHandlers(),null!=this.reportHeaders&&(
this.reportHeaders.disconnect(),this.reportHeaders=null),
this.resizeSubscription&&this.resizeSubscription.remove();var t,e=this.byClass(
"pivotTable");e&&(t=v.findWidgets(e),R.forEach(t,t=>{t.destroyRecursive(!1)})),
e&&(e.innerHTML="",cv.api.event._eventListenerUtil.removeEventListener(e,
"contextmenu",this.rptTblPopupMenuHandler),
cv.api.event._eventListenerUtil.removeEventListener(e,"click",
this.rptTblClickHandler,!0),cv.api.event._eventListenerUtil.removeEventListener(
e,"contextmenu",this.rptTblContextmenuHandler,!0),this.rptOnKeepAndShow.remove()
,cv.api.event._eventListenerUtil.removeEventListener(e,"dblclick",
this.rptTblDblClickHandler,!0),
cv.api.event._eventListenerUtil.removeEventListener(e,"mouseenter",
this.rptTblMouseOverHandler,!0),
cv.api.event._eventListenerUtil.removeEventListener(e,"mousemove",
this.rptTblMouseMoveHandler,!0),cv.util.hide(this.nodeColTruncate,
this.nodeRowTruncate,this.nodeTransTruncate,this.nodeChartInfo))},
hideReportMessages(){cv.util.hide(this.nodeColTruncate,this.nodeRowTruncate,
this.nodeTransTruncate,this.nodeChartInfo)},loadReportResizeParams(){
0<this.rowFieldWidths.length||0<this.columnDataFieldWidths.length||(
this.reportDoc.reportRecord.documentElement.selectNodes(
"cv:uiAttributes/cv:rowFieldWidths/cv:labelWidth").forEach(t=>{var[{value:e}
]=t.attributes,t=r.textContent(t.selectSingleNode("cv:width"));
this.rowFieldWidths[e]=parseInt(t,10)}),
this.reportDoc.reportRecord.documentElement.selectNodes(
"cv:uiAttributes/cv:columnDataFieldWidths/cv:labelWidth").forEach(t=>{var[{
value:e}]=t.attributes,t=r.textContent(t.selectSingleNode("cv:width"));
this.columnDataFieldWidths[e]=parseInt(t,10)}))},updateReportResizeParams(t,e,i,
r){if("remove"===t)if("measure"===r)for(
let t=e;t<this.columnDataFieldWidths.length;t+=1)this.columnDataFieldWidths[t
]=this.columnDataFieldWidths[t+1];else for(
let t=e;t<this.rowFieldWidths.length;t++)this.rowFieldWidths[t
]=this.rowFieldWidths[t+1];else if("add"===t&&"before"===i)if("measure"===r){
for(let t=this.columnDataFieldWidths.length;t>e;--t)this.columnDataFieldWidths[t
]=this.columnDataFieldWidths[t-1];this.columnDataFieldWidths[e]=null}else{for(
let t=this.rowFieldWidths.length;t>e;--t)this.rowFieldWidths[t
]=this.rowFieldWidths[t-1];this.rowFieldWidths[e]=null}},
_transformDataFieldToDom(e,i){for(let t=0;t<e.length;t++){var r;void 0!==e[t
]&&null!=e[t]&&(r=cv.parseXML(
`<labelWidth xmlns="http://www.pentaho.com" index='${t}'>
                 <width>${parseInt(e[t],10)}</width>
               </labelWidth>`).documentElement,i.appendChild(r.cloneNode(!0)))}
},saveUIAttributes(){var t=this.reportDoc.getUIAttributes(),
e=t.selectSingleNode("cv:rowFieldWidths"),i=(this.actualRowFieldWidths&&(
r.removeChildren(t.selectSingleNode("cv:rowFieldWidths")),e.setAttribute(
"actualWidths",this.actualRowFieldWidths.toString())),t.selectSingleNode(
"cv:columnDataFieldWidths"));this.actualColumnFieldWidths&&(r.removeChildren(
t.selectSingleNode("cv:columnDataFieldWidths")),i.setAttribute("actualWidths",
this.actualColumnFieldWidths.toString())),this._transformDataFieldToDom(
this.rowFieldWidths,e),this._transformDataFieldToDom(this.columnDataFieldWidths,
i),this.savePluginDataToXML(this.getPluginDataJSON())},loadReportHTML(e){
this.refreshRequest=null,this.refreshRequestId=null,this.hideProgressPane(),
this._removeAutoRefreshPane();var i=cv.util.parseAjaxMsg(e);if(this.emit(
"postExecution",i)){i=this.handleReportMsg(i);if(i){if(
"success"===i.type&&"successGenerateReport"!==i.id){let t=cvCatalog[i.id];
t=t||i.id,e="reportNoDataMsg"===i.id?cv.util.substituteParams(
"EDIT"===this.mode?cvCatalog.reportNoDataMsgHTML:cvCatalog.reportSuccessMsgHTML,
t):cv.util.substituteParams(cvCatalog.reportSuccessMsgHTML,t)}
"reportNoDataMsg"===i.id?this.displayReport(e,i):this.isClientSideViz(
)?this.displayClientSideReport(e):(this.loadReportResizeParams(),
this.displayReport(e,i)),this.resizeRows(),this._callRenderingEvents()}}},log(e,
t){if(e){let t=e;this.manager.cmdUndo&&(
"UNDO"===e&&this?t=this.manager.cmdUndo.title:"REDO"===e&&(
t=this.manager.cmdRedo.title));e=t.indexOf(" (Ctrl+");0<e&&(t=t.substring(0,e)),
this.actionLog.push(t)}t&&(this.pendingActionLen=this.actionLog.length)},
_compareObjects(t,e){return a(t,e)},_getJsonFilter(t,e){let i={};if(t){
t=cv.util.xmlToJson(t);if(""===t._text&&delete t._text,i=t,!e)for(
const r of i=Array.isArray(t.predicate)?t.predicate:[t.predicate]
)"attributes"in r&&delete r.attributes.containsRegExp,
""===r._text&&delete r._text}return i},refreshPreFilters(){
var i=this.getOptionsSync();if(i){var t=this.reportDoc.getChildMembers("filters"
),e=this.reportDoc.getMetricFilter(),e=this._getFilterProps(e,t),
r="true"===this.reportDoc.getDefaultFiltersAvailable(i);for(const a of e)if(r){
let t=!1;var s=i.getFilterPredicates(a.formula);s&&(
o=this.reportDoc.getFilterPredicates(a.formula),o=this._getJsonFilter(o,!1),
s=this._getJsonFilter(s,!1),t=this._compareObjects(o,s)),
this.reportDoc.updateIsDefaultFilter(a.formula,t,null);let e=!1;
var o=i.getFilterConditions(a.formula);o&&(s=this.reportDoc.getFilterConditions(
a.formula),e=this._compareObjects(this._getJsonFilter(o,!0),this._getJsonFilter(
s,!0))),this.reportDoc.updateIsDefaultFilter(a.formula,null,e)
}else this.reportDoc.updateIsDefaultFilter(a.formula,!1,!1);
this.populateFilters()}},handleReportMsg(t){if(!t)return null;var e=o.isObject(t
)?t:cv.util.parseAjaxMsg(t);if(!e)return{type:"success",
id:"successGenerateReport",text:t};switch(e.type){case"exception":
return null!=e.message&&(0<=e.message.indexOf(
"Component returned failure code: 0x80040111")||0<=e.message.indexOf(
"XMLHttpTransport Error: 0"))||null!=e.initId&&null==e.initId||(
this.rptDlg.showError(cvCatalog.reportErrorMsg,null,cvCatalog.dlgSorryTitle),
this.hideProgressPane()),null;case"error":return this.rptDlg.showError(e.details
),this._revertToLastSuccessState(),this.hideProgressPane(),null;case"confirm":{
const i=this;return this.refreshRequestId=e.text,this.rptDlg.showConfirm(
e.details,null,{srcFunc(){cv.io.getReportHTML(i)}},{srcObj:this,
srcFunc:"cancelReport"}),null}case"warn":return cv.prefs.suppressMsg[e.id
]||this.rptDlg.showWarning(e.details,null,!1,!0,e.id),e;case"sessionExpired":
return null;default:return e}},_findClosestTdForClickEvent(t){let e;
t=this._query(t).closest("td[type]");return t&&0<t.length&&([e]=t),e},
_findClosestTdForMouseOverEvent(t){let e;
return e="TD"===t.tagName&&t.getAttribute("type")?t:e},_onBindAdditionalEvent(t,
e,i){var r,s;cv.api.event.isEventDisabled(t)?u.stop(i):(r=i.target,(e=e.call(
this,r))&&(r=this.buildCellActionContext(e),s=this.buildFilterActionContext(),
this.emit(t,e,r,s,i)||u.stop(i)))},_addSortHandlersToPivot(){
this.rptTblClickSortHandler=o.hitch(this,"onToggleSort"),
this.rptTblDblClickEditDlgHandler=o.hitch(this,"onShowEditDialogOnColumnHeader")
const e=t=>{cv.api.event._eventListenerUtil.addEventListener(t,"click",
this.rptTblClickSortHandler),cv.api.event._eventListenerUtil.addEventListener(t,
"dblclick",this.rptTblDblClickEditDlgHandler)};this._query(
".sortActiveAsc, .sortActiveDesc, .sortInactive",
this.reportHeaders.rowLabelHeaderContainer).forEach(t=>{this._query(".sort",t
).forEach(e)}),this._query(".sortActiveAsc, .sortActiveDesc, .sortInactive",
this.reportHeaders.columnHeaderContainer).forEach(t=>{this._query(".sort",t
).forEach(e)})},_removeSortHandlers(){if(this.reportHeaders){const e=t=>{
cv.api.event._eventListenerUtil.removeEventListener(t,"click",
this.rptTblClickSortHandler),
cv.api.event._eventListenerUtil.removeEventListener(t,"dblclick",
this.rptTblDblClickEditDlgHandler)};this._query(
".sortActiveAsc, .sortActiveDesc, .sortInactive",
this.reportHeaders.rowLabelHeaderContainer).forEach(t=>{this._query(".sort",t
).forEach(e)}),this._query(".sortActiveAsc, .sortActiveDesc, .sortInactive",
this.reportHeaders.columnHeaderContainer).forEach(t=>{this._query(".sort",t
).forEach(e)})}},_updatePivotLayout(t){this.reportHeaders=new cv.ReportHeaders(
this,t);let e=0;var i=this._query(".resize",
this.reportHeaders.rowLabelHeaderContainer);for(let t=0;t<i.length;t++)0!==t&&(
this.reportHeaders.attachResizeNode(i[t],"Label","before",e),e+=1),
this.reportHeaders.attachResizeNode(i[t],"Label","after",e),e+=1,D.set(i[t],
"position","relative");var r=this._query(".resize",
this.reportHeaders.columnHeaderContainer);for(let t=0;t<r.length;t++
)"measure"===r[t].parentNode.getAttribute("type")&&(
this.reportHeaders.attachResizeNode(r[t],"Column","before",e),e+=1,
this.reportHeaders.attachResizeNode(r[t],"Column","after",e),e+=1,D.set(r[t],
"position","relative"));this.reportHeaders.resizeLabels=i,
this.reportHeaders.resizeColumns=r,this.closeTruncateStatus="None",
this.resizeContainer(),this.reportHeaders.updateLayout()},_truncateMsgFromPivot(
t,e){let i=t.getAttribute("rowcount"),r=t.getAttribute("columncount");if(e
)switch(e.truncate&&(t.truncateType=e.truncate),e.truncate){case"ROW":
i=cv.util.substituteParams(cvCatalog.reportTableCountValue,i,e.rows),t.rowMsg=i;
break;case"COL":r=cv.util.substituteParams(cvCatalog.reportTableCountValue,r,
e.cols),t.colMsg=r;break;case"BOTH":i=cv.util.substituteParams(
cvCatalog.reportTableCountValue,i,e.rows),t.rowMsg=i,r=cv.util.substituteParams(
cvCatalog.reportTableCountValue,r,e.cols),t.colMsg=r}return{rowMsg:i,colMsg:r}},
_bindRptOnKeepAndShowHandler(t){this.rptOnKeepAndShow=s(t,"dblclick",o.hitch(
this,"onKeepAndShow"))},displayReport(t,e,i){cv.util.TRACE("_START");
var r=this.getReportFormat();t&&(this.destroyReport(),
this._vizView&&this._disposeVizView(),cv.util.TRACE("set report HTML"),
this.nodeReportArea.innerHTML=t,
e&&"reportNoDataMsg"===e.id&&"EDIT"===this.mode?cv.util.setHelpTopics([
cv.util.getFirstChildByClass(this.nodeReportArea,"helpLinkReportNoData"),
"CV/Business_User/working_with_filters.html#when_the_report_returns_no_data"]
):"PIVOT"===r&&(t=this.byClass("pivotTable"))&&(this.hideReportMessages(),
this.rptTblClickHandler=o.hitch(this,"_onBindAdditionalEvent","tableClick",
this._findClosestTdForClickEvent),this.rptTblContextmenuHandler=o.hitch(this,
"_onBindAdditionalEvent","tableContextMenu",this._findClosestTdForClickEvent),
this.rptTblMouseOverHandler=o.hitch(this,"_onBindAdditionalEvent",
"tableMouseOver",this._findClosestTdForMouseOverEvent),
this.rptTblMouseMoveHandler=o.hitch(this,"_onBindAdditionalEvent",
"tableMouseMove",this._findClosestTdForClickEvent),
cv.api.event._eventListenerUtil.addEventListener(t,"click",
this.rptTblClickHandler,!0),cv.api.event._eventListenerUtil.addEventListener(t,
"contextmenu",this.rptTblContextmenuHandler,!0),
cv.api.event._eventListenerUtil.addEventListener(t,"mouseenter",
this.rptTblMouseOverHandler,!0),
cv.api.event._eventListenerUtil.addEventListener(t,"mousemove",
this.rptTblMouseMoveHandler,!0),e=this._truncateMsgFromPivot(t,e),
this.statusBar.innerHTML=cv.util.substituteParams(cvCatalog.reportTableCount,
e.rowMsg,e.colMsg),cv.util.TRACE("Update layout"),this._updatePivotLayout(t),
this.rptTblDblClickHandler=o.hitch(this,"_onBindAdditionalEvent",
"tableDoubleClick",this._findClosestTdForClickEvent),
cv.api.event._eventListenerUtil.addEventListener(t,"dblclick",
this.rptTblDblClickHandler,!0),this._bindRptOnKeepAndShowHandler(t),
this.rptTblPopupMenuHandler=o.hitch(this,"toggleInReportPopupMenu"),
cv.api.event._eventListenerUtil.addEventListener(t,"contextmenu",
this.rptTblPopupMenuHandler),(e=cv.util.getDojoWidget("memberPopMenu")
)&&e.domNode&&(e.domNode.memberId=null),
this.wordWrap=this.getAttributeGemValues().some(t=>t.isWordWrap()),
this._addSortHandlersToPivot()),this.dropTargets.reportArea.init(r),
this.successState=this.history.current(),"exception"!==i&&(
this.pivotReportLoaded=!0),cv.util.TRACE("_END"))},refreshReport(r,s){if(
this._syncVizModelFromReport(),s||this.reportDoc.replaceSelectionItems(),
T.publish("/analyzer/reportDisplayed",this),!r&&!this.autoRefresh())return!0;if(
cv.util.hide(this.nodeReportRefresh),this.history.setRefreshed(!1),
this.statusBar.innerHTML="",this.reportDoc.isEmpty(
)||!this.isRequiredGembarsFilled()){this.hideProgressPane(),
this.refreshRequest&&(this.refreshRequest.cancel(),this.refreshRequest=null),
this.refreshRequestId&&(cv.io.cancelAsyncRequest(this.refreshRequestId),
this.refreshRequestId=null),this.destroyReport();let t="PIVOT",e,
i="../analyzer/images/spacer.gif";this.isClientSideViz()?(s=this.vizModelType,
e=s.label,t=this.isLegacyViz()?this.reportDoc.getChartOption("customChartType"
).toUpperCase():` ${_.getCssClasses(s.id)} component-icon-landscape`,
r=this._getVizHelper(),i=r&&r.placeholderImageSrc||i):e=cvCatalog.VIZ_PIVOT_DESC
,this._vizView&&this._disposeVizView(),
this.nodeReportArea.innerHTML=cv.util.substituteParams(
cvCatalog.emptyReportAreaHTML,this.id,cvCatalog.emptyVizArea,t,e,i),
cv.util.setHelpTopics([this.id+"GettingStarted",
"CV/Business_User/creating_a_new_report.html#start_adding_fields_and_filters"]);
s=this.getReportFormat();return this.dropTargets.reportArea.init(s),
this.refreshPreFilters(),this._callRenderingEvents(),
this.successState=this.history.current(),!0}return!this.emit("preExecution")||(
this.pivotReportLoaded=!1,this.chartLoaded=!1,this.refreshTimeStamp=(new Date
).getTime(),this.saveUIAttributes(),cv.io.refreshReport(this))},
_callRenderingEvents(){var t=this.byClass("reportArea");this.emit("render",t)},
cancelReport(){this.reportBeCanceled=!0,this.hideProgressPane(),
this.refreshRequestId&&(this.refreshRequest&&this.refreshRequest.cancel(),
cv.io.cancelAsyncRequest(this.refreshRequestId),this.refreshRequest=null,
this.refreshRequestId=null,this._revertToLastSuccessState())},setOptions(t){
cv.io.setOptions(this,t)},getOptions(t){cv.io.getOptions(this,t,this.catalog,
this.cube)},removeOptions(t,e){cv.io.removeOptions(this,t,this.catalog,this.cube
),e.getChildMembers("filters").forEach(t=>{this.reportDoc.updateIsDefaultFilter(
t.getAttribute("formula"),!1,!1)}),this.populateFilters()},showResetOptions(t,e
){var i=this.handleReportMsg(t);if(i&&"success"===i.type){
const r=new cv.ReportDocument;r.initialize(t),
"REPORT"===e?this.rptDlg.resetUpdateOptions(r
):"CHART"===e?this.chartOptionsDlg.resetUpdateOptions(r):"FILTER"===e?(
i=this._getFiltersNodes(r),t=this.getFiltersSummary(i).join(""),
this.rptDlg.showConfirm(["promptResetDefaultFilters",t],null,{srcFunc:(
)=>this.resetDefaultFiltersConfirmation(r)})):"FILTER_REMOVE"===e?(
i=this._getFiltersNodes(r),t=this.getFiltersSummary(i).join(""),
this.rptDlg.showConfirm(["promptRemoveDefaultFilters",t],null,{srcFunc:(
)=>this.removeOptions("FILTER",r)})
):"DRILL"===e&&this.drillDlg.resetUpdateOptions(r)}},
resetDefaultFiltersConfirmation(t){var e=t.getChildMembers("filters"),
t=t.getMetricFilter(),t=(t&&(t.type="FILTER_METRIC"),this._getFilterProps(t,e));
this._removeCurrentFilters(),t.forEach(t=>{this.reportDoc.updateFilter(t),
this.reportDoc.updateIsDefaultFilter(t.formula,!0,!0)}),this.populateFilters(),
this.history.add(new cv.ReportState("actionPreFilterReset")),this.refreshReport(
)},_getFilterProps(e,t){const i=[];return t.forEach(t=>{
t=this.reportDoc.getFilterProps(t);!e||t.formula!==e.formula?i.push(t):(
e.predicates=t.predicates,i.push(e))}),i},_getFiltersNodes(t){
var e=this.createNode("DIV","filters","hidden",this.domNode),
i=t.getChildMembers("filters"),r=t.getSelectionFilters();let s;var o=[],a=[];
for(const n of i)n.selectSingleNode("cv:predicates/cv:predicate")?(
s=this.createGemDomNode(n,"filters"))&&(cv.getFieldHelp().isTimeAttribute(
s.getFormula())?o:a).push(s):t.removeEmptyFilter(n);for(const l of o
)e.appendChild(l.domNode);for(const h of a)e.appendChild(h.domNode);
return 0<r.length&&e.appendChild(this._createSelectionFilterNode()),(
s=this.createMetricFilterGem(t))&&e.appendChild(s.domNode),e},getFiltersSummary(
t){const e=[];return this._query(".filterItem",t).forEach(t=>{t.id.startsWith(
"filter_metric")?this._query(".filterItemList",t).forEach(t=>{e.push(
t.innerText.trim()+"<br>")}):e.push(t.innerText.trim()+"<br>")}),e},
_removeCurrentFilters(){this._query(".filterItem",this.nodeFilters).forEach(t=>{
this.removeFilter(t.id,!0)})},getOptionsSync(){var t=cv.io.getOptionsSync(
this.catalog,this.cube),e=this.handleReportMsg(t);if(e&&"success"===e.type
)return(e=new cv.ReportDocument).initialize(t),e;return null},
isDefaultFiltersAvailable(){var t=this.getOptionsSync();
return!!t&&"true"===this.reportDoc.getDefaultFiltersAvailable(t)},getReportXml(
){return this.reportDoc.getXml()},getReportFormat(){
return this.reportDoc.getReportOption("reportTypeEnum")},
getModelAnnotationsJson(){return S.stringify(this.modelAnnotations)},
getReportPDF(t){t&&!this.isVisualizationPrintable("PDF")||(
this.saveUIAttributes(),cv.io.getReportInFormat(this,"PDF"))},getReportExcel(t){
t&&!this.isVisualizationPrintable("EXCEL")||(this.saveUIAttributes(),
cv.io.getReportInFormat(this,"EXCEL"))},getReportCSV(){this.saveUIAttributes(),
cv.io.getReportInFormat(this,"CSV")},showProgressDownloadPane(){
this.statusBar.innerHTML="",this.downloadCount+=1;const t=this.downloadCount;
this.showProgressPane(!0),setTimeout(()=>{cv.getActiveReport(
).downloadCount===t&&cv.getActiveReport().hideProgressPane()},5e3)},
showProgressPane(e){this.reportBeCanceled=!1;var i=C.byId("progressPane");if(i){
let t=`
          <div style='float:left' id='progressTooltipDiv'>
            <div class='refresh-icon vertical-align-middle'></div>
            <div style='float:left'>
              &nbsp;&nbsp;${e?cvCatalog.progressExporting:cvCatalog.refreshing}&nbsp;&nbsp;
            </div>
          </div>`;e||(
t+="<div id='progressPaneCancel' class='button-cancel vertical-align-middle'></div>"
),i.innerHTML=t,cv.util.show(i);i=cv.util.getFirstChildByClass(C.byId(
"refreshTooltip"),"progressPaneHeaderLabel");if(null!=i&&(i.innerHTML=`
            <span class='refresh-icon vertical-align-middle'></span>
            &nbsp;&nbsp;
            <b>${e?cvCatalog.progressExporting:cvCatalog.refreshing}</b>`),e||s(
C.byId("progressPaneCancel"),"click",o.hitch(this,"cancelReport")),!cv.isMobile(
)){m.add(C.byId("refreshHeader"),"progressPaneUp"),m.add(C.byId("refreshAction")
,"progressPaneContent"),m.add(C.byId("refreshFooter"),"progressPaneDown");
var i=cv.util.getDojoWidget("refreshTooltip"),r=null;if(i._setConnectIdAttr(
"progressTooltipDiv"),r=cv.util.getFirstChildByClass(i.domNode,
"progressPaneContent"),this.HISTORY_ACTION_LIST="",e)this.HISTORY_ACTION_LIST+=`
            <div style='font-size:11px;width:210px;'>
              ${cvCatalog.progressExportingMessage}
            </div>`;else for(
let t=this.pendingActionLen;t<this.actionLog.length;t+=1
)this.HISTORY_ACTION_LIST+=`<div style='font-size:11px;width:210px;'>${this.actionLog[
t]}</div>`;r&&(r.innerHTML=this.HISTORY_ACTION_LIST)}}},_fadeInRefreshReport(){
e.fadeIn({duration:3*cv.prefs.fadeTime,node:this.nodeReportArea}).play()},
hideProgressPane(){this.log(null,!0);let t="";var e=C.byId("progressPane");e&&(
cv.util.getDojoWidget("refreshTooltip").close(),this.reportBeCanceled&&(
t=cv.util.substituteParams(cvCatalog.refreshPanelCancel,
cvCatalog.refreshPanelCancelMsg)),e.innerHTML=t,
this.reportBeCanceled||cv.util.hide(e))},getReportProperties(){var t={};for(
const i of this.reportDoc.reportProps){var e=this.reportDoc.getReportProperty(i)
t[i]=null!=e?e:""}return t},setReportProperties(t){for(const e in t
)this.reportDoc.setReportProperty(e,t[e]);this.setReportPropsDirty(!0)},
toggleActionsPopupMenu(t){var e,i,r;cv.util.getDojoWidget("reportFormatMenu")&&(
e=cv.util.getDojoWidget("actionsMenu"))&&(this.isReportFormatPivot()?(
cv.util.setVizMenuItemSelected("PIVOT",!0),cv.util.setVizMenuItemSelected(
this.chartMenuItem,!1)):(cv.util.setVizMenuItemSelected(this.chartMenuItem,!0),
cv.util.setVizMenuItemSelected("PIVOT",!1)),cv.util.setMenuItem(
"cmdGrandTotalRow","true"===this.reportDoc.getReportOption("showRowGrandTotal"
)?"checked":"none"),cv.util.setMenuItem("cmdGrandTotalCol",
"true"===this.reportDoc.getReportOption("showColumnGrandTotal")?"checked":"none"
),this.isReportFormatPivot()?cv.util.setMenuItem("cmdReportWordWrap",
this.wordWrap?"checked":"none","enabled"):cv.util.setMenuItem(
"cmdReportWordWrap","none","disabled"),i=this.byId("CmdActions"),r=y.position(i,
!0),cv.util.showPopupMenu(e,r.x+60,r.y+13,i),u.stop(t))},toggleGrandTotalRow(){
this.reportDoc.setReportOption("showRowGrandTotal",
"true"===this.reportDoc.getReportOption("showRowGrandTotal")?"false":"true"),
this.history.add(new cv.ReportState("actionReportOptions")),this.refreshReport()
},toggleGrandTotalCol(){this.reportDoc.setReportOption("showColumnGrandTotal",
"true"===this.reportDoc.getReportOption("showColumnGrandTotal")?"false":"true"),
this.history.add(new cv.ReportState("actionReportOptions")),this.refreshReport()
},toggleChartTypePopupMenu(t){var e,i,r=cv.util.getDojoWidget("chartTypeMenu");
r&&(cv.util.setVizMenuItemSelected(this.chartMenuItem,!0),e=C.byId(
"cmdSelectChartType"),i=y.position(e,!0),cv.util.showPopupMenu(r,i.x+5,i.y+13,e)
,u.stop(t))},toggleReportFormat(t){let e;var i=this.getReportFormat();let r=null
if(t&&t.target)for(r=t.target;!r.id;)r=r.parentNode;if("PIVOT"===i){if(
r&&0<=r.id.indexOf("CmdShowPivot"))return;this.reportDoc.getChartOption(
"chartType");t=this.reportDoc.getChartOption("customChartType");
this.history.updateReportUsingPreviousChartTypeState(this,t),this._initDisplay(
"JSON","CUSTOM",t),e="actionShowChart"}else{if(r&&0<=r.id.indexOf("CmdShowChart"
))return;this._initDisplay("PIVOT"),e="actionShowPivot"}this.history.add(
new cv.ReportState(e)),this.refreshReport()},setAutoRefresh(t,e){
cv.prefs.autoRefresh=t,this.reportDoc.setReportOption("autoRefresh",
t?"true":"false"),t||!this.isInitialized||e||this.showLayoutPanel()},
showLayoutPanel(){this.manager&&!cv.util.isShowing("layoutPanelWrapper"
)&&this.toggleReportPane("cmdLayout")},populateDropZone(e){
var i=this.reportDoc.getChildMembers(e);for(let t=0;i&&t<i.length;t++
)this.createGemDomNode(i[t],e)},populateFilters(){
var i=this.reportDoc.getChildMembers("filters"),
r=this.reportDoc.getSelectionFilters();let s=0;if(this.timeUnlimited=!0,
this.gemList.getValueList().forEach(t=>{
t.type===cvConst.TYPE_FILTER&&this._removeGemObjectById(t.getId())}),
this._extraFiltersHandles.remove(),I.empty(this.nodeFilters),
0===i.length&&0===r.length)this.nodeFilters.innerHTML=cvCatalog[
"EDIT"===this.mode?"filterSummZoneHint":"filterSummZoneNone"];else{let t,e;
var o=[],a=[];for(t=0;t<i.length;t++)i[t].selectSingleNode(
"cv:predicates/cv:predicate")?(e=this.createGemDomNode(i[t],"filters"))&&(
cv.getFieldHelp().isTimeAttribute(e.getFormula())?o:a).push(e
):this.reportDoc.removeEmptyFilter(i[t]);if(0<o.length)for(this.timeUnlimited=!1
,t=0;t<o.length;t++)this.nodeFilters.appendChild(o[t].domNode),s+=o[t].itemCount
if(0<a.length)for(t=0;t<a.length;t++)this.nodeFilters.appendChild(a[t].domNode),
s+=a[t].itemCount;0<r.length&&(this.nodeFilters.appendChild(
this._createSelectionFilterNode()),s+=1),(e=this.createMetricFilterGem())&&(
this.nodeFilters.appendChild(e.domNode),s+=1)}r=this.byId("FilterCountLabel");
if(r&&(r.innerHTML=0===s?cvCatalog.filterTitleNone:cv.util.substituteParams(
1<s?cvCatalog.filterTitlePlural:cvCatalog.filterTitleSingular,""+s)),
this.dropTargets.filters&&this.dropTargets.filters.sync(),this.isEditDisabled()
){var e=document.getElementsByClassName("filterAction pentaho-deletebutton");
for(let t=0;t<e.length;t++)e[t].style.display="none";document.getElementById(
"remove_filter_metric")&&(document.getElementById("remove_filter_metric"
).style.display="none")}this.updateDefaultFilterIcon()},
_createSelectionFilterNode(){var t=I.create("div",{
innerHTML:cvCatalog.filterTemplateSelection}).firstChild,e=t.querySelector(
".remove-filter-button");return e&&this._extraFiltersHandles.add(s(e,"click",
o.hitch(this,"_onRemoveSelectionFilters")),P.makeAccessibleActionButton(e)),t},
showEditDialogOnColumnHeader(e){if(
"EDIT"===this.mode&&"member"!==e.target.parentNode.getAttribute("type")){let t;
if(e.target.parentNode.parentNode&&(
t=e.target.parentNode.parentNode.getAttribute("formula")),
this.currentSelection=this.getGem(e.target.getAttribute("formula"
)||e.target.parentNode.getAttribute("formula")||t),this.currentSelection){
let t="attribute";"EXPRESSION"===(
t=this.currentSelection.type===cvConst.TYPE_METRIC?this.currentSelection.metricType:t
)?this.rptDlg.showEditArithMeasure(
):"PCTOF"===t||"RANK"===t||"RSUM"===t||"PCTRSUM"===t?this.rptDlg.showEditSummaryMeasure(
):"VALUE"===t||"attribute"===t?this.rptDlg.showEditColumn(
):"TREND"===t&&this.rptDlg.showEditTrendMeasure()}}},showHelpDlg(){
var t=this.currentSelection.metricType&&"VALUE"!==this.currentSelection.metricType?this.currentSelection.getBaseFieldFormula(
):this.currentSelection.getFormula();t&&0!==t.indexOf("[MEASURE:"
)&&cv.getFieldHelp().showDlg(t)},showPropHelpDlg(){this.rptDlg.show("show",
"propHelp")},resize(){const t=this.domNode.parentNode.offsetWidth,
e=this.domNode.parentNode.offsetHeight;this.domNode.style.width=t+"px",
this.domNode.style.height=e+"px";var i,r=this.byId("filters");r&&(
o=y.getMarginBox(this.byId("HideFilterPane")).w,i=y.getMarginBox(this.byId(
"HelpFilterPane")).w,r.style.width=r.offsetWidth-o-i+"px");let s=e;r=this.byId(
"ReportSummary");if(r&&(s-=y.position(r).h),(
s-="filterPane"===this.topPaneId?y.position(this.nodeFilter).h:0)<=0)return!1;
if(this.reportWidth===t&&this.reportHeight===s)return!1;this.reportWidth=t,
this.reportHeight=s,this.nodeReportArea.style.width=t+"px",
this.nodeReportArea.style.height=s+"px";var o=this.byId("ReportEmpty");o&&(
o.style.height=s+"px"),this.reportHeaders&&this.reportHeaders.updateLayout();
const a=this.byId("Trashcan");return a&&setTimeout(()=>{a.style.top=e-140+"px",
a.style.left=t-130+"px"},200),this.vizDiv&&(
this.vizDiv.style.height=this.reportHeight+"px",
this.vizDiv.style.width=this.reportWidth+"px",T.publish("/Analyzer/resize",
this.reportHeight,this.reportWidth)),this.setReportName(),!0},setReportName(t){
if(this.byId("ReportName")){try{if(window.parent&&window.parent.PentahoMobile
)return;if(window.parent&&window.parent.mantle_initialized)return}catch(t){}t&&(
this.byId("ReportName").innerHTML=cv.util.escapeHtml(t));t=(y.position(
this.byId("ReportSummary")).w-y.position(this.byId("ReportName")).w)/2;
this.byId("ReportName").style.left=t+"px"}},resizeContainer(){
return this.manager.resize()},addOptionsForAllMeasures(e,i,t,r,s){
s=s&&cv.api.util._hasInlineModelingPermission()&&!cv.getFieldHelp(
).disableInlineModeling;let o=[];var a,n=[];let l,h;const d={};
let c=this.reportDoc.getMetrics(),p=0;var u={};for(l=0;l<c.length;l++){if(
"VALUE"===c[l].getAttribute("measureTypeEnum"))u[h=c[l].getAttribute("formula")
]=!r;else if(h=c[l].getAttribute("id"),t&&h===t){p+=1;continue}o.push(h)}
const g={};function m(t,e){return d[e]||(g[t]?(g[t]+=1,m(t+"_"+g[t],h)):(g[t]=1,
t))}var v=c.length-p,f=cv.getFieldHelp();for(c=f.getMeasureList(),
l=0;l<c.length;l++)a=c[l].getAttribute("formula"),f.isHidden(c[l])&&!s||u[a]||(
n.push(a),d[a]=m(this.getFieldLabel(a,!0),a));if(0===o.length&&0===n.length
)return!1;for(n.sort(function(t,e){return d[t]>d[e]?1:d[t]<d[e]?-1:0}),
o=o.concat(n),e.innerHTML="",l=0;l<o.length;l++){l===v&&r&&(R=new Option(
"-------------------------------------------------------",""),cv.addOption(e,R))
let t=l<v?m(this.getFieldLabel(o[l],!0),o[l]):d[o[l]];i&&(t=t.replace(/\]/g,
"\\]"));var R=new Option(t,o[l]);R.setAttribute("title",t),cv.addOption(e,R)}
return!0},addOptionsForAttributes(t,e){var i=[];let r;var s=e?1:0;
let o=this.reportDoc.getChildMembers("columnAttributes");for(
r=0;r<o.length-s;r++)i.push(o[r]);for(o=this.reportDoc.getChildMembers(
"rowAttributes"),r=0;r<o.length-s;r++)i.push(o[r]);if(0===i.length)return!1;
t.innerHTML="";let a=!1;for(r=i.length-1;0<=r;--r){var n=i[r].getAttribute(
"formula"),l=this.getFieldLabel(n,!0),n=new Option(l,n);n.setAttribute("title",l
),cv.addOption(t,n),a=a||!0}return a},showFilterDlg(){if(!this.isEditDisabled()
){var i,r=this.currentSelection;if(r){let t,e=(r.getAttribute?t=r.getAttribute(
"formula"):r.getFormula&&(t=r.getFormula()),r)["id"];e||t?0===e?.indexOf(
"filter_")?(i=e.startsWith("filter_metric"),this.reportDoc.isDefaultFilter(t,i
)&&(this.banner.fixedMessage=cvCatalog.bannerEditDefaultFilter),
this.filterDlg.show(e)):t&&(this.reportDoc.isDefaultFilter(t,!1)&&(
this.banner.fixedMessage=cvCatalog.bannerEditDefaultFilter),
this.rptDlg.showFilterList(t)):(t=r.parentNode.getAttribute("formula"))&&(i=(
e=r.parentNode.getAttribute("id"))?.startsWith("filter_metric")??!1,
this.reportDoc.isDefaultFilter(t,i)&&(
this.banner.fixedMessage=cvCatalog.bannerEditDefaultFilter),
this.rptDlg.showFilterList(t))}}},showNewFilterDlg(){var t,
e=this.currentSelection;e&&(t=this.getGem(e.parentNode.id))&&(e=e.id.startsWith(
"filter_metric"),this.reportDoc.isDefaultFilter(t.getFormula(),e)&&(
this.banner.fixedMessage=cvCatalog.bannerEditDefaultFilter),this.filterDlg.show(
t.getFormula()))},showFilterDlgCondition(){var t=this.currentSelection;t&&(
this.reportDoc.isDefaultFilter(t.getFormula(),!0)&&(
this.banner.fixedMessage=cvCatalog.bannerEditDefaultFilter),
this.filterDlg.showMetricFilter(t.getFormula(),"CONDITIONS"))},
showFilterDlgRank(){var t=this.currentSelection;t&&(
this.reportDoc.isDefaultFilter(t.getFormula(),!0)&&(
this.banner.fixedMessage=cvCatalog.bannerEditDefaultFilter),
this.filterDlg.showMetricFilter(t.getFormula(),"RANK"))},isDirty(){
return this.isReportPropsDirty||this.history.isStateDirty()},isEmpty(){
return this.reportDoc.isEmpty()},isEditDisabled(){
return"VIEW"===this.mode&&cv.analyzerProperties["report.viewer.edit.disable"]},
_revertToLastSuccessState(){this.history.setTo(this.successState),
this.successState&&this.successState.exec(!0),
cv.prefs.autoRefresh&&this.history.setRefreshed(!1),
this.history.isStateRefreshed()||cv.util.show(this.nodeReportRefresh),T.publish(
"/analyzer/reportDisplayed",this),this.log(cvCatalog.actionCancel,!0)},
_initRptTypeButtons(t){var e,i,r;C.byId("reportBtns")&&"EDIT"===this.mode&&(
e=C.byId("cmdShowPivot"),i=C.byId("cmdShowChart"),r=C.byId("cmdSelectChartType")
,"PIVOT"===t?(m.add(e,"reportDisplayFormatPressed"),e.setAttribute(
"aria-pressed","true"),m.remove(i,"reportDisplayFormatPressed"),i.setAttribute(
"aria-pressed","false"),r.title=cvCatalog.titleShowChartTypeTT):(m.add(i,
"reportDisplayFormatPressed"),i.setAttribute("aria-pressed","true"),m.remove(e,
"reportDisplayFormatPressed"),e.setAttribute("aria-pressed","false"),
r.title=cvCatalog.titleSwitchChartTypeTT))},_checkBadFields(t){if(
0<this.badFields.length){let i="";for(let t=0,e=this.badFields.length;t<e;t++
)i+=`	${this.badFields[t]}
`;var e=cv.util.substituteParams(cvCatalog.warnMissingFields,i);t||alert(e),
this.setReportPropsDirty(!0)}},_validateMaxValue(t){var e;"PIVOT"!==t&&(
t=this.reportDoc.getChartOption("maxValues"),e=this._getVizApplicationSpec()[
"maxValues"],e=cv.api.util._findClosestValueFromArray(e,t),
this.reportDoc.setChartOption("maxValues",e))},_initDisplay(t,e,i,r){var s=this[
"reportDoc"],o=(t=t||this.getReportFormat(),e=e||s.getChartOption("chartType"),
s.getChartOption("customChartType")),o=((i=i||o)!==o?this.savePluginDataToXML(
"[]"):(o=this.vizModelType
)&&"analyzer_PIVOT"!==o.v2Id&&this.savePluginDataToXML(this.getPluginDataJSON())
,s.setReportOption("reportTypeEnum",t),s.setChartOption("chartType",e),
s.setChartOption("customChartType",i||""),this._initClientViz()),a=(null!=o&&(
this._handleInitClientVizError(o),this.reportDoc.setReportOption(
"reportTypeEnum",t="PIVOT"),this._initClientViz()),
"PIVOT"!==t&&this.hasVizModel&&(e=this.isLegacyViz()?"2.0":"3.0",
s.setChartOption("vizApiVersion",e)),this._initRptTypeButtons(t),
this.clearGemList(),this.populateDropZone("measures"),this.populateDropZone(
"rowAttributes"),this.populateDropZone("columnAttributes"),this.populateFilters(
),this.isEditDisabled()&&(document.getElementById("PM:sprBeforeRemove"
).style.display="none",document.getElementById("PM:removeAttr"
).style.display="none",document.getElementById("PM:removeMetric"
).style.display="none",document.getElementById("PM:removeFilter"
).style.display="none"),this.reportDoc.getDrillColumns());for(
let t=0;t<a.length;t++){var n=a[t],l=cv.textContent(n);this.validateField(l
)||cv.util.removeNode(n)}this._checkBadFields(r),this._syncVizModelFromReport(),
this._validateMaxValue(t),this.validateLayoutState()},onGemToggleInChart(){var t
,e,i=this.currentSelection;i&&(t=!i.isHideInChart(),i.setHideInChart(t),
e="JSON"===this.getReportFormat(),this.history.add(new cv.ReportState(
t?"actionHide":"actionShow",i.getDisplayLabel(!0))),this.setVizModelRolesDirty()
,e)&&this.refreshReport()},onGemSortDesc(){this.setSortOrder(null,"DESC",!0)},
onGemSortAsc(){this.setSortOrder(null,"ASC",!0)},onToggleSort(t){
this.headerClicked?(this.headerClicked=!1,clearTimeout(this.headerTimeout)):(
this.headerClicked=!0,this.headerTimeout=setTimeout(o.hitch(this,
"onToggleSortHandler",t),300))},onToggleSortHandler(t){this.headerClicked=!1;
t=this.findTableCell(t.target);this.currentSelection=this.getGem(t.getAttribute(
"formula")),m.contains(t,"sortInactive")?(cv.util.popupSourceNode=t,
this.onGemSortAsc()):m.contains(t,"sortActiveAsc")?this.onGemSortDesc(
):this.onGemSortAsc()},onShowEditDialogOnColumnHeader(t){
cv.api.event.isEventDisabled("doubleClick")||this.showEditDialogOnColumnHeader(t
)},onGemConditionalFormatting(e){var e=(e.target.parentNode.id||e.target.id
).substr("PM:condFormat_".length),i=this.currentSelection;if(i){
var r=i.getNumberFormat();let t;t=r.formatShortcut==e?(i.setNumberFormat({
formatShortcut:"NONE"}),"actionRemoveCondFormat"):(i.setNumberFormat({
formatShortcut:e}),"actionAddCondFormat"),this.history.add(new cv.ReportState(t,
i.getDisplayLabel(!0))),this.refreshReport()}},onGemToggleSubtotal(){var t,
e=this.currentSelection;e&&(t="true"===e.xmlNode.getAttribute("showSubtotal"
)?"false":"true",e.xmlNode.setAttribute("showSubtotal",t),this.history.add(
new cv.ReportState("true"==t?"actionShowSubtotal":"actionHideSubtotal",
e.getDisplayLabel(!0))),this.refreshReport())},onRptExclude(){
this.updateInTableFilter("EXCLUDE"),this.setReportPropsDirty(!0)},onRptKeep(){
this.updateInTableFilter("KEEP"),this.setReportPropsDirty(!0)},
onRptKeepAndDrillDown(){this.updateInTableFilter("KEEP_AND_DRILL"),
this.setReportPropsDirty(!0)},onRptDrillDown(){this.updateInTableFilter(
"DRILL_DOWN"),this.setReportPropsDirty(!0)},onRptDrillUp(){
this.updateInTableFilter("DRILL_UP"),this.setReportPropsDirty(!0)},onRptShowAll(
){this.updateInTableFilter("SHOW_ALL"),this.setReportPropsDirty(!0)},
onRptNonVisualTotal(){this.reportDoc.setReportOption("useNonVisualTotals",
"true"===this.reportDoc.getReportOption("useNonVisualTotals")?"false":"true"),
this.history.add(new cv.ReportState("actionNonVisual")),this.refreshReport()},
onRptHideGrandTotal(){var t=this.currentSelection;m.contains(
cv.util.getAncestorByTag(t,"TABLE"),"ZONE_columnAttributes"
)?this.reportDoc.setReportOption("showRowGrandTotal","false"
):this.reportDoc.setReportOption("showColumnGrandTotal","false"),
this.history.add(new cv.ReportState("actionHideGrandTotal")),this.refreshReport(
)},onResetReport(){cv.util.goToURL(window.location)},onResetColumnSize(){
this.columnDataFieldWidths=[],this.rowFieldWidths=[],
this.reportHeaders.updateLayout(),this.isReportPropsDirty=!0,this.resizeRows();
var t=new cv.ReportState("Reset Column Sizes"),e=(t.resizeData={rowFieldWidths:[
...this.rowFieldWidths],columnDataFieldWidths:[...this.columnDataFieldWidths]},
this.history.isStateRefreshed());this.history.add(t),
e&&this.history.setRefreshed(!0)},onToggleReportPane(t){let e=t.target;for(
;!e.id;)e=e.parentNode;t=e.id.substring(this.id.length);if(
this.toggleReportPane(t,{restoreFocus:!0}))return!1},toggleReportPane(t,e){
return this.manager.toggleReportPane(t,e)},hideTruncateMessage(t){
"closeRowTruncate"===t.target.id?(cv.util.hide(this.nodeRowTruncate),
"None"===this.closeTruncateStatus?this.closeTruncateStatus="RowClose":this.closeTruncateStatus="BothClose"
):"closeColTruncate"===t.target.id?(cv.util.hide(this.nodeColTruncate),
"None"===this.closeTruncateStatus?this.closeTruncateStatus="ColClose":this.closeTruncateStatus="BothClose"
):"closeTransTruncate"===t.target.id&&cv.api.ui.isFromTransformation?(
cv.util.hide(this.nodeTransTruncate),this.closeTruncateStatus="BothClose"
):"closeChartInfo"===t.target.id&&cv.util.hide(this.nodeChartInfo)},
getAttributeGemValues(){return this.gemList.getValueList().filter(({xmlNode:t}
)=>"attribute"===t.nodeName)},onSetDefaultFilter(){var t=this.getFiltersSummary(
this.nodeFilters).join("");this.rptDlg.showConfirm(["promptSetDefaultFilters",t]
,null,{srcFunc:()=>{this._query(".filterItem",this.nodeFilters).forEach(t=>{
this.reportDoc.updateIsDefaultFilter(t.getAttribute("formula"),!0,!0)}),
this.updateDefaultFilterIcon(),this.setOptions("FILTER")}})},_getFilterIcons(t,e
){let i;e=`[id="${i=e?"prefilter_metric_"+t:"prefilter_"+t}"]`;
return this._query(e,this.nodeFilters)},updateDefaultFilterIcon(){
const e=this.reportDoc.getMetricFilter();var t;e&&(t=e.formula,
this._getFilterIcons(t,!0).forEach(t=>{
"true"===e.isDefaultMetricFilter?cv.util.show(t):cv.util.hide(t)})),this._query(
".filterItem",this.nodeFilters).forEach(t=>{const e=this.reportDoc.getFilter(
t.getAttribute("formula"));e&&this._getFilterIcons(e.getAttribute("formula"),!1
).forEach(t=>{"true"===e.getAttribute("isDefaultFilter")?cv.util.show(t
):cv.util.hide(t)})})},onResetDefaultFilter(){this.getOptions("FILTER")},
onRemoveDefaultFilter(){this.getOptions("FILTER_REMOVE")},onToggleWordWrap(){
const e=!this.wordWrap;this.getAttributeGemValues().forEach(({xmlNode:t})=>{
t.setAttribute("wordWrap",""+e)});var t=(this.wordWrap=e
)?"actionAddReportWordWrap":"actionRemoveReportWordWrap";this.history.add(
new cv.ReportState(t)),this.resizeRows()},onGemToggleWordWrap(){var t,
e=this.currentSelection;e&&(t=!e.isWordWrap(),e.xmlNode.setAttribute("wordWrap",
""+t),this.wordWrap=t||this.getAttributeGemValues().some(t=>t.isWordWrap()),
this.history.add(new cv.ReportState(t?"actionAddWordWrap":"actionRemoveWordWrap"
,e.getDisplayLabel(!0))),this.resizeRows())},_changeGemWordWrap(e){var t,i;e&&(
i=`td[type='member'][formula="${e.getFormula()}"]`,t=this._query(i,
this.reportHeaders.rowLabelContainer),i=this._query(i,
this.reportHeaders.columnHeaderContainer),t.concat(i).forEach(t=>{e.isWordWrap(
)?m.add(t,"wordWrap"):m.remove(t,"wordWrap")}))},_changeRowHeight(t){
const i=this.reportHeaders.dataContainer.getElementsByTagName("tr");if(!0===t
)this._query("tr",this.reportHeaders.rowLabelContainer).forEach((t,e)=>{e=i[e];
e&&(e.style.height=t.getBoundingClientRect().height+"px")});else for(
let t=0;t<i.length;t++)i[t].style.height=null},resizeRows(){if(
this.reportHeaders&&this.gemList.count){let e=!1;this.gemList.getValueList(
).forEach(t=>{t.type===cvConst.TYPE_ATTRIBUTE&&(this._changeGemWordWrap(t),
t.isWordWrap())&&(e=!0)}),this._changeRowHeight(e)}}});return(
cv.Report.prototype.cv=cv).Report.prototype.cvConst=cvConst,
cv.Report.prototype.cvCatalog=cvCatalog,t("cv.ReportState",[],{constructor(t,e,i
){this.action=t,this.label=t&&e?cv.util.substituteParams(cvCatalog[t],
cv.util.escapeHtml(e)):cvCatalog[t],this.label||(this.label=t),this.actionCtx=i,
this.ended=!1},pluginDataJSON:"",customChartType:null,resizeData:{},init(t){
this.report=t,this.reportXml||(this.reportXml=r.innerXML(
t.reportDoc.getReportNode())),this.updatePluginState(),
this.reportTypeEnum=t.reportDoc.getReportOption("reportTypeEnum"),
this.chartType=t.reportDoc.getChartOption("chartType"),
this.customChartType=t.reportDoc.getChartOption("customChartType"),
this.resizeData.rowFieldWidths=this.report.rowFieldWidths.slice(0,
this.report.rowFieldWidths.length),
this.resizeData.columnDataFieldWidths=this.report.columnDataFieldWidths.slice(0,
this.report.columnDataFieldWidths.length),
this.modelAnnotations=this.report.modelAnnotations.slice(0,
this.report.modelAnnotations.length),"Column Resize"!==this.action&&t.log(
this.label)},end(){this.ended||(this.ended=!0,this.report.isLegacyViz()
)||this.updatePluginState()},checkRefresh(){
cv.prefs.autoRefresh?this.report.history.setRefreshed(
):this.report.refreshReport()},exec(t,e){var i=cv.parseXML(this.reportXml);
i&&i.documentElement&&(this.ended=!1,"UNDO"===e&&"Column Resize"===this.action?(
this.report.reportHeaders.updateLayout(this.resizeData.index,-this.resizeData.dx
,this.resizeData.colspan),this.checkRefresh()
):"REDO"===e&&"Column Resize"===this.action?(
this.report.reportHeaders.updateLayout(this.resizeData.index,this.resizeData.dx,
this.resizeData.colspan),this.checkRefresh()):(
this.report.columnDataFieldWidths=this.resizeData.columnDataFieldWidths.slice(0,
this.resizeData.columnDataFieldWidths.length),
this.report.rowFieldWidths=this.resizeData.rowFieldWidths.slice(0,
this.resizeData.rowFieldWidths.length),
this.report.modelAnnotations.length!==this.modelAnnotations.length&&(
this.report.modelAnnotations=this.modelAnnotations.slice(0,
this.modelAnnotations.length),this.report.manager.updateCatalog()),
this.report.savePluginDataToXML(this.pluginDataJSON),
this.report._clearClientViz(),this.report.openReport(i.documentElement),
t||this.report.refreshReport(!1,!0)))},back(t){(
this.report.mode&&"VIEW"===this.report.mode||this.report.manager.cmdUndo.title.indexOf(
"Column")<0)&&this.report.log("UNDO"),this.exec(t,"UNDO")},forward(t){(
this.report.mode&&"VIEW"===this.report.mode||this.report.manager.cmdRedo.title.indexOf(
"Column")<0)&&this.report.log("REDO"),this.exec(t,"REDO")},copy(t){
this.reportXml=t.reportXml},setPluginDataJSON(t){this.pluginDataJSON=t},
updatePluginState(){var t=this.report.vizModelType;
t&&"analyzer_PIVOT"!==t.v2Id&&this.setPluginDataJSON(
this.report.getPluginDataJSON())}}),f});define("pentaho/analyzer/report/cv_rptReport.viz",["./cv_rptReport",
"dojo/_base/lang","dojox/xml/parser","dojo/json","dojo/_base/array",
"../LayoutPanel","pentaho/common/propertiesPanel/Configuration",
"pentaho/data/Table","pentaho/type/action/Transaction","pentaho/util/object",
"pentaho/visual/role/adaptation/IdentityStrategy",
"pentaho/visual/role/adaptation/TupleStrategy","../visual/dataFilterUtils",
"../visual/utils","pentaho/visual/util","pentaho/theme/service",
"pentaho/common/Messages","common-ui/vizapi/Events",
"common-ui/vizapi/VizController","common-ui/vizapi/DataTable"],function(e,t,i,r,
n,o,s,l,a,c,p,u,h,d,v,z,_){var g="incompatible-stock-viz",
V="missing-visual-model";Object.defineProperty(cv.Report.prototype,
"vizModelType",{get:function(){var e=this._vizModel;return e&&e.$type}}),
Object.defineProperty(cv.Report.prototype,"hasVizModel",{get:function(){
return null!=this._vizModel}}),Object.defineProperty(cv.Report.prototype,
"vizModel",{get:function(){return this._syncVizModelRolesFromReport(),
this._vizModel}}),Object.defineProperty(cv.Report.prototype,"vizModelAdapter",{
get:function(){return this._syncVizModelRolesFromReport(),this._vizModelAdapter}
}),Object.defineProperty(cv.Report.prototype,"vizView",{get:function(){
return this._vizView&&this._syncVizModelRolesFromReport(),this._vizView}}),
t.extend(cv.Report,{_constructViz:function(){this.visualizationController=null,
this.visualization=null,this.highlights=null,pentaho.palettes.splice(0,0,{
name:"palette analyzer",colors:cv.analyzerProperties["chart.series.colors"]}),
this._vizModel=null,this._vizModelAdapter=null,this._vizView=null,
this._promiseVizClassesEntering=null,this._scrollSize=18,
this._vizContainerId="VIZFRAME",this._isVizModelRolesDirty=!0,
this._isVizViewConfigDirty=!1,this._vizPropsImplied=null},
setVizModelRolesDirty:function(){this._isVizModelRolesDirty=!0},
setVizViewConfigDirty:function(){this._isVizViewConfigDirty=!0},
_loadVizRegistryAsync:function(){return cv.api.ui._visualRegistry.loadAsync(
).then(function(){})},isClientSideViz:function(){
return"JSON"==this.getReportFormat()&&"CUSTOM"==this.reportDoc.getChartOption(
"chartType")},isLegacyViz:function(){var e=this.vizModelType;return!(
!e||!e.v2Spec)},_getVizApplicationSpec:function(){var e=this.vizModelType,i=null
return null!=(i=null!=e?d.getVizOptionsAnnotation(e.id):i)?i:{}},
getVizMultiChartMaxList:function(){if(null!=this._vizModel){
var e=d.getVizOptionsAnnotation(this.vizModelType);if(
null!=e&&null!=e.getMultiChartMaxList){e=e.getMultiChartMaxList(this._vizModel);
if(null!=e)return e}}e=cv.analyzerProperties["chart.options.multiChartMaxList"];
return e?e.split(/\s*,\s*/).map(function(e){return parseInt(e,10)}):[50,100,150,
200,250]},_getVizHelper:function(){var e=this.vizModelType,
i=cv.pentahoVisualizationHelpers[e.id];return(
i=!i&&e.v2Spec?cv.pentahoVisualizationHelpers[e.v2Id]:i)||null},
isVisualizationPrintable:function(e){var i;return this.isClientSideViz()?(i=(
i=this.vizModelType).v2Spec?i.v2Id:i.id,"true"==cv.io.ajaxLoad(
"service/checkPrintAvailable",{vizId:i},!0)||(setTimeout(function(){
cv.getActiveReport().rptDlg.showConfirm("CANNOT_PRINT_VIZ",null,{
srcFunc:function(){"PDF"==e?cv.getActiveReport().getReportPDF(
):cv.getActiveReport().getReportExcel()}})},500),!1)):this.isReportFormatPivot()
},getVizDataReq:function(){return this.vizModelType.v2Spec.dataReqs[0].reqs},
getVizDefiniton:function(){return this.visualization},_initClientViz:function(){
this._clearClientViz();var e=this.isReportFormatPivot(),
i=!e&&this.isClientSideViz();if(e||i){var i=i?this.reportDoc.getChartOption(
"customChartType"):"analyzer_PIVOT",t=cv.api.ui._visualRegistry.get(i);if(!t
)return this._createMissingVisualModelError(i);var r=t.type,n=!!r.v2Spec;if(!n){
var o=d.getVizOptionsAnnotation(r.id);if(
o&&o.isStockVisualization&&2===cv.vizApiVersion
)return this._createIncompatibleStockVizError()}o=this._getStoredVizSpec();n&&(
this.visualization=this._createLegacyViz(r.v2Spec,o),o=o&&o.args),(o=o||{}
).isAutoUpdate=!1,o.application={_:"pentaho/analyzer/visual/Application",cv:cv},
this._vizModel=new t(o),this._vizModelAdapter=this.__createVizModelAdapter(
this._vizModel),e||(n||this._prefetchVizClasses(),
cv.util.setVizMenuItemSelected(this.chartMenuItem,!1),this.chartMenuItem=i)}
return null},__createVizModelAdapter:function(e){var i=e.$type,t=require(
"pentaho/visual/ModelAdapter").extend({$type:{props:{model:{
valueType:e.constructor}}}});return!!i.v2Spec&&t.type.eachVisualRole(function(e
){e.strategies=[p,u]}),new t({model:e})},_prefetchVizClasses:function(){
var e=this._vizModel.$type.id;
return this._promiseVizClassesEntering=Promise.all([
v.getModelAndDefaultViewClassesAsync(e),z.loadModuleThemeAsync(e)]).then(
function(e){return e[0]}),this._promiseVizClassesEntering},
_createLegacyViz:function(e,i){e=t.clone(e);return i&&(i.options&&t.mixin(
e.options||(e.options={}),i.options),i.args)&&t.mixin(e.args||(e.args={}),i.args
),e},_clearClientViz:function(){null!==this._vizModel&&(
this._vizModel.application=null),
this._vizModel=this._vizModelAdapter=this._vizPropsImplied=this.visualization=this._promiseVizClassesEntering=null
,this.setVizModelRolesDirty()},_createIncompatibleStockVizError:function(){
var e=_.getString("INCOMPATIBLE_STOCK_VIZ_ERROR"),e=new Error(e);return e.name=g
,e},_createMissingVisualModelError:function(e){e=_.getString(
"MISSING_VISUAL_MODEL_ERROR",e),e=new Error(e);return e.name=V,e},
_handleInitClientVizError:function(e){var i;switch(e.name){case g:i=_.getString(
"INCOMPATIBLE_STOCK_VIZ_ERROR_TITLE");break;case V:i=_.getString(
"MISSING_VISUAL_MODEL_ERROR_TITLE");break;default:i=_.getString(
"GENERIC_ERROR_TITLE")}this.rptDlg.showError(e.message,null,i)},
_disposeVizView:function(){null!=this._vizView&&(this._vizView.dispose(),
this._vizView=null)},_vizWillOverflow:function(e,i){
var t=this._getVizApplicationSpec();return t.willOverflow?t.willOverflow(
this._vizView,e,i):{vertical:!0,horizontal:!0}},
isRequiredGembarsFilled:function(){if(this.isClientSideViz()){
var e=this._getVizHelper();if(e&&e.canRefreshReport)return e.canRefreshReport(
this)}return this.vizModelAdapter.$isValid},
_restrictFilterToDrillOrder:function(e){return this.__restrictFilterToList(e,
"drillOrder")},_restrictFilterToSelectionRestriction:function(e){
return this.__restrictFilterToList(e,"selectionRestriction")},
__restrictFilterToList:function(e,i){var i=this._getVizApplicationSpec()[i];
return i?(i=this._getKeyFieldsMappedToViz(i),h.restrictFilter(e,i)):e},
_getKeyFieldsMappedToViz:function(e){var t,r,n=[];return e&&(t=cv.getFieldHelp()
,r=this.vizModelAdapter,e.forEach(function(e){var i,e=r.get(e);e&&e.hasFields&&(
i=[],e.fields.each(function(e){t.isAttribute(e.name)&&i.push(e.name)}),
n.push.apply(n,i))})),n},createSchemaDataTable:function(e){var i=null,t=null,o=(
null!=e&&("string"==typeof e?t=e:i=e),cv.getFieldHelp()),r=this.gemList,n=[];
return r.getKeyList().forEach(function(e){var i=r.item(e);(
i instanceof cv.AttributeGem||i instanceof cv.MetricGem)&&(null!==t&&e===t&&(
t=null),n.push(s(e,i.getFormula())))}),null!==(i=null!==t?s(t,t):i)&&n.push(i),
new l({model:n});function s(e,i){var t=null,r=o.isAttribute(i),
n=r?"string":"number",e=(r&&(o.hasStartDateTimeKey(i)?t={
EntityWithTimeIntervalKey:{duration:o.get(i,"duration"),
isStartDateTimeProvided:!0}}:o.hasNumberKey(i)&&(t={EntityWithNumberKey:{
isNumberProvided:!0}})),{name:e,type:n,isKey:r,p:t});return r&&(
e.hierarchyName=o.getHierarchyName(i),e.hierarchyOrdinal=o.getHierarchyOrdinal(i
)),e}},_syncVizModelFromReport:function(){var e=this._vizModelAdapter;if(e){
var i=e.model,t=i.$type,e=this.isClientSideViz(),
r=this._vizPropsImplied=e?this._generateVizPropsImplied():{};try{a.enter(
).using(function(e){
this._isVizModelRolesDirty&&this._syncVizModelRolesFromReportCore(),t.each(
function(e){t.isVisualRole(e)||(e=e.name,c.hasOwn(r,e)&&i.set(e,r[e]))}),
e.accept()},this)}catch(e){console.warn(
"Refreshing the visual model was rejected: "+e)}this._isVizModelRolesDirty=!1}},
_syncVizModelRolesFromReport:function(){if(
this._isVizModelRolesDirty&&this._vizModelAdapter){try{a.enter().using(function(
e){this._syncVizModelRolesFromReportCore(),e.accept()},this)}catch(e){
console.warn("Refreshing the visual model roles was rejected: "+e)}
this._isVizModelRolesDirty=!1}},_syncVizModelRolesFromReportCore:function(){
var e=this._vizModelAdapter;e.data=this.createSchemaDataTable(),
e.selectionFilter=null,this._vizModelAdapter.$type.eachVisualRole(function(e){
this._syncVizModelRoleFromReport(e.name)},this)},
_syncVizModelRoleFromReport:function(e){this._vizModelAdapter.get(e
).fields=this.findGemsByGembarId(e).map(function(e){return e.getId()})},
_generateVizPropsImplied:function(){var e,i=this._getVizHelper();
return i&&i.generateOptionsFromAnalyzerState?e=i.generateOptionsFromAnalyzerState(
this):(i=this._getVizApplicationSpec().generateOptionsFromAnalyzerState)&&(e=i(
this)),e||{}},_inferVizUsesChartOptions:function(){var e=this._getVizHelper(),
e=e&&e.generateOptionsFromAnalyzerState||this._getVizApplicationSpec(
).generateOptionsFromAnalyzerState;return Boolean(e)},
_getStoredVizSpec:function(){var e;return!this.isReportFormatPivot(
)&&this.isClientSideViz()&&(e=(e=this.reportDoc.getPluginDataJSON())?JSON.parse(
e):[]).length?e[0]:null},getPluginDataJSON:function(){this.isClientSideViz()&&(
this.isLegacyViz()?(t={},(e=this.visualization).args&&(t.args=e.args),
e.options&&(t.options=e.options),t.visualizationId=e.id):(e=this.vizModel)&&(
delete(t=e.toJSON()).width,delete t.height,this._vizPropsImplied&&c.eachOwn(
this._vizPropsImplied,function(e,i){delete t[i]}),e.$type.eachVisualRole(
function(e){delete t[e.name]})));var t,e=t?[t]:[];return r.stringify(e)}})});define("pentaho/analyzer/report/cv_rptReport2",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dijit/Menu","dijit/MenuItem",
"dijit/MenuSeparator","dojox/collections/Dictionary","dojox/xml/parser",
"dijit/Declaration","dojo/dom-class","dojo/_base/event","dojo/dom",
"dojo/_base/array","common-ui/util/_focus","./cv_rptReport"],(declare,on,query,
lang,Menu,MenuItem,MenuSeparator,Dictionary,parser,Declaration,domClass,event,
dom,array,focusUtil)=>{lang.extend(cv.Report,{appendGem(e,t){var r;return!(
!this.checkDuplicateGem(e)&&!this.isGemMetricValueAndUnmapped(this.getGem(e))
)&&(this._getGemsInHierarchy(e)?this.insertGemInHierarchy(e,t):(
r=cv.getFieldHelp().isAttribute(e),this.insertGem(e,r?"rowAttributes":"measures"
,"append",t)))},checkDuplicateGem(e,t){let r;var i=this.gemList.getKeyList();if(
!i||0===i.length)return!0;for(const o of i){var s=this.gemList.item(o);if(
o===e||s.type===cvConst.TYPE_METRIC&&"VALUE"===s.metricType&&s.getFormula()===e
){r=s;break}}return!r||(t||this.rptDlg.showError(["errorDuplicateItemInReport",
r.getDisplayLabel()],"CV/Business_User/working_with_fields.html"),!1)},
checkGemHierarchy(e,r,i,s,t){if("rowAttributes"!==e&&"columnAttributes"!==e
)return!0;var o=this._getGemsInHierarchy(r);if(!o||o[0].getZone()===e)return!0;
if(s){let t="";var l=[];for(let e=0;e<o.length;++e)0<e&&(t+=", "),t+=o[e
].getDisplayLabel(),l.push(o[e]);l.push(this.getGem(r)),this.pendingAction={
func:"moveHierarchy",params:{list:l,zoneId:e,refId:s.refId,pos:s.pos}},
this.rptDlg.showConfirm(["promptMoveFieldHierarchy",i,t],
"CV/Business_User/working_with_fields.html#about_field_hierarchies",{
srcObj:this,srcFunc:"moveHierarchy"})}else t||this.rptDlg.showError([
"errorBreakFieldHierarchy",i,o[0].getDisplayLabel()],
"CV/Business_User/working_with_fields.html#about_field_hierarchies");return!1},
isGemMetricValueAndUnmapped(e){
return null!=e&&e.type===cvConst.TYPE_METRIC&&"VALUE"===e.metricType&&(
e.isHideInChart()||null==e.getGembarId())},checkColumnSelectionFilters(e,t){if(
"columnAttributes"===e&&0<this.reportDoc.getSelectionFilters().length
)return t||this.rptDlg.showError(["errorColumnSelectionFilters"]),!1;return!0},
clearGemList(){this.currentSelection=null,this.gemList.getValueList().forEach(
e=>{e.destroy()}),this.gemList.clear(),this.badFields=[],this.badFilters=!1,
this.setVizModelRolesDirty()},_addGemObject(e){var t=e.getId(),
r=this.gemList.item(t);if(null!=r){if(r===e)return e;r.destroy()}
return this.gemList.add(t,e),e},_removeGemObjectById(e){var t=this.gemList.item(
e);return null!=t&&(t.destroy(),this.gemList.remove(e)),t},createGem(e){
e.gemType===cvConst.TYPE_METRIC&&"VALUE"!==e.metricType&&"EXPRESSION"!==e.metricType?(
t=this.getGem(e.formula))&&(t=t.xmlNode.selectSingleNode(
"cv:displayLabels/cv:displayLabel"))&&t.getAttribute("label")&&(
e.label=cv.util.substituteParams(cvCatalog["metric"+e.metricType],
t.getAttribute("label")),e.locale=t.getAttribute("locale")
):"measures"!==e.zoneId||e.metricType||(e.metricType="VALUE");
var t=this.reportDoc.createNode(e);return this.createGemDomNode(t,e.zoneId)},
createGemDomNode(e,t){let r;switch(cvConst.defaultGemTypes[t]){
case cvConst.TYPE_ATTRIBUTE:r=new cv.AttributeGem(e,this);break;
case cvConst.TYPE_METRIC:r=new cv.MetricGem(e,this);break;
case cvConst.TYPE_FILTER:(r=new cv.FilterGem(e,this,!1)).bad||r.createDomNode();
break;default:return null}return r.bad?null:(t&&r.setZone(t),this._addGemObject(
r))},createMetricFilterGem(e){let t;return!(t=(e||this.reportDoc
).getMetricFilterNode())||(e=new cv.FilterGem(t,this,!0)).bad?null:(e.setZone(
"filters"),e.createDomNode(),this._addGemObject(e))},createSpecialMetricGem(e){
e.gemType=cvConst.TYPE_METRIC;var t=this.createGem(e);return this.insertGem(t,
e.refGem,"after",!0),t},getFieldLabel(e,t){if(!e)return"";let r=null,i=null;if(
"string"==typeof e?r=e:lang.isObject(e)&&(e.id&&this.gemList.item(e.id
)?i=this.gemList.item(e.id).getDisplayLabel(!0):r=e.getAttribute("formula")),!i
){if(!r)return"";e=this.getGem(r);i=e?e.getDisplayLabel(!0):cv.getFieldHelp(
).get(r,"displayLabel")}return i=i||cv.util.parseMDXExpression(r,!1),
t?i:cv.util.escapeHtml(i)},getFieldLabelPlural(e,t){if(!e)return"";let r=null,
i=null;if("string"==typeof e?r=e:lang.isObject(e)&&(e.id&&this.gemList.item(e.id
)?i=this.gemList.item(e.id).getDisplayLabelPlural(!0):r=e.getAttribute("formula"
)),!i){if(!r)return"";e=this.getGem(r);i=e?e.getDisplayLabelPlural(!0
):cv.getFieldHelp().get(r,"displayLabelPlural")}
return!i||t?i:cv.util.escapeHtml(i)},getGem(e,t){if(e){if("string"==typeof e){
if(this.gemList.contains(e))return this.gemList.item(e);t=t||"VALUE"}else if(
!e.xmlNode)return null;var r=this.gemList.getKeyList();if(r&&0!==r.length)for(
const s of r){var i=this.gemList.item(s);if(i&&(
e.xmlNode&&i.xmlNode===e.xmlNode||i.getFormula()===e&&i.metricType===t))return i
}}return null},getGemFromDomNode(e){if(!e)return null;if(e.id){
var t=this.getGem(e.id);if(t)return t}t=cv.util.getAttribute(e,"formula");
return"measure"===e.getAttribute("type")?this.getGem(t,e.getAttribute(
"metrictype")):this.getGem(t)},_getGemsInHierarchy(e){var t=cv.getFieldHelp(
).getHierarchy(e);if(null==t)return null;var r,i=[];for(const s of t)s!==e&&(
r=this.getGem(s))&&i.push(r);return 0===i.length?null:i},getSummaryFacet(e,t){
e=this.getGem(e,t);return e?e.getMetricFacet():null},getTrendNumberOnAncestors(e
){var t=cv.getFieldHelp().getHierarchy(e);if(t)for(const i of t){if(i===e)break;
var r=this.reportDoc.getNode(
`cv:report/cv:measures/cv:measure/cv:trendFacet[@trendAttributeFormula="${i}"]`)
if(r)return{ancestor:i,trend:this.getGem({xmlNode:r.parentNode})}}return null},
insertGem(e,t,r,i,s){let o,l,a="object"==typeof t?t:this.getGem(t);
a?l=a.getZone():(0===(l=t).indexOf(this.id)&&(l=l.substring(this.id.length)),
a=this.reportDoc.getReportZoneNode(l)),o="object"==typeof e?e:this.getGem(e);
let n;if(n=o?(e=o.getFormula(),o.setZone(l),s||o.getHistoryActionCode("Move")):(
o=this.createGem({zoneId:l,formula:e}),{[l]:t}=cvConst.defaultGemTypes,
t===cvConst.TYPE_ATTRIBUTE&&this.wordWrap&&o.xmlNode.setAttribute("wordWrap",
"true"),s||o.getHistoryActionCode("Add")),this.isReportFormatPivot(
)||null!=o.getGembarId())this.setVizModelRolesDirty();else{let e;if(
"append"!==r&&"measures"!==l?e=a.getGembarId():null!==(
t=this.getNextAvailableGembarForField(o.getId()))&&(e=t.name),e)if(
o.setGembarId(e),this.setVizModelRolesDirty(),"after"===r){
let r=a.getGembarOrdinal(),i;if(i="measures"===l?this.reportDoc.getReportNode(
).selectNodes("*/cv:measure"):this.reportDoc.getReportNode().selectNodes(
"*/cv:attribute"))for(let e=0,t=i.length;e<t;e++){var c,u=i[e];
u.nodeType===Node.ELEMENT_NODE&&(c=u.getAttribute("gembarOrdinal")
)>r&&u.setAttribute("gembarOrdinal",++c)}o.setGembarOrdinal(++r)
}else o.setGembarOrdinal(this.getNextOrdinal(e))}"append"!==r?(
s=this.reportDoc.getReportZoneNode(l).childNodes.length,
t="VALUE"===o.metricType?"measure":void 0,this.updateReportResizeParams("add",s,
r,t)
):"VALUE"===o.metricType&&null!=this.reportHeaders&&this.reportHeaders.columnHeaderContainer.getElementsByTagName(
"COL").length>a.childNodes.length&&this.updateReportResizeParams("add",
a.childNodes.length,"before","measure");var s=cv.getFieldHelp().get(e,
"hyperlink");return s&&(t={type:"URL",url:s.trim(),toolTip:"",target:"NEW_TAB"},
o.setLink(t)),"before"===r?a.xmlNode.parentNode.insertBefore(o.xmlNode,a.xmlNode
):"after"===r?a.xmlNode.parentNode.insertBefore(o.xmlNode,a.xmlNode.nextSibling
):"append"===r&&a.appendChild(o.xmlNode),i||(s={formula:e},this.history.add(
new cv.ReportState(n,o.getDisplayLabel(!0),s))),this.resizeContainer(),
i||this.refreshReport(),o},insertGemInHierarchy(e,t,r){var i=cv.getFieldHelp(
).getHierarchy(e);if(!i)return null;let s=null,o=null;for(const a of i)if(a===e
){if(s){o="after";break}o="before"}else{var l=this.getGem(a);if(l&&(
!r||l.zone===r)&&(s=l)&&o)break}return s&&o?this.insertGem(e,s,o,t):null},
moveHierarchy(){if(this.pendingAction&&"moveHierarchy"===this.pendingAction.func
){var r=this.pendingAction["params"];for(let t=0;t<r.list.length;++t){
let e=r.list[t];var i=e.getFormula(),s=e.getSortOrder();this.removeGem(e,!0,null
,!0),(e=0===t?this.insertGem(i,r.refId,r.pos,!0):this.insertGemInHierarchy(i,!0,
r.zoneId))&&e.setSortOrder(s)}this.history.add(new cv.ReportState(
"actionMoveHierarchy")),this.refreshReport()}},onMouseOverFilters(e){
e=cv.util.getAncestorByClass(e.target,"filterItem");
e&&e===this.currentSelection||!this.currentSelection||(this._setFilterSelected(
this.currentSelection,!1),this.currentSelection=e),e&&(this._setFilterSelected(e
,!0),this.currentSelection=e)},removeFilter(e,t){var r,i,
e=/^(filter_.+)_(\d+)$/.exec(e);return!!e&&!!(r=this.getGem(e[1]))&&(
r.isNumeric?(cv.util.removeNode(this.reportDoc.getNode(
"cv:report/cv:filters/cv:filter/cv:conditions")),cv.util.removeNode(
this.reportDoc.getNode("cv:report/cv:filters/cv:filter/cv:topBottom")),
this.reportDoc.removeEmptyFilter(r.xmlNode),this._removeGemObjectById(r.getId())
):"99"===e[2]?(i={formula:r.getFormula(),predicates:new Dictionary},
this.reportDoc.updateFilter(i),this._removeGemObjectById(r.getId())
):this.reportDoc.removeFilterPredicate(r.xmlNode,e[2]
)||this._removeGemObjectById(r.getId()),cv.dlgWidget&&cv.dlgWidget.open&&(i=e[1]
,(e=this.getGem(i))?(this.rptDlg.load(this.getFieldLabel(i.substring(7)),
cv.util.escapeHtml(i.substring(7)))||cv.dlgWidget.hide(),i=this.rptDlg.byId(
"predicateList"),domClass.add(i,"unlocked"),domClass.add(i,"filterGroup"),
parser.removeChildren(i),i.innerHTML=e.createSummary(!0),
e.addDomNodeInteraction(i,cv.util.createCompositeHandle())):cv.dlgWidget.hide())
,this.populateFilters(),this.currentSelection=null,t||(
r.isNumeric?this.history.add(new cv.ReportState("actionRemoveNumericFilter")
):this.history.add(new cv.ReportState("actionRemoveFilter",r.getDisplayLabel(!0)
))),this.setVizModelRolesDirty(),this.resizeContainer(),void(
t||this.refreshReport()))},onRemoveFilter(t){const r=query(t.target).closest(
".filterItem")[0];if(null!=r){cv.util.setRestoreFocus(
focusUtil.previousTabbable(t.target));let e=!1;r.id.startsWith("filter_metric"
)&&(e=!0),this.reportDoc.isDefaultFilter(r.getAttribute("formula"),e
)?this.rptDlg.showConfirm(["promptRemoveDefaultFilter"],null,{srcFunc:(
)=>this.removeFilter(r.id)}):this.removeFilter(r.id),cv.util.restoreFocus()}},
onEditFilter({target:e}){var t,[e]=query(e).closest(".filterItem");null!=e&&(
t=e.id.startsWith("filter_metric"),this.reportDoc.isDefaultFilter(
e.getAttribute("formula"),t)&&(
this.banner.fixedMessage=cvCatalog.bannerEditDefaultFilter),this.filterDlg.show(
e.id))},removeCurrentGem(e,t){(e=e&&!e.tagName?e.target:e)&&(
this.currentSelection=this.getGemFromDomNode(e));let i=this.currentSelection;if(
i||(i=this.getGemFromDomNode(cv.util.popupSourceNode),this.currentSelection=i),
!i)return!1;if(!(i instanceof cv.BaseGem)){const m=i["id"];if(0===m?.indexOf(
"filter_")){e=m.startsWith("filter_metric");if(!this.reportDoc.isDefaultFilter(m
,e))return this.removeFilter(m),!0;this.rptDlg.showConfirm([
"promptRemoveDefaultFilter"],null,{srcFunc:()=>(this.removeFilter(m),!0)})}
return!1}e=i.getZone();if("rowAttributes"===e||"columnAttributes"===e){
var s=i.getFormula(),o=i.getDisplayLabel(),l=this.reportDoc.getNode(
`cv:report/cv:measures/cv:measure/cv:summaryFacet[@breakAttributeFormula="${s}"]`
);if(l=l&&this.getGem({xmlNode:l.parentNode}))return this.rptDlg.showError([
"errorUsedByMetric",o,l.getDisplayLabel()]),!1;if(
this.reportDoc.isUsedByMetricFilter(s))return this.rptDlg.showConfirm([
"promptUsedByFilter",o],
"CV/Business_User/working_with_filters.html#numeric_filters_larger_than",{
srcObj:this,srcFunc:"removeGem"});let r=this.reportDoc.getNode(
`cv:report/cv:measures/cv:measure/cv:trendFacet[@trendAttributeFormula="${s}"]`)
r=r&&this.getGem({xmlNode:r.parentNode});var a=cv.getFieldHelp().getHierarchy(s,
!1);if(a){let e=!1,t=!1;for(const h of a)if(h===s)t=!0;else if(t&&this.getGem(h)
){e=!0;break}if(e)r=null;else if(!r){var n=this.reportDoc.getMetrics("TREND");
if(0<n.length){var c=array.indexOf(a,s);for(let e=0;!r&&e<n.length;++e){var u=n[
e].selectSingleNode("cv:trendFacet").getAttribute("trendAttributeFormula"),
d=array.indexOf(a,u);if(!(d<0||c<d)){if(r=n[e],this.getGem("filter_"+s)
)return this.rptDlg.showError(["errorRemoveWithTrendOnAncestor",o,
this.getFieldLabel(u),this.getGem({xmlNode:r}).getDisplayLabel()]),!1;for(
let e=d;e<c;++e)if(this.getGem(a[e])){r=null;break}}}}if(r
)return this.rptDlg.showError(["errorUsedByTrendMetric",o,this.getGem({xmlNode:r
}).getDisplayLabel()]),!1}}if(r)return this.rptDlg.showError([
"errorUsedByTrendMetric",o,r.getDisplayLabel()]),!1}else if(
"measures"===e&&"VALUE"!==i.metricType){var l=i.getFormula(),
r=this.reportDoc.getFirstMetricDependent(l);if(r=r&&this.getGem({xmlNode:r})
)return this.rptDlg.showError(["errorUsedByMetric",i.getDisplayLabel(),
r.getDisplayLabel()]),!1;if(this.reportDoc.isUsedByMetricFilter(l)
)return this.rptDlg.showConfirm(["promptUsedByFilter",i.getDisplayLabel()],
"CV/Business_User/working_with_filters.html#numeric_filters_larger_than",{
srcObj:this,srcFunc:"removeGem"}),!1}if("filters"===e){r=i.getFormula();let e=!1
i.isNumeric&&(e=!0),this.reportDoc.isDefaultFilter(r,e)?this.rptDlg.showConfirm(
["promptEditDefaultFilter"],null,{srcFunc:()=>this.removeGem(i,!0,null,t)}
):this.removeGem(i,!0,null,t)}else this.removeGem(i,!0,null,t);return!(
cv.util.popupSourceNode=null)},removeGem(t,e,r,i){if(
t=t&&void 0===t.getFormula?this.currentSelection:t){this.setVizModelRolesDirty()
var s=query(".gemLabel",t.zone);for(let e=0;e<s.length;++e)if(
parser.textContent(t.domNode)===parser.textContent(s[e])){
"VALUE"===t.metricType?this.updateReportResizeParams("remove",e,"","measure"
):this.updateReportResizeParams("remove",e);break}
e||this.reportDoc.removeFromMetricFilter(t.getFormula())&&this.populateFilters()
,this._removeGemObjectById(t.getId()),cv.util.removeNode(t.xmlNode),
this.currentSelection=null,r=r||t.getHistoryActionCode("Remove");e={
formula:t.getFormula()};t.type===cvConst.TYPE_FILTER&&this.populateFilters(),
this.resizeContainer(),i||(this.history.add(new cv.ReportState(r,
t.getDisplayLabel(!0),e)),this.refreshReport())}},removeCurrentProp(){
var e=this.currentSelection.getAttribute("name"),
t=this.currentSelection.getAttribute("formula");this.getGem(t).removeProperty(e)
},addCalcMeasureToDataSource(){let e=this.currentSelection;var t,r,i,s,o;e||(
e=this.getGemFromDomNode(cv.util.popupSourceNode),this.currentSelection=e),e&&(
t=e.getDisplayLabel(),!0!==(o=cv.util.isValidMeasureName(t))?cv.Dialog(
).showError(o):(o=cv.textContent(e.getMetricFacet()),r=e.getNumberFormat()[
"formatCategory"],i=e.getNumberFormat()["formatScale"],
s=e.getCalculateSubtotalsUsingFormula(),0<=o.indexOf("[MEASURE:")?cv.Dialog(
).showError(cvCatalog.errorModelingCalcMeasureValidationReportMeasure):(
cv.util.createCalcMeasureAnnotation(t,o,t,t,r,i,s),o=cv.getFieldHelp().manager[
"report"],o.manager.updateCatalog(),cv.util.convertReportCalcMeasureToModel(
e.getFormula(),t),o.history.add(new cv.ReportState(
"actionCreateCalculatedMeasure",t)),o.api.operation.refreshReport())))},
_setFilterSelected(e,t){t?(domClass.add(e,"filterItemMouseOver"),
this.selectedFilterHandle=on(e,"MouseOut",lang.hitch(this,"deselectFilter"))):(
domClass.remove(e,"filterItemMouseOver"),this.selectedFilterHandle&&(
this.selectedFilterHandle.remove(),this.selectedFilterHandle=null))},
deselectFilter(){this._setFilterSelected(this.currentSelection,!1)},
setSortOrder(e,t,r){if(e=e&&"string"==typeof e?this.getGem(e
):e||this.currentSelection)if(this.isReportFormatPivot()){
var i="rowAttributes"===e.getZone()&&e.isLast();if(e.setSortOrder(t),
e.metricType||i)for(const l of this.gemList.getKeyList()??[]){
var s=this.gemList.item(l);s?.metricType&&s.getId()!==e.getId()&&s.setSortOrder(
"NONE")}r&&(e.metricType?(i=this.reportDoc.getChildMembers("rowAttributes"),
this.history.add(new cv.ReportState("actionSort",e.getDisplayLabel(!0))),
2<=i.length?this.rptDlg.showWarning(["warnSortMetric",this.getFieldLabel(i[
i.length-1]),e.getDisplayLabel(),this.getFieldLabel(i[i.length-2])],null,null,
null,null,this):this.refreshReport()):(this.history.add(new cv.ReportState(
"actionSort",e.getDisplayLabel(!0))),this.refreshReport()))}else{if(
e.setSortOrder(t),"rows"===e.getGembarId()||e.metricType)for(
const a of this.gemList.getKeyList()??[]){var o=this.gemList.item(a);
o?.metricType&&o.getId()!==e.getId()&&o.setSortOrder("NONE")}this.history.add(
new cv.ReportState("actionSort",e.getDisplayLabel(!0))),this.refreshReport()}},
sortMembers(e,t){var r,i;return e.caption==t.caption?(
r=cv.util.parseMDXExpression(e.formula))==(i=cv.util.parseMDXExpression(
t.formula))?0:r<i?-1:1:e.caption<t.caption?-1:1},onKeepAndShow(e){
cv.api.event.isEventDisabled(e.type)||(e=this.findTableCell(e.target)
)&&"member"===e.getAttribute("type")&&(this.currentSelection=e,
e=this.currentSelection.getAttribute("formula"),e=cv.getFieldHelp(
).getDirectChild(e))&&!this.getGem(e)&&this.updateInTableFilter("KEEP_AND_DRILL"
)},findTableCell(e){for("resize"===e.className&&(e=e.parentNode
);e&&"TD"!==e.tagName;)e=e.parentNode;return e},toggleInReportPopupMenu(e){
var o=this.findTableCell(e.target);if(o){var l=(cv.util.popupSourceNode=o
).getAttribute("type");let s=cv.util.getDojoWidget(l+"PopMenu");switch(
this.currentSelection=null,l){case"measure":case"attribute":
var a=cv.util.getAttribute(o,"formula");this.currentSelection=this.getGem(a),
null!=this.currentSelection&&this.currentSelection.updatePopupMenu();break;
case"prop":this.currentSelection=o;break;case"member":{this.currentSelection=o;
var a=this.currentSelection.getAttribute("member"),
n=this.currentSelection.getAttribute("formula"),c=this.getGem("filter_"+n),
u=cv.getFieldHelp().getDirectChild(n);if((s=cv.util.getDojoWidget(l+"PopMenu")
).domNode?.memberId===a)break;cv.util.disconnectPopupMenu(this,[{
id:"PM:membEXCLUDE",handler:"onRptExclude"},{id:"PM:membKEEP",
handler:"onRptKeep"},{id:"PM:membKEEP_AND_DRILL",handler:"onRptKeepAndDrillDown"
},{id:"PM:membSHOW_ALL",handler:"onRptShowAll"}]),s.destroyDescendants(),
s.domNode.memberId=a,a=parser.textContent(o.firstChild);let e=new MenuItem({
id:"PM:membEXCLUDE",label:cv.util.substituteParams(cvCatalog.menuMembEXCLUDE,
cv.util.escapeHtml(a))}),t=(s.addChild(e),on(e,"click",lang.hitch(this,
"onRptExclude")),e=new MenuItem({id:"PM:membKEEP",
label:cv.util.substituteParams(cvCatalog.menuMembKEEP,cv.util.escapeHtml(a))}),
s.addChild(e),on(e,"click",lang.hitch(this,"onRptKeep")),u&&(e=new MenuItem({
id:"PM:membKEEP_AND_DRILL",label:cv.util.substituteParams(
cvCatalog.menuMembKEEP_AND_DRILL,a,this.getFieldLabel(u))}),s.addChild(e),on(e,
"click",lang.hitch(this,"onRptKeepAndDrillDown"))),c&&!cv.getActiveReport(
).isEditDisabled()&&(e=new MenuItem({id:"PM:membSHOW_ALL",
label:cv.util.substituteParams(cvCatalog.menuMembSHOW_ALL,this.getFieldLabel(n))
}),s.addChild(e),on(e,"click",lang.hitch(this,"onRptShowAll"))),!1),r=!1;for(
const d of cv.getFieldHelp().getHierarchy(n)??[])if(d===n)r=!0;else if(
r&&this.getGem(d)){t=!0;break}let i=!1;t&&(s.addChild(new MenuSeparator),i=!0,
e=new MenuItem({id:"PM:membDRILLUP",label:cv.util.substituteParams(
cvCatalog.menuMembDRILL_UP,this.getFieldLabel(n))}),s.addChild(e),on(e,"click",
lang.hitch(this,"onRptDrillUp"))),u&&!this.getGem(u)&&(i||s.addChild(
new MenuSeparator),e=new MenuItem({id:"PM:membDRILLDOWN",
label:cv.util.substituteParams(cvCatalog.menuMembDRILL_DOWN,this.getFieldLabel(u
))}),s.addChild(e),on(e,"click",lang.hitch(this,"onRptDrillDown"))),
this.addCustomActionMenuItems(s,l,o,n);break}case"cell":this.currentSelection=o,
(s=cv.util.getDojoWidget(l+"PopMenu")).destroyDescendants(),
this.addCustomActionMenuItems(s,l,o,"[Measures].[MeasuresLevel]");break;
case"grandTotal":this.currentSelection=o,cv.util.setMenuItem("PM:totalNonVisual"
,"true"===this.reportDoc.getReportOption("useNonVisualTotals")?"checked":"none",
"enabled"),cv.util.updateMenuItemCaption("PM:totalHide",domClass.contains(
cv.util.getAncestorByTag(o,"TABLE"),"ZONE_columnAttributes"
)?"menuHideGrandTotalRow":"menuHideGrandTotalCol");break;default:return}
null!=this.currentSelection&&s.hasChildren()&&cv.util.showPopupMenu(s,e.clientX,
e.clientY),event.stop(e)}},_getById(e){return dom.byId(e)},_fromJson(e){
return dojo.fromJson(e)},buildFilterActionContext(){let e={};
var t=this._getById("pivotTable");return e=t?this._fromJson(t.getAttribute(
"filterCtx")):e},buildCellActionContext(t){let r={};var i=t.getAttribute("type")
if("member"===i||"measure"===i)r=this._fromJson(t.getAttribute("ctx"));else if(
"cell"===i){i=t.getAttribute("colindex"),t=t.getAttribute("rowindex");let e={};
var t=this._query("tr",this.reportHeaders.rowLabelContainer)[t],t=this._query(
"td[type=member]",t),t=(0<t.length&&(t=t[t.length-1].getAttribute("ctx"))&&(
e=this._fromJson(t)),this._query("tr",this.reportHeaders.columnHeaderTable)),
t=this._query("td",t[t.length-1]);r=this._fromJson(t[i].getAttribute("ctx"));
for(const s in e)r[s]=e[s]}return r},addCustomActionMenuItems(menu,type,obj,
level){const ctx=this.buildCellActionContext(obj);let formula;if(
formula="cell"===type?ctx["[Measures].[MeasuresLevel]"]:level,formula){
const customActions=cv.getFieldHelp().getCustomActions(formula);if(
0!==customActions.length){let separator=!1;this.currentSelection=obj,
this.currentCustomActionCtx=ctx,this.currentCustomActionFormula=formula,
this.currentCustomActionType=type;const filterCtx=this.buildFilterActionContext(
);for(const action of customActions){const fnObj=eval(
`cv.extension.${action.fn}_validate`);if(!fnObj||fnObj(this,
this.currentCustomActionFormula,this.currentCustomActionCtx,filterCtx)){
"[Measures].[MeasuresLevel]"===level||separator||(menu.addChild(
new MenuSeparator),separator=!0);const mi=new MenuItem({
id:"PM:customAction_"+type+action.fn,label:action.label});menu.addChild(mi),
dojo.connect(mi,"onClick",this,"handleCustomAction")}}}}},handleCustomAction(e){
const fn=e.target.parentElement.id.substring(
16+this.currentCustomActionType.length),fnObj=eval("cv.extension."+fn);if(fnObj
){const filterCtx=this.buildFilterActionContext();fnObj(this,
this.currentCustomActionFormula,this.currentCustomActionCtx,filterCtx)
}else alert("Unable to find custom action function: cv.extension."+fn)},
updateFilterProps(t,r,i,s){var o=t.predicates;let l=null;
!s&&r.members&&r.members.sort(this.sortMembers);var a=o.getKeyList();if(
"CONTAIN"===r.op||"NOT_CONTAIN"===r.op||("EQUAL"===r.op||"NOT_EQUAL"===r.op
)&&!r.preset)for(let e=0;e<a.length;++e){for(const b of o.item(a[e]))if(
b.op===r.op&&!b.preset){if(b.ordinal===r.ordinal)break;if(i||alert(
cv.util.substituteParams(cvCatalog.infoMergeFilter,cvCatalog[
"filterOpString_"+r.op],this.getFieldLabel(t.formula))),
"CONTAIN"===r.op||"NOT_CONTAIN"===r.op){var n=b.exp,c=r.exp,u=n.length,
d=c.length;for(let e,t=0;t<d;++t){for(e=0;e<u&&c[t]!==n[e];++e);e>=u&&n.push(c[t
])}}else{b.members.sort(this.sortMembers);var m=b.members,h=r.members;let e=0,
t=0;for(var p,g=m.length,f=h.length,v=[];e<g||t<f;)if(e>=g)for(;t<f;)v.push(h[
t++]);else if(t>=f)for(;e<g;)v.push(m[e++]);else 0===(p=this.sortMembers(m[e],h[
t]))?(v.push(m[e++]),++t):v.push(0<p?h[t++]:m[e++]);b.members=v}(l=b
).ordinal=e+1;break}if(l){o.contains(r.ordinal)&&o.remove(r.ordinal);break}}if(
!l){let e=(l=r).ordinal;if(!e){for(const y of o.getKeyList())y>e&&(e=y);e+=1}s=[
];s.push(l),o.add(e,s)}return l},updateRelativeFilterProps(e,t){var e=e[
"predicates"],r=e.getKeyList();let[{ordinal:i}]=t;if(!i)for(const l of r){
var s=parseInt(l,10);s>=i&&(i=s+1)}for(const a of t){if(a.ordinal)break;
a.ordinal=i}const o={EQUAL:0,TIME_YAGO:1,TIME_RANGE_PREV:2,TIME_RANGE_NEXT:3,
TIME_AGO:4,TIME_AHEAD:5};t.sort((e,t)=>e.op===t.op?0:o[e.op]>o[t.op]?1:-1),
e.add(i,t)},updateInTableFilter(e,r,t,s){let o,i;s?o=r.formula:s=r?(o=r.formula,
[i={formula:r.member,caption:r.caption}]):(o=this.currentSelection.getAttribute(
"formula"),[i={formula:this.currentSelection.getAttribute("member"),
caption:parser.textContent(this.currentSelection.firstChild)}]);r=this.getGem(
"filter_"+o);let l=null;if("SHOW_ALL"===e){if(!r)return;cv.util.removeNode(
r.xmlNode.selectSingleNode("cv:predicates")),
0===r.xmlNode.childNodes.length&&this.removeGem(r,!0,null,!0),
l=cv.util.substituteParams(cvCatalog.actionSHOW_ALL,this.getFieldLabel(o,!0))
}else if("DRILL_DOWN"===e){r=cv.getFieldHelp().getDirectChild(o);r&&(
this.insertGemInHierarchy(r,!0),l=cv.util.substituteParams(
cvCatalog.actionDRILL_DOWN,this.getFieldLabel(r,!0)))}else if("DRILL_UP"===e){
let e;for(const m of cv.getFieldHelp().getHierarchy(o)??[])if(m===o
)e=!0;else if(e){var a=this.getGem(m);if(a&&(this.currentSelection=a,
!this.removeCurrentGem(null,!0)))return}l=cv.util.substituteParams(
cvCatalog.actionDRILL_UP,this.getFieldLabel(o,!0))}else{let t="";for(
let e=0;e<s.length;e++)e&&(t+=", "),t+=s[e].caption;let i;
r=this.reportDoc.getFilter(o);switch(i=r?this.reportDoc.getFilterProps(r):{
formula:o,viewFilterEnum:"MULTIPLE"},e){case"EXCLUDE":case"ADD":
var n="ADD"===e?"EQUAL":"NOT_EQUAL";if(i.predicates){let e=!1,t,r;for(
const h of i.predicates.getKeyList()){for(const p of i.predicates.item(h))if((
t=p).ordinal>r&&(r=t.ordinal+1),t.op===n){for(const g of s)t.members.push(g);
e=!0;break}if(e)break}if(e){if(t.members.length>cv.analyzerProperties[
"filter.include.exclude.max.count"])return void this.rptDlg.showError([
"errprFilterMaxMembers",cv.analyzerProperties["filter.include.exclude.max.count"
]])}else{var c=[],u=i.predicates;c.push({ordinal:r,op:n,members:s}),u.add(r,c)}
}else{u=new Dictionary,c=[];c.push({ordinal:1,op:n,members:s}),u.add(1,c),
i.predicates=u}l=cv.util.substituteParams(cvCatalog.actionEXCLUDE,t);break;
case"KEEP":c=new Dictionary,u=[];u.push({ordinal:1,op:"EQUAL",members:s}),c.add(
1,u),i.predicates=c,l=cv.util.substituteParams(cvCatalog.actionKEEP,t);break;
case"KEEP_AND_DRILL":var d,u=cv.getFieldHelp().getDirectChild(o);u&&(
c=new Dictionary,(d=[]).push({ordinal:1,op:"EQUAL",members:s}),c.add(1,d),
i.predicates=c,this.insertGemInHierarchy(u,!0),l=cv.util.substituteParams(
cvCatalog.actionKEEP_AND_DRILL,t,this.getFieldLabel(u,!0)));break;default:return
}this.reportDoc.updateFilter(i)}t||(this.history.add(new cv.ReportState(l)),
this.openReport(),this.refreshReport(!1,!0))},validateField(t,e){if(
0!==t.indexOf("[MEASURE:")){var r=cv.getFieldHelp().get(t);if(
!r||cv.getFieldHelp().isHidden(r)&&!e){let e;var i=this.getFieldLabel(t);for(
e=0;e<this.badFields.length&&this.badFields[e]!==i;++e);
return e===this.badFields.length&&this.badFields.push(i),!1}}return!0},
autoRefresh(){if(this.history.isEmpty())return!0;try{if(
"dashboards"===window.parent.PENTAHO_CONTEXT_NAME)return!0}catch(e){}var e;
return cv.prefs.autoRefresh||(
null!=this.nodeReportArea.lastChild&&"autoRefreshDirtyPane"===this.nodeReportArea.lastChild.className||(
cv.util.show(this.nodeReportRefresh),(e=document.createElement("div")
).className="autoRefreshDirtyPane",e.id="autoRefreshDirtyPaneId",
this.nodeReportArea.appendChild(e),e=dom.byId("progressPane"),cv.util.hide(e),
this.statusBar.innerHTML=""),this.history.isStateRefreshed()&&(
this._removeAutoRefreshPane(),cv.util.hide(this.nodeReportRefresh))),
cv.prefs.autoRefresh},_removeAutoRefreshPane(){var e=dom.byId(
"autoRefreshDirtyPaneId");e&&e.parentNode.removeChild(e)},clickChart(e,t){for(
const r of e)"KEEP"===r.action?this.updateInTableFilter("KEEP",r,!0):(
this.updateInTableFilter("KEEP_AND_DRILL",r,!0),t||this.removeGem(this.getGem(
r.formula),null,null,!0));this.history.add(new cv.ReportState(
"actionDrillIntoChart")),this.reportDoc.replaceSelectionItems(),this.openReport(
),this.refreshReport(!1,!0)}})});define("pentaho/action/Base",["pentaho/module!_","pentaho/lang/Base"],function(n
,t){"use strict";return t.extend(n.id,{get eventName(){
return this.constructor.id},validate:function(){return null},clone:function(){
return new this.constructor}},{get isSync(){return!0}})});define("pentaho/action/Generic",["pentaho/module!_","./Base"],function(n,t){
"use strict";return t.extend(n.id,{constructor:function(n){this._init(n)},
_init:function(n){},clone:function(){return new this.constructor(this.toSpec())
},toSpec:function(){var n={};return this._fillSpec(n),n},_fillSpec:function(n){}
})});define("pentaho/visual/action/Base",["module","pentaho/action/Generic"],
function(e,n){"use strict";return n.extend(e.id)});define("pentaho/lang/UserError",["./Base"],function(r){"use strict";
return r.Error.extend("pentaho.lang.UserError",{get name(){return"UserError"}})}
);define("pentaho/lang/ArgumentInvalidTypeError",["./ArgumentError","../util/text"
],function(e,a){"use strict";return e.extend(
"pentaho.lang.ArgumentInvalidTypeError",{constructor:function(e,t,n){var r,i,
o="Expected type to be ";1<(t=Array.isArray(t)?t:[t]).length?(i=(r=t.slice()
).pop(),o+="one of "+r.join(", ")+" or "+i):o+=t[0],this.base(e,a.andSentence(
"Argument "+e+" is invalid.",o+=n?", but got "+n+".":".")),
this.actualType=n||null,this.expectedTypes=t},name:"ArgumentInvalidTypeError"})}
);define("pentaho/visual/action/Message",["pentaho/module!_","./Base",
"pentaho/util/text","pentaho/lang/UserError",
"pentaho/lang/ArgumentInvalidTypeError"],function(e,t,i,n,o){"use strict";
return t.extend(e.id,{constructor:function(e){this.base(e),this.code=e.code,
this.description=e.description},get code(){return this.__code},set code(e){
this.__code=s("code",e)},get description(){return this.__description},
set description(e){this.__description=s("description",e)},_fillSpec:function(e){
this.base(e),e.code=this.__code,e.description=this.__description},
validate:function(){var e;return null===this.__code&&(e=[]).push(new n(
"Message 'code' cannot be Null")),null===this.__description&&(e=e||[]).push(
new n("Message 'description' cannot be Null")),e}},{get id(){return e.id}});
function s(e,t){if("string"!=typeof t)throw new o(e,["string"],typeof t);
return i.nonEmptyString(t)}});define("pentaho/config/impl/Service",["../service"],function(e){"use strict";
return e.constructor});define("pentaho/analyzer/report/cv_rptReport3",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dojo/topic","dojo/_base/array","dojo/json",
"dojox/fx","dojo/dom","dojo/dom-geometry","./cv_rptReport2","pentaho/data/Table"
,"pentaho/data/filter/False","pentaho/type/action/Transaction",
"pentaho/visual/action/Select","pentaho/visual/action/Execute",
"pentaho/visual/action/Message","../visual/dataFilterUtils",
"pentaho/visual/util","pentaho/visual/role/util","pentaho/data/util",
"pentaho/config/impl/Service","pentaho/environment","common-ui/util/_focus",
"./cv_rptConst"],function(e,o,t,l,u,i,r,n,s,a,c,h,f,d,b,C,y,z,p,g,D,I,A,m){
function v(e,t){return e.ordinal-t.ordinal||e.index-t.index}function _(e){var t,
i,r,o=[];if(e){if(e.columnId&&0<e.columnId.length)for(t=0,
i=e.columnId.length;t<i;t++)(r=e.columnItem[t])&&o.push({formula:e.columnId[t],
member:r});if(e.rowId&&0<e.rowId.length)for(t=0,i=e.rowId.length;t<i;t++)(
r=e.rowItem[t])&&o.push({formula:e.rowId[t],member:r})}return o}l.extend(
cv.Report,{isChartSelectionsDisabled:function(){
var e=this.reportDoc.getChildMembers("columnAttributes").length;
return this.isLegacyViz()?1<e:0<e},onClearSelectionItems:function(e){
this.reportDoc.replaceSelectionItems(),this.isLegacyViz()?(
this.visualizationController.highlights=[],
this.visualizationController.updateHighlights()):(
this._vizModelAdapter.selectionFilter=null,this._vizModel.update()),
this.hideSelectionFilterButtons()},onApplySelectionItems:function(e){
var t=this.reportDoc.getSelectionItems();if(0!=t.length)if(
this.isChartSelectionsDisabled())this.rptDlg.showError([
"actionSelectionFilterDisabledTooltip"]);else{
var i=this.reportDoc.getChildMembers("columnAttributes").length,r="INCLUDE";if(
"cmdSelectionExclude"!=e.target.id&&"cmdSelectionExclude"!=e.target.parentNode.id||(
r="EXCLUDE"),t=this.reportDoc.getSelectionItems(),1==i)for(var o={},l=0,
n=t.length;l<n;++l)for(var s=t[l].selectNodes("cv:selectionMember"),a=0,
c=s.length;a<c;++a){var h=s[a],h={formula:h.getAttribute("formula"),
member:h.getAttribute("member")};h.caption=cv.util.parseMDXExpression(h.member,
!1),"INCLUDE"!=r||o[h.formula]||this.updateInTableFilter("SHOW_ALL",h,o[
h.formula]=!0),this.updateInTableFilter("INCLUDE"==r?"ADD":"EXCLUDE",h,!0)
}else this.reportDoc.addSelectionFilters(t,r);
this.reportDoc.replaceSelectionItems(),"INCLUDE"==r?this.history.add(
new cv.ReportState("actionKeepSelectedItems")):this.history.add(
new cv.ReportState("actionExcludeSelectedItems")),this.populateFilters(),
this.refreshReport(),this.hideSelectionFilterButtons()}},
removeSelectionFilters:function(e){this.reportDoc.removeSelectionFilters(),
this.populateFilters(),this.history.add(new cv.ReportState(
"actionRemoveSelectionFilters")),this.resizeContainer(),e||this.refreshReport()
},_onRemoveSelectionFilters:function(e){cv.util.setRestoreFocus(
m.previousTabbable(e.target)),this.removeSelectionFilters(),
cv.util.restoreFocus()},isReportFormatPivot:function(){
return"PIVOT"===this.getReportFormat()},displayClientSideReport:function(h){if(
this.isLegacyViz())return this._displayClientSideReportLegacy(h);try{
this.visualizationController&&(this.visualizationController.dispose(),
this.visualizationController=null),
this.resizeSubscription&&this.resizeSubscription.remove();
0===this.reportDoc.getSelectionItems().length&&(this.highlights=[]);
var u=this.nodeReportArea,e=(this.hideReportMessages(),
this._promiseVizClassesEntering);if(!e){if(
this._vizView&&!this._isVizViewConfigDirty)return this._updateVizModel(h,
u.offsetWidth,u.offsetHeight).catch(this._updateVizModelRejected.bind(this));
e=this._prefetchVizClasses()}this._isVizViewConfigDirty=!1;var t,i=new I(A),
r=this.reportDoc.getPluginViewDataJSON();if(r&&null!=(t=JSON.parse(r)))try{
i.add({rules:t})}catch(e){console.error(
"View instance configuration is invalid: ",e)}var d=this._vizView,p=null,m=this,
g=m._vizModelAdapter;return e.then(function(c){if(
m._promiseVizClassesEntering===e)return i.selectAsync(c.viewTypeId,null,{
inherit:!0}).then(function(e){var t=u.offsetWidth,i=u.offsetHeight,
r=m._createVizDomContainer(t,i,c.viewTypeId),o=m._vizModel,r=new c.View({
model:o,domContainer:r,config:e}),l=(m._promiseVizClassesEntering=null,
m._vizView=p=r,o.on(C.id,{init:function(e,t){m._executeActionInitHandler(t)},
do:function(e,t){m._executeActionHandler(t)}}),m.isChartSelectionsDisabled()),
n=(o.on(b.id,{init:function(e,t){var i,r;l?e.reject("Selection is disabled"):(
i=g._convertFilterToExternal(t.dataFilter),"false"===(
r=m._restrictFilterToSelectionRestriction(i)).kind?e.reject("Empty selection"
):r.equals(i)||(t.dataFilter=g._convertFilterToInternal(r)))}}),o.on(y.id,{
do:function(e,t){t=cvCatalog[t.code]||t.description;m.nodeChartMsg.innerText=t,
cv.util.show(m.nodeChartInfo)}}),cv.analyzerProperties[
"filter.selection.max.count"]||200),s={},a=0;return g.on("change",{
init:function(e){var t;e.action.hasChange("selectionFilter")&&(e=g.data,0<(
t=g.measureFieldNames).length&&(t=D.getColumnIndexesByIds(e,t),
t=D.buildRowPredicateNotAllNullColumns(t),e=D.filterByPredicate(e,t)),0===(
t=function(e){for(var t=[],i=e.getNumberOfColumns(),r=0;r<i;r++
)"string"===e.getColumnType(r)&&t.push(e.getColumnId(r));return t}(e)
).length?g.selectionFilter=f.instance:(e=g.selectionFilter.toExtensional(e,t),
t=z.limitSelection(n,e,s,a),(g.selectionFilter=t).equals(e)||cv.getActiveReport(
).rptDlg.showConfirm(["infoExceededMaxSelectionItems",n],
"SELECT_ITEM_LIMIT_REACHED")))},finally:function(e){if(!e.isRejected){e=e.action
if(e.hasChange("selectionFilter")){s={},a=0;var t=g.selectionFilter.toDnf();if(
"or"===t.kind){var i=t.operands;a=i.count;for(var r=0;r!==a;++r){var o=i.at(r
).$contentKey;s[o]=!0}}var l=g.$type,t=e.propertyNames.some(function(e){
return"data"===e||l.isVisualRole(l.get(e))});m.onSelectionChange(t)}}}}),d&&(
d.dispose(),d=null),m._updateVizModel(h,t,i).then(v,function(e){return v(),
m._updateVizModelRejected(e)})})})}catch(e){return alert(e.message),
Promise.reject(e)}function v(){var e=m._vizView;if(p===e){for(;u.hasChildNodes(
);)u.removeChild(u.firstChild);e=m.vizDiv;u.appendChild(e),
e.style.visibility="inherit"}}},_createVizDomContainer:function(e,t,i){
var r=this._vizModel.$type.id,r=p.getCssClasses(r,i)+" component-container",
i=this._vizContainerId+Math.ceil(1e7*Math.random()).toString(20),
o=document.createElement("DIV");return o.setAttribute("id",i),o.setAttribute(
"class",r),o.setAttribute("style",
"position: absolute; top: 0; left: 0; visibility: hidden; width: "+e+"px; height: "+t+"px; "
),document.body.appendChild(o),this.vizDiv=o},_updateVizModel:function(t,i,r){
var o=this._vizModel,l=this._vizModelAdapter,n=(d.enter().using(function(e){
o.width=i,o.height=r,l.data=new h(t),l.selectionFilter=null,e.accept()}),this);
return o.update().then(function(){return n.resizeSubscription=u.subscribe(
"/Analyzer/resize",function(e,t){n._updateVizModelOnResizeOrOverflow(t,e,!0)}),
n._updateVizModelOnResizeOrOverflow(i,r,!1)})},
_updateVizModelOnResizeOrOverflow:function(e,t,i){var r,o,l,n,s=this._vizModel;
if(!s.isDirty)return l=this._vizWillOverflow(e,t),r=l.vertical,o=l.horizontal,
i||r||o?(l=e-(r?this._scrollSize:0),i=t-(o?this._scrollSize:0),n=this.vizDiv,
s.configure({width:l,height:i}),s.update().then(function(){r?n.classList.add(
"vertical-axis-overflow"):n.classList.remove("vertical-axis-overflow"),
o?n.classList.add("horizontal-axis-overflow"):n.classList.remove(
"horizontal-axis-overflow")}).catch(function(){})):void 0},
_updateVizModelRejected:function(e){var t;if(e&&"no-data"===e.name
)return t=cv.util.substituteParams(
"EDIT"===this.mode?cvCatalog.reportNoDataMsgHTML:cvCatalog.reportSuccessMsgHTML,
cvCatalog.reportNoDataMsg),this.displayReport(t,{id:"reportNoDataMsg"}),null;
return Promise.reject(e)},_displayClientSideReportLegacy:function(e){try{
0==this.reportDoc.getSelectionItems().length&&(this.highlights=[]),
this.localData=e,this.reportDoc.getChildMembers(["measures"]);var t=JSON.parse(
cv.util.sanitizeJSONString(e)),i=t.colors,r=t.formatStrings,o=(delete t.colors,
delete t.formatStrings,new pentaho.DataTable(t));if(this._addGeoMetadata(o),
this._vizView&&this._disposeVizView(),
this.visualizationController&&this.nodeReportArea.firstChild&&this.nodeReportArea.firstChild.id==this._vizContainerId&&this.visualizationController.currentViz==this.visualization
)this.visualizationController.setDataTable(o),
this.visualizationController.setMemberPalette(i),
this.visualizationController.setFormatInfo(r),
this.visualizationController.highlights=this.highlights,
this.visualizationController.updateVisualization(this._generateVizPropsImplied()
);else{this.destroyReport();var l=this.nodeReportArea.offsetHeight,
n=this.nodeReportArea.offsetWidth;for(this.vizDiv=document.createElement("DIV"),
this.vizDiv.id=this._vizContainerId,this.vizDiv.setAttribute("style",
"position:absolute; top:0; left:0; width:"+n+"px; height:"+l+"px; overflow: auto"
);this.nodeReportArea.firstChild;)this.nodeReportArea.removeChild(
this.nodeReportArea.firstChild);this.nodeReportArea.appendChild(this.vizDiv),
this.visualizationController&&(this.visualizationController.dispose(),
this.visualizationController=null);var s=this,a=document.createElement("DIV"),
c=(a.setAttribute("style",
"position:absolute; top:0; left:0; width:"+n+"px; height:"+l+"px"),
a.setAttribute("id","vizdiv0"),this.vizDiv.appendChild(a),
new pentaho.VizController(0));this.visualizationController=c,
pentaho.events.addListener(c,"select",function(){
return s.selectChartItems.apply(s,arguments)}),pentaho.events.addListener(c,
"doubleclick",function(){return s._chartDoubleClickHandler.apply(s,arguments)}),
c.setDomNode(a),c.setDataTable(o),c.setMemberPalette(i),c.setFormatInfo(r),
c.highlights=this.highlights,c.setVisualization(this.visualization,
this._generateVizPropsImplied()),
this.resizeSubscription&&this.resizeSubscription.remove(),
this.resizeSubscription=u.subscribe("/Analyzer/resize",function(e,t){
a.style.height=e+"px",a.style.width=t+"px",c.resize(t,e)})}}catch(e){
return alert(e.message),Promise.reject(e)}},_addGeoMetadata:function(e){for(
var t="geoRole",i=0,r=e.getNumberOfColumns();i<r;i++){
var o=this.manager.fieldHelp.get(e.getColumnId(i));if(o){var l=o.getAttribute(t)
if(l){switch(l){case"country":l="Country";break;case"state":
l="CountrySubdivision";break;case"county":l="CountrySecondarySubdivision";break;
case"city":l="Municipality";break;case"postal_code":l="PostalCode";break;
case"latitude":l="Latitude";break;case"longitude":l="Longitude"}
e.setColumnProperty(i,t,l)}}}return e},getDoubleClickTooltip:function(e){
var t=this._getDoubleClickAction(_(e));if(t)switch(t.type){case"hyperlink":
var i=this.getGem(t.level).getLink(),r=i.getAttribute("type");if(
"URL"===r||"FILE"===r)return i=(i=i.getAttribute("toolTip")
)||cvCatalog.chartTooltipHyperlinkDefaultTitle,cv.util.substituteParams(
cvCatalog.chartTooltipFooterHyperlink,i);if("DASHBOARD"===r
)return cvCatalog.chartTooltipFooterContentlink;break;case"drilldown":
i=this.manager.fieldHelp.getDirectChild(t.level);
return cv.util.substituteParams(cvCatalog.chartTooltipFooterDrillDown,
cv.util.parseMDXExpression(i,!0))}return null},_getDoubleClickAction:function(e
){var e=e.map(function(e){return e.formula}),t=this._getHyperlinkLevel(e);
return t?{type:"hyperlink",level:t}:(t=this._getDrillLevel(e))?{
type:"drilldown",level:t}:null},_getDrillLevel:function(e){
return this.__getLevelFormula(e,this._getDrilldownGemBars(),function(e,t){
var i=this.manager.fieldHelp,r=this;if(i.getChildLevels(e).some(function(e){
return null!==r.getGem(e)}))return null;if(!i.getDirectChild(e))return null;if(
!this.isLegacyViz()&&this._getVizApplicationSpec().keepLevelOnDrilldown){
var i=this.vizModelAdapter,o=i.$type.get(t);if(this.findGemsByGembarId(t
).length+1>o.fields.countRangeOn(i,{ignoreCurrentMode:!0}).max)return null}
return e})},_getHyperlinkLevel:function(e){return this.__getLevelFormula(e,
this._getHyperlinkGemBars(),function(e){return this.getGem(e).getLink()?e:null})
},__getLevelFormula:function(e,t,i){if(0!==t.length)for(var r=0;r<t.length;r++
)for(var o=t[r],l=this.findGemsByGembarId(o).map(function(e){
return e.getFormula()}),n=l.length-1;0<=n;n--){var s=l[n],s=e.indexOf(s);if(
-1!==s){s=e[s];if(null!==(s=i.call(this,s,o)))return s}}return null},
_getDrilldownGemBars:function(){var t,i=this._getVizApplicationSpec().drillOrder
return i||(t=!(i=[]),this.vizModelAdapter.$type.eachVisualRole(function(e){if(
e.hasAnyCategoricalModes)switch(e.name){case"multi":break;case"columns":t=!0;
break;default:i.push(e.name)}}),t&&i.unshift("columns")),i},
_getHyperlinkGemBars:function(){return this._getVizApplicationSpec(
).hyperlinkOrder||this._getDrilldownGemBars()},
_buildChartItemActionContext:function(e){var t,i,r={};if(e.columnId)for(t=0,
i=e.columnId.length;t<i;t++)r[e.columnId[t]]=e.columnItem[t];if(e.rowId)for(t=0,
i=e.rowId.length;t<i;t++)r[e.rowId[t]]=e.rowItem[t];return r},
_executeActionInitHandler:function(e){
var t=this._vizModelAdapter._convertFilterToExternal(e.dataFilter),
i=z.toAnalyzerSelectionFormat(t);0<i.length&&(i=_(i[0]),
i=this._getDoubleClickAction(i))&&"drilldown"===i.type&&(
t=this._restrictFilterToDrillOrder(t),
e.dataFilter=this._vizModelAdapter._convertFilterToInternal(t))},
_executeActionHandler:function(e){
var t=this._vizModelAdapter._convertFilterToExternal(e.dataFilter),
t=this._restrictFilterToDrillOrder(t),t=z.toAnalyzerSelectionFormat(t);
this._chartDoubleClickHandler({selections:t})&&e.done()},
_chartDoubleClickHandler:function(e){if(0<e.selections.length){
var e=e.selections[0],t=this._buildChartItemActionContext(e);if(!this.emit(
"chartDoubleClick",t))return!0;this.selectDoubleClick(e)}return!1},
selectDoubleClick:function(e){var t=_(e),i=this._getDoubleClickAction(t);if(i
)switch(i.type){case"hyperlink":for(var r=0,o=t.length;r<o;r++)if(t[r
].formula===i.level){t[r].clickLevel=!0;break}this.linkDlg.performAction(t);
break;case"drilldown":t.forEach(function(e){
e.action=e.formula===i.level?"KEEP_AND_DRILL":"KEEP",
e.caption=cv.util.parseMDXExpression(e.member,!1)});
var l=this._getVizApplicationSpec().keepLevelOnDrilldown;this.clickChart(t,l)}},
onSelectionChange:function(e){var t=this._vizModelAdapter.selectionFilter,
t=z.toAnalyzerSelectionFormat(t);this.selectChartItems({selections:t},e)},
selectChartItems:function(e,t){this.selectTriggered(e,t);var i=[];
e.selections.forEach(function(e){i.push(this._buildChartItemActionContext(e))},
this),this.emit("chartSelectItems",i)},selectTriggered:function(e,t){
this.isLegacyViz()?(this.highlights=e.source.controller.highlights,
this.visualizationController.highlights=this.highlights,
this.visualizationController.updateHighlights()):(this.highlights=e.selections,
t||this._vizModel.update());for(
var i='<selectionItems xmlns="http://www.pentaho.com" >',
r=0;r<this.highlights.length;r++){var o,l=this.highlights[r],
n=l.colItem||l.columnItem,s=l.colId||l.columnId,a=l.rowItem,c=l.rowId;if((n||a
)&&(i+='<selectionItem op="SELECT" type="CategoryItem">'),void 0!==n)for(
o=0;o<n.length&&o<s.length;o++
)i+='<selectionMember member="'+cv.util.escapeHtml(n[o]
)+'" formula="'+cv.util.escapeHtml(s[o])+'"/>';if(void 0!==a)for(
o=0;o<a.length&&o<c.length;o++
)i+='<selectionMember member="'+cv.util.escapeHtml(a[o]
)+'" formula="'+cv.util.escapeHtml(c[o])+'"/>';(n||a)&&(i+="</selectionItem>")}
i+="</selectionItems>";e=cv.parseXML(i).documentElement;
this.reportDoc.replaceSelectionItems(e.cloneNode(!0)),
0!=this.reportDoc.getSelectionItems().length?this.showSelectionFilterButtons(
):this.hideSelectionFilterButtons()},getNextAvailableGembarForField:function(e){
var t=this.createSchemaDataTable(e);return g.getBestRoleForAddingField(
this.vizModelAdapter,e,{alternateData:t})},findGemsByGembarId:function(e){for(
var t,i=[],r=this.reportDoc.getChildMembers("rowAttributes"),o=0;o<r.length;o++
)t=(t=this.getGem(r[o].getAttribute("formula")))||this.createGemDomNode(r[o],
"rowAttributes"),this.isReportFormatPivot()?"rows"==e&&i.push(t):t.getGembarId(
)==e&&i.push(t);for(r=this.reportDoc.getChildMembers("columnAttributes"),
o=0;o<r.length;o++)t=(t=this.getGem(r[o].getAttribute("formula"))
)||this.createGemDomNode(r[o],"columnAttributes"),this.isReportFormatPivot(
)?"columns"==e&&i.push(t):t.getGembarId()==e&&i.push(t);for(
r=this.reportDoc.getChildMembers("measures"),o=0;o<r.length;o++)t=(
t=this.getGem(r[o].getAttribute("id")))||this.createGemDomNode(r[o],"measures"),
this.isReportFormatPivot()?"measures"==e&&i.push(t):t.getGembarId()==e&&i.push(t
);return this.isReportFormatPivot()||i.sort(function(e,t){e=e.getGembarOrdinal()
,t=t.getGembarOrdinal();return e<t?-1:t<e?1:0}),i},validateLayoutState:function(
){if(!this.isReportFormatPivot()){var e,t,i,r,c=this,
h=this.vizModelAdapter.$type,o=[],s=Object.create(null),a=0,
u=this.createSchemaDataTable();for(h.eachVisualRole(function(e){o.push(e)}),
o.sort(v),i=c.reportDoc.getChildMembers("rowAttributes"),e=0,t=i.length;e<t;e++
)l(i[e],!1);for(i=c.reportDoc.getChildMembers("columnAttributes"),e=0,
t=i.length;e<t;e++)l(i[e],!1);for(i=c.reportDoc.getChildMembers("measures"),e=0,
t=i.length;e<t;e++)l(i[e],!0);Object.keys(s).forEach(function(e){s[e].sort(d)}),
c.setVizModelRolesDirty(),o.forEach(function(e){var e=e.name,t=s[e];
void 0!==t&&(delete s[e],p(t))}),r=[],Object.keys(s).forEach(function(e){
r.push.apply(r,s[e])}),r.sort(n),p(r)}function l(e,t){var i,r,o,l,n;
t&&"true"===e.getAttribute("hideInChart")||(i=e.getAttribute("formula"),
t=t?e.getAttribute("id"):i,o=(r=e.getAttribute("gembarId"))||"",l=+(
r&&e.getAttribute("gembarOrdinal"))||0,void 0===(n=s[o])&&(s[o]=n=[]),n.push({
id:t,formula:i,index:a++,element:e,roleName:r,roleOrdinal:l})),
e.removeAttribute("gembarOrdinal"),e.removeAttribute("gembarId")}function n(e,t
){return e.index-t.index}function d(e,t){return e.roleOrdinal-t.roleOrdinal||n(e
,t)}function p(e){e.forEach(m)}function m(e){var t=null,i=e.id,r=e.roleName;if(
null==(t=null!=r&&null!==h.get(r,!0)?g.testAddFieldAtAutoPosition(
c.vizModelAdapter,r,i,{alternateData:u}):t)&&null==(
t=g.getBestRoleForAddingField(c.vizModelAdapter,i,{alternateData:u})))return!1;
var r=e.element,i=t.name,o=t.fieldPosition;r.setAttribute("gembarId",i),
r.setAttribute("gembarOrdinal",-1);for(var l=c.findGemsByGembarId(i),n=0,s=1,
a=l.length;s<a;s++)n===o&&n++,l[s].setGembarOrdinal(n++);return r.setAttribute(
"gembarOrdinal",o),c.setVizModelRolesDirty(),!0}},getNextOrdinal:function(e){
for(var t,i=-1,r=this.reportDoc.getChildMembers("rowAttributes"),
o=0;o<r.length;o++)r[o].getAttribute("gembarId")===e&&i<(t=parseInt(r[o
].getAttribute("gembarOrdinal")))&&(i=t);for(r=this.reportDoc.getChildMembers(
"columnAttributes"),o=0;o<r.length;o++)r[o].getAttribute("gembarId")===e&&i<(
t=parseInt(r[o].getAttribute("gembarOrdinal")))&&(i=t);for(
r=this.reportDoc.getChildMembers("measures"),o=0;o<r.length;o++)r[o
].getAttribute("gembarId")===e&&i<(t=parseInt(r[o].getAttribute("gembarOrdinal")
))&&(i=t);return i+1},savePluginDataToXML:function(e){
this.reportDoc.setPluginDataJSON(e)},hideSelectionFilterButtons:function(){
var e=s.byId("selectionFilterPanel");e&&cv.util.hide(e)},
showSelectionFilterButtons:function(){var e,t,i,r=s.byId("selectionFilterPanel")
r?cv.util.isHidden(r)&&(r.style.height="0px",cv.util.show(r),n.wipeTo({node:r,
duration:150,height:cv.isMobile()?35:27}).play()):((e=document.createElement(
"div")).id="selectionFilterPanel",
e.innerHTML='<div class="btnContainer"><button onclick="this.blur();" style="border-top-right-radius:0px; border-bottom-right-radius:0px;" type="button" class="pentaho-button" id="cmdSelectionKeepOnly" title="Keep only selected items">'+cvCatalog.btnSelectionKeepOnly+'</button></div><div class="btnContainer" style="margin-left: -5px;"><button onclick="this.blur();" style="border-top-right-radius:0px; border-bottom-right-radius:0px; border-top-left-radius:0px; border-bottom-left-radius:0px;" type="button" class="pentaho-button" id="cmdSelectionExclude" title="Exclude selected items">'+cvCatalog.btnSelectionExclude+'</button></div><div class="btnContainer" style="margin-left: -5px;"><button onclick="this.blur();" style="border-top-left-radius:0px; border-bottom-left-radius:0px;" type="button" class="pentaho-button" id="cmdClearSelections" title="Clear all selected items">'+cvCatalog.btnClearSelections+"</button></div>"
,this.nodeReportArea.appendChild(e),(r=s.byId("selectionFilterPanel")
).style.marginLeft=(a.position(s.byId(this.nodeReportArea)).w-a.position(r).w
)/2+"px",r.style.height="0px",e=s.byId("cmdSelectionKeepOnly"),t=s.byId(
"cmdSelectionExclude"),i=s.byId("cmdClearSelections"),o(e,"click",l.hitch(this,
"onApplySelectionItems")),o(t,"click",l.hitch(this,"onApplySelectionItems")),o(i
,"click",l.hitch(this,"onClearSelectionItems")),n.wipeTo({node:r,duration:150,
height:cv.isMobile()?35:27}).play())},insertField:function(e,t,i,r,o){if(
this.isReportFormatPivot()){if(
"columns"==e?s="columnAttributes":"rows"==e?s="rowAttributes":"measures"==e&&(
s="measures"),"measures"!=s){
var l=-1==i&&null==r.previousGemBar?this.checkGemHierarchy(s,r.formula,
this.getFieldLabel(r.formula)):this.checkGemHierarchy(s,r.formula,
this.getFieldLabel(r.formula),{refId:s,pos:"append"});if(!l)return u.publish(
"/analyzer/reportDisplayed",this),!1}var l=this.reportDoc.getChildMembers(s);
0==l.length?this.insertGem(r.formula,s,"append",o):(
s=-1!=i&&i<t?"after":"before",(n=t)>=l.length&&(n--,s="after"),l=null!=l[n
].getAttribute("id")?l[n].getAttribute("id"):l[n].getAttribute("formula"),
this.insertGem(r.formula,l,s,o))}else{for(var n="Move",l=(
-1==i&&null==r.previousGemBar&&(this.appendGem(r.formula,!0),n="Add"),
this.getGem(r.formula)),s=(l.setGembarId(e),l.setGembarOrdinal(-1),
this.setVizModelRolesDirty(),l.getHistoryActionCode(n)),
a=this.findGemsByGembarId(e),c=0,h=1;h<a.length;h++)c==t&&c++,a[h
].setGembarOrdinal(c++);l.setGembarOrdinal(t);i={formula:l.getFormula()};
o||this.history.add(new cv.ReportState(s,l.getDisplayLabel(!0),i))}}})});define("pentaho/analyzer/report/cv_rptGem",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dijit/Menu","dojox/collections/Dictionary",
"dojo/dnd/Source","dijit/_base/popup","dijit/Declaration","./cv_rptReport3",
"dojo/dom-class","dijit/MenuItem","dijit/MenuSeparator","dijit/PopupMenuItem",
"dijit/registry","dojo/_base/event","dojo/_base/array","dojo/dom-construct",
"dojo/dom-geometry","common-ui/util/_a11y","common-ui/util/_focus"],function(e,n
,t,o,c,v,i,d,r,s,m,h,p,g,b,l,a,u,N,f,A){e("cv.BaseGem",null,{
constructor:function(e,t){this.report=t,
this.handles=cv.util.createCompositeHandle()},type:null,htmlTemplate:null,
commonCssClass:"dropZoneItem",cssClass:null,cssClassHover:null,popMenu:null,
label:null,xmlNode:null,domNode:null,zone:null,getLink:function(){return null},
getFormula:function(){return this.xmlNode.getAttribute("formula")},
getUniqueId:function(){return this.getFormula()},getId:function(){
return this.getUniqueId()},getXmlAttributes:function(){
return this.xmlNode.attributes},getTagName:function(){
return this.xmlNode.tagName},getZone:function(){return this.zone},
getName:function(e){var t=cv.getFieldHelp().get(this.getFormula(),"displayLabel"
);return t?e?t:cv.util.escapeHtml(t):""},getNamePlural:function(e){
var t=cv.getFieldHelp().get(this.getFormula(),"displayLabelPlural");
return t?e?t:cv.util.escapeHtml(t):""},getDisplayLabel:function(e,t){
t=t?this.xmlNode.selectSingleNode(
"cv:displayLabels/cv:displayLabel[locale='"+t+"']"
):this.xmlNode.selectSingleNode("cv:displayLabels/cv:displayLabel"),
t=t&&t.getAttribute("label")?t.getAttribute("label"):this.getName(!0);
return t?e?t:cv.util.escapeHtml(t):""},getDisplayLabelPlural:function(e,t){
t=t?this.xmlNode.selectSingleNode(
"cv:displayLabels/cv:displayLabel[locale='"+t+"']"
):this.xmlNode.selectSingleNode("cv:displayLabels/cv:displayLabel"),
t=t&&t.getAttribute("labelPlural")?t.getAttribute("labelPlural"
):this.getNamePlural(!0);return t?e?t:cv.util.escapeHtml(t):""},
getGembarId:function(){return this.xmlNode.getAttribute("gembarId")},
setGembarId:function(e){this.xmlNode.setAttribute("gembarId",e)},
getGembarOrdinal:function(){return this.xmlNode.getAttribute("gembarOrdinal")},
setGembarOrdinal:function(e){this.xmlNode.setAttribute("gembarOrdinal",e)},
setDisplayLabel:function(e,t,i){this.report.reportDoc.updateDisplayLabel(
this.xmlNode,e,t,i),this.updateDomNode()},
getCalculateSubtotalsUsingFormula:function(){return this.xmlNode.getAttribute(
"calculateSubtotalsUsingFormula")},setCalculateSubtotalsUsingFormula:function(e
){this.report.reportDoc.updateCalculateSubtotalsUsingFormula(e,this.xmlNode)},
isLast:function(){var e=this.xmlNode.parentNode.selectNodes(
"cv:"+this.xmlNode.tagName);return e[e.length-1]==this.xmlNode},
setXmlNode:function(e){(this.xmlNode=e).parentNode&&(this.zone=this.report.byId(
e.parentNode.tagName))},setSortOrder:function(e){this.xmlNode.setAttribute(
"sortOrderEnum","ASC"==e||"DESC"==e?e:"NONE")},getSortOrder:function(){
return this.xmlNode.getAttribute("sortOrderEnum")},setZone:function(e){
this.zone=e},createDomNode:function(){},destroy:function(){this.handles.remove()
,this.domNode=null},update:function(){},updateDomNode:function(){},
onContextMenu:function(e){this.report.currentSelection=this;var t,
i=cv.util.getDojoWidget(this.popMenu);i&&(this.updatePopupMenu(),
"click"===e.type?cv.util.showPopupMenu(i,e.clientX,e.clientY,A.closestTabbable(
e.target)):(t=N.position(e.currentTarget.id),cv.util.showPopupMenu(i,t.x+t.w,
t.y+t.h,e.target)),l.stop(e))},onMouseOver:function(e){
this.cssClassHover&&m.add(this.domNode,this.cssClassHover)},onMouseOut:function(
e){this.cssClassHover&&m.remove(this.domNode,this.cssClassHover)},
onClick:function(e){d.close()},updatePopupMenu:function(){},
getHistoryActionCode:function(e){return"action"+e}}),currentGem=null,e(
"cv.AttributeGem",cv.BaseGem,{constructor:function(e,t){
this.bad=!this.report.validateField(e.getAttribute("formula")),
this.bad?cv.util.removeNode(e):this.setXmlNode(e)},type:cvConst.TYPE_ATTRIBUTE,
htmlTemplate:"<div class='gemLabel'>%{0}</div>",cssClass:"attributeItem",
cssClassHover:"attributeItemHover",popMenu:"attributePopMenu",
updatePopupMenu:function(){var e=this.getSortOrder(),t=this.getFormula(),i=(
this.report.isReportFormatPivot()?(cv.util.setMenuItem("PM:wordWrap",
this.isWordWrap()?"checked":"none","enabled"),
this.report.reportDoc.getSortedMetric()&&"rowAttributes"==this.getZone(
)&&this.isLast()&&(e="NONE")):(cv.util.setMenuItem("PM:wordWrap","none",
"disabled"),this.report.reportDoc.getSortedMetric()&&"rows"==this.getGembarId(
)&&(e="NONE")),this.report.getGem("filter_"+t)),i=(cv.util.setMenuItem(
"PM:attrFilter",i?"checked":"none","enabled"),cv.util.setMenuItem(
"PM:attrFilterRank",this.report.reportDoc.isUsedByMetricFilter(t,"RANK"
)?"checked":"none"),cv.util.setMenuItem("PM:attrSortAZ",
"ASC"==e?"checked":"none"),cv.util.setMenuItem("PM:attrSortZA",
"DESC"==e?"checked":"none"),!this.isLast());cv.util.setMenuItem("PM:attrShowSub"
,i&&"true"==this.xmlNode.getAttribute("showSubtotal")?"checked":"none",
i?"enabled":"disabled"),this._createHierarchyMenu(),this._createPropertiesMenu()
},_createHierarchyMenu:function(){var e=this.getFormula(),t=cv.getFieldHelp(
).getHierarchy(e),i=cv.util.getDojoWidget("PM:addHier");if(!t||t.length<=1
)i.setDisabled(!0);else{i.setDisabled(!1);this.getZone();
var r=cv.util.getDojoWidget("hierarchyPopMenu");r&&r.destroyDescendants();for(
var o=0;o<t.length;++o){var s,l=t[o],a=this.report.getFieldLabel(l);l&&a&&(
l==e?s=new h({id:"HierPop:"+l,label:a,disabled:!0}):this.report.getGem(l)?(
s=new h({id:"HierPop:"+l,label:a})
).iconNode.src=cv.contextPath+"images/checkmark.png":(s=new h({id:"HierPop:"+l,
label:a}),n(s,"Click",cv.util.bindRestoreFocus({form:l,execute:function(){
cv.getActiveReport().insertGemInHierarchy(this.form),d.close()}},"execute"))),
r.addChild(s))}}},_createPropertiesMenu:function(){var e=this.getFormula(),
t=cv.getFieldHelp().getProperties(e);if(!t||t.length<1)cv.util.getDojoWidget(
"PM:addProp").setDisabled(!0);else{cv.util.getDojoWidget("PM:addProp"
).setDisabled(!1);for(var i=b.byId("propertiesPopMenu"),r=(
i&&i.destroyDescendants(),currentGem=this,new h({id:"PropPop:AllMemberProps",
label:cvCatalog.memberPropertiesAddProps})),o=(n(r,"click",
cv.util.bindRestoreFocus(null,function(){currentGem.addAllProperties(),d.close()
})),i.addChild(r),r=new p,i.addChild(r),Math.floor((this.report.reportHeight-125
)/25)),s=this.getProperties(),l=0;l<t.length;++l){l%o==o-1&&(a=new c,m.add(
a.domNode,"pentaho-menu-outer pentaho-menu"),u=new g({
label:cvCatalog.memberPropertiesMoreProps,popup:a}),i.addChild(new p),
i.addChild(u),i=a);var a,u=t[l];s[u]?(r=new h({id:"PropPop:"+u,label:u}),
m.remove(r.iconNode,"dijitNoIcon"),m.add(r.iconNode,"checked"),n(r,"Click",
cv.util.bindRestoreFocus({prop:u,execute:function(){currentGem.removeProperty(
this.prop),d.close()}},"execute"))):(r=new h({id:"PropPop:"+u,label:u}),
m.remove(r.iconNode,"dijitNoIcon"),m.add(r.iconNode,"unchecked"),n(r,"Click",
cv.util.bindRestoreFocus({prop:u,execute:function(){currentGem.addProperty(
this.prop),d.close()}},"execute"))),i.addChild(r)}}},getProperties:function(){
for(var e=this.xmlNode.selectNodes("cv:property"),t={},i=0;i<e.length;++i){
var r=e[i].getAttribute("name");t[r]=r}return t},addProperty:function(e){
this.getProperties()[e]||(this.report.reportDoc.addMemberProperty(this.xmlNode,e
),this.report.history.add(new cv.ReportState("actionAdd",e)),
this.report.refreshReport())},addAllProperties:function(){for(
var e=cv.getFieldHelp().getProperties(this.getFormula()),t=this.getProperties(),
i=!1,r=0;r<e.length;++r){var o=e[r];t[o]||(i=!0,
this.report.reportDoc.addMemberProperty(this.xmlNode,o))}i&&(
this.report.history.add(new cv.ReportState("actionAdd",
cvCatalog.memberPropertiesAddProps)),this.report.refreshReport())},
removeProperty:function(e){var t=this.xmlNode.selectSingleNode(
"cv:property[@name='"+e+"']");t&&(cv.util.removeNode(t),this.report.history.add(
new cv.ReportState("actionRemove",e)),this.report.refreshReport())},
getLink:function(){return this.xmlNode.selectSingleNode("cv:link")},
setLink:function(e,t){var i=this.xmlNode.selectSingleNode("cv:link");
i&&cv.util.removeNode(i),this.report.reportDoc.addLink(this.xmlNode,e,t)},
removeLink:function(){var e=this.xmlNode.selectSingleNode("cv:link");
e&&cv.util.removeNode(e)},setSortFormula:function(e){
e&&"TOTAL"!=e?this.xmlNode.setAttribute("sortFormula",e
):this.xmlNode.removeAttribute("sortFormula")},getSortFormula:function(){
return this.xmlNode.getAttribute("sortFormula")},getHistoryActionCode:function(e
){return"action"+e+"Level"},isWordWrap:function(){
return"true"===this.xmlNode.getAttribute("wordWrap")}}),e("cv.MetricGem",
cv.BaseGem,{constructor:function(e,t){var i=e.getAttribute("formula");if(
this.bad=!!i&&!this.report.validateField(i),this.popMenu="measurePopMenu",
!this.bad)if(this.metricType=e.getAttribute("measureTypeEnum"),
this.isSummaryMetric()){var i=e.selectSingleNode("cv:summaryFacet");i&&(
"LABEL"!=i.getAttribute("summaryAcrossEnum")||this.report.validateField(
i.getAttribute("breakAttributeFormula")))||(this.bad=!0)}else if(
"EXPRESSION"==this.metricType){i=e.selectSingleNode("cv:expression");if(i){
var r=cv.textContent(i).match(/\[Measures\]\.\[[^\]]+\]/g);if(r)for(
var o=0;o<r.length;++o)if(!this.report.validateField(r[o],!0)){this.bad=!0;break
}}else this.bad=!0}else"TREND"!=this.metricType||(i=e.selectSingleNode(
"cv:trendFacet"))&&this.report.validateField(i.getAttribute(
"trendAttributeFormula"))||(this.bad=!0);this.bad?cv.util.removeNode(e):(
this.id=e.getAttribute("id"),this.id||(
this.id=this.report.reportDoc.getNextMetricId(),e.setAttribute("id",this.id)),
this.setXmlNode(e))},type:cvConst.TYPE_METRIC,
htmlTemplate:"<div class='gemLabel'>%{0}</div>",cssClass:"metricItem",
cssClassHover:"metricItemHover",popMenuOrigin:"measurePopMenu",id:null,
metricType:null,getFormula:function(){
return"VALUE"==this.metricType?this.xmlNode.getAttribute("formula"):this.id},
getBaseFieldFormula:function(){
return"EXPRESSION"==this.metricType?null:this.xmlNode.getAttribute("formula")},
getId:function(){return this.id},getUniqueId:function(){return this.id},
getDisplayLabel:function(e,t){var i;
return"VALUE"==this.metricType?cv.BaseGem.prototype.getDisplayLabel.call(this,e,
t):(t=this.xmlNode.selectSingleNode(
t?"cv:displayLabels/cv:displayLabel[locale='"+t+"']":"cv:displayLabels/cv:displayLabel"
))&&t.getAttribute("label")?e?t.getAttribute("label"):cv.util.escapeHtml(
t.getAttribute("label")):(i="EXPRESSION"==this.metricType?this.id:(
i=cv.getFieldHelp().get(this.xmlNode.getAttribute("formula"),"displayLabel",!e)
)||cvCatalog.missingFieldLabel,cv.util.substituteParams(cvCatalog[
"metric"+this.metricType],i))},update:function(e){if(this.isSummaryMetric()){
var t=this.xmlNode.selectSingleNode("cv:summaryFacet");if(!t)return!1;
t.setAttribute("summaryAcrossEnum",e.sumAcross),t.setAttribute(
"useNonVisualTotals",e.sumTotal),"LABEL"==e.sumAcross?t.setAttribute(
"breakAttributeFormula",e.sumBreakBy):t.removeAttribute("breakAttributeFormula")
}else"EXPRESSION"==this.metricType?cv.textContent(this.getMetricFacet(),
e.expression):"TREND"==this.metricType&&((t=this.getMetricFacet()).setAttribute(
"trendTypeEnum",e.trendType),t.setAttribute("amount",e.trendAmount),
t.setAttribute("trendDirectionEnum",e.trendDir),t.setAttribute(
"trendAttributeFormula",e.trendField));
e.label&&this.report.reportDoc.updateDisplayLabel(this.xmlNode,e.label),
e.numberFormat&&this.setNumberFormat(e.numberFormat),this.updateDomNode()},
updatePopupMenu:function(){for(var e=this.getSortOrder(),t=this.getFormula(),
i=this._getSortCtx(),r=this.report.gemList.getKeyList(),o="",s=!0,
l=0;l<r.length;++l){var a=this.report.gemList.item(r[l]);
a.type==cvConst.TYPE_ATTRIBUTE&&i[a.getId()]&&"TOTAL"!=i[a.getId()]&&(s||(
o+=", "),o+=cv.util.parseMDXExpression(i[a.getId()]),s=!1)}var u,
n=o=o+" "+cvCatalog.popupMenuNumberSortValue,c=(25<o.length&&(o=o.substr(0,25
)+"..."),!0);for(u in i)if(("TOTAL"!=i[u]||this.report.getGem(u).getSortFormula(
))&&i[u]!=this.report.getGem(u).getSortFormula()){c=!1;break}
var d=cv.util.getDojoWidget("PM:measSortLowHi"),d=(d.setLabel(
cv.util.substituteParams(cvCatalog.popupMenuNumberSortLowHigh,o)),
d.domNode.title=cv.util.substituteParams(cvCatalog.popupMenuNumberSortLowHigh,n
).replace("&#8594;","→"),(d=cv.util.getDojoWidget("PM:measSortHiLow")).setLabel(
cv.util.substituteParams(cvCatalog.popupMenuNumberSortHighLow,o)),
d.domNode.title=cv.util.substituteParams(cvCatalog.popupMenuNumberSortHighLow,n
).replace("&#8594;","→"),cv.util.setMenuItem("PM:measSortLowHi",
c&&"ASC"==e?"checked":"none"),cv.util.setMenuItem("PM:measSortHiLow",
c&&"DESC"==e?"checked":"none"),cv.util.setMenuItem("PM:measFilterCond",
this.report.reportDoc.isUsedByMetricFilter(t,"CONDITIONS")?"checked":"none"),
cv.util.setMenuItem("PM:measFilterRank",
this.report.reportDoc.isUsedByMetricFilter(t,"RANK")?"checked":"none"),
cv.util.setMenuItem("PM:helpMetric",null,
"VALUE"==this.metricType?"enabled":"disabled"),cv.util.updateMenuItemCaption(
"PM:inChartHideMetric",this.isHideInChart(
)?"menuShowOnChart":"menuHideFromChart"),cv.util.getDojoWidget("newNumberMenu"),
cv.util.displayWidget("PM:editMeasureSummary",this.isSummaryMetric()),
cv.util.displayWidget("PM:editMeasureArith","EXPRESSION"==this.metricType),
"EXPRESSION"==this.metricType&&cv.api.util._hasInlineModelingPermission(
)&&!cv.getFieldHelp().disableInlineModeling),m=(cv.util.displayWidget(
"PM:addCalcMeasureToDataSourceSeparator",d),cv.util.displayWidget(
"PM:addCalcMeasureToDataSource",d),cv.util.displayWidget("PM:editMeasureTrend",
"TREND"==this.metricType),cv.util.displayWidget("menuSeparator",
this.isSummaryMetric()||"TREND"==this.metricType||"EXPRESSION"==this.metricType)
,cv.util.getDojoWidget("condFormatMenu"),this.getNumberFormat()),h=[
"COLOR_SCALE_G_Y_R","COLOR_SCALE_R_Y_G","COLOR_SCALE_B_Y_R","COLOR_SCALE_R_Y_B",
"DATA_BAR_RED","DATA_BAR_GREEN","DATA_BAR_BLUE","TREND_ARROW_GR",
"TREND_ARROW_RG"];for(l in h)cv.util.setMenuItem("PM:condFormat_"+h[l],
m.formatShortcut==h[l]?"checked":"none");this._createSwapWithMeasureMenu()},
_createSwapWithMeasureMenu:function(){if(e=b.byId("swapMeasurePopMenu")){var e,
t=this.report.reportDoc.getMetrics();if(
t.length<=1||this.report.isReportFormatPivot())cv.util.getDojoWidget(
"PM:swapMeasure").setDisabled(!0);else for(cv.util.getDojoWidget(
"PM:swapMeasure").setDisabled(!1),(e=b.byId("swapMeasurePopMenu")
)&&e.destroyDescendants(),currentGem=this,x=0;x<t.length;++x){var i,r=t[x
].getAttribute("id");r!=this.id&&(i=new h({id:"swapWithPop:"+r,
label:this.report.getFieldLabel(r,!1)}),n(i,"Click",cv.util.bindRestoreFocus({
measureId:r,execute:function(){currentGem._swapMeasure(this.measureId),d.close()
}},"execute")),e.addChild(i))}}},_swapMeasure:function(e){
var t=this.report.getGem(e),i=this.xmlNode.getAttribute("gembarId"),
r=this.xmlNode.getAttribute("gembarOrdinal");"true"==t.xmlNode.getAttribute(
"hideInChart")?(this.xmlNode.removeAttribute("gembarId"),
this.xmlNode.removeAttribute("gembarOrdinal"),this.xmlNode.setAttribute(
"hideInChart","true")):t.xmlNode.getAttribute("gembarId")?(
this.xmlNode.setAttribute("gembarId",t.xmlNode.getAttribute("gembarId")),
this.xmlNode.setAttribute("gembarOrdinal",t.xmlNode.getAttribute("gembarOrdinal"
))):(this.xmlNode.removeAttribute("gembarId"),this.xmlNode.removeAttribute(
"gembarOrdinal")),t.xmlNode.setAttribute("gembarId",i),t.xmlNode.setAttribute(
"gembarOrdinal",r),t.xmlNode.removeAttribute("hideInChart"),
this.report.history.add(new cv.ReportState("actionSwapMeasure",
this.report.getFieldLabel(e,!0))),this.report.setVizModelRolesDirty(),
this.report.refreshReport()},getNumberFormat:function(){
var e=this.report.reportDoc.getNumberFormat(this.xmlNode);return e||((
e="VALUE"==this.metricType?cv.getFieldHelp().get(this.xmlNode.getAttribute(
"formula"),"format"):"PCTOF"==this.metricType||"PCTRSUM"==this.metricType?{
formatCategory:"Percentage (%)",formatScale:"2"}:{
formatCategory:"General Number",formatScale:"0"}).formatExpression="",
e.formatShortcut="NONE",e.currencySymbol=cv.analyzerProperties[
"renderer.currency.symbol"],e.measureDisplayUnits="UNITS_0"),e},
setNumberFormat:function(e){this.report.reportDoc.setNumberFormat(this.xmlNode,e
)},isSummaryMetric:function(){return-1<a.indexOf(["PCTOF","RSUM","PCTRSUM",
"RANK"],this.metricType)},getMetricFacet:function(){return this.isSummaryMetric(
)?this.xmlNode.selectSingleNode("cv:summaryFacet"
):"TREND"==this.metricType?this.xmlNode.selectSingleNode("cv:trendFacet"
):"EXPRESSION"==this.metricType?this.xmlNode.selectSingleNode("cv:expression"
):null},setGembarId:function(e){this.inherited(arguments),
e&&this.setHideInChart(!1)},isHideInChart:function(){
return"true"==this.xmlNode.getAttribute("hideInChart")},setHideInChart:function(
e){e=!!e,this.xmlNode.setAttribute("hideInChart",String(e)),e&&(
this.xmlNode.removeAttribute("gembarOrdinal"),this.xmlNode.removeAttribute(
"gembarId"))},setSortOrder:function(e){if("ASC"==e||"DESC"==e)for(
var t=this._getSortCtx(),i=this.report.gemList.getKeyList(),r=0;r<i.length;++r){
var o=this.report.gemList.item(i[r]);
o.type==cvConst.TYPE_ATTRIBUTE&&o.setSortFormula(t[o.getId()])}this.inherited(
arguments)},_getSortCtx:function(){if(!(e=cv.util.popupSourceNode?dojo.fromJson(
cv.util.popupSourceNode.getAttribute("sortctx")):e))for(var e={},
t=this.report.gemList.getKeyList(),i=0;i<t.length;++i){
var r=this.report.gemList.item(t[i]);
r.type==cvConst.TYPE_ATTRIBUTE&&"columnAttributes"==r.getZone()&&(e[r.getId()
]="TOTAL")}return e},getHistoryActionCode:function(e){return"action"+e+"Measure"
}}),e("cv.FilterGem",cv.BaseGem,{constructor:function(e,t,i){if(
this._contentHandles=cv.util.createCompositeHandle(),this.isNumeric=i,
this.bad=!t.validateField(e.getAttribute("formula")),!this.bad)if(this.isNumeric
){for(var r,o=(l=e.selectNodes("cv:conditions/cv:condition")).length,
s=0;l&&s<l.length;++s)r=l[s],t.validateField(r.getAttribute("formula"))||(
cv.util.removeNode(r),--o);0==o&&0<l.length&&e.removeChild(e.selectSingleNode(
"cv:conditions")),(r=e.selectSingleNode("cv:topBottom"))&&!t.validateField(
r.getAttribute("formula"))&&(e.removeChild(r),r=null),r||0!=o||(this.bad=!0)
}else{(l=e.selectNodes("cv:predicates/cv:predicate"))&&0!=l.length||(this.bad=!0
);for(var l,a=cv.getFieldHelp().isTimeAttribute(e.getAttribute("formula")),
u=0;u<l.length;++u){var n=l[u].getAttribute("operatorEnum"),c=l[u].getAttribute(
"preset");a||!c&&"BETWEEN"!=n&&"BEFORE"!=n&&"AFTER"!=n||(this.bad=!0)}
this.bad&&(t.badFilters=!0)}this.bad?cv.util.removeNode(e):this.setXmlNode(e)},
type:cvConst.TYPE_FILTER,htmlTemplate:cvCatalog.filterTemplate,
cssClass:"filterItem",cssClassHover:null,popMenu:"filterPopMenu",itemCount:0,
getUniqueId:function(){return"filter_"+(this.isNumeric?"metric":this.getFormula(
))},createDomNode:function(){this.domNode=u.create("div",{
innerHTML:this.htmlTemplate}).firstChild,this.domNode.id=this.getUniqueId(),
this.domNode.setAttribute("formula",this.getFormula()),this.updateDomNode(),
this.handles.add(n(this.domNode,"contextmenu",o.hitch(this,"onContextMenu")))},
updateDomNode:function(){var e=u.create("div",{innerHTML:this.createSummary()}
).childNodes;for(this._contentHandles.remove(),u.empty(this.domNode);0<e.length;
)this.domNode.appendChild(e[0]);this.addDomNodeInteraction(this.domNode,
this._contentHandles),m.add(this.domNode,"unlocked")},
addDomNodeInteraction:function(e,t){var i=o.hitch(this.report,"onRemoveFilter"),
r=o.hitch(this.report,"onEditFilter");e.querySelectorAll(".remove-filter-button"
).forEach(function(e){t.add(n(e,"click",i),f.makeAccessibleActionButton(e))}),
e.querySelectorAll(".edit-filter-button").forEach(function(e){t.add(n(e,"click",
r),f.makeAccessibleActionButton(e))})},onContextMenu:function(e){var t,i,r,o;
this.report.currentSelection&&(cv.util.popupSourceNode=this.domNode,
t=cv.util.getDojoWidget(this.popMenu))&&(this.updatePopupMenu(),i=e.target,
r=this.report.currentSelection.querySelector(".edit-filter-button"),
o=this.report.currentSelection.querySelector(".remove-filter-button"),
A.isTabbable(i)||A.isTabbable(i=r)||(i=o),cv.util.showPopupMenu(t,e.clientX,
e.clientY,i),l.stop(e))},updatePopupMenu:function(){
var e=this.report.getFieldLabel(this.getFormula());
cv.util.updateMenuItemCaption("PM:addFilter","menuAddFilter",e),
cv.util.setMenuItem("PM:editFilter",null,"enabled"),cv.util.setMenuItem(
"PM:removeFilter",null,"enabled"),cv.util.setMenuItem("PM:addFilter",null,
"enabled"),cv.util.setMenuItem("PM:removeFilter",null,
this.report.currentSelection.id?"enabled":"disabled")},getViewType:function(){
return this.xmlNode.getAttribute("viewFilterEnum")},setViewType:function(e){
this.xmlNode.setAttribute("viewFilterEnum",e),"NONE"!=e?m.add(this.domNode,
"unlocked"):m.remove(this.domNode,"unlocked")},createSummary:function(e){
var t="",i=this.report.getFieldLabel(this.getFormula());if(this.isNumeric){
this.itemCount=1;for(var r,o,s=this.xmlNode.selectNodes(
"cv:conditions/cv:condition"),l=0;s&&l<s.length;++l)r=s[l],
t+="<div class='filterItemList'>"+cv.util.substituteParams(cvCatalog[
"filterSummMetric"+r.getAttribute("operator")],{
METRIC:this.report.getFieldLabel(r.getAttribute("formula")),OP1:r.getAttribute(
"op1"),OP2:r.getAttribute("op2"),ATTR:i})+"</div>";(
r=this.xmlNode.selectSingleNode("cv:topBottom"))&&(
t+="<div class='filterItemList'>"+cv.util.substituteParams(cvCatalog[
"filterSummMetric"+r.getAttribute("type")],{METRIC:this.report.getFieldLabel(
r.getAttribute("formula")),COUNT:r.getAttribute("count"),ATTR:i})+"</div>"),
this.isNumeric&&(o=cv.util.escapeHtml(this.getFormula()),
t=cv.util.substituteParams(cvCatalog.filterTemplateMetric,o,t))}else{for(
var s=this.xmlNode.selectNodes("cv:predicates/cv:predicate"),a=new v,
u=0;u<s.length;++u){var n=this._createPredicateSummary(s[u]).split("`"),c=s[u
].getAttribute("ordinal");if(a.contains(c))for(l=0;l<n.length;++l)a.item(c
).labels.push(n[l]);else a.add(c,{operatorEnum:s[u].getAttribute("operatorEnum"
),labels:n})}var d=a.getKeyList(),m=d.length;if(this.itemCount=m,0==s.length
)return cvCatalog.filterTemplateNone;!e&&1<m&&(t+=cv.util.substituteParams(
cvCatalog.filterTemplateMultiLine,i));for(u=0;u<d.length;u++){for(var h,p="",
g=a.item(d[u]).labels,b=0;b<g.length;b++)0<b?b!=g.length-1||-1<p.indexOf("<a"
)?p+=", "+g[b].replace("includes",""):p+=("NOT_CONTAIN"!=(h=a.item(d[u]
).operatorEnum)&&"CONTAIN"!=h?" and ":" or ")+g[b].replace("includes",""):p=g[b]
t+=e||1!=m?cv.util.substituteParams(cvCatalog.filterTemplateAttr,
this.getFormula(),"filter_"+this.getFormula()+"_"+d[u],p
):cv.util.substituteParams(cvCatalog.filterTemplateSingleLine,this.getFormula(),
"filter_"+this.getFormula()+"_"+d[u],i,p)}}return t},
_createPredicateSummary:function(e){for(var t,i="",r="",o=e.getAttribute(
"operatorEnum"),s=e.selectNodes("cv:member"),l=cv.getFieldHelp().get(
this.getFormula()),a=0;0<s.length&&a<s.length;++a)s[a].getAttribute("formula"
)||(0<a?t+=","+s[a].getAttribute("pos"):t=s[a].getAttribute("pos"));switch(o){
case"EQUAL":case"NOT_EQUAL":if(t){if(!l)return"ERROR";for(var u=cv.getFieldHelp(
).get(l,"type"),n=t.split(","),c=0;c<n.length;++c)0<c&&(i+="`"),
i+="TIME_DATE"==u?cvCatalog["filterPreset"+cv.getFieldHelp().get(l,"type"
)+"_"+n[c].replace(",","a").replace("-","n")]:cvCatalog["filterSummR_3_"+n[c
].replace("-","n")];i=cv.util.substituteParams(i,this.report.getFieldLabel(
this.getFormula()))}else{if(0==s.length)return cvCatalog.filterTemplateNone;if(
s.length<5)for(c=0;c<s.length;++c)i+=(0<c?"` ":"")+cv.util.escapeHtml(s[c
].getAttribute("caption"));else i=cv.util.substituteParams(
cvCatalog.filterSummSimple,cv.util.escapeJavaScript(this.getFormula()),
e.getAttribute("ordinal"),s.length)}break;case"CONTAIN":case"NOT_CONTAIN":
var d=e.selectNodes("cv:containsExpression");if(!d||0==d.length
)return cvCatalog.filterTemplateNone;for(c=0;c<d.length;++c)i+=(0<c?"` ":""
)+cv.util.escapeHtml(cv.textContent(d[c]));break;case"BETWEEN":
r=cv.util.escapeHtml(s[1].getAttribute("caption"));case"BEFORE":case"AFTER":
i=cv.util.escapeHtml(s[0].getAttribute("caption"));break;case"TIME_AHEAD":
case"TIME_AGO":case"TIME_RANGE_NEXT":case"TIME_RANGE_PREV":i=t,
r=this.report.getFieldLabel(this.getFormula());break;case"TIME_YAGO":
return r=this.report.getFieldLabel(this.getFormula()),cv.util.substituteParams(
cvCatalog["filterSumm"+o],r);case"NUMERIC_BETWEEN":case"NUMERIC_GREATER_THAN":
case"NUMERIC_GREATER_THAN_EQUAL":case"NUMERIC_LESS_THAN":
case"NUMERIC_LESS_THAN_EQUAL":i=e.getAttribute("op1"),r=e.getAttribute("op2");
break;default:0<s.length&&(i=cv.util.escapeHtml(s[0].getAttribute("caption")))}
return cv.util.substituteParams(cvCatalog["filterSumm"+o],i,r)},
getHistoryActionCode:function(e){return"action"+e+"Filter"},destroy:function(){
this.inherited(arguments),this._contentHandles.remove(),null!=this.domNode&&(
u.destroy(this.domNode),this.domNode=null)}})});define("pentaho/analyzer/report/cv_rptDlg",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dojox/xml/parser","dijit/registry","dojo/html",
"dojo/_base/array","dojo/json","dojo/string","dojo/request","dojo/dom-class",
"dojo/dom","common-ui/util/_a11y","dojo/dom-style","./cv_rptGem"],(e,S,t,I,R,i,s
,T,c,n,r,F,C,a,E)=>e("cv.ReportDialog",[cv.Dialog],{constructor(e){this.report=e
,this.dlgTemplates={reportOpt_edit:"reportOptionsDlg.html",
report_rename:"saveReportDlg.html",report_props:"reportPropsDlg.html",
report_xml:"reportDefDlg.html",create_calculated_measure:"arithNumberDlg.html",
edit_calculated_measure:"arithNumberDlg.html",
create_measure:"createMeasureDlg.html",
show_measure_properties:"measurePropertiesDlg.html",
show_attribute_properties:"attributePropertiesDlg.html",
remove_measure:"removeMeasureDlg.html",measures_subtotal:"measureDlg.html",
measures_summaries:"summaryMetricsDlg.html",summary_new:"singleSummaryDlg.html",
summary_edit:"singleSummaryDlg.html",measures_arith:"arithNumberDlg.html",
measures_trend:"trendNumberDlg.html",arith_edit:"arithNumberDlg.html",
trend_edit:"trendNumberDlg.html",gem_edit:"editGemDlg.html",
filter_list:"filterListDlg.html",field_edit:"editFieldDlg.html",
fieldHelp_show:"fieldHelpDlg.html",propHelp_show:"fieldHelpDlg.html"},
this.prefixes={reportOpt_edit:"RO_",report_props:"RP_",report_xml:"RD_",
create_calculated_measure:"MA_",edit_calculated_measure:"MA_",
measures_create:"MC_",measures_subtotal:"VF_",measures_summaries:"SM_",
summary_edit:"SM_",summary_new:"SM_",measures_arith:"MA_",measures_trend:"MT_",
arith_edit:"MA_",trend_edit:"MT_",gem_edit:"ED_",filter_list:"FT_",
field_edit:"MF_",fieldHelp_show:"FH_",propHelp_show:"FH_",
gadget_displaying:"GD_",remove_measure:"RM_"},this.helpTopics={
reportOpt_edit:"CV/Business_User/setting_report_preferences.html",
report_props:"",report_xml:"",
measures_subtotal:"CV/Business_User/working_with_calculations.html#displaying_totals_as_averages_max",
measures_summaries:"CV/Business_User/working_with_calculations.html#displaying_percent_rank_etc",
measures_create:"CV/Business_User/working_with_calculations.html#displaying_percent_rank_etc",
summary_edit:"CV/Business_User/working_with_calculations.html#",
summary_new:"CV/Business_User/working_with_calculations.html#",
measures_arith:"CV/Business_User/working_with_calculations.html#",
measures_trend:"CV/Business_User/working_with_calculations.html#",
arith_edit:"CV/Business_User/working_with_calculations.html#",
trend_edit:"CV/Business_User/working_with_calculations.html#",
gem_edit:"CV/Business_User/working_with_fields.html#renaming_a_field",
filter_list:"CV/Business_User/working_with_filters.html#filters_on_text_fields",
field_edit:"CV/Business_User/edit_field.html#edit_field",
fieldHelp_show:"CV/Business_User/working_with_fields.html#viewing_the_definition_of_a_field",
remove_measure_show:"CV/Business_User/working_with_fields.html#viewing_the_definition_of_a_field",
gadget_displaying:""},this.src=null,this.dataSource=null},destroy(){
this.inherited(arguments),this.src=null,this.dataSource=null},
resetUpdateOptions(e){this._resetUpdateOptions(e,"REPORT")},show(e,t,i){
this.dataSource=this.report.currentSelection;var s=this.report["reportDoc"];
switch(t?this.src=t:this.dataSource&&this.dataSource.getZone()&&(
this.src=this.dataSource.getZone()),this.type=this.src+"_"+e,this.param=i,
this.prefix=this.prefixes[this.type],this.dlgTemplate=this.dlgTemplates[
this.type],this.helpTopic=this.helpTopics[this.type],this.defaultFocus=null,
this._widgetCss=null,this.type){case"reportOpt_edit":{if(!this.load())break;
this._widgetCss="responsive dw-xs ds-fill-viewport-width",
this.resetUpdateOptions(s),this.report.manager.isAdministrator&&((r=this.byId(
"setDefaultBox")).checked&&cv.util.check(r,!1),cv.util.show(
this.prefix+"setDefault"));const y=this.dlgWidget;this._own(S(this.byId(
"resetToDefault"),"click",()=>{F.add(y.domNode,"resetting-to-default")})),
this.report.manager.disableDrillLinks&&cv.util.hide("RO_drillLinkTable");
var r=cv.analyzerProperties["report.options.showEmpty"];"disable"!==r&&(
"adminonly"!==r||this.report.manager.isAdministrator)||cv.util.hide(
"RO_showEmptyRow"),cv.util.setHelpTopics(["RO_helpNonVisualTotal",
"CV/Business_User/working_with_calculations.html#non_visual_totals"]),
this.defaultFocus=this.byId("showEmptyCells");break}case"report_props":if(
this._widgetCss="responsive dw-xs ds-fill-viewport-width dmh-content",
this.loadRptProps())for(var[a,o]of Object.entries(
this.report.getReportProperties())){var l,d=this.byId(a);null!=d&&(
"INPUT"===d.tagName||"TEXTAREA"===d.tagName?d.value=o:d.innerHTML=cv.util.escapeHtml(
o),"description"===a&&""===o&&(
"INPUT"===d.tagName||"TEXTAREA"===d.tagName?d.value=cvCatalog.RendererNoDescription:d.innerHTML=cv.util.escapeHtml(
cvCatalog.RendererNoDescription)),"created"!==a&&"update"!==a||""===o||(
l=cv.util.formatDateString(o),d.innerHTML=cv.util.escapeHtml(l)),"folder"===a
)&&o.startsWith("/")&&(d.innerHTML=o.substring(1))}break;case"report_xml":
this._widgetCss="responsive dw-md ds-fill-viewport-width dmh-content",this.load(
)&&(this.byId("reportDef").value=R.innerXML(s.getReportNode()),this.byId(
"pluginData").value=this.report.getPluginDataJSON(),cv.util.setHelpTopics([
this.prefix+"helpPluginData",
"CV/Business_User/working_with_charts.html#configuring-viz-properties-report"]))
break;case"measures_subtotal":if(
this._widgetCss="responsive dw-xs ds-fill-viewport-width",!this.dataSource
)return;if(this.load(this.dataSource.getDisplayLabel())){for(
const v of this.dataSource.getXmlAttributes())this.updateHtml(v.name,v.value);
this.defaultFocus=this.byId("showSum"),S(this.byId("showSumTD"),"click",()=>{
var e=C.byId("VF_showSum");e.checked=!e.checked}),S(this.byId("showAggregateTD")
,"click",()=>{var e=C.byId("VF_showAggregate");e.checked=!e.checked}),S(
this.byId("showAverageTD"),"click",()=>{var e=C.byId("VF_showAverage");
e.checked=!e.checked}),S(this.byId("showMaxTD"),"click",()=>{var e=C.byId(
"VF_showMax");e.checked=!e.checked}),S(this.byId("showMinTD"),"click",()=>{
var e=C.byId("VF_showMin");e.checked=!e.checked})}break;
case"measures_summaries":this._widgetCss="responsive dw-sm",
this.dataSource&&this.load(this.dataSource.getDisplayLabel())&&(
this.param?this.defaultFocus=this.byId(this.param):this.defaultFocus=this.byId(
"PCTOF"),this.defaultFocus.checked=!0);break;case"summary_new":if(
!this.dataSource)return;var r=this.dataSource.getDisplayLabel();this.load(
cvCatalog.summaryMetricTitle,r)&&(h=this.byId("formatCategory"),u=this.byId(
"formatScale"),this.byId("name").value=this._getUniqueLabel(
cv.util.substituteParams(cvCatalog["metric"+i],r)),
"PCTOF"!==i&&"PCTRSUM"!==i&&"RSUM"!==i||(
h.value="RSUM"===i?this.dataSource.getNumberFormat(
).formatCategory:"Percentage (%)",u.value="2"),this.byId(i
).className="summaryOption",r=this.byId("field_"+i),
this.report.addOptionsForAttributes(r,!0)||(r.disabled=!0,this.byId("LABEL_"+i
).disabled=!0),S(C.byId("dlgBtnPrev"),"click",()=>{this.show("summaries",null,
this.param)}),"true"===s.getReportOption("useNonVisualTotals")&&this.displayMsg(
cvCatalog.dlgInfoNonvisualTotal),this.helpTopic+=i,this.defaultFocus=this.byId(
"ROWS_"+i));break;case"summary_edit":if(!this.dataSource)return;
var h=this.dataSource["metricType"],u=this.dataSource.getDisplayLabel();
this.load(cvCatalog.summaryMetricEditTitle,this.report.getFieldLabel(
this.dataSource.getBaseFieldFormula()))&&(this.byId("name").value=u,
this._updateNumberFormat(this.dataSource,!0),this.byId(h
).className="summaryOption",r=this.byId("field_"+h),
this.report.addOptionsForAttributes(r,!0)||(r.disabled=!0,this.byId("LABEL_"+h
).disabled=!0),g=(u=this.dataSource.getMetricFacet()).getAttribute(
"summaryAcrossEnum"),this.updateHtml("RD_"+h,g),"LABEL"===g&&this.updateHtml(r,
u.getAttribute("breakAttributeFormula")),"true"===s.getReportOption(
"useNonVisualTotals")&&this.displayMsg(cvCatalog.dlgInfoNonvisualTotal),
this.helpTopic+=h,this.defaultFocus=this.byId("ROWS_"+h),(g=C.byId("dlgBtnPrev")
)&&E.set(g,"display","none"),g=C.byId("dlgBtnSave"))&&(g.innerHTML="OK");break;
case"create_calculated_measure":case"edit_calculated_measure":
case"measures_arith":case"arith_edit":if("create_calculated_measure"===this.type
){if(!this.load(this.report.getFieldLabel(i)," "))break}else if(!this.load()
)break;r=this.report["arithNumberDlg"];return this._widgetCss=r._widgetCss,
void r.show(i);case"measures_trend":case"trend_edit":if(!this.dataSource)return;
this._widgetCss="responsive dw-sm ds-fill-viewport-width";
var u=this.report.reportDoc.getChildMembers("columnAttributes","rowAttributes"),
c=[];if(u)for(const f of u){var n=f.getAttribute("formula"),p=cv.getFieldHelp(
).getHierarchy(n,!1,!0);if(p)for(const w of p)-1===T.indexOf(c,w)&&c.push(w
);else-1===T.indexOf(c,n)&&c.push(n)}if(0===c.length)return void this.showError(
"errorNoFieldForTrend");if("trend_edit"===this.type){if(!this.load(
this.report.getFieldLabel(this.dataSource.getBaseFieldFormula())))break}else if(
!this.load(this.dataSource.getDisplayLabel()))break;var m=this.byId(
"trendFields");m.innerHTML="";for(const D of c)cv.addOption(m,new Option(
this.report.getFieldLabel(D,!0),D));this._updateNumberFormat(this.dataSource,!0)
,"trend_edit"===this.type?(C.byId("dialogTitleText"
).innerHTML=cvCatalog.trendNumberEditTitle,this.byId("name"
).value=this.dataSource.getDisplayLabel(!0),h=this.dataSource.getMetricFacet(),
this.updateHtml("trendType",h.getAttribute("trendTypeEnum")),this.updateHtml(
"amount",h.getAttribute("amount")),this.updateHtml("trendFields",h.getAttribute(
"trendAttributeFormula"))):(this.baseGemFormat=this.dataSource.getNumberFormat(
).formatCategory,this.byId("formatScale").value="2"),S(this.byId("trendType"),
"change",I.hitch(this,"_onclickTrendType"));break;case"gem_edit":if(
this._widgetCss="responsive dw-sm ds-fill-viewport-width",!this.dataSource
)return;var g=this.dataSource.getDisplayLabel();if(this.dataSource.metricType){
if(!this.load(cvCatalog.editColumn))break}else if(!this.load(g))break;this.byId(
"name").innerHTML=this.dataSource.getName();r=this.byId("displayLabel");
r.value=this.dataSource.getDisplayLabel(!0),this.dataSource.metricType?(
this._widgetCss+=" metric-gem",cv.util.hide("ED_pluralNameRow"),cv.util.hide(
"ED_pluralLabelRow"),this.dataSourceOrigin={},
this.dataSourceOrigin.numberFormat=this._updateNumberFormat(this.dataSource,!0),
"VALUE"!==this.dataSource.metricType&&(cv.util.hide("ED_nameRow"),cv.util.hide(
"blankRow")),u=()=>{var e=this.byId("formatCategory"),t=this.byId(
"formatExpression");cv.util.hide("ED_formatScaleDiv"),cv.util.hide(
"ED_currencySymbolDiv"),cv.util.hide("ED_formatExpRow"),cv.util.hide(
"ED_displayUnitsRow"),"Expression"===e.value?(cv.util.show("ED_formatExpRow"),
""===t.value&&(t.value=cvConst.defaultFormatExp)):"Currency ($)"===e.value?(
cv.util.show("ED_formatScaleDiv"),cv.util.show("ED_currencySymbolDiv"),
cv.util.show("ED_displayUnitsRow")):"Default"!==e.value&&(
"Percentage (%)"===e.value?cv.util.show("ED_formatScaleDiv"
):"General Number"===e.value&&(cv.util.show("ED_formatScaleDiv"),cv.util.show(
"ED_displayUnitsRow")))},S(this.byId("formatCategory"),"change",u),u()):(
this.byId("namePlural").innerHTML=this.dataSource.getNamePlural(),this.byId(
"displayLabelPlural").value=this.dataSource.getDisplayLabelPlural(!0),
cv.util.hide("ED_formatRow","ED_formatExpRow","ED_displayUnitsRow")),
this.defaultFocus=r;break;case"create_measure":if(this.load(
this.report.getFieldLabel(i)," "))return void this.report.createMeasureDlg.show(
i);break;case"remove_measure":if(this.load(this.report.getFieldLabel(i)," ")
)return void this.report.removeMeasureDlg.show(i);break;
case"show_measure_properties":if(this.load(this.report.getFieldLabel(i)," ")
)return h=this.report["measurePropertiesDlg"],this._widgetCss=h._widgetCss,
void h.show(i);break;case"show_attribute_properties":if(this.load(
this.report.getFieldLabel(i)," "))return g=this.report["attributePropertiesDlg"]
,this._widgetCss=g._widgetCss,void g.show(i);break;case"field_edit":break;
case"filter_list":this._widgetCss="responsive dw-sm";u=this.report.getGem(
"filter_"+i);if(!u)return this.report.filterDlg.show(i);if(1===u.itemCount
)return this.report.filterDlg.show(i,1);this.load(this.report.getFieldLabel(i),
cv.util.escapeHtml(i))&&((r=this.byId("predicateList")
).innerHTML=u.createSummary(!0),u.addDomNodeInteraction(r,
cv.util.createCompositeHandle()));break;case"fieldHelp_show":{
this._widgetCss="responsive dw-sm ds-fill-viewport-width";h=cv.getFieldHelp(),
g=h.get(i);let e=h.get(g,"displayLabelOriginal",!0);e=e||"&nbsp;";
u=this.report.getFieldLabel(i),r=h.get(g,"displayLabel",!0);if(!this.load(u,r,e)
)break;u!==r&&cv.util.show("FH_customLabel"),
"nbsp;"!==e&&e!==r&&cv.prefs.isAdmin&&cv.util.show("FH_name");u=h.get(g,
"displayDescription",!0);this.updateHtml("displayDescription",u||r),
this.updateHtml("formula",i);let t=h.get(g,"type");"true"===h.get(g,"calculated"
)&&(t="CALCULATED_"+t),this.updateHtml("type",cvCatalog["fieldTypes_"+t]);
var _=cv.getFieldHelp().getProperties(i);if(_&&1<_.length){let t="";
cv.util.show("FH_memberProperties");for(let e=0;e<_.length;++e){var b=_[e];
0!==e&&(t+=", "),t+=b}this.updateHtml("memberPropertiesDescription",t)}break}
case"propHelp_show":{this._widgetCss="responsive dw-sm";
u=this.dataSource.getAttribute("formula"),r=this.dataSource.getAttribute("name")
,h=cv.getFieldHelp(),g=h.get(u);let e=this.report.getFieldLabel(u);if(
e=e||h.get(g,"displayLabel",!0),!this.load(r,r,r))break;this.updateHtml(
"displayDescription",cv.util.substituteParams(cvCatalog.memberPropertyHelp,r,e))
,this.updateHtml("type",cvCatalog.fieldTypes_PROPERTY);break}default:return}
this.status?alert(this.status):(this.showDialog(),this.lastSaveTime=null)},
_onclickTrendType(e){let t=this.dataSource;"trend_edit"===this.type&&(
t=this.report.getGem(this.dataSource.xmlNode.getAttribute("formula"))),
this.byId("formatCategory"
).value="PCT_CHANGE"===e.target.value?"Percentage (%)":t.getNumberFormat(
).formatCategory},getPendingAction(){var e={func:"saveReportOptions",params:{
refresh:!1}};for(const t of this.theForm.elements
)"INPUT"!==t.tagName&&"SELECT"!==t.tagName||(e.params[this._attributeName(t.id)
]=this._getSrcValue(t));return e},save(e){var{banner:t,reportDoc:i}=this.report,
s=(this.setInvalidInputField(null),t.hide(),this.theForm.elements);let r=!0;
switch(this.type){case"reportOpt_edit":this.pendingAction=this.getPendingAction(
);var a="true"===this.pendingAction.params.setDefaultBox,o=i.getReportOption(
"showEmptyEnum"),l=this.pendingAction.params.showEmptyEnum;if(
"SHOW_MEASURE"===o&&"SHOW_MEASURE"!==l
)return this.pendingAction.params.refresh=!0,
o=a?"promptChangeShowEmptyAndSetDefault":"promptChangeShowEmpty",
cv.getActiveReport().rptDlg.showConfirm([o],null,{srcObj:this,
srcFunc:"saveReportOptions"}),!1;if(a
)return this.pendingAction.params.refresh=!0,cv.getActiveReport(
).rptDlg.showConfirm(["promptSetDefault"],null,{srcObj:this,
srcFunc:"saveReportOptions"}),!1;this.saveReportOptions();break;
case"report_props":this.report.setReportProperties({description:this.byId(
"description").value}),r=!1;break;case"report_xml":l=cv.parseXML(this.byId(
"reportDef").value);if(
!l||!l.documentElement||"report"!==l.documentElement.tagName
)return this.displayError(cvCatalog.errorReportDefinition),!1;try{c.parse(
this.byId("pluginData").value)}catch(e){return this.displayError(
"Invalid visualization state JSON"),!1}this.report.savePluginDataToXML(
this.byId("pluginData").value);try{this.report._clearClientViz(),
this.report.openReport(l.documentElement)}catch(e){
return this.report.history.current().exec(!0),this.displayError(
cvCatalog.errorReportDefinition),!1}this.report.history.add(new cv.ReportState(
"actionImport"));break;case"measures_subtotal":for(
let e=0;null!=this.dataSource&&e<s.length;++e)"INPUT"===s[e
].tagName&&this.updateXml(this.dataSource.xmlNode,s[e]);this.report.history.add(
new cv.ReportState("actionEdit",this.dataSource.getDisplayLabel(!0)));break;
case"measures_summaries":o=this.getRadioGroupValue(this.prefix+"Group");if(o
)return this.show("new","summary",o);r=!1;break;case"summary_new":a=n.trim(
this.byId("name").value),l=this.report.createSpecialMetricGem({
zoneId:"measures",formula:this.dataSource.getFormula(),metricType:this.param,
sumAcross:this.getRadioGroupValue(this.prefix+"RD_"+this.param),
sumTotal:"false",sumBreakBy:this.byId("field_"+this.param).value,
refGem:this.dataSource});this._updateNumberFormat(l),l.setDisplayLabel(a),
this.report.history.add(new cv.ReportState("actionAdd",a));break;
case"summary_edit":o=n.trim(this.byId("name").value),l=this.dataSource[
"metricType"],a={sumAcross:this.getRadioGroupValue(this.prefix+"RD_"+l),
sumBreakBy:this.byId("field_"+l).value,sumTotal:"false"};this.dataSource.update(
a),this._updateNumberFormat(this.dataSource),this.dataSource.setDisplayLabel(o),
i.isUsedByMetricFilter(this.dataSource.getFormula()
)&&this.report.populateFilters(),this.report.history.add(new cv.ReportState(
"actionEdit",o));break;case"create_calculated_measure":
case"edit_calculated_measure":case"measures_arith":case"arith_edit":
r=this.report.arithNumberDlg.save();break;case"measures_trend":case"trend_edit":
{var d={zoneId:"measures",metricType:"TREND",formula:this.dataSource.getFormula(
),trendType:this.byId("trendType").value,trendDir:this.byId("direction").value,
trendAmount:this.byId("amount").value,trendField:this.byId("trendFields").value,
refGem:this.dataSource},h=cv.getFieldHelp().getHierarchy(d.trendField);if(h)for(
let e=T.indexOf(h,d.trendField)+1;e<h.length;++e){var{[e]:u}=h;if(
!this.report.getGem(u)&&this.report.getGem("filter_"+u))return this.showError([
"errorAddTrendWithFilterOnChild",this.report.getFieldLabel(u),
this.report.getFieldLabel(d.trendField)]),!1}if(!this._validateName()
)return this.byId("name").focus(),!1;l=this._validateAmountField(d.trendAmount);
if(l)return this.displayMsg(cvCatalog[l]),this.byId("amount").focus(),!1;let e;
e="trend_edit"===this.type?(this.dataSource.update(d),"actionEdit"):(
this.dataSource=this.report.createSpecialMetricGem(d),"actionAdd");a=n.trim(
this.byId("name").value);this.dataSource.setDisplayLabel(a),
this._updateNumberFormat(this.dataSource),this.report.history.add(
new cv.ReportState(e,a)),"trend_edit"===this.type&&i.isUsedByMetricFilter(
this.dataSource.getFormula())&&this.report.populateFilters();break}
case"gem_edit":if(this.dataSource.metricType&&(this._updateNumberFormat(
this.dataSource),"Expression"===this.byId("formatCategory").value)){if(
""===this.byId("formatExpression").value)return this.displayError(
"Format expression cannot be empty."),!1;o=cv.util.parseAjaxMsg(cv.io.ajaxLoad(
"service/ajax/parseReport",{reportXML:this.report.getReportXml(),
annotations:this.report.getModelAnnotationsJson()},!0));if("error"===o?.type
)return this.displayError(o.details||cvCatalog.dlgErrGeneric),!1}
this.dataSource.setDisplayLabel(n.trim(this.byId("displayLabel").value),n.trim(
this.byId("displayLabelPlural").value)),this.report.populateFilters(),
this.report.history.add(new cv.ReportState("actionRename"));break;
case"create_measure":this.report.createMeasureDlg.save();break;
case"remove_measure":this.report.removeMeasureDlg.save();break;
case"show_measure_properties":this.report.measurePropertiesDlg.save();break;
case"show_attribute_properties":this.report.attributePropertiesDlg.save();break;
default:r=!1}t=!e&&!this.report.rptDlg.noHide;return t&&this.dlgWidget.hide(),
r&&this.report.refreshReport(),t},openDrillDlg(){const{rptDlg:e,drillDlg:t
}=cv.getActiveReport(),i=this.getPendingAction();e.showConfirm([
"promptOpenDrillDlg"],null,{srcFunc:()=>{this.saveReportOptions(i),t.show()}},{
srcFunc:()=>{this.showReportOptions()}})},cancel(){switch(this.type){
case"gem_edit":this.dataSource.metricType&&this.dataSource.setNumberFormat(
this.dataSourceOrigin.numberFormat);break;case"create_calculated_measure":
case"edit_calculated_measure":case"measures_arith":case"arith_edit":
this.report.arithNumberDlg.cancel();break;case"alertDlg":if(
this._alertCallbacks.onCancel)return}cv.Dialog.prototype.cancel.call(this)},
showEditColumn(){this.show("edit","gem")},showEditSummaryMeasure(){this.show(
"edit","summary")},showEditArithMeasure(){this.show("edit","arith")},
showEditTrendMeasure(){this.show("edit","trend")},showReplaceAttribute(){
this.show("replace","attribute")},resetToDefault(){this._resetToDefault("REPORT"
)},showReportOptions(){this.show("edit","reportOpt")},showReportProps(){
this.show("props","report")},loadRptProps(...e){var t;return this.status=null,
this.cache[this.type]||r.get(
cv.contextPath+"service/templates/"+this.dlgTemplate,{handleAs:"text",sync:!0}
).then(e=>{cv.util.parseAjaxMsg(e)?this.status="errorDlgLoad":this.cache[
this.type]=e},()=>{this.status="errorDlgLoad"}),null==this.status&&(
t=this.cache[this.type],e=0<e.length?cv.util.substituteParams(t,e):t,
this._initDialogWidget(e),(t=this.byId("editDescButton"))&&(S(t,"click",
this.showEditDesc.bind(this)),a.makeAccessibleActionButton(t)),(e=this.byId(
"descBtnCancel"))&&S(e,"click",this.hideEditDesc.bind(this)),(t=this.byId(
"descBtnSave"))&&S(t,"click",this.saveRptDesc.bind(this)),(e=this.byId(
"closeButton"))&&(S(e,"click",this.cancel.bind(this)),
a.makeAccessibleActionButton(e)),!0)},showReportDefinition(){this.show("xml",
"report")},showSubtotals(){this.show("subtotal")},showNewSummaryOptions(){
this.show("summaries")},showNewArithBuilder(){this.show("arith")},
showNewTrendNumber(){this.show("trend")},showCreateMeasureDlg(){this.show(
"measure","create")},showCreateCalculatedMeasureDlg(){this.show(
"calculated_measure","create")},showEditCalculatedMeasureDlg(){this.show(
"calculated_measure","edit")},showRemoveMeasureDlg(){this.show("measure",
"remove")},showMeasurePropertiesDlg(){this.show("measure_properties","show")},
showAttributePropertiesDlg(){this.show("attribute_properties","show")},
showFilterList(e){this.show("list","filter",e)},showEditField(){this.show("edit"
,"field")},remove(){
"attribute_replace"===this.type&&this.report.reportDoc.setReplaced(
this.dataSource.getFormula(),null)},_updateNumberFormat(e,t){var i=this.byId(
"formatCategory"),s=this.byId("formatScale"),r=this.byId("formatExpression"),
a=this.byId("currencySymbol"),o=this.byId("measureDisplayUnits");let l;
return t?e?((l=e.getNumberFormat()).formatCategory&&(i.value=l.formatCategory),
l.formatScale&&(s.value=l.formatScale),a&&l.currencySymbol&&(
a.value=l.currencySymbol),r&&(r.value=l.formatExpression),o&&(
o.value=l.measureDisplayUnits)):(i.selectedIndex=-1,s.selectedIndex=-1,
o.selectedIndex=-1):(l={formatCategory:i.value,formatScale:s.value},a&&(
l.currencySymbol=a.value),r&&(l.formatExpression=r.value),o&&(
l.measureDisplayUnits=o.value),e&&e.setNumberFormat(l)),l},_validateAmountField(
e){return F.remove(C.byId("MT_amount"),"invalid"),!cv.util.checkNumber(e
)||parseInt(e,10)<=0||parseInt(e,10)!==parseFloat(e)?(
this.report.filterDlg.setInvalidInputField("MT_amount"),
"dlgErrTrendNumberAmountNumberExpected"):null},_getUniqueLabel(e){
const i=this.report["gemList"],s=i.getKeyList();if(!s||0===s.length)return e;
var t=t=>s.some(e=>i.item(e).getDisplayLabel()===t);if(!t(e))return e;let r=2,
a=e+"_"+r;for(;t(a);)r+=1,a=e+"_"+r;return a},
_validateNumberFormatAndDecimalPlaces(){F.remove(this.byId("formatCategory"),
"invalid"),F.remove(this.byId("formatScale"),"invalid");let e=!0;
return this.byId("formatScale").value===cvCatalog.dlgNullSelection&&(this.byId(
"formatScale").focus(),F.add(this.byId("formatScale"),"invalid"),e=!1),
e||this.displayMsg(cvCatalog.dlgErrNumberFormatOrDecimalRequired),e},
_validateName(){return F.remove(this.byId("name"),"invalid"),""!==this.byId(
"name").value||(this.byId("amount")&&this._validateAmountField(this.byId(
"amount").value)?(F.add(this.byId("name"),"invalid"),F.add(this.byId("amount"),
"invalid"),this.displayMsg(cvCatalog.dlgErrNameAndNmbPeriodRequired)):(F.add(
this.byId("name"),"invalid"),this.displayMsg(cvCatalog.dlgErrNameRequired)),!1)
},showEditDesc(){var e=this.byId("editDescTextArea");F.remove(this.byId(
"editDescTextAreaTR"),"hidden"),F.add(this.byId("descDivTR"),"hidden"),
cv.getActiveReport().reportDoc.getReportProperty("description"
)?e.innerHTML=`<input id="RP_hiddenDesc" type="hidden" value="${this.byId(
"description").innerHTML.replace(/(")/gm,"&quot;"
)}"><textarea id="RP_description" rows=3 class="flex-auto">${this.byId(
"description").innerHTML.replace(/(")/gm,"&quot;"
)}</textarea>`:e.innerHTML=`<input id="RP_hiddenDesc" type="hidden" value="${this.byId(
"description").innerHTML.replace(/(")/gm,"&quot;"
)}"><textarea id="RP_description" rows=3 class="flex-auto"></textarea>`,
F.remove(this.byId("descBtn"),"hidden"),this.byId("editDescDiv").innerHTML="",
this.byId("description").focus(),this.isEditDescHidden=!1,
this.isShowingNow=this.isEditDescHidden&&this.isRenamingHidden},hideEditDesc(){
var e=this.byId("editDescDiv"),t=(F.add(this.byId("editDescTextAreaTR"),"hidden"
),F.remove(this.byId("descDivTR"),"hidden"),this.byId("hiddenDesc").value);
e.innerHTML="<div id='RP_description' class='RP_description flex-auto'></div>",
e.children.namedItem("RP_description").innerHTML=cv.util.escapeHtml(t),F.add(
this.byId("descBtn"),"hidden"),this.byId("editDescTextArea").innerHTML="",
this.isEditDescHidden=!0,
this.isShowingNow=this.isEditDescHidden&&this.isRenamingHidden,this.byId(
"editDescButton").focus()},saveRptDesc(){this.report.setReportProperties({
description:this.byId("description").value});var e=this.byId("description"
).value;this.byId("description").innerHTML=cv.util.escapeHtml(e),this.byId(
"hiddenDesc").value=e,this.hideEditDesc()},saveReportOptions(e){
e=this.pendingAction||e;if(e&&"saveReportOptions"===e.func){var t=e["params"],
i=this.report.reportDoc.getReportNode();for(const s in t
)"refresh"!==s&&i.setAttribute(s,t[s]);this.report.history.add(
new cv.ReportState("actionReportOptions")),
"true"===t.setDefaultBox&&this.report.setOptions("REPORT"),
t.refresh&&this.report.refreshReport()}}}));define("pentaho/analyzer/report/cv_rptLinkDlg",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dijit/registry","dojo/html","dojo/request",
"dojo/dom","dojo/dom-class","dojo/has","common-ui/util/URLEncoder","./cv_rptDlg"
],(e,c,t,b,i,a,l,o,r,s,m)=>e("cv.LinkDialog",cv.Dialog,{constructor(e){
this.report=e,this.dlgTemplate="linkDlg.html",this.prefix="AL_",
this.dataSource=null,this.linkTypes=["FILE","URL"],
this._widgetCss="responsive dw-sm"},performAction(e){var t=e.find(({clickLevel:e
})=>e),i=this.report.getGem(t.formula).getLink(),a=cv.util.parseMDXExpression(
t.member,!1);switch(i.getAttribute("type")){case"URL":this._performUrlAction(e,i
,a);break;case"FILE":this._performFileAction(e,i,a);break;case"DASHBOARD":
this._performDashboardAction(e)}},_performUrlAction(e,t,i){let a=t.getAttribute(
"url"),l=i;for(const o of e){var r=cv.util.parseMDXExpression(o.formula,!1);
l=cv.util.parseMDXExpression(o.member,!1);let e=encodeURIComponent(l);
0===l.toLowerCase().indexOf("http")&&(e=l),a=a.replace(`{${r}}`,e)}
i=t.getAttribute("target");this._openUrl(i,a,l)},_performFileAction(e,t,i){
var a=t.getAttribute("filePath"),a=m.encodeRepositoryPath(a);let l="default",r=(
".xanalyzer"===a.substring(a.length-10,a.length)&&(
l="EDIT"===this.report.mode?"editor":"viewer"),m.encode(
`${window.CONTEXT_PATH}api/repos/{0}/${l}?`,a));var o=t.selectNodes(
"cv:linkParam"),a=m.encode(CONTEXT_PATH+"api/repos/{0}/parameter",a);let s=null;
0<o.length&&a&&(s=this._getParams(a));for(const d of o){var n=d.getAttribute(
"name");r=`${r}&${encodeURIComponent(n)}=`;let t=this._substituteParam(
d.getAttribute("value"),e);if(s){let e;(e=-1!==n.indexOf('"')||-1!==t.indexOf(
'"')?s.selectSingleNode(`parameter[@name='${n}']/values/value[@label='${t}']`
):s.selectSingleNode(`parameter[@name="${n}"]/values/value[@label="${t}"]`))&&(
t=e.getAttribute("value"))}r+=encodeURIComponent(t)}a=t.getAttribute("target");
this._openUrl(a,r,i)},_performDashboardAction(e){for(const i of e){
var t=cv.util.parseMDXExpression(i.member,!1);if(
!parent?.pentahoDashboardController)return void alert(
`Unable to call.fireChange on param ${i.formula} with value `+t);
parent.pentahoDashboardController.fireOutputParam(window,i.formula,t)}},
_substituteParam(e,t){for(const l of t){var i=cv.util.parseMDXExpression(
l.formula,!1),a=cv.util.parseMDXExpression(l.member,!1);if(e===`{${i}}`)return a
}return e},_openUrl(e,t,i){if("NEW_TAB"===e){if(
console_enabled&&window.parent.mantle_openTab
)return void window.parent.mantle_openTab(i,i,t);if(
isRunningIFrameInSameOrigin&&window.parent?.parent?.mantle_openTab
)return void window.parent.parent.mantle_openTab(i,i,t)}
"CURRENT"===e?window.location=t:window.open(t)},show(){if(
this.dataSource=this.report.currentSelection,this.dataSource){
var t=this.dataSource.getName();if(this.load(t)){cv.getFieldHelp().get(
this.dataSource.getFormula(),"hyperlink")&&(this.byId("enableCheckbox"
).disabled=!0),c(this.byId("enableCheckbox"),"click",b.hitch(cv.util,
"onToggleSectionCheckbox")),c(this.byId("linkType"),"change",b.hitch(this,
"_changeType")),c(this.byId("filePicker"),"click",b.hitch(this,
"_openGwtRepositoryBrowser"));t=this.dataSource.getLink();if(t){
var e=t.getAttribute("type");if("URL"===e){let e=t.getAttribute("url");
e=e.replace(/{(.*?)}/g,e=>this._tryResolveNameToCaption(e)),this.byId("urlInput"
).value=e,this.byId("urlToolTip").value=t.getAttribute("toolTip"),
cv.util.selectByValue(this.byId("urlTarget"),t.getAttribute("target"))
}else"FILE"===e&&(this.byId("fileLabel").value=t.getAttribute("fileLabel"),
this.byId("filePath").value=t.getAttribute("filePath"),this.byId("fileToolTip"
).value=t.getAttribute("toolTip"),cv.util.selectByValue(this.byId("fileTarget"),
t.getAttribute("target")),this._populateParameters(t.getAttribute("fileLabel"),
t.getAttribute("filePath"),t.selectNodes("cv:linkParam")));
cv.util.selectByValue(this.byId("linkType"),t.getAttribute("type"))
}else cv.util.setSectionCollapsed("AL_enableCheckbox");this._changeType(),
this.showDialog()}}},save(){var{banner:t,history:i}=this.report;if(
this.setInvalidInputField(null),t.hide(),this.byId("enableCheckbox").checked){
t=this.byId("linkType").value;if(!this._validateParameter(t))return!1;if(
"URL"===t){let e=this.byId("urlInput").value;e=e.replace(/{(.*?)}/g,
e=>this._tryResolveCaptionToName(e)),this.dataSource.setLink({type:t,url:e,
toolTip:this.byId("urlToolTip").value,target:this.byId("urlTarget").value}),
i.add(new cv.ReportState("actionAdd","hyperlink"))}else if("FILE"===t){var e,
a={},t={type:t,fileLabel:this.byId("fileLabel").value,filePath:this.byId(
"filePath").value,toolTip:this.byId("fileToolTip").value,target:this.byId(
"fileTarget").value},l=this.byId("linkParamsTable")["rows"];for(const r of l
)r.lastChild.firstChild.checked&&(a[(e=r.lastChild.lastChild).name
]=this._tryResolveCaptionToName(e.value));this.dataSource.setLink(t,a),i.add(
new cv.ReportState("actionAdd","hyperlink"))}}else this.dataSource.removeLink(),
i.add(new cv.ReportState("actionRemove","hyperlink"));
return this.dlgWidget.hide(),this.report.refreshReport(),!0},
_openGwtRepositoryBrowser(){const l=o.byId("theDialog"),r=l.style["z-index"];
l.style["z-index"]=100,openFileChooserDialog({fileSelected:(e,t,i,a)=>{
this.byId("fileLabel").value=a,this.byId("filePath").value=t,
this._populateParameters(a,t,null),l.style["z-index"]=r},dialogCanceled:()=>{
l.style["z-index"]=r}})},_changeType(){var e=this.byId("linkType");for(
const i of this.linkTypes){var t=this.prefix+i;i===e.value?cv.util.show(t
):cv.util.hide(t)}},_validateParameter(e){if("URL"===e){if(!this.byId("urlInput"
).value)return this.displayError(cvCatalog.linkRequiredURL),
this.setInvalidInputField("AL_urlInput"),!1}else if("FILE"===e&&!this.byId(
"fileLabel").value)return this.displayError(cvCatalog.linkRequiredFile),
this.setInvalidInputField("AL_fileLabel"),!1;return!0},_getParams(e){let t;
return l(e,{method:"POST",sync:!0}).then(e=>{s("ie")||s("trident")?((
t=new ActiveXObject("Microsoft.XMLDOM")).async=!1,t.loadXML(e)
):t=dojox.xml.parser.parse(e)}),t?t.documentElement:null},_populateParameters(t,
i,s){this.byId("fileLabelSpan").title=t;var n=this.byId("linkParamsTable");for(
cv.util.hide(this.prefix+"linkParamsDiv");0<n.rows.length;)n.deleteRow(0);if(
null==i)alert(cvCatalog.linkFileRemoved),this.byId("fileLabel").value="",
this.byId("fileName").value="";else{t=m.encodeRepositoryPath(i),i=m.encode(
CONTEXT_PATH+"api/repos/{0}/parameter",t);let e=this._getParams(i),o=!1;for(
const h of e=e?e.selectNodes("parameter"):[]){let r=h.selectSingleNode(
"attribute[@name='parameter-group']");if("system"!==r?.getAttribute("value"
)&&"subscription"!==r?.getAttribute("value")){o=!0;var d=h.getAttribute("name");
let e=null;r=h.selectSingleNode("attribute[@name='label']"),e=r?r.getAttribute(
"value"):d;var u=n.insertRow(n.rows.length);let t=null,i=!(
u.className="flex-row");if(s)for(const p of s)if(p.getAttribute("name")===d){
t=p.getAttribute("value"),t=this._tryResolveNameToCaption(t),i=!0;break}t||(
e===this.dataSource.getName()?(t=`{${e}}`,i=!0):t="");
let a=document.createElement("td"),l=(
a.className="paramCell flex-row flex-center-v",u.appendChild(a),a.innerHTML=e,(
a=document.createElement("td")
).className="valueCell flex-row flex-center-v with-layout-gap-normal",
u.appendChild(a),document.createElement("input"));l.type="checkbox",
l.className="flex-none",a.appendChild(l),(l=document.createElement("input")
).name=d,l.type="text",l.className="flex-auto",l.size=1,l.value=t,a.appendChild(
l),i?u.lastChild.firstChild.checked=!0:u.lastChild.lastChild.disabled=!0,c(
u.lastChild.firstChild,"click",b.hitch(this,"_toggleLinkParam"))}}
o&&cv.util.show("AL_linkParamsDiv")}},_toggleLinkParam(e){var t=e.target.checked
,e=e.target.parentNode.lastChild;t?(e.disabled=!1,e.focus()):(e.value="",
e.disabled=!0)},_tryResolveCaptionToName(e){for(
const i of this.report.gemList.getKeyList()){var t=this.report.gemList.item(i);
if(e===`{${t.getDisplayLabel(!0)}}`)return`{${cv.util.parseMDXExpression(
t.getFormula(),!1)}}`}return e},_tryResolveNameToCaption(e){for(
const i of this.report.gemList.getKeyList()){var t=this.report.gemList.item(i);
if(e===`{${cv.util.parseMDXExpression(t.getFormula(),!1)}}`
)return`{${t.getDisplayLabel(!0)}}`}return e}}));define("pentaho/analyzer/report/cv_rptDrillDlg",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dojo/dom","./cv_rptDlg"],(t,e,l,i,o)=>t(
"cv.DrillDialog",[cv.Dialog],{constructor(t){this.report=t,
this.dlgTemplate="drillDlg.html",this.prefix="DT_",this.fieldHelp=null,
this.col=null,this.row=null,
this._widgetCss="responsive dw-xs ds-fill-viewport-width"},show(t,e){if(
this.load()){null!=t&&(this.col=t,this.row=e),
this.report.manager.isAdministrator&&((t=this.byId("setDefaultBoxDrill")
)&&t.checked&&cv.util.check(t,!1),cv.util.show("setDefaultDrill"));var l={};for(
const i of this.report.reportDoc.getDrillColumns())l[cv.textContent(i)]=!0;
this.fieldHelp=new cv.FieldHelp(o.byId("fieldHelpXML").value,this.report.manager
,!0),
this.report.modelAnnotations&&this.report.modelAnnotations.length&&cv.util.updateCatalog(
!0,this.report,this.fieldHelp,this.report.getModelAnnotationsJson()),
this.fieldHelp.init(l),this.showDialog()}},resetToDefault(){
this._resetToDefault("DRILL")},resetUpdateOptions(t){this._resetUpdateOptions(t,
"DRILL")},save(){const t=this.fieldHelp.getSelectedFields();var e;
return 0<Object.keys(t).length?(e=[...this.theForm.elements].find(({id:t}
)=>t===this.prefix+"setDefaultBoxDrill"))&&"true"===this._getSrcValue(e)?(
cv.getActiveReport().rptDlg.showConfirm(["promptSetDefault"],null,{srcFunc:(
)=>this.saveDrillDialog(t,!0)}),!1):this.saveDrillDialog(t):(this.displayError(
cvCatalog.dlgDrillthroughNoFieldsError),!1)},saveDrillDialog(t,e){
return this.report.reportDoc.replaceDrillColumns(t),this.fieldHelp=null,
this.dlgWidget.hide(),null!=this.col&&(drill(this.col,this.row),delete this.col,
delete this.row),e&&this.report.setOptions("DRILL"),!0},cancel(){
this.fieldHelp=null,cv.Dialog.prototype.cancel.call(this)}}));define("dojox/html/entities",["dojo/_base/lang"],function(e){function r(e,a){if(
a._encCache&&a._encCache.regexp&&a._encCache.mapper&&a.length==a._encCache.length
)r=a._encCache.mapper,i=a._encCache.regexp;else{for(var r={},i=["["],
c=0;c<a.length;c++)r[a[c][0]]="&"+a[c][1]+";",i.push(a[c][0]);i.push("]"),
i=new RegExp(i.join(""),"g"),a._encCache={mapper:r,regexp:i,length:a.length}}
return e=e.replace(i,function(e){return r[e]})}function i(e,a){if(
a._decCache&&a._decCache.regexp&&a._decCache.mapper&&a.length==a._decCache.length
)r=a._decCache.mapper,i=a._decCache.regexp;else{for(var r={},i=["("],
c=0;c<a.length;c++){var l="&"+a[c][1]+";";c&&i.push("|"),r[l]=a[c][0],i.push(l)}
i.push(")"),i=new RegExp(i.join(""),"g"),a._decCache={mapper:r,regexp:i,
length:a.length}}return e=e.replace(i,function(e){return r[e]})}
var c=e.getObject("dojox.html.entities",!0);return c.html=[["&","amp"],['"',
"quot"],["<","lt"],[">","gt"],[" ","nbsp"]],c.latin=[["¡","iexcl"],["¢","cent"],
["£","pound"],["€","euro"],["¤","curren"],["¥","yen"],["¦","brvbar"],["§","sect"
],["¨","uml"],["©","copy"],["ª","ordf"],["«","laquo"],["¬","not"],["­","shy"],[
"®","reg"],["¯","macr"],["°","deg"],["±","plusmn"],["²","sup2"],["³","sup3"],[
"´","acute"],["µ","micro"],["¶","para"],["·","middot"],["¸","cedil"],["¹","sup1"
],["º","ordm"],["»","raquo"],["¼","frac14"],["½","frac12"],["¾","frac34"],["¿",
"iquest"],["À","Agrave"],["Á","Aacute"],["Â","Acirc"],["Ã","Atilde"],["Ä","Auml"
],["Å","Aring"],["Æ","AElig"],["Ç","Ccedil"],["È","Egrave"],["É","Eacute"],["Ê",
"Ecirc"],["Ë","Euml"],["Ì","Igrave"],["Í","Iacute"],["Î","Icirc"],["Ï","Iuml"],[
"Ð","ETH"],["Ñ","Ntilde"],["Ò","Ograve"],["Ó","Oacute"],["Ô","Ocirc"],["Õ",
"Otilde"],["Ö","Ouml"],["×","times"],["Ø","Oslash"],["Ù","Ugrave"],["Ú","Uacute"
],["Û","Ucirc"],["Ü","Uuml"],["Ý","Yacute"],["Þ","THORN"],["ß","szlig"],["à",
"agrave"],["á","aacute"],["â","acirc"],["ã","atilde"],["ä","auml"],["å","aring"]
,["æ","aelig"],["ç","ccedil"],["è","egrave"],["é","eacute"],["ê","ecirc"],["ë",
"euml"],["ì","igrave"],["í","iacute"],["î","icirc"],["ï","iuml"],["ð","eth"],[
"ñ","ntilde"],["ò","ograve"],["ó","oacute"],["ô","ocirc"],["õ","otilde"],["ö",
"ouml"],["÷","divide"],["ø","oslash"],["ù","ugrave"],["ú","uacute"],["û","ucirc"
],["ü","uuml"],["ý","yacute"],["þ","thorn"],["ÿ","yuml"],["ƒ","fnof"],["Α",
"Alpha"],["Β","Beta"],["Γ","Gamma"],["Δ","Delta"],["Ε","Epsilon"],["Ζ","Zeta"],[
"Η","Eta"],["Θ","Theta"],["Ι","Iota"],["Κ","Kappa"],["Λ","Lambda"],["Μ","Mu"],[
"Ν","Nu"],["Ξ","Xi"],["Ο","Omicron"],["Π","Pi"],["Ρ","Rho"],["Σ","Sigma"],["Τ",
"Tau"],["Υ","Upsilon"],["Φ","Phi"],["Χ","Chi"],["Ψ","Psi"],["Ω","Omega"],["α",
"alpha"],["β","beta"],["γ","gamma"],["δ","delta"],["ε","epsilon"],["ζ","zeta"],[
"η","eta"],["θ","theta"],["ι","iota"],["κ","kappa"],["λ","lambda"],["μ","mu"],[
"ν","nu"],["ξ","xi"],["ο","omicron"],["π","pi"],["ρ","rho"],["ς","sigmaf"],["σ",
"sigma"],["τ","tau"],["υ","upsilon"],["φ","phi"],["χ","chi"],["ψ","psi"],["ω",
"omega"],["ϑ","thetasym"],["ϒ","upsih"],["ϖ","piv"],["•","bull"],["…","hellip"],
["′","prime"],["″","Prime"],["‾","oline"],["⁄","frasl"],["℘","weierp"],["ℑ",
"image"],["ℜ","real"],["™","trade"],["ℵ","alefsym"],["←","larr"],["↑","uarr"],[
"→","rarr"],["↓","darr"],["↔","harr"],["↵","crarr"],["⇐","lArr"],["⇑","uArr"],[
"⇒","rArr"],["⇓","dArr"],["⇔","hArr"],["∀","forall"],["∂","part"],["∃","exist"],
["∅","empty"],["∇","nabla"],["∈","isin"],["∉","notin"],["∋","ni"],["∏","prod"],[
"∑","sum"],["−","minus"],["∗","lowast"],["√","radic"],["∝","prop"],["∞","infin"]
,["∠","ang"],["∧","and"],["∨","or"],["∩","cap"],["∪","cup"],["∫","int"],["∴",
"there4"],["∼","sim"],["≅","cong"],["≈","asymp"],["≠","ne"],["≡","equiv"],["≤",
"le"],["≥","ge"],["⊂","sub"],["⊃","sup"],["⊄","nsub"],["⊆","sube"],["⊇","supe"],
["⊕","oplus"],["⊗","otimes"],["⊥","perp"],["⋅","sdot"],["⌈","lceil"],["⌉",
"rceil"],["⌊","lfloor"],["⌋","rfloor"],["〈","lang"],["〉","rang"],["◊","loz"],[
"♠","spades"],["♣","clubs"],["♥","hearts"],["♦","diams"],["Œ","OElig"],["œ",
"oelig"],["Š","Scaron"],["š","scaron"],["Ÿ","Yuml"],["ˆ","circ"],["˜","tilde"],[
" ","ensp"],[" ","emsp"],[" ","thinsp"],["‌","zwnj"],["‍","zwj"],["‎","lrm"],[
"‏","rlm"],["–","ndash"],["—","mdash"],["‘","lsquo"],["’","rsquo"],["‚","sbquo"]
,["“","ldquo"],["”","rdquo"],["„","bdquo"],["†","dagger"],["‡","Dagger"],["‰",
"permil"],["‹","lsaquo"],["›","rsaquo"]],c.encode=function(e,a){return e=e&&(
a?r(e,a):(e=r(e,c.html),r(e,c.latin)))},c.decode=function(e,a){return e=e&&(a?i(
e,a):(e=i(e,c.html),i(e,c.latin)))},c});define("pentaho/analyzer/report/cv_rptChartOptionsDlg",["dojo/_base/declare",
"dojo/on","dojo/query","dijit/ColorPalette","dijit/registry","dojo/dom",
"dojo/dom-class","dojo/dom-geometry","dojo/dom-style","dojox/html/entities",
"common-ui/util/_a11y","./cv_rptLinkDlg"],(t,l,s,o,a,r,e,n,h,d,u)=>t(
"cv.ChartOptionsDialog",[cv.Dialog],{constructor(t){this.report=t,
this.dlgTemplate="chartPropsDlg.html",this.prefix="CP_",this.originalOptions={},
this._originalPluginViewDataJson="",
this._widgetCss="responsive dw-sm ds-fill-viewport-width",this.applied=!1,
this.lastScale=0,this.lastScaleSecondary=0},init(){var t=this.report["reportDoc"
];const i=this.toggleFillType.bind(this);l(this.byId("backgroundFill"),"change",
t=>{i(t.target.value)}),this._initMaxValuesSelector();var e=t.getChartOption(
"displayUnits"),e=(this.lastScale=e?parseInt(e.substring(6),10):0,l(this.byId(
"autoRange"),"click",this.toggleAutoRange.bind(this,"autoRange")),l(this.byId(
"displayUnits"),"change",this.toggleDisplayUnits.bind(this,"displayUnits")),
t.getChartOption("displayUnitsSecondary")),s=(
this.lastScaleSecondary=e?parseInt(e.substring(6),10):0,l(this.byId(
"autoRangeSecondary"),"click",this.toggleAutoRange.bind(this,
"autoRangeSecondary")),l(this.byId("displayUnitsSecondary"),"change",
this.toggleDisplayUnits.bind(this,"displayUnitsSecondary")),this.byId(
"multiChartMax"));for(const o of this.report.getVizMultiChartMaxList())s.add(
new Option(o,o),null);this._originalPluginViewDataJson=t.getPluginViewDataJSON()
,this.byId("viewConfiguration").value=this._originalPluginViewDataJson;
var a=t.getChartOptions().attributes;for(let t=0,i=a.length;t<i;t++){var r=a[t];
this.updateHtml(r.name,r.value),this.originalOptions[r.name]=r.value}},
_initColorPalette(t,i){var e=this.byId(t+"Div");u.makeAccessibleActionButton(e),
h.set(e,"background-color",i);const s=new o({palette:"7x10",value:i},this.byId(
t+"PaletteWidget")),a=(s.startup(),this.byId(t+"Palette")),r=(l(s,"blur",()=>{
cv.util.hide(a)}),l(s,"change",this.selectColor.bind(this,t)),
this.toggleColorPalette.bind(this));s.own(l(e,"click",t=>{t.preventDefault(),
t.stopPropagation(),r(s)}))},_initMaxValuesSelector(){var t=this.byId(
"maxValues");let i=this.report.reportDoc.getChartOption("maxValues"),e=(
"string"==typeof i&&(i=parseInt(i,10)),this.report._getVizApplicationSpec())[
"maxValues"];for(const s of e=e||[])s===i&&(i=null),t.add(new Option(s,s),null);
this.report.isReportFormatPivot()&&i&&t.add(new Option(i,i),null)},show(){if(
this.load()){var t;this.applied=!1,this.init(),
this.report.manager.isAdministrator&&((t=this.byId("setDefaultBox")
).checked&&cv.util.check(t,!1),cv.util.show(this.prefix+"setDefault"));
const i=this.dlgWidget;this._own(l(this.byId("resetToDefault"),"click",()=>{
e.add(i.domNode,"resetting-to-default")})),l(r.byId("dlgBtnApply"),"click",
this.apply.bind(this)),cv.util.setHelpTopics([
this.prefix+"helpViewConfiguration",
"CV/Business_User/working_with_charts.html#configuring-viz-view-report"]),
this.showDialog()}},save(t){var{banner:i,reportDoc:e}=this.report,i=(
this.setInvalidInputField(null),i.hide(),this.theForm)["elements"],s=this.byId(
"viewConfiguration");if(""!==s.value)try{JSON.parse(s.value)}catch(t){
return this.displayError(d.encode(t.message)),this.setInvalidInputField(
this.prefix+"viewConfiguration"),s.focus(),!1}if(!this.byId("autoRange").checked
){s=this.byId("valueAxisLowerLimit");if(!cv.util.checkNumber(s.value)
)return this.displayError(cvCatalog.dlgChartPropsAxisLimitError),
this.setInvalidInputField(this.prefix+"valueAxisLowerLimit"),s.focus(),!1;
s=this.byId("valueAxisUpperLimit");if(!cv.util.checkNumber(s.value)
)return this.displayError(cvCatalog.dlgChartPropsAxisLimitError),
this.setInvalidInputField(this.prefix+"valueAxisUpperLimit"),s.focus(),!1}if(
!this.byId("autoRangeSecondary").checked){s=this.byId(
"valueAxisLowerLimitSecondary");if(!cv.util.checkNumber(s.value)
)return this.displayError(cvCatalog.dlgChartPropsAxisLimitError),
this.setInvalidInputField(this.prefix+"valueAxisLowerLimitSecondary"),s.focus(),
!1;s=this.byId("valueAxisUpperLimitSecondary");if(!cv.util.checkNumber(s.value)
)return this.displayError(cvCatalog.dlgChartPropsAxisLimitError),
this.setInvalidInputField(this.prefix+"valueAxisUpperLimitSecondary"),s.focus(),
!1}s=this.applyChanges(i,e);if(!t){if(this.applied&&this.report.history.add(
new cv.ReportState("actionChartProps")),this.byId("setDefaultBox").checked
)return void cv.getActiveReport().rptDlg.showConfirm(["promptSetDefault"],null,{
srcObj:this,srcFunc:"saveChartOptions"});this.dlgWidget.hide()}
return s&&this.report.refreshReport(),!0},saveChartOptions(){
this.report.setOptions("CHART")},applyChanges(t,i){let e=!1;for(const a of t)if(
"INPUT"===a.tagName||"SELECT"===a.tagName){if(""===a.value){var s=a.id;if(
s===this.prefix+"valueAxisLowerLimit"||s===this.prefix+"valueAxisUpperLimit"||s===this.prefix+"valueAxisLowerLimitSecondary"||s===this.prefix+"valueAxisUpperLimitSecondary"
)continue}s=i.getChartOptions();this._isNewValue(s,a)&&(this.updateXml(s,a),e=!0
)}else"TEXTAREA"===a.tagName&&i.getPluginViewDataJSON()!=a.value&&(
this.beautifyConfiguration(),i.setPluginViewDataJSON(a.value),e=!0,
this.report.setVizViewConfigDirty());return e&&(this.applied=!0),e},_isNewValue(
t,i){var e;return!!t&&!!(e=this._attributeName(i.id))&&t.getAttribute(e
)!==this._getSrcValue(i)},toggleAutoRange(t){var i=t.endsWith("Secondary"
)?"Secondary":"",e=this.byId("valueAxisLowerLimit"+i),i=this.byId(
"valueAxisUpperLimit"+i);this.byId(t).checked?(e.setAttribute("disabled",""),
i.setAttribute("disabled","")):(e.removeAttribute("disabled"),i.removeAttribute(
"disabled"))},toggleColorPalette(t){var i=t.domNode.parentNode;cv.util.show(
i.getAttribute("id")),this._isColorPickerOnLeftSide(i)?e.add(i,"leftColorPicker"
):e.remove(i,"leftColorPicker"),t.focus()},_isColorPickerOnLeftSide(t){var i,e,
t=s(t).siblings(".colorPicker")[0];return!!t&&(i=n.position(r.byId(
"standardDialog")),t=n.position(t),e=i.w/2,t.x-i.x<e)},toggleFillType(t){
var i=this.prefix+"backgroundColorWrapper",
e=this.prefix+"backgroundColorEndWrapper";switch(t){case"SOLID":cv.util.show(i),
cv.util.hide(e);break;case"GRADIENT":cv.util.show(i),cv.util.show(e);break;
default:cv.util.hide(i),cv.util.hide(e)}},toggleDisplayUnits(t){
var t=t.endsWith("Secondary"),i=t?"Secondary":"",e=this.byId("displayUnits"+i
).value,e=parseInt(e.substring(6),10);let s;t?(s=this.lastScaleSecondary-e,
this.lastScaleSecondary=e):(s=this.lastScale-e,this.lastScale=e);t=this.byId(
"valueAxisLowerLimit"+i),t.value&&(t.value*=10**s),e=this.byId(
"valueAxisUpperLimit"+i);e.value&&(e.value*=10**s)},selectColor(t,i){this.byId(t
).value=i;var e=this.byId(t+"Div");h.set(e,"backgroundColor",i),cv.util.hide(
this.prefix+t+"Palette"),e.focus()},apply(){this.save(!0)},resetToDefault(){
this._resetToDefault("CHART")},resetUpdateOptions(t){this._resetUpdateOptions(t,
"CHART")},cancel(){if(this.applied){var t=this.report["reportDoc"];for(
const i in this.originalOptions)t.setChartOption(i,this.originalOptions[i]);
t.getPluginViewDataJSON()!==this._originalPluginViewDataJson&&(
t.setPluginViewDataJSON(this._originalPluginViewDataJson),
this.report.setVizViewConfigDirty()),this.report.refreshReport()}this.inherited(
arguments)},beautifyConfiguration(){var i=this.byId("viewConfiguration");if(
""!==i.value)try{var t=JSON.parse(i.value);i.value=JSON.stringify(t,void 0,2)
}catch(t){this.displayError(t.message),this.setInvalidInputField(
"viewConfiguration"),i.focus()}},updateHtml(t,i){switch(this.inherited(arguments
),t){case"backgroundFill":this.toggleFillType(i);break;case"backgroundColor":
case"backgroundColorEnd":case"labelColor":case"legendBackgroundColor":
case"legendColor":var e=a.byId(this.prefix+t+"PaletteWidget");
e&&e.destroyRecursive(!0),this._initColorPalette(t,i);break;case"autoRange":
case"autoRangeSecondary":this.toggleAutoRange(t)}}}));define("pentaho/analyzer/report/cv_rptPageSetupDlg",["dojo/_base/declare",
"dojo/on","dojo/query","dojo/_base/lang","dijit/Declaration","dojo/html",
"dijit/registry","dojo/dom-class","dojo/dom","common-ui/util/_a11y",
"./cv_rptLinkDlg"],(e,o,t,l,i,a,c,n,s,r)=>e("cv.PageSetupDialog",[cv.Dialog],{
constructor(e){this.report=e,this.dlgTemplate="pageSetupDlg.html",this.prefix=""
,this.originalOptions={},this.formatType="PDF",
this._widgetCss="responsive dw-sm ds-fill-viewport-width"},showExcel(){
this.load()&&(this.formatType="EXCEL",cv.util.show("pageFormatFieldSet"),
cv.util.show("pageOrientationFieldSet"),cv.util.hide("csvOptions"),cv.util.hide(
"pdfPageSize"),cv.util.show("excelPageSize"),cv.util.show("excelScalingRow"),
cv.util.show("excelOptions"),this.byId("pageSetupTitle"
).innerHTML=cvCatalog.dlgPageSetupExcelTitle,this._showDialog())},showPDF(){
this.load()&&(this.formatType="PDF",cv.util.show("pageFormatFieldSet"),
cv.util.show("pageOrientationFieldSet"),cv.util.hide("csvOptions"),cv.util.show(
"pdfPageSize"),cv.util.hide("excelPageSize"),cv.util.hide("excelScalingRow"),
cv.util.hide("excelOptions"),this.byId("pageSetupTitle"
).innerHTML=cvCatalog.dlgPageSetupPDFTitle,this._showDialog())},showCSV(){
this.load()&&(this.formatType="CSV",cv.util.hide("pageFormatFieldSet"),
cv.util.hide("pageOrientationFieldSet"),cv.util.show("csvOptions"),cv.util.hide(
"pdfPageSize"),cv.util.hide("excelPageSize"),cv.util.hide("excelScalingRow"),
cv.util.hide("excelOptions"),this.byId("pageSetupTitle"
).innerHTML=cvCatalog.dlgCSVDownloadTitle,this._showDialog())},_showDialog(){
var e=this.report["reportDoc"],e=e.getPageSetup()["attributes"];for(const a of e
){var{name:t,value:i}=a;this.updateHtml(t,i),this.originalOptions[t]=i,(
"PDF"===this.formatType&&"pdfOrientation"===t||"EXCEL"===this.formatType&&"excelOrientation"===t
)&&this.setPortraitOrientation("PORTRAIT"===i)}s.byId("dlgBtnSave").disabled=!0;
e=this.byId("orientationPortrait"),o(e,"click",l.hitch(this,()=>{
this.setPortraitOrientation(!0)})),r.makeAccessibleActionButton(e),e=this.byId(
"orientationLandscape"),o(e,"click",l.hitch(this,()=>{
this.setPortraitOrientation(!1)})),r.makeAccessibleActionButton(e),o(s.byId(
"dlgBtnDownload"),"click",l.hitch(this,"download")),o(s.byId("excelPageSize"),
"change",l.hitch(this,"enableDoneButton")),o(s.byId("pdfPageSize"),"change",
l.hitch(this,"enableDoneButton")),o(s.byId("csvIncludeSubtotals"),"click",
l.hitch(this,"enableDoneButton")),o(s.byId("csvFormatNumbers"),"click",l.hitch(
this,"enableDoneButton")),o(s.byId("csvSeparator"),"change",l.hitch(this,
"enableDoneButton")),o(s.byId("excelScalingPercent"),"click",l.hitch(this,
"enableDoneButton")),o(s.byId("excelScalingPageWide"),"click",l.hitch(this,
"enableDoneButton")),o(s.byId("excelScalingPageTall"),"click",l.hitch(this,
"enableDoneButton")),o(s.byId("excelMergePivotCells"),"click",l.hitch(this,
"enableDoneButton")),e=this.theForm.excelScalingType;o(e[0],"click",l.hitch(this
,"enableDoneButton")),o(e[1],"click",l.hitch(this,"enableDoneButton")),
this.showDialog()},download(){this._updatePageSetupXML()&&(this.dlgWidget.hide()
,"PDF"===this.formatType?this.report.getReportPDF(!0
):"EXCEL"===this.formatType?this.report.getReportExcel(!0
):"CSV"===this.formatType&&this.report.getReportCSV())},save(){
return this.setInvalidInputField(null),this.report.banner.hide(),
!!this._updatePageSetupXML()&&(this.dlgWidget.hide(),!0)},_updatePageSetupXML(){
if(!cv.util.checkPositiveInteger(s.byId("excelScalingPercent").value)
)return this.displayError(cvCatalog.dlgSharedErrorPositiveInteger),
this.setInvalidInputField("excelScalingPercent"),s.byId("excelScalingPercent"
).focus(),!1;if(!cv.util.checkPositiveInteger(s.byId("excelScalingPageWide"
).value))return this.displayError(cvCatalog.dlgSharedErrorPositiveInteger),
this.setInvalidInputField("excelScalingPageWide"),s.byId("excelScalingPageWide"
).focus(),!1;if(!cv.util.checkPositiveInteger(s.byId("excelScalingPageTall"
).value))return this.displayError(cvCatalog.dlgSharedErrorPositiveInteger),
this.setInvalidInputField("excelScalingPageTall"),s.byId("excelScalingPageTall"
).focus(),!1;var e=this.report["reportDoc"];for(const a of this.theForm.elements
)"INPUT"!==a.tagName&&"SELECT"!==a.tagName||this.updateXml(e.getPageSetup(),a);
var t,i=s.byId("orientationPortrait"),i=("CSV"!==this.formatType&&(
t="PDF"===this.formatType?"pdf":"excel",t+="Orientation",n.contains(i,
"pageSetupDialogPortraitSelected")?e.setPageSetup(t,"PORTRAIT"):e.setPageSetup(t
,"LANDSCAPE")),this.getRadioGroupValue("excelScalingType"));
return e.setPageSetup("excelScalingType",i),!0},setPortraitOrientation(e){
var t=this.byId("orientationPortrait"),i=this.byId("orientationLandscape");e?(
n.add(t,"pageSetupDialogPortraitSelected"),n.remove(i,
"pageSetupDialogLandscapeSelected")):(n.add(i,"pageSetupDialogLandscapeSelected"
),n.remove(t,"pageSetupDialogPortraitSelected")),this.enableDoneButton()},
enableDoneButton(){s.byId("dlgBtnSave").disabled=!1},cancel(){var e=this.report[
"reportDoc"];for(const t in this.originalOptions)e.setPageSetup(t,
this.originalOptions[t]);cv.Dialog.prototype.cancel.call(this)}}));define("pentaho/analyzer/report/cv_rptFilterDlg",["dojo/_base/declare","dojo/on"
,"dojo/query","dojo/_base/lang","dojox/collections/Dictionary",
"dojox/collections/ArrayList","dojo/html","dojo/dom-class","dojo/dom-geometry",
"dojo/request","dojo/dom","dojo/dom-construct","dojox/xml/parser",
"dijit/form/DateTextBox","pentaho/common/Messages","common-ui/util/_a11y",
"./cv_rptDlg"],(e,d,t,o,l,r,i,a,s,h,n,c,p,u,E,_)=>e("cv.FilterDialog",[cv.Dialog
],{constructor(e){this.report=e,this.dlgTemplate=null,this.prefix="FT_",
this.filterTypes=["FILTER_METRIC","FILTER_PICKLIST","FILTER_MATCH",
"FILTER_PRESET","FILTER_RANGE","FILTER_NUMERIC_LEVEL"],
this._widgetCss="responsive ds-fill-viewport-width dw-sm"},destroy(){
this.inherited(arguments),this.clear()},clear(){this.gem=null,this.type=null,
this.attribute=null,this.attributeType=null,this.isTimeAttribute=!1,
this.metric=null,this.ordinal=0,this.filterProps=null,this.parentFilterMsg=null,
this.asyncRequestId=null,this.asyncMode=!1,this.searchCache=new Array(30),
this.searchCacheTopIndex=-1,this.search=null,this._destroyDisplay()},
_destroyDisplay(){this.inherited(arguments),this.valueListNode=null,
this.valueListbox&&this.valueListbox.destroy(),
this.memberListbox&&this.memberListbox.destroy(),this._destroyHandles()},
_destroyHandles(){["handleSetFilterType","handleOnChangeRangeOp",
"handleOnShowDatePicker","handleOnClickMatchTbl","handleKeyPressMatchTbl",
"handleAddExpressionItem","handleOnChangePicklistOp",
"handleValueListNodeAddMembers","handleMemberListNodeRemoveMembers",
"handleSearchValueList","handleSelectAddAddMembers",
"handleSelectAddAllAddMembers","handleSelectRemoveRemoveMembers",
"handleSelectRemoveAllRemoveMembers","handleAccessibleAddMembers",
"handleAccessibleAddAllMembers","handleAccessibleRemoveMembers",
"handleAccessibleRemoveAllMembers","handleOnChangeNumericLevelOp",
"handleOnKeyDownSearchText"].forEach(e=>{this[e]?.remove(),this[e]=null})},show(
t,i){if("string"==typeof t&&0===t.indexOf("filter_metric")
)return this.showMetricFilter();if("NUMBER"===cv.getFieldHelp().get(t,"type"
)||"string"==typeof t&&0===t.indexOf("[MEASURE:"))return this.showMetricFilter(t
);this.clear();let e;if(0===t.indexOf("filter_")){
var s=/^filter_(.+)_(\d)$/.exec(t);if(!s)return!1;[,this.attribute,e]=s,
this.ordinal=parseInt(e,10)}else this.attribute=t,e=parseInt(i,10),
!Number.isNaN(e)&&0<e&&(this.ordinal=e);if(this.attributeType=cv.getFieldHelp(
).get(this.attribute,"type"),this.attributeType){if(
this.isTimeAttribute=cv.getFieldHelp().isTimeAttribute(this.attribute),
this.gem=this.report.getGem("filter_"+this.attribute),this.gem
)this.filterProps=this.report.reportDoc.getFilterProps(this.gem.xmlNode);else{
if(!this.report.getGem(this.attribute)){s=this.report.getTrendNumberOnAncestors(
this.attribute);if(s)return this.showError(["errorAddFilterWithTrendOnAncestor",
this.report.getFieldLabel(this.attribute),this.report.getFieldLabel(s.ancestor),
s.trend.getDisplayLabel()]),!1}this.filterProps={type:this.type,
formula:this.attribute,predicates:new l}}if(0===this.ordinal
)this.type=this.isTimeAttribute?"FILTER_PRESET":"FILTER_PICKLIST";else{var[r
]=this.filterProps.predicates.item(this.ordinal);switch(r.op){case"CONTAIN":
case"NOT_CONTAIN":this.type="FILTER_MATCH";break;case"BEFORE":case"AFTER":
case"BETWEEN":this.type="FILTER_RANGE";break;case"EQUAL":case"NOT_EQUAL":
this.type=this.isTimeAttribute&&r.preset?"FILTER_PRESET":"FILTER_PICKLIST";break
case"TIME_YAGO":case"TIME_AHEAD":case"TIME_AGO":case"TIME_RANGE_NEXT":
case"TIME_RANGE_PREV":this.type="FILTER_PRESET";break;case"NUMERIC_BETWEEN":
case"NUMERIC_GREATER_THAN":case"NUMERIC_GREATER_THAN_EQUAL":
case"NUMERIC_LESS_THAN":case"NUMERIC_LESS_THAN_EQUAL":
this.type="FILTER_NUMERIC_LEVEL";break;default:return}}
this.dlgTemplate="filterPredicateDlg.html",
this.helpTopic="CV/Business_User/working_with_filters.html#filters_on_text_fields"
t=this.report.getFieldLabel(this.attribute)?this.report.getFieldLabel(
this.attribute):this.report.getFieldLabelPlural(this.attribute),
i=cv.getFieldHelp().get(this.attribute,"type");let e;if(
e="TIME_DATE"===i?this.load(t,E.getString("FilterPresetTIME_DATE0"),E.getString(
"FilterPresetTIME_DATE__1"),E.getString("FilterPresetTIME_DATE1")):this.load(t,
E.getString("FilterTIME_CURRENT",t),E.getString("FilterTIME_PREVIOUS",t),
E.getString("FilterTIME_NEXT",t))){let e;if(this.isTimeAttribute?(e=this.byId(
"filterTypeTime"),cv.util.removeNode(this.byId("filterTypeText")),
cv.util.removeNode(this.byId("filterTypeNumericLevel"))):cv.getFieldHelp(
).isNumberAttribute(this.attribute)?(e=this.byId("filterTypeNumericLevel"),
cv.util.removeNode(this.byId("filterTypeText")),cv.util.removeNode(this.byId(
"filterTypeTime"))):(e=this.byId("filterTypeText"),cv.util.removeNode(this.byId(
"filterTypeTime")),cv.util.removeNode(this.byId("filterTypeNumericLevel"))),
this.handleSetFilterType||(this.handleSetFilterType=d(e,"click",o.hitch(this,
"_setFilterType"))),this.valueListNode=this.byId("valueList"),
this.valueListbox=_.makeAccessibleListbox(this.valueListNode),
cv.util.disableTextSelection(this.valueListNode),
!this.report.manager.applyReportContextInFilterDialog){s=cv.getFieldHelp(
).getHierarchy(this.attribute);if(s){let e=null;for(const a of s){if(
a===this.attribute)break;this.report.getGem("filter_"+a)&&(e=a)}
this.parentFilterMsg=e?cv.util.substituteParams(cvCatalog.dlgInfoFilterOnParent,
this.report.getFieldLabel(e)):null}}this._setFilterType(this.type
)&&this.showDialog()}else alert(this.status)}},save(){var{banner:e,history:t,
reportDoc:i}=this.report;this.setInvalidInputField(null),e.hide();let s;switch(
this.type){case"FILTER_METRIC":s=this._saveMetricFilter();break;
case"FILTER_PICKLIST":s=this._savePicklistFilter();break;case"FILTER_MATCH":
s=this._saveMatchFilter();break;case"FILTER_PRESET":s=this._savePresetFilter();
break;case"FILTER_RANGE":s=this._saveRangeFilter();break;
case"FILTER_NUMERIC_LEVEL":s=this._saveNumericLevelFilter();break;default:s=!1}
return s&&(this.dlgWidget.hide(),this.filterProps)&&(i.updateFilter(
this.filterProps),
"FILTER_METRIC"===this.filterProps.type?i.updateIsDefaultFilter(
this.filterProps.formula,null,!1):i.updateIsDefaultFilter(
this.filterProps.formula,!1,null),this.report.populateFilters(),
this.report.resizeContainer(),t.add(new cv.ReportState("actionEditFilter")),
this.report.refreshReport(),this.valueListNode=null),s},showAttrSelection(e,t,i
){var s,r,a,l=this.report.getGem("filter_"+e);if(l){if("EDIT"===this.report.mode
)return a="NUMBER"===cv.getFieldHelp().get(e,"type"
)||"string"==typeof e&&!e.indexOf("[MEASURE:"),{banner:s,reportDoc:r
}=this.report,r.isDefaultFilter(e,a)&&(
s.fixedMessage=cvCatalog.bannerEditDefaultFilter),this.show(e,t);
this.type="filter_selection",this.attribute=e,
this.dlgTemplate="filterAttrViewDlg.html",this.helpTopic=null,this.load(
this.report.getFieldLabel(e),i)&&(r=this.byId("memberList"),
_.makeAccessibleListbox(r),a=this.report.reportDoc.getFilterProps(l.xmlNode),
r.innerHTML=this._formatValueList(a.predicates.item(t)[0].members,"SELECTED"),
this.showDialog())}},showSelectionFilter(e){this.type="filter_selection",
this.attribute="foo",this.dlgTemplate="filterSelectionViewDlg.html",
this.helpTopic=null;let i="",s=0;for(
const l of this.report.reportDoc.getSelectionFilters())if(l.getAttribute("op"
)===e){let t="";var r=l.selectNodes("cv:selectionMember");for(
let e=0;e<r.length;e++){var a=r[e].getAttribute("member");0!==e&&(t+=" and "),
t+=cv.util.parseMDXExpression(a,!0)}i+=`<option>${t}</option>`,s+=1}this.load(
cvCatalog["dlgSelectionFilterTitle"+e],s)&&(this.byId("memberList").innerHTML=i,
this.showDialog())},_setFilterType(e){let t=!0,i=null,s=null;if(
"string"==typeof e&&e.startsWith("FILTER_"))this.type=e,this.updateHtml(
"filterType",e);else{if(!e.target)return;s=this.type;var{id:r,tagName:a
}=e.target;if("INPUT"===a)this.type=this.getRadioGroupValue(
this.prefix+"filterType");else if("A"===a){switch(r){
case this.prefix+"filterOp_PRESET_EQUAL":
case this.prefix+"filterOp_PRESET_NOT_EQUAL":this.type="FILTER_PRESET",
i=r.substring(19);break;case this.prefix+"filterOp_EQUAL":
case this.prefix+"filterOp_NOT_EQUAL":this.type="FILTER_PICKLIST",i=r.substring(
12);break;case this.prefix+"filterOp_CONTAIN":
case this.prefix+"filterOp_NOT_CONTAIN":this.type="FILTER_MATCH",i=r.substring(
12);break;case this.prefix+"filterOp_AFTER":case this.prefix+"filterOp_BEFORE":
case this.prefix+"filterOp_BETWEEN":this.type="FILTER_RANGE",
this.type="FILTER_RANGE",i=r.substring(12);break;default:return t}
dojo.stopEvent(e),this.updateHtml("filterType",this.type)}}if(
this._showFilterTab(),this.type!==s){let e=null;switch(this.type){
case"FILTER_PICKLIST":e=this.parentFilterMsg,t=this._initPicklistFilter(i);break
case"FILTER_MATCH":t=this._initMatchFilter(i);break;case"FILTER_PRESET":
t=this._initPresetFilter(i);break;case"FILTER_RANGE":e=this.parentFilterMsg,
t=this._initRangeFilter(i);break;case"FILTER_NUMERIC_LEVEL":
t=this._initNumericLevelFilter(i)}this.report.banner.defaultMessage=e}return t},
_showFilterTab(){for(let e=1;e<this.filterTypes.length;++e)this.filterTypes[e
]===this.type?cv.util.show(this.prefix+this.filterTypes[e]):cv.util.hide(
this.prefix+this.filterTypes[e])},_initPresetFilter(){let e;var t,i;let s;if(
0<this.ordinal)for(e of this.filterProps.predicates.item(this.ordinal))if(t=e.op
,i=e.preset,e.parameterName&&this._setParameterName(e.parameterName),
i||"TIME_YAGO"===t)switch(t){case"EQUAL":for(const r of i.split(","))(
s="-1"===r?this.byId("PREVIOUS_TIME"):"0"===r?this.byId("CURRENT_TIME"
):"-4"===r||"-12"===r?this.byId("TIME_YAGO"):this.byId("NEXT_TIME")).checked=!0;
break;case"TIME_YAGO":this.byId("TIME_YAGO").checked=!0;break;
case"TIME_RANGE_PREV":this.byId("TIME_RANGE_PREV").checked=!0,this.byId(
"TIME_RANGE_PREV_NUM").value=i;break;case"TIME_AGO":this.byId("TIME_AGO"
).checked=!0,this.byId("TIME_AGO_NUM").value=i;break;case"TIME_RANGE_NEXT":
this.byId("TIME_RANGE_NEXT").checked=!0,this.byId("TIME_RANGE_NEXT_NUM").value=i
break;case"TIME_AHEAD":this.byId("TIME_AHEAD").checked=!0,this.byId(
"TIME_AHEAD_NUM").value=i}return s=this.byId("TIME_RANGE_PREV"),this.byId(
"TIME_RANGE_PREV_NUM").disabled=!s.checked,d(s,"click",o.hitch(this,
"_switchPreset")),s=this.byId("TIME_AGO"),this.byId("TIME_AGO_NUM"
).disabled=!s.checked,d(s,"click",o.hitch(this,"_switchPreset")),s=this.byId(
"TIME_RANGE_NEXT"),this.byId("TIME_RANGE_NEXT_NUM").disabled=!s.checked,d(s,
"click",o.hitch(this,"_switchPreset")),s=this.byId("TIME_AHEAD"),this.byId(
"TIME_AHEAD_NUM").disabled=!s.checked,d(s,"click",o.hitch(this,"_switchPreset"))
,"TIME_YEAR"===this.attributeType?a.add(n.byId("TD_FT_TIME_YAGO"),"hidden"
):a.remove(n.byId("TD_FT_TIME_YAGO"),"hidden"),!0},_switchPreset(e){
var t=e.target.id,e=e.target.checked;let i;switch(t){
case this.prefix+"TIME_RANGE_PREV":i=this.byId("TIME_RANGE_PREV_NUM");break;
case this.prefix+"TIME_AGO":i=this.byId("TIME_AGO_NUM");break;
case this.prefix+"TIME_RANGE_NEXT":i=this.byId("TIME_RANGE_NEXT_NUM");break;
case this.prefix+"TIME_AHEAD":i=this.byId("TIME_AHEAD_NUM")}e?(i.disabled=!1,
i.focus()):(i.value="",i.disabled=!0,a.remove(i,"inputNum invalid"))},
_savePresetFilter(){if(this.byId("TIME_RANGE_PREV"
).checked&&!this._validatePreset(this.byId("TIME_RANGE_PREV_NUM").value)
)return this.byId("TIME_RANGE_PREV_NUM").focus(),a.add(this.byId(
"TIME_RANGE_PREV_NUM"),"inputNum invalid"),!1;if(this.byId("TIME_AGO"
).checked&&!this._validatePreset(this.byId("TIME_AGO_NUM").value)
)return this.byId("TIME_AGO_NUM").focus(),a.add(this.byId("TIME_AGO_NUM"),
"inputNum invalid"),!1;if(this.byId("TIME_RANGE_NEXT"
).checked&&!this._validatePreset(this.byId("TIME_RANGE_NEXT_NUM").value)
)return this.byId("TIME_RANGE_NEXT_NUM").focus(),a.add(this.byId(
"TIME_RANGE_NEXT_NUM"),"inputNum invalid"),!1;if(this.byId("TIME_AHEAD"
).checked&&!this._validatePreset(this.byId("TIME_AHEAD_NUM").value)
)return this.byId("TIME_AHEAD_NUM").focus(),a.add(this.byId("TIME_AHEAD_NUM"),
"inputNum invalid"),!1;if(!(this.byId("TIME_RANGE_PREV").checked||this.byId(
"TIME_AGO").checked||this.byId("TIME_RANGE_NEXT").checked||this.byId(
"CURRENT_TIME").checked||this.byId("PREVIOUS_TIME").checked||this.byId(
"NEXT_TIME").checked||this.byId("TIME_AHEAD").checked||"hidden"!==n.byId(
"TD_FT_TIME_YAGO").className&&("hidden"===n.byId("TD_FT_TIME_YAGO"
).className||this.byId("TIME_YAGO").checked)))return this.report.removeFilter(
`filter_${this.filterProps.formula}_`+this.ordinal),!1;let e;this.byId(
"PREVIOUS_TIME").checked&&(e="-1"),this.byId("CURRENT_TIME").checked&&(
e=e?e+",0":"0");var t=[];return(e=this.byId("NEXT_TIME").checked?e?e+",1":"1":e
)&&t.push({ordinal:this.ordinal,op:"EQUAL",preset:e,rela_filter:1,
parameterName:this.byId("PARAMETER_NAME").value}),this.byId("TIME_YAGO"
).checked&&t.push({ordinal:this.ordinal,op:this.byId("TIME_YAGO").value,
rela_filter:1,parameterName:this.byId("PARAMETER_NAME").value}),this.byId(
"TIME_RANGE_PREV").checked&&t.push({ordinal:this.ordinal,op:this.byId(
"TIME_RANGE_PREV").value,preset:this.byId("TIME_RANGE_PREV_NUM").value,
rela_filter:1,parameterName:this.byId("PARAMETER_NAME").value}),this.byId(
"TIME_RANGE_NEXT").checked&&t.push({ordinal:this.ordinal,op:this.byId(
"TIME_RANGE_NEXT").value,preset:this.byId("TIME_RANGE_NEXT_NUM").value,
rela_filter:1,parameterName:this.byId("PARAMETER_NAME").value}),this.byId(
"TIME_AGO").checked&&t.push({ordinal:this.ordinal,op:this.byId("TIME_AGO"
).value,preset:this.byId("TIME_AGO_NUM").value,rela_filter:1,
parameterName:this.byId("PARAMETER_NAME").value}),this.byId("TIME_AHEAD"
).checked&&t.push({ordinal:this.ordinal,op:this.byId("TIME_AHEAD").value,
preset:this.byId("TIME_AHEAD_NUM").value,rela_filter:1,parameterName:this.byId(
"PARAMETER_NAME").value}),0<t.length&&this.report.updateRelativeFilterProps(
this.filterProps,t),!0},_validatePreset(e){return!(!cv.util.checkNumber(e
)||parseInt(e,10)<=0||180<parseInt(e,10))||(this.displayError(
"Please input a number between 1 and 180"),!1)},_setPresetMenu(e){if(!(
1<e.childNodes.length)){e.innerHTML="";var t=cvCatalog[
"filterPreset"+this.attributeType];for(const i in t)cv.addOption(e,new Option(t[
i],i));e.childNodes[0].selected=!0}},_initRangeFilter(e){return cv.getFieldHelp(
).get(this.attribute,"currentDateMember")||cv.util.hide(this.byId(
"openDatePicker")),this.asyncMode=!0,this._loadAttributeMembers(e),
this._populateUIRangeFilter(e),!0},_populateUIRangeFilter(e){var t=this.byId(
"rangeOp");if(!t.disabled){var i=this.byId("range1"),s=this.byId("range2"),r=(
this.handleOnChangeRangeOp||(this.handleOnChangeRangeOp=d(t,"change",o.hitch(
this,"_onChangeRangeOp"))),this.handleOnShowDatePicker||(
this.handleOnShowDatePicker=d(this.byId("openDatePicker"),"click",o.hitch(this,
"_onShowDatePicker")),_.makeAccessibleActionButton(this.byId("openDatePicker")))
,0<this.ordinal?this.filterProps.predicates.item(this.ordinal)[0]:null);if(
"BETWEEN"===r?.op||"AFTER"===r?.op||"BEFORE"===r?.op)t.value=r.op,
i.value=r.members[0].formula,i.value!==r.members[0].formula&&(cv.addOption(i,
new Option(r.members[0].caption,r.members[0].formula)),i.value=r.members[0
].formula),"BETWEEN"===r.op?(s.value=r.members[1].formula,s.value!==r.members[1
].formula&&(cv.addOption(s,new Option(r.members[1].caption,r.members[1].formula)
),s.value=r.members[1].formula)):s.options[s.options.length-1].selected=!0,
r.parameterName&&this._setParameterName(r.parameterName);else{var r=parseInt(
cv.getFieldHelp().get(this.attribute,"dateFilterStart"),10),a=parseInt(
cv.getFieldHelp().get(this.attribute,"dateFilterEnd"),10),l=parseInt(
cv.getFieldHelp().get(this.attribute,"dateFilterDefaultStart"),10),h=parseInt(
cv.getFieldHelp().get(this.attribute,"dateFilterDefaultEnd"),10),n=r<1?-1*r:0;
let e,t;(e=0===l?n:l===r?0:l===a?i.options.length-1:Number.isNaN(l)?0:l+n
)>i.options.length-1&&(e=i.options.length-1),(
t=0===h?n:h===r?0:h===a||Number.isNaN(h)?s.options.length-1:h+n
)>s.options.length-1&&(t=s.options.length-1),i.options[e].selected=!0,s.options[
t].selected=!0}e&&(t.value=e),this._onChangeRangeOp()}},_saveRangeFilter(){
var e=this.byId("rangeOp").value,t=this.byId("range1").options[this.byId(
"range1").selectedIndex],i=[{formula:t.value,caption:t.text}];return i[0]?(
"BETWEEN"===e&&(t=this.byId("range2").options[this.byId("range2").selectedIndex]
,i.push({formula:t.value,caption:t.text})),this.report.updateFilterProps(
this.filterProps,{ordinal:this.ordinal,op:e,preset:null,members:i},!1,!0
).parameterName=this.byId("PARAMETER_NAME").value,!0):(this.displayMsg(
cvCatalog.dlgErrFilterInvalidValue),!1)},_initNumericLevelFilter(e){
var t=this.byId("numericLevelOp"),i=this.byId("numericLevelOp1"),s=this.byId(
"numericLevelOp2"),r=(this.handleOnChangeNumericLevelOp||(
this.handleOnChangeNumericLevelOp=d(t,"change",o.hitch(this,
"_onChangeNumericLevelOp"))),0<this.ordinal?this.filterProps.predicates.item(
this.ordinal)[0]:null);
return"NUMERIC_BETWEEN"!==r?.op&&"NUMERIC_GREATER_THAN"!==r?.op&&"NUMERIC_GREATER_THAN_EQUAL"!==r?.op&&"NUMERIC_LESS_THAN"!==r?.op&&"NUMERIC_LESS_THAN_EQUAL"!==r?.op||(
t.value=r.op,i.value=r.op1,"NUMERIC_BETWEEN"===r.op&&(s.value=r.op2),
r.parameterName&&this._setParameterName(r.parameterName)),e&&(t.value=e),
this._onChangeNumericLevelOp(),!0},_onChangeNumericLevelOp(){cv.util.isHidden(
this.prefix+"numericLevelOp1")&&cv.util.show(this.prefix+"numericLevelOp1"),
"NUMERIC_BETWEEN"===this.byId("numericLevelOp").value?cv.util.isHidden(
this.prefix+"numericLevelOp2_row")&&cv.util.show(
this.prefix+"numericLevelOp2_row"):cv.util.isHidden(
this.prefix+"numericLevelOp2_row")||cv.util.hide(
this.prefix+"numericLevelOp2_row")},_saveNumericLevelFilter(){var e=this.byId(
"numericLevelOp").value,t=this.byId("numericLevelOp1").value,i=this.byId(
"numericLevelOp2").value,s={ordinal:this.ordinal,op:e,preset:null};if(
"NUMERIC_BETWEEN"===e){if(!(t&&i&&cv.util.checkNumber(t)&&cv.util.checkNumber(i)
))return this.displayMsg(cvCatalog.dlgErrFilterNumericLevelNumberExpected),!1;
s.op1=t,s.op2=i}else{if(!t||!cv.util.checkNumber(t))return this.displayMsg(
cvCatalog.dlgErrFilterNumericLevelNumberExpected),!1;s.op1=t}
return this.report.updateFilterProps(this.filterProps,s,!1,!0
).parameterName=this.byId("PARAMETER_NAME").value,!0},_onChangeRangeOp(){switch(
this.byId("rangeOp").value){case"AFTER":cv.util.isHidden(
this.prefix+"range1_row")&&cv.util.show(this.prefix+"range1_row"),
cv.util.isHidden(this.prefix+"range2_row")||cv.util.hide(
this.prefix+"range2_row");break;case"BETWEEN":cv.util.isHidden(
this.prefix+"range1_row")&&cv.util.show(this.prefix+"range1_row"),
cv.util.isHidden(this.prefix+"range2_row")&&cv.util.show(
this.prefix+"range2_row");break;case"BEFORE":cv.util.isHidden(
this.prefix+"range1_row")&&cv.util.show(this.prefix+"range1_row"),
cv.util.isHidden(this.prefix+"range2_row")||cv.util.hide(
this.prefix+"range2_row")}},_onShowDatePicker(){new cv.DatePickerDialog(this,
this.report).show()},_initPicklistFilter(e){this.memberListNode=this.byId(
"memberList"),this.memberListbox=_.makeAccessibleListbox(this.memberListNode),
cv.util.disableTextSelection(this.memberListNode),this.search=this.byId(
"searchText"),this.handleOnKeyDownSearchText||(this.handleOnKeyDownSearchText=d(
this.search,"keydown",o.hitch(this,"_onKeyDownSearchText"))),this.asyncMode=!1,
this._loadAttributeMembers(e);var t=this.byId("picklistOp");
return this.handleOnChangePicklistOp||(this.handleOnChangePicklistOp=d(t,
"change",o.hitch(this,"_onChangePicklistOp"))),
this.handleValueListNodeAddMembers||(this.handleValueListNodeAddMembers=d(
this.valueListNode,"dblclick",o.hitch(this,"_addMembers"))),
this.handleMemberListNodeRemoveMembers||(this.memberListNodeRemoveMembers=d(
this.memberListNode,"dblclick",o.hitch(this,"_removeMembers"))),
this.handleSearchValueList||(this.handleSearchValueList=d(this.byId("searchBy"),
"click",o.hitch(this,"_searchValueList"))),this.handleSelectAddAddMembers||(
this.handleSelectAddAddMembers=d(this.byId("select_add"),"click",o.hitch(this,
"_addMembers"))),this.handleSelectAddAllAddMembers||(
this.handleSelectAddAllAddMembers=d(this.byId("select_addAll"),"click",o.hitch(
this,"_addMembers"))),this.handleSelectRemoveRemoveMembers||(
this.handleSelectRemoveRemoveMembers=d(this.byId("select_remove"),"click",
o.hitch(this,"_removeMembers"))),this.handleSelectRemoveAllRemoveMembers||(
this.handleSelectRemoveAllRemoveMembers=d(this.byId("select_removeAll"),"click",
o.hitch(this,"_removeMembers"))),
this.handleAccessibleAddMembers=_.makeAccessibleActionButton(this.byId(
"select_add")),this.handleAccessibleAddAllMembers=_.makeAccessibleActionButton(
this.byId("select_addAll")),
this.handleAccessibleRemoveMembers=_.makeAccessibleActionButton(this.byId(
"select_remove")),
this.handleAccessibleRemoveAllMembers=_.makeAccessibleActionButton(this.byId(
"select_removeAll")),this._populateUIPicklistFilter(e),!0},
_populateUIPicklistFilter(e){var t=this.byId("picklistOp"),
i=0<this.ordinal?this.filterProps.predicates.item(this.ordinal)[0]:null;
!i||"EQUAL"!==i.op&&"NOT_EQUAL"!==i.op||i.preset||(t.value=i.op,
this.memberListNode.innerHTML=this._formatValueList(i.members,"SELECTED"),
i.parameterName&&this._setParameterName(i.parameterName)),e&&(t.value=e),
t.value||(t.options[0].selected=!0),this._onChangePicklistOp()},
_savePicklistFilter(){var e,t,i=this._getSelectionList();return 0===i.count?(
this.displayMsg(cvCatalog.dlgErrFilterNoSelection),!1):(e=cv.analyzerProperties[
"filter.include.exclude.max.count"],i.count>e?(t=cv.util.substituteParams(
cvCatalog.dlgErrFilterMaxMembers,e),this.displayMsg(t),!1):((
t=this.report.updateFilterProps(this.filterProps,{ordinal:this.ordinal,
op:this.byId("picklistOp").value,members:i.toArray()})).parameterName=this.byId(
"PARAMETER_NAME").value,!(t.members.length>e&&(i=cv.util.substituteParams(
cvCatalog.dlgErrFilterMaxMembers,e),this.displayMsg(i),
0<t.ordinal&&t.ordinal!==this.ordinal&&(
this.memberListNode.innerHTML=this._formatValueList(t.members,"SELECTED"),
this.ordinal=t.ordinal),1))))},_onChangePicklistOp(){a.remove(
this.memberListNode,"excluded"),a.remove(this.memberListNode,"included");
var e="EQUAL"===this.byId("picklistOp").value?"included":"excluded";a.add(
this.memberListNode,e)},_onKeyDownSearchText(e){
"Enter"===e.code&&this._searchValueList(e)},_addMembers(e){let i;switch(
e.target.id){case this.prefix+"select_add":
i=this.valueListbox.getSelectedOptions();break;case this.prefix+"select_addAll":
i=this.valueListNode.getElementsByTagName("DIV");break;default:if(
0!==e.target.id.indexOf(this.prefix+"AVA_"))return;i=[e.target]}if(0!==i.length
){var s=this._getSelectionList();let t=s["count"];var r={};for(let e=0;e<t;++e
)r[s.item(e).formula]=!0;for(const h of i){var a=h.id?.substring(7);a&&r[a]||(
a=c.create("div",{id:this.prefix+"SEL_"+a,title:a,role:"option",
innerHTML:h.innerHTML}),this.memberListNode.appendChild(a),t+=1)}
var l=cv.analyzerProperties["filter.include.exclude.max.count"];t>l&&(
l=cv.util.substituteParams(cvCatalog.dlgErrFilterMaxMembers,l),this.displayMsg(l
)),this.byId("memberListStat").innerHTML=cv.util.substituteParams(cvCatalog[
"filterSelectionSummary"+(t<=1?"Single":"All")],t)}},_removeMembers(e){
let t=this.memberListNode.getElementsByTagName("DIV"),i=t.length;switch(
e.target.id){case this.prefix+"select_remove":
t=this.memberListbox.getSelectedOptions(),i-=t.length;break;
case this.prefix+"select_removeAll":i=0;break;default:if(
0!==e.target.id.indexOf(this.prefix+"SEL_"))return;t=[e.target],--i}if(
0!==t.length){for(let e=t.length-1;0<=e;--e)this.memberListbox.removeOption(t[e]
);this.byId("memberListStat").innerHTML=cv.util.substituteParams(cvCatalog[
i<=1?"filterSelectionSummarySingle":"filterSelectionSummaryAll"],i)}return!1},
_loadAttributeMembers(t){o.isObject(this.searchCache[0]
)?"FILTER_RANGE"===this.type?(t&&(this.byId("rangeOp").value=t),
this._onChangeRangeOp()):"FILTER_PICKLIST"===this.type&&t&&(this.byId(
"picklistOp").value=t,this._onChangePicklistOp()):(
this.valueListNode.innerHTML=`<span style='margin-left:5px'><span class='page-loading-icon'></span>&nbsp;${cvCatalog.progressLoading}</span>`
,this._initGetMembersRequest("",e=>{e&&(this.asyncRequestId=e,this._getMembers({
requestId:e,timeout:1,search:"",op:t}))}))},_searchValueList(e){
const t=this.search.value;var i=t?.toLowerCase(),s=i?.length??0,
r=this.searchCache[s];if(this.valueListbox.clearSelectedOptions(),
this.valueListbox.clearActiveOption(),!r||0!==s&&r.key!==i)if(
0===this.searchCacheTopIndex||0<this.searchCacheTopIndex&&0<=i?.indexOf(
this.searchCache[this.searchCacheTopIndex].key)){var a=this.searchCache[
this.searchCacheTopIndex].data,l=[];for(let e=0,t=a.length;e<t;++e
)0<=cv.util.escapeHtml(a[e].caption).toLowerCase().indexOf(i)&&l.push(a[e]);
this.searchCache[i.length]={key:i,data:l},
this.valueListNode.innerHTML=this._formatValueList(l,"AVAILABLE")
}else this.asyncRequest&&this.asyncRequest.cancel(),
this.valueListNode.innerHTML=`
              <span style="margin-left:5px">
                <span class="page-loading-icon"></span>
                &nbsp;${cvCatalog.progressLoading}
              </span>`,this._initGetMembersRequest(t,e=>{e&&(
this.asyncRequestId=e),this._getMembers({requestId:e,timeout:1,search:t})}
);else this.valueListNode.innerHTML=this._formatValueList(r.data,"AVAILABLE",
r.count);return e.preventDefault(),e.stopPropagation(),!1},
_initGetMembersRequest(e,t){e={reportXML:this.report.getReportXml(),
action:"MEMBERS",attribute:this.attribute,search:e};
return this.asyncRequestId&&(e.prevId=this.asyncRequestId),
cv.io.initAsyncRequest(e,t)},_getMembers(e){if(e.requestId===this.asyncRequestId
){const n={...e,attribute:this.attribute,time:(new Date).getTime()};h(
cv.contextPath+"service/ajax/getMembers",{handleAs:"json",method:"post",
sync:this.asyncMode,headers:{},data:n}).then(i=>{if(this.dlgWidget.open&&(
this.status=null,n.requestId===this.asyncRequestId)){if(i){
this.asyncRequestId=null,this.asyncRequest=null;var{op:e,search:t}=n;if(
this.searchCacheTopIndex=i.count&&i.values.length!==i.count?-1:t.length,
0<t.length)this.searchCache[t.length]={key:t.toLowerCase(),data:i.values,
count:i.count};else if(this.searchCache[0]={key:null,data:i.values,count:i.count
},this.isTimeAttribute){var s=this.byId("range1"),r=(s.innerHTML="",this.byId(
"range2"));r.innerHTML="",cv.util.hide(this.prefix+"rangeLoading");for(let e=0,
t=i.values.length;e<t;++e){var a=cv.util.escapeHtml(i.values[e].caption),
l=i.values[e].formula,h=new Option(a,l),a=(h.title=l,new Option(a,l));a.title=l,
cv.addOption(s,h),cv.addOption(r,a)}i.values.length<i.count&&(cv.util.show(
this.prefix+"rangeWarning"),this.byId("rangeWarningText"
).innerHTML=cv.util.substituteParams(cvCatalog.dlgAttributeFilterTooManyValues,
i.values.length))}switch(this.valueListNode.innerHTML=this._formatValueList(
i.values,"AVAILABLE",i.count),this.type){case"FILTER_PICKLIST":
0===t.length&&this._populateUIPicklistFilter(e);break;case"FILTER_MATCH":
case"FILTER_PRESET":break;case"FILTER_RANGE":this._populateUIRangeFilter(e)}
}else n.timeout=1,this.asyncRequest=null,setTimeout(o.hitch(this,"_getMembers",n
),3e3);this.status&&this.displayMsg(cvCatalog[this.status])}},e=>{
"xhr cancelled"!==e.message&&"Request canceled"!==e.message&&n.requestId===this.asyncRequestId&&(
this.asyncRequestId=null,this.asyncRequest=null,this.status="dlgErrGeneric",
this.displayMsg(cvCatalog[this.status]))})}},cancel(){this.asyncRequest&&(
this.asyncRequest.cancel(),this.asyncRequest=null),this.asyncRequestId&&(
cv.io.cancelAsyncRequest(this.asyncRequestId),this.asyncRequestId=null),
cv.Dialog.prototype.cancel.call(this)},_formatValueList(t,i,e){
var s=t?t.length:0;let r,a="",l;l="SELECTED"===i?(r=this.byId("memberListStat"),
"filterSelectionSummary"):(r=this.byId("valueListStat"),
this.search&&this.search.value?"filterMatchesSummary":"filterValuesSummary"),
r&&(r.innerHTML=!e||0<=e&&e<=s?cv.util.substituteParams(cvCatalog[l+(
s<=1?"Single":"All")],s):cv.util.substituteParams(cvCatalog[l+(
-1===e?"PartialFirst":"Partial")],s,e));for(let e=0;e<s;++e){
var h=cv.util.escapeHtml(t[e].formula),n=cv.util.escapeHtml(t[e].caption);
"SELECTED"===i?a+='<div role="option" id="FT_SEL_':"AVAILABLE"===i&&(
a+='<div role="option" id="FT_AVA_'),a+=h+`" title="${h}">${n}</div>`}
return s<e&&(
a+=`<div style='font-size:92%'>${cvCatalog.filterHintForFind}</div>`),a},
_getSelectionList(){var i=this.memberListNode.getElementsByTagName("DIV"),
s=new r;for(let e=0,t=i.length;e<t;++e)s.add({formula:i[e].id.substring(7),
caption:p.textContent(i[e])});return s},_initMatchFilter(e){var t=this.byId(
"matchOp"),i=this.byId("FILTER_MATCH"),s=(this.handleOnClickMatchTbl||(
this.handleOnClickMatchTbl=d(i,"click",o.hitch(this,"_onClickMatchTbl"))),
this.handleKeyPressMatchTbl||(this.handleKeyPressMatchTbl=d(i,"keypress",
o.hitch(this,"_onClickMatchTbl"))),this.handleAddExpressionItem||(
this.handleAddExpressionItem=d(this.byId("exp_add"),"click",o.hitch(this,
"_addExpressionItem"))),_.makeAccessibleActionButton(this.byId("exp_add")),
this.defaultFocus=this.byId("expression_0"),
0<this.ordinal?this.filterProps.predicates.item(this.ordinal)[0]:null);if(s&&(
"CONTAIN"===s.op||"NOT_CONTAIN"===s.op)){if(t.value=s.op,s.exp)for(
let e=0;e<s.exp.length;++e)this._createExpressionItem(s.exp[e],""+e);
s.parameterName&&this._setParameterName(s.parameterName)}return e&&(t.value=e),
t.value||(t.options[0].selected=!0),!0},_saveMatchFilter(){
var e=this._getExpressionList();if(0===e.length)return this.displayMsg(
cvCatalog.dlgErrFilterRequiredExpression),!1;
var t=this.report.updateFilterProps(this.filterProps,{ordinal:this.ordinal,
op:this.byId("matchOp").value,exp:e});if(t.parameterName=this.byId(
"PARAMETER_NAME").value,t.exp.length>cvConst.MAX_FILTER_EXPRESSIONS){
e=cv.util.substituteParams(cvCatalog.dlgErrFilterMaxExpressions,
cvConst.MAX_FILTER_EXPRESSIONS);if(this.displayMsg(e),
0<t.ordinal&&t.ordinal!==this.ordinal){for(
let e=0;e<cvConst.MAX_FILTER_EXPRESSIONS;++e)this._createExpressionItem(t.exp[e]
,""+e);this.ordinal=t.ordinal}return!1}return!0},_addExpressionItem(e){
e&&!cv.util.isValidInteractionEvent(e)||(this.byId("FILTER_MATCH"
).rows.length===cvConst.MAX_FILTER_EXPRESSIONS+1?(e=cv.util.substituteParams(
cvCatalog.dlgErrFilterMaxExpressions,cvConst.MAX_FILTER_EXPRESSIONS),
this.displayMsg(e)):this._createExpressionItem())},_onClickMatchTbl(e){if(
e.target?.id&&cv.util.isValidInteractionEvent(e)){let t=e.target["id"];if(
0===t.indexOf(this.prefix+"exp_remove_")){var e=this.byId("FILTER_MATCH"),
i=e.rows.length;if(2!==i){for(let e=t=parseInt(t.substr(14),10);e<i-2;++e
)this.byId("expression_"+e).value=this.byId("expression_"+(e+1)).value;3===i&&(
a.remove(e,this.prefix+"multiExp"),this.byId("exp_remove_0").setAttribute(
"tabindex","-1")),e.deleteRow(i-2)}}}},_getExpressionList(){var i=[];for(let e=0
,t=this.byId("FILTER_MATCH").rows.length-1;e<t;++e){var s=this.byId(
"expression_"+e).value;s&&i.push(s)}return i},_createExpressionItem(e,t){
let i=null;if(!(i=t?this.byId("expression_"+t):i)){var t=this.byId(
"FILTER_MATCH"),s=t.rows.length-1,r=t.insertRow(s);
r.className="flex-row flex-center";let e=r.insertCell(0);
e.innerHTML=cvCatalog.filterTemplateExpressionOR,
e.className=this.prefix+"expressionOR flex-row flex-none",(e=r.insertCell(1)
).innerHTML=`<input type="text" class="flex-auto" id="${this.prefix}expression_${s}">`
,e.className=this.prefix+"expression",(e=r.insertCell(2)).innerHTML="&nbsp;",
e.id=this.prefix+"exp_remove_"+s,e.setAttribute("tabindex","0"),
e.className=this.prefix+"removeExp flex-none",3===t.rows.length&&(a.add(t,
this.prefix+"multiExp"),this.byId("exp_remove_0").setAttribute("tabindex","0")),
i=this.byId("expression_"+s)}e&&(i.value=e)},_setParameterName(e){this.byId(
"PARAMETER_NAME").value=e}}));define("pentaho/analyzer/report/cv_rptArithNumberDlg",["dojo/_base/declare",
"dojo/on","dojo/query","dojo/_base/lang","dojox/collections/Dictionary",
"dojox/collections/ArrayList","dojo/html","dojo/dom-class","dojo/dom-geometry",
"dojo/request","dojo/dom","dojo/dom-construct","dojox/xml/parser",
"dijit/form/DateTextBox","dojo/string","common-ui/util/_a11y","./cv_rptDlg"],(e,
u,t,p,r,a,i,n,l,o,h,s,g,d,m,v)=>e("cv.ArithNumberDialog",[cv.Dialog],{
constructor(e){this.report=e,this.rptDlg=this.report.rptDlg,
this.dlgTemplate="arithNumberDlg.html",
this._widgetCss="responsive dw-sm ds-fill-viewport-width",this.prefix="MA_"},
destroy(){this.inherited(arguments),this.clear()},clear(){},show(){
const r=this.rptDlg.byId("measures");r.selectedIndex=-1;var e=this.rptDlg.byId(
"ops").childNodes;const a=this.rptDlg.byId("content");var t=cv.getFieldHelp();
let i=!1;const l=this;function o(e,t){var r,a;
"number"==typeof e.selectionStart?(a=e.selectionStart,r=e.selectionEnd,
e.value=e.value.slice(0,a)+t+e.value.slice(r)):document.selection&&(i||((
a=e.createTextRange()).moveStart("character",e.value.length),a.collapse(!0),
a.select()),e.focus(),document.selection.createRange().text=t)}function s(e){
var t=e.target;if(!t)return!0;if("INPUT"===t.tagName&&"button"===t.type
)1===t.value.length?o(a,t.value):t.id===l.prefix+"clear"&&(a.value=""),
e.preventDefault();else if(
t.id===l.prefix+"measures"||t.id===l.prefix+"addField"||"OPTION"===t.tagName){
if(""!==r.options[r.selectedIndex].value){let e;e=0===r.options[r.selectedIndex
].value.indexOf("[MEASURE:")?`[${r.options[r.selectedIndex].text}]`:r.options[
r.selectedIndex].value,o(a,e),l.enableOkButton()}
}else t.id===l.prefix+"content"&&(i=!0);return a.focus(),!1}cv.util.hide(h.byId(
"mdxTableRow"));for(const n of e)"INPUT"===n.tagName&&"button"===n.type&&u(n,
"click",s);u(this.rptDlg.byId("addField"),"click",s),
v.makeAccessibleActionButton(this.rptDlg.byId("addField")),u(r,"dblclick",s),u(
this.rptDlg.byId("clear"),"click",s),u(this.rptDlg.byId("content"),"click",s),
this.dlgWidget.onCancel=p.hitch(this,"cancel"),cv.util.setHelpTopics([
"helpCalculateSubtotals",
"CV/Business_User/working_with_calculations.html#subtotal_calculation"]),
this.helpTopic+="creating_new_numbers";var d,c,e=cv.getFieldHelp(
).showHiddenFields;"arith_edit"===this.rptDlg.type?(this.dataSourceOrigin={},
this.report.addOptionsForAllMeasures(r,!0,this.rptDlg.dataSource.getId(),!0,e),
c=this.rptDlg.dataSource.getDisplayLabel(!0),this.dataSourceOrigin.label=c,
this.byId("name").value=c,
this.dataSourceOrigin.numberFormat=this.rptDlg._updateNumberFormat(
this.rptDlg.dataSource,!0),this.dataSourceOrigin.expression=cv.textContent(
this.rptDlg.dataSource.getMetricFacet()),a.value=this._transformArithExpression(
this.dataSourceOrigin.expression,!1),this.rptDlg.byId(
"calculateSubtotalsUsingFormula"
).checked="true"===this.rptDlg.dataSource.getCalculateSubtotalsUsingFormula(),
c=cv.util.substituteParams(cvCatalog.dlgPropertiesTitle,
this.dataSourceOrigin.label),(d=h.byId("dialogTitleText")).innerText=c,d.title=c
):"edit_calculated_measure"===this.rptDlg.type?(
this.report.addOptionsForAllMeasures(r,!0,null,!0,e),this.populateFormFields(),
t.selectedMenuField&&(d=t.selectedMenuField.getAttribute("formula"),c=t.get(d,
"displayLabel").trim(),t=cv.util.substituteParams(cvCatalog.dlgPropertiesTitle,c
),(c=h.byId("dialogTitleText")).innerText=t,c.title=t,this.setTextAndTitle("mdx"
,d),cv.util.show(h.byId("mdxTableRow"))),this.byId("applyDataSource").checked=!0
,this.byId("applyDataSourceWrapper").style.display="none"):(this.byId("name"
).value="",this.report.addOptionsForAllMeasures(r,!0,null,!0,e),
"measures_arith"===this.rptDlg.type?(c=this.rptDlg.dataSource.getFormula(),
c=this._transformArithExpression(c,!1),a.value+=c):a.value+=cv.getFieldHelp(
).selectedMenuField.getAttribute("formula"),
this.rptDlg.refGem=this.rptDlg.dataSource,this.rptDlg.dataSource=null,
"create_calculated_measure"===this.rptDlg.type&&(this.byId("applyDataSource"
).checked=!0,this.byId("applyDataSourceWrapper").style.display="none")),
cv.api.util._hasInlineModelingPermission()&&!cv.getFieldHelp(
).disableInlineModeling||(this.byId("applyDataSourceWrapper"
).style.display="none",this.byId("applyDataSource").checked=!1),this.showDialog(
),this.trackFormChange()},populateFormFields(){var e=cv.getFieldHelp();if(
e.selectedMenuField){var t=e.selectedMenuField.getAttribute("formula").trim(),
r=e.getModelInfoValue(t,"InlineFormatCategory").trim(),a=e.getModelInfoValue(t,
"InlineFormatScale").trim(),i=e.getModelInfoValue(t,"InlineFormulaExpression"
).trim(),l=e.getModelInfoValue(t,"InlineCalcSubtotals").trim(),o=(this.byId(
"name").value=e.get(t,"displayLabel").trim(),this.byId("formatCategory").options
);for(let e=0;e<=o.length-1;e++){var s=o[e];s.value===r&&(
o.selectedIndex=s.index)}var d=this.byId("formatScale").options;for(
let e=0;e<=d.length-1;e++){var c=d[e];c.value===a&&(d.selectedIndex=c.index)}
this.byId("content").value=i,this.byId("calculateSubtotalsUsingFormula"
).checked="true"===l}},save(){var t=m.trim(this.byId("name").value),e=this.byId(
"applyDataSource").checked;if(this.rptDlg.noHide=!1,n.remove(this.byId("name"),
"invalid"),n.remove(this.byId("formatCategory"),"invalid"),n.remove(this.byId(
"formatScale"),"invalid"),n.remove(this.byId("content"),"invalid"),
!this.rptDlg._validateName())return!(this.rptDlg.noHide=!0);
var a="edit_calculated_measure"===this.rptDlg.type,a=cv.util.isValidMeasureName(
t,!a);if(e&&!0!==a)return n.add(this.byId("name"),"invalid"),this.displayError(a
),!(this.rptDlg.noHide=!0);if(
!this.rptDlg._validateNumberFormatAndDecimalPlaces())return!(
this.rptDlg.noHide=!0);let r,i="[MEASURE:0]";var a=this.report["reportDoc"],
l=this._transformArithExpression(this.byId("content").value,!0),o=this.byId(
"calculateSubtotalsUsingFormula").checked?"true":"false";if(e){if(0<=l.indexOf(
"[MEASURE:"))return n.add(this.byId("content"),"invalid"),
this.rptDlg.displayError(
cvCatalog.errorModelingCalcMeasureValidationReportMeasure),!(
this.rptDlg.noHide=!0);r=a.reportRecord.cloneNode(!0);var s=a.createNode({
zoneId:"measures",metricType:"EXPRESSION",formula:null,expression:l,
refGem:this.rptDlg.refGem,gemType:cvConst.TYPE_METRIC}),d=(s.setAttribute("id",i
),cv.createNode(a.reportRecord,"displayLabel")),d=(d.setAttribute("label",t||"")
,d.setAttribute("labelPlural",""),d.setAttribute("locale",""),
this.rptDlg._updateNumberFormat()),d=(a.setNumberFormat(s,d),
a.updateCalculateSubtotalsUsingFormula(o,s),r.getElementsByTagName("report")),
c=r.getElementsByTagName("measures");if(1!==d.length
)return this.rptDlg.noHide=!0,this.rptDlg.displayError(cvCatalog.dlgErrGeneric),
!1;[d]=d,1===c.length&&d.removeChild(c[0]),(c=cv.createNode(a.reportRecord,
"measures")).appendChild(s),d.appendChild(c),r=g.innerXML(r)
}else this.rptDlg.dataSource||(
this.rptDlg.dataSource=this.report.createSpecialMetricGem({zoneId:"measures",
metricType:"EXPRESSION",formula:null,refGem:this.rptDlg.refGem})),
this.rptDlg.dataSource.update({expression:l}),
this.rptDlg.dataSource.setDisplayLabel(t),this.rptDlg._updateNumberFormat(
this.rptDlg.dataSource),
this.rptDlg.dataSource.setCalculateSubtotalsUsingFormula(o),
r=this.report.getReportXml(),i=this.rptDlg.dataSource.getId();
a=cv.util.parseAjaxMsg(cv.io.ajaxLoad("service/ajax/validateCalculatedMeasure",{
reportXML:r,measureId:i,annotations:this.report.getModelAnnotationsJson()},!0));
if(!a||"error"===a?.type)return this.rptDlg.noHide=!0,this.rptDlg.displayError(
a?.details?a.details:cvCatalog.dlgErrGeneric),!1;if(e){let e;s=cv.getFieldHelp()
let r;if("edit_calculated_measure"===this.rptDlg.type?(
r=s.selectedMenuField.getAttribute("formula").trim(),d=s.get(r,"measureName"),
e="actionUpdateCalculatedMeasure",cv.util.createUpdateCalcMeasureAnnotation(d,d,
l,t,t,this.byId("formatCategory").value,this.byId("formatScale").value,o,!1),
this.rptDlg.dataSource=void 0):(r=`[Measures].[${t}]`,
e="actionCreateCalculatedMeasure",cv.util.createCalcMeasureAnnotation(t,l,t,t,
this.byId("formatCategory").value,this.byId("formatScale").value,o,!1)),
void 0!==this.report.manager.updateCatalog(!0)
)return this.report.modelAnnotations.pop(),this.rptDlg.displayMsg(
cvCatalog.dlgErrGeneric),!(this.rptDlg.noHide=!0);if(this.rptDlg.dataSource
)cv.util.convertReportCalcMeasureToModel(this.rptDlg.dataSource.getFormula(),t
);else if("measures_arith"===this.rptDlg.type){let e,t;
this.report.isReportFormatPivot()?(e="measures",
c=this.report.api.report.getLayoutFields(e),t=c.indexOf(
this.rptDlg.refGem.getFormula())+1):null!==(
a=this.report.getNextAvailableGembarForField(r))&&(e=a.name,t=a.fieldPosition),
e&&this.report.api.report.addLayoutField(e,r,t)}r&&t&&this.report.refreshReport(
),this.report.history.add(new cv.ReportState(e,t))}else{
e="arith_edit"===this.rptDlg.type;this.report.history.add(new cv.ReportState(
e?"actionEdit":"actionAdd",t)),e&&this.report.reportDoc.isUsedByMetricFilter(
this.rptDlg.dataSource.getFormula())&&this.report.populateFilters()}return!0},
cancel(){switch(this.rptDlg.type){case"measures_arith":this.rptDlg.dataSource&&(
this.report.gemList.remove(this.rptDlg.dataSource.getId()),cv.util.removeNode(
this.rptDlg.dataSource.xmlNode));break;case"arith_edit":
this.rptDlg.dataSource.update(this.dataSourceOrigin)}
cv.Dialog.prototype.cancel.call(this)},_transformArithExpression(e,t){
var r=this.byId("measures")["options"];const a={};for(const l of r
)0===l.value.indexOf("[MEASURE:")&&(t?a[`[${l.text}]`]=l.value:a[l.value
]=`[${l.text}]`);let i;return i=t?/(\[(\\]|[^\]])+])/g:/(\[MEASURE[^\]]+])/g,
e.replace(i,e=>{var{[e]:t}=a;return t||e})}}));define("pentaho/analyzer/report/cv_rptCreateMeasureDlg",["dojo/_base/declare",
"dojo/on","dojo/query","dojo/_base/lang","dojox/collections/Dictionary",
"dojox/collections/ArrayList","./cv_rptDlg","dojo/html","dojo/dom-class",
"dojo/dom-geometry","dojo/request","dojo/dom","dojo/dom-construct",
"dojox/xml/parser","dijit/form/DateTextBox"],function(e,t,o,r,a,i,l,n,s,c,d,u,p,
m,g){return e("cv.CreateMeasureDialog",[cv.Dialog],{constructor:function(e){
this.report=e,this.rptDlg=this.report.rptDlg,
this.dlgTemplate="createMeasureDlg.html",this.prefix="FT_",this.filterTypes=[
"FILTER_METRIC","FILTER_PICKLIST","FILTER_MATCH","FILTER_PRESET","FILTER_RANGE"]
},destroy:function(){this.inherited(arguments),this.clear()},clear:function(){},
show:function(e,t){this.dlgTemplate="createMeasureDlg.html",
this.helpTopic="CV/Business_User/working_with_filters.html#filters_on_text_fields"
,this.showDialog()},save:function(){var e=cv.getFieldHelp(),
t=document.getElementById("CM_measureName").value,o=document.getElementById(
"CM_aggType").value,r=document.getElementById("CM_formatCategory"),
a=document.getElementById("CM_formatScale"),i=(null==r&&(r="General Number"),
null==a&&(a="0"),cv.util.isValidMeasureName(t));if(!0!==i
)return this.rptDlg.noHide=!0,this.showError(i),!1;if(e.selectedMenuField){
var i=e.selectedMenuField.getAttribute("formula"),l="NUMBER"==e.get(i,"type"
)?"Measure":"HierarchyLevel",n=(e.get(i,"displayLabel"),e.manager.report),s={},
e=(e.count||(e.count=1),s.source={cube:n.cube,measure:i,sourceType:l},
s.type="CREATE_MEASURE",s.properties={name:t,aggregationType:o,formatCategory:r,
formatScale:a},n.modelAnnotations.push(s),n.manager.updateCatalog(!0));if(
void 0!==e)return n.modelAnnotations.pop(),this.rptDlg.noHide=!0,this.showError(
e),!1;n.history.add(new cv.ReportState("actionCreateMeasure",t)),
n.api.operation.refreshReport()}return!0},cancel:function(){
cv.Dialog.prototype.cancel.call(this)}})});define("pentaho/analyzer/report/cv_rptRemoveMeasureDlg",["dojo/_base/declare",
"dojo/on","dojo/query","dojo/_base/lang","dojox/collections/Dictionary",
"dojox/collections/ArrayList","./cv_rptDlg","dojo/html","dojo/dom-class",
"dojo/dom-geometry","dojo/request","dojo/dom","dojo/dom-construct",
"dojox/xml/parser","dijit/form/DateTextBox"],function(e,o,t,r,a,i,l,s,n,c,d,u,p,
m,h){return e("cv.RemoveMeasureDialog",[cv.Dialog],{constructor:function(e){
this.report=e,this.dlgTemplate="removeMeasureDlg.html",this.prefix="RM_"},
destroy:function(){this.inherited(arguments),this.clear()},clear:function(){},
show:function(e,o){this.dlgTemplate="removeMeasureDlg.html",
this.helpTopic="CV/Business_User/working_with_filters.html#filters_on_text_fields"
,this.showDialog()},save:function(){var e,o,t,r,a=cv.getFieldHelp();
return a.selectedMenuField&&(e=a.selectedMenuField.innerHTML,
o=a.selectedMenuField.getAttribute("formula"),t="NUMBER"==a.get(o,"type"
)?"Measure":"HierarchyLevel","true"==a.get(o,"calculated")&&(
t="CalculatedMember"),a.get(o,"displayLabel"),a=a.manager.report,(r={}).source={
cube:a.cube,measure:o,sourceType:t},r.properties={name:e,dimension:"Measures"},
r.type="REMOVE_MEASURE",a.modelAnnotations.push(r),a.manager.updateCatalog(),
a.history.add(new cv.ReportState("actionRemoveMeasure",e)),
a.api.operation.refreshReport()),!0},cancel:function(){
cv.Dialog.prototype.cancel.call(this)}})});define("pentaho/analyzer/report/cv_rptMeasurePropertiesDlg",[
"dojo/_base/declare","dojo/on","dojo/query","dojo/_base/lang",
"dojox/collections/Dictionary","dojox/collections/ArrayList","./cv_rptDlg",
"dojo/html","dojo/dom-class","dojo/dom-geometry","dojo/request","dojo/dom",
"dojo/dom-construct","dojox/xml/parser","dijit/registry",
"pentaho/common/FormatCombo"],function(e,t,i,a,r,o,s,l,d,n,u,c,g,h,p,m){
return e("cv.MeasurePropertiesDialog",[cv.Dialog],{constructor:function(e){
this.report=e,this.rptDlg=this.report.rptDlg,
this.dlgTemplate="measurePropertiesDlg.html",this.prefix="MP_",
this.helpTopic="CV/Business_User/working_with_filters.html#filters_on_text_fields"
,this.formatText=p.byId("MP_formatText"),
this._widgetCss="responsive dw-sm ds-fill-viewport-width"},destroy:function(){
this.inherited(arguments),this.clear()},clear:function(){},show:function(e,t){
this.formatText=p.byId("MP_formatText");var i,a,r,o,s,l,
d=cv.api.util._hasInlineModelingPermission()&&!cv.getFieldHelp(
).disableInlineModeling,n=(this.measure={},cv.getFieldHelp());
n.selectedMenuField&&(i=n.selectedMenuField.getAttribute("formula"),a=n.get(i,
"aggregationType"),r=n.get(i,"displayLabel"),o=n.get(i,"formatString"),s=n.get(i
,"displayDescription"),n="true"===n.get(i,"calculated"),
l=cv.util.substituteParams(cvCatalog.dlgPropertiesTitle,r),c.byId(
"dialogTitleText").innerText=l,c.byId("dialogTitleText").title=l,(
l=this.report.getFieldLabel(i))&&l!=r&&(l=cv.util.substituteParams(
cvCatalog.dlgAboutFieldRenamed,l),this.setTextAndTitle("fieldRenamed",l),
cv.util.show("MP_fieldRenamed")),this.setTextAndTitle("mdx",i),
this.setTextAndTitle("description",s||r),d?(this.byId("name").value=r,
cv.util.hide("MP_nameLabel"),this.byId("aggType").value=a,cv.util.hide(
"MP_aggTypeLabel"),cv.util.show("MP_aggContainer"),this.formatText.setDataType(
"numeric"),this.formatText.set("value",o),cv.util.hide("MP_formatTextLabel")):(
cv.util.hide("MP_name"),this.setTextAndTitle("nameLabel",r),cv.util.hide(
"MP_aggType"),this.setTextAndTitle("aggTypeLabel",a),cv.util.hide(
"MP_formatContainer"),o?this.setTextAndTitle("formatTextLabel",o):cv.util.hide(
"MP_format"),cv.util.hide("dlgBtnSave"),c.byId("dlgBtnCancel"
).innerText=cv.util.substituteParams(cvCatalog.btnLabelClose)),n)&&cv.util.hide(
"MP_aggContainer"),this.showDialog(),this.trackFormChange(),
this.addKeyUpHandler(this.byId("name"))},addKeyUpHandler:function(e){var i,
a=c.byId("dlgBtnSave"),r=c.byId("error-measure-name"),o=c.byId(
"error-measure-spacer"),s=this.report.okTimeoutInterval;e.onkeyup=function(e){
clearInterval(i);var t=this;i=setTimeout(function(){var e=t.value.toLowerCase(),
e=cv.util.isValidMeasureName(e);!0!==e?(a.disabled=!0,l.set(r,e),
r.classList.remove("hidden"),o.classList.remove("hidden")):(a.disabled=!1,
r.classList.add("hidden"),o.classList.add("hidden"))},s)}},
hasPropertiesChanged:function(e,t){var i=e.selectedMenuField.getAttribute(
"formula"),a=e.get(i,"aggregationType"),r=e.get(i,"displayLabel"),e=e.get(i,
"formatString");
return a!==t.properties.aggregation||r!==t.properties.name||e!==t.properties.format
},save:function(){var e=cv.getFieldHelp(),t=this.byId("name").value,i=this.byId(
"aggType").value,a=this.formatText.get("value"),r=(this.rptDlg.noHide=!1,
cv.util.isValidMeasureName(t));if(!0!==r)return this.rptDlg.noHide=!0,
this.showError(r),!1;if(e.selectedMenuField){
var r=e.selectedMenuField.getAttribute("formula"),o=(e.get(r,"displayLabel"),
e.manager.report),s={};if(e.count||(e.count=1),s.source={cube:o.cube,measure:r},
s.type="UPDATE_MEASURE",s.properties={name:"",caption:t,aggregation:i,format:a},
!this.hasPropertiesChanged(e,s))return!0;o.modelAnnotations.push(s);
r=o.manager.updateCatalog(!0);if(void 0!==r)return o.modelAnnotations.pop(),
this.rptDlg.noHide=!0,this.showError(r),!1;this.report.refreshReport(),
o.history.add(new cv.ReportState("actionUpdateMeasure",t))}return!0},
cancel:function(){cv.Dialog.prototype.cancel.call(this)}})});define("pentaho/analyzer/report/cv_rptAttributePropertiesDlg",[
"dojo/_base/declare","dojo/on","dojo/query","dojo/_base/lang",
"dojox/collections/Dictionary","dojox/collections/ArrayList","./cv_rptDlg",
"dojo/html","dojo/dom-class","dojo/dom-geometry","dojo/request","dojo/dom",
"dojo/dom-construct","dojox/xml/parser","dijit/registry"],function(e,t,i,r,o,a,s
,l,n,d,c,u,h,p,g){return e("cv.AttributePropertiesDialog",[cv.Dialog],{
constructor:function(e){this.report=e,this.rptDlg=this.report.rptDlg,
this.dlgTemplate="attributePropertiesDlg.html",this.prefix="AP_",
this.helpTopic="CV/Business_User/working_with_filters.html#filters_on_text_fields"
,this.formatText=g.byId("AP_formatText"),
this._widgetCss="responsive dw-sm ds-fill-viewport-width"},destroy:function(){
this.inherited(arguments),this.clear()},clear:function(){},show:function(e,t){
this.attribute={},this.formatText=g.byId("AP_formatText");
var i=cv.api.util._hasInlineModelingPermission()&&!cv.getFieldHelp(
).disableInlineModeling,r=cv.getFieldHelp();if(r.selectedMenuField){
var o=r.selectedMenuField.getAttribute("formula"),a=r.get(o,"displayLabel"),
s=r.get(o,"type"),l=r.get(o,"displayDescription"),s=cvCatalog["fieldTypes_"+s],
n=r.get(o,"formatString"),d=cv.util.substituteParams(
cvCatalog.dlgPropertiesTitle,a),c=(u.byId("dialogTitleText").innerText=d,u.byId(
"dialogTitleText").title=d,this.setTextAndTitle("mdx",o),this.setTextAndTitle(
"description",l||a),this.setTextAndTitle("type",s),cv.getFieldHelp(
).getProperties(o));if(c&&1<c.length){var h="";cv.util.show(
"AP_memberProperties");for(var p=0;p<c.length;++p)0!=p&&(h+=", "),h+=c[p];
this.setTextAndTitle("memberPropertiesDescription",h)}i?(cv.util.hide(
"AP_nameLabel"),cv.util.hide("AP_formatTextLabel"),this.byId("name").value=a,
this.formatText.set("value",n)):(cv.util.hide("AP_name"),cv.util.hide(
"AP_formatContainer"),this.setTextAndTitle("nameLabel",a),this.setTextAndTitle(
"formatTextLabel",n),cv.util.hide("dlgBtnSave"),u.byId("dlgBtnCancel"
).innerText=u.byId("dlgBtnSave").innerText);d=r.getDatabaseInfo(o);
d.dataType&&"string"!=d.dataType.toLowerCase()?(cv.util.show("formatWrapper"),
this.formatText.setDataType(d.dataType.toLowerCase())):n?cv.util.show(
"formatWrapper"):cv.util.hide("formatWrapper")}this.showDialog(),
this.trackFormChange(),this.addKeyUpHandler(this.byId("name"))},
addKeyUpHandler:function(e){var i,r=u.byId("dlgBtnSave"),o=u.byId(
"error-attribute-name"),a=u.byId("error-attribute-spacer"),
s=this.report.okTimeoutInterval;e.onkeyup=function(e){clearInterval(i);
var t=this;i=setTimeout(function(){var e=t.value.toLowerCase(),
e=cv.util.isValidAttributeName(e);!0!==e?(r.disabled=!0,l.set(o,e),
o.classList.remove("hidden"),a.classList.remove("hidden")):(r.disabled=!1,
o.classList.add("hidden"),a.classList.add("hidden"))},s)}},
hasPropertiesChanged:function(e,t){var i=e.selectedMenuField.getAttribute(
"formula"),r=e.get(i,"displayLabel"),e=e.get(i,"formatString");
return r!==t.properties.name||e!==t.properties.formatString},save:function(){
var e=cv.getFieldHelp(),t=e.selectedMenuField.getAttribute("formula"),i=e.get(t)
,r=this.byId("name").value,o=i.getAttribute("level"),a=i.getAttribute(
"hierarchy").replace(/[\[\]]/g,""),i=i.getAttribute("dimension").replace(
/[\[\]]/g,""),s=this.formatText.get("value"),l=(0===a.indexOf(i+".")&&(
a=a.substring(i.length+1)),this.rptDlg.noHide=!1,cv.util.isValidAttributeName(r)
);if(!0!==l)return this.rptDlg.noHide=!0,this.showError(l),!1;if(
e.selectedMenuField){e.get(t,"displayLabel");l=e.manager.report,t={};if(
e.count||(e.count=1),t.source={cube:l.cube},t.type="UPDATE_ATTRIBUTE",
t.properties={name:r,dimension:i,hierarchy:a,level:o,formatString:s},
!this.hasPropertiesChanged(e,t))return!0;l.modelAnnotations.push(t);
i=l.manager.updateCatalog(!0);if(void 0!==i)return l.modelAnnotations.pop(),
this.rptDlg.noHide=!0,this.showError(i),!1;this.report.refreshReport(),
l.history.add(new cv.ReportState("actionUpdateAttribute",r))}return!0},
cancel:function(){cv.Dialog.prototype.cancel.call(this)}})});define("pentaho/analyzer/report/cv_rptFilterMetricDlg",["dojo/on","dojo/query",
"dojo/_base/lang","dojo/html","dojo/dom-class","dojo/dom",
"common-ui/util/_focus","./cv_rptFilterDlg"],(e,t,o,i,r,n,s)=>{
const l="FT_condition_",d=Object.freeze({
GT:cvCatalog.filterConditionOperators_GREATER_THAN,
GTE:cvCatalog.filterConditionOperators_GREATER_THAN_EQUAL,
LT:cvCatalog.filterConditionOperators_LESS_THAN,
LTE:cvCatalog.filterConditionOperators_LESS_THAN_EQUAL,
E:cvCatalog.filterConditionOperators_EQUAL,
NE:cvCatalog.filterConditionOperators_NOT_EQUAL,
B:cvCatalog.filterConditionOperators_BETWEEN,
NN:cvCatalog.filterConditionOperators_IS_NOT_EMPTY});let a;var h;
h=cv.FilterDialog.prototype,a=h.clear,cv.FilterDialog.extend({clear(){a.call(
this),this.selectedItem=null,this.numConditions=0},showMetricFilter(t,i){
this.clear(),this.attributeType="FILTER_METRIC",this.type="FILTER_METRIC",t&&(
0===t.indexOf("[MEASURE:")||"NUMBER"===cv.getFieldHelp().get(t,"type"
)?this.metric=t:this.attribute=t),this._initMetricFilter(i=i||"CONDITIONS"
)&&this.showDialog()},_initMetricFilter(t){if(
this.helpTopic="CV/Business_User/working_with_filters.html#filters_on_number_fields"
,!this.report.reportDoc.getNode("//cv:attribute")
)return this.report.rptDlg.showError("errorNoAttributeInReport",
"CV/Business_User/working_with_filters.html#filters_on_number_fields"),!1;if(
this.type="FILTER_METRIC",this.gem=this.report.getGem("filter_metric"),
this.gem&&(this.attribute&&!this.report.reportDoc.isUsedByMetricFilter(
this.attribute)||this.metric&&!this.report.reportDoc.isUsedByMetricFilter(
this.metric))&&(this.attribute=null,this.metric=null),
this.dlgTemplate="filterMetricDlg.html",!this.load())return alert(this.status),
!1;this.filterProps=this.report.reportDoc.getMetricFilter(),
this.rankCtrl=this.byId("rank"),this._own(e(this.rankCtrl,"click",o.hitch(
cv.util,"onToggleSectionCheckbox")));var i=this.byId("rankMetric"),i=(
this.report.addOptionsForAllMeasures(i),this.filterProps?(
this.attribute=this.filterProps.formula,this.filterProps.rank?(
i.value=this.filterProps.rank.formula,this.byId("rankType"
).value=this.filterProps.rank.type,this.byId("rankCount"
).value=this.filterProps.rank.count):"RANK"!==t&&cv.util.setSectionCollapsed(
"FT_rank")):(this.metric&&(i.value=this.metric),
"RANK"!==t&&cv.util.setSectionCollapsed("FT_rank")),
this.conditionsCtrl=this.byId("conditions"),document.querySelector(
".filterConditionsListWrapper"));if(this._own(e(this.conditionsCtrl,"click",
o.hitch(cv.util,"onToggleSectionCheckbox")),e(this.byId("addCondition"),"click",
o.hitch(this,"_onAddCondition")),e(i,"focusout",o.hitch(this,"_onFocusOut")),e(i
,".filterConditionEdit:click",o.hitch(this,"_onEditCondition")),e(i,
".filterConditionDelete:click",o.hitch(this,"_onRemoveCondition")),e(i,"click",
o.hitch(this,"_onClickConditionsList")),e(i,"#FT_condOp:change",o.hitch(this,
"_setConditionOperands"))),this.filterProps?.conditions){
this.numConditions=this.filterProps.conditions.length;for(
let t=0;t<this.numConditions;t++)this._initCondition(t)
}else!this.filterProps&&"RANK"!==t||cv.util.setSectionCollapsed("FT_conditions")
,this.numConditions=0,this._addCondition();i=this.byId("attribute");
return this.report.addOptionsForAttributes(i),1===i.options.length?(
this.attribute=i.options[0].value,
i.parentNode.innerHTML=cv.util.substituteParams(cvCatalog.filterMetricSubtitle,
i.options[0].innerHTML)):(this.attribute&&(i.value=this.attribute),this._own(e(i
,"change",o.hitch(this,"_selectMetricFilterAttribute")))),
this._selectMetricFilterAttribute(),this.filterProps||(this.filterProps={}),
this.filterProps.type=this.type,this.filterProps.old=this.attribute,
this.defaultFocus=n.byId("RANK"===t?"FT_rank":"FT_conditions"),!0},
_saveMetricFilter(){var t=this.byId("attribute");if(
this.filterProps.formula=t?t.value:this.attribute,this.conditionsCtrl.checked){
if(this.selectedItem&&!this._updateCondition())return!1
}else this.filterProps.conditions=null;if(this.rankCtrl.checked){var t={
formula:this.byId("rankMetric").value,type:this.byId("rankType").value,
count:this.byId("rankCount").value},i=this._validateRank(t);if(i
)return this.displayMsg(cvCatalog[i]),!1;t.count=parseInt(t.count,10),
this.filterProps.rank=t,this.report.setSortOrder(t.formula,
"BOTTOM"===t.type?"ASC":"DESC",!1,!0)}else this.filterProps.rank=null;
return this.filterProps.conditions||this.filterProps.rank||(
this.report.removeFilter("filter_metric_0"),this.filterProps=null),!0},
_initCondition(t){var i=this._createConditionNode(t),
e=this.filterProps.conditions[t];this._loadStaticCondition(t,i,e)},
_createConditionNode(t){var t=this._buildListItemId(t),i=document.createElement(
"tr");return i.id=t,this.byId("conditionsList").appendChild(i),r.add(i,
"filterCondition"),i},_addCondition(){
var t=this.filterProps?.conditions?.length??0,t=(this.numConditions+=1,
this._buildListItemId(t));return this._editCondition(t)},_editCondition(t){var i
,e,o;this.selectedItem!==t&&this._updateCondition()&&(o=this._getListItemIndex(t
),i=n.byId(t)||this._createConditionNode(o),r.add(i,"filterConditionSelected"),
i.innerHTML=cv.util.substituteParams(cvCatalog.filterConditionEdit,d),
e=this.byId("condMetric"),this.report.addOptionsForAllMeasures(e),
e=this.filterProps?.conditions?.[o],this._writeConditionEditProps(e),
this.selectedItem=t,this.report.banner.hide(),null!=(o=s.firstTabbable(i))
)&&o.focus()},_cancelCondition(){var t,i,e,o=this.selectedItem;o&&(
e=this._getListItemIndex(o),t=n.byId(o),null!=(i=this.filterProps?.conditions?.[
e])?(this._loadStaticCondition(e,t,i),null!=(e=s.firstTabbable(t))&&e.focus()
):this._removeCondition(o))},_removeCondition(i){if(1===this.numConditions
)this.displayMsg(cvCatalog.dlgErrFilterLastCondition);else{var e=n.byId(i),
o=this._getListItemIndex(i);this.selectedItem===i&&(this.selectedItem=null,
this.report.banner.hide()),this.filterProps.conditions[o]=null,
cv.util.removeNode(e),--this.numConditions;let t=null;0<o&&(i=n.byId(
this._buildListItemId(o-1)),t=s.lastTabbable(i)),(
t=null==t?this.conditionsCtrl:t).focus()}},_updateCondition(t){if(t||(
t=this.selectedItem)){var i=n.byId(t);if(i){var e=this._readConditionEditProps()
,o=this._validateCondition(e);if(o)return this.displayMsg(cvCatalog[o]),!1;
o=this._getListItemIndex(t);this.filterProps.conditions||(
this.filterProps.conditions=[]),this.filterProps.conditions[o]=e,
this._loadStaticCondition(o,i,e)}}return!0},_writeConditionEditProps(t){
var i=this.byId("condMetric");null!=t?(i.value=t.formula,this.byId("condOp"
).value=t.operator,this.byId("condOp1").value=t.op1,this.byId("condOp2"
).value=t.op2||""):this.metric&&(i.value=this.metric),
this._setConditionOperands()},_readConditionEditProps(){var t=this.byId("condOp"
).value;return{formula:this.byId("condMetric").value,operator:t,op1:this.byId(
"condOp1").value,op2:"BETWEEN"!==t?null:this.byId("condOp2").value}},
_loadStaticCondition(t,i,e){i.innerHTML=cv.util.substituteParams(
cvCatalog.filterConditionStatic,{metric:this.report.getFieldLabel(e.formula),
op:cvCatalog["filterConditionOperators_"+e.operator],op1:e.op1||" ",
op2:e.op2||" ",op2Css:e.op2?" ":"hidden",id:t}),r.remove(i,
"filterConditionSelected"),this.selectedItem=null,this.report.banner.hide()},
_onAddCondition(){this._addCondition()},_onEditCondition(t){t.preventDefault();
t=cv.util.getAncestorByClass(t.target,"filterCondition");this._editCondition(
t.id)},_onRemoveCondition(t){t.preventDefault();t=cv.util.getAncestorByClass(
t.target,"filterCondition");this._removeCondition(t.id)},_onFormKeyDown(t){if(
"Escape"===t.code&&null!=this.selectedItem)return n.byId(this.selectedItem
).contains(t.target)&&this._cancelCondition(),t.stopPropagation(),
void t.preventDefault();return this.inherited(arguments)},_onFocusOut(t){var i;
null!=this.selectedItem&&(i=n.byId(this.selectedItem),null!=(t=t.relatedTarget
)&&i.contains(t)||this._updateCondition())},_onClickConditionsList(t){if(
!t.defaultPrevented){var i=cv.util.getAncestorByClass(t.target,"filterCondition"
);if(i&&i.id!==this.selectedItem&&null==cv.util.getAncestorByClass(t.target,
"filterConditionActions"))return this._editCondition(i.id),!0}},
_selectMetricFilterAttribute(){var t=this.byId("attribute");this.byId(
"rankAttribute").innerHTML=this.report.getFieldLabel(t?t.value:this.attribute)},
_setConditionOperands(){var t=this.byId("condOp").value,i=this.byId("condOp1"),
e=this.byId("condOp2").parentNode;"IS_NOT_EMPTY"===t?(cv.util.hide(i,e),
i.value="",e.value=""):"BETWEEN"===t?cv.util.show(i,e):(cv.util.show(i),
cv.util.hide(e),e.value="")},_validateCondition(t){var i=parseFloat(t.op1),
e=parseFloat(t.op2);
return t.formula&&t.operator?"IS_NOT_EMPTY"===t.operator||cv.util.checkNumber(
t.op1)?"BETWEEN"!==t.operator||cv.util.checkNumber(t.op2)?e<=i?(
this.setInvalidInputField("FT_condOp1"),"dlgErrFilterConditionOp2LTOp1"):null:(
this.setInvalidInputField("FT_condOp2"),"dlgErrFilterConditionNumberExpected"):(
this.setInvalidInputField("FT_condOp1"),"dlgErrFilterConditionNumberExpected"
):"dlgErrFilterConditionRequiredFields"},_validateRank(t){
return cv.util.checkPositiveInteger(t.count
)?t.formula&&t.type?null:"dlgErrFilterRankRequiredFields":(
this.setInvalidInputField("FT_rankCount"),"dlgErrFilterRankNumberExpected")},
_getListItemIndex(t){return parseInt(t.substr(l.length),10)},_buildListItemId(t
){return l+t}})});define("pentaho/analyzer/report/cv_rptDatePickerDlg",["dojo/_base/declare",
"dojo/aspect","dojo/dom","dojo/dom-class","dojo/json","dojo/request","dojo/on",
"common-ui/jquery","./cv_rptDlg"],(e,t,s,i,l,a,r)=>e("cv.DatePickerDialog",[
cv.Dialog],{constructor(e,t){this.report=t,this.dlgTemplate="datePickerDlg.html"
,this.prefix="DP_",this.templateCache=null,this.rangeOp=null,this.parent=e,
this.validatedMember1=null,this.validatedMember2=null,
this.lastValidatedMember=null,this.lastRange1LookupValue=null,
this.lastRange2LookupValue=null,
this._widgetCss="responsive dw-sm ds-fill-viewport-width",
this._dialogId="theDialog2",this._dialogFormId="theDialogForm2",
this._dialogBannerId="dialogMessageBar2",Object.defineProperty(this,"dlgWidget",
{set(e){cv.dlgWidget2=e},get(){return cv.dlgWidget2}})},init(){
this.rangeOp=s.byId("FT_rangeOp").value;let e=this.report.getFieldLabel(
this.parent.attribute)+" is ";
"BETWEEN"===this.rangeOp?e+=cvCatalog.filterConditionOperators_BETWEEN:"AFTER"===this.rangeOp?e+=cvCatalog.dlgAttributeFilterAfter:e+=cvCatalog.dlgAttributeFilterBefore
,e+=" "+cvCatalog.dlgAttributeFilterAndIncludes,this.byId("title").innerHTML=e,
"BETWEEN"===this.rangeOp?(this.byId("range1DateLabel"
).innerHTML=cvCatalog.dlgDatePickerDateBegin+":",this._getDateByMember(1),
this._getDateByMember(2)):(this.byId("range1DateLabel"
).innerHTML=cvCatalog.dlgDatePickerDate+":",cv.util.hide(this.byId("range2")),
this._getDateByMember(1));const a=this,i=(this.lastRange1LookupValue=this.byId(
"range1_lookup").value,this.lastRange2LookupValue=this.byId("range2_lookup"
).value,$(`#${this.prefix}range1_lookup, #${this.prefix}range2_lookup`));i.on(
"focus keyup blur",function(){$(".dijitTooltip").hide();var[e]=$(this),{id:e,
value:t}=e;if(e===this.prefix+"range1_lookup"){if(a.lastRange1LookupValue===t
)return;a.lastRange1LookupValue=t}else if(e===this.prefix+"range2_lookup"){if(
a.lastRange2LookupValue===t)return;a.lastRange2LookupValue=t}
a._dateLookupValidation($(this),i)})},_dateLookupValidation(e,t){let a=!0;
return this.report.banner.hide(),a="BETWEEN"===this.rangeOp?(t.each((e,t)=>{
a=this._isValid($(t),!1)&&a}),a=a&&this._isDateRangeValid()&&a,t.each((e,t)=>{
t=$(t);"true"===t.attr("isValid")&&i.remove(t[0],"invalid")}),a&&!t.hasClass(
"invalid")):(a=this._isValid(e,!0))&&!e.hasClass("invalid"),$("#dlgBtnSave2"
).attr("disabled",!a),a},_showError(e,t){this.displayError(t),i.add(e[0],
"invalid"),e.attr("isValid",!1)},_isValid(e,t){if(e.val(
)===cvCatalog.attributeNullValue)this.lastValidatedMember={
caption:cvCatalog.attributeNullValue,formula:e.attr("formula"),exact:!0},
"1"===e.attr("id").charAt((this.prefix+"range").length
)?this.validatedMember1=this.lastValidatedMember:this.validatedMember2=this.lastValidatedMember;else{
if(""===e.val())return this._showError(e,cvCatalog.dlgDatePickerDateFormatError)
,!1;if(e.val().search("[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])")<0
)return this._showError(e,cvCatalog.dlgDatePickerDateFormatError),!1;
var a=this._lookupByDate(e[0]);if(a)return this._showError(e,a),!1;
this.lastValidatedMember.exact||(this.displayError(cv.util.substituteParams(
cvCatalog.dlgDatePickerNearbyInfo,this.report.getFieldLabel(
this.parent.attribute),e.val(),this.lastValidatedMember.caption,
this.lastValidatedMember.nearbyDate)),e.val(this.lastValidatedMember.nearbyDate)
,e[0
].id===this.prefix+"range1_lookup"?this.lastRange1LookupValue=this.lastValidatedMember.nearbyDate:e[
0].id===this.prefix+"range2_lookup"&&(
this.lastRange2LookupValue=this.lastValidatedMember.nearbyDate))}
return t&&i.remove(e[0],"invalid"),e.attr("isValid",!0),!0},_isDateRangeValid(){
var e,t=$(`#${this.prefix}range1_lookup`),a=$(`#${this.prefix}range2_lookup`);
return t===cvCatalog.attributeNullValue||a===cvCatalog.attributeNullValue||(
e=new Date(t.val()),!(new Date(a.val())<e&&(this._showError(t,
cvCatalog.dlgDatePickerDateRangeError),this._showError(a,
cvCatalog.dlgDatePickerDateRangeError),1)))},save(){let e=s.byId("FT_range1");
var t=cv.util.escapeHtml(this.validatedMember1.caption);
return e.value=this.validatedMember1.formula,
e.value!==this.validatedMember1.formula&&(cv.addOption(e,new Option(t,
this.validatedMember1.formula)),e.value=this.validatedMember1.formula),
"BETWEEN"===this.rangeOp&&(e=s.byId("FT_range2"),t=cv.util.escapeHtml(
this.validatedMember2.caption),cv.addOption(e,new Option(t,
this.validatedMember2.formula)),e.value=this.validatedMember2.formula,
e.value!==this.validatedMember2.formula)&&(cv.addOption(e,new Option(t,
this.validatedMember2.formula)),e.value=this.validatedMember2.formula),
this.dlgWidget.hide(),!0},cancel(){this.dlgWidget.hide()},_getDateByMember(e){
var t,a,i,l,r=this.byId(`range${e}_lookup`),e=s.byId("FT_range"+e)["value"];
-1<e.indexOf("[#null]")?(r.value=cvCatalog.attributeNullValue,r.setAttribute(
"formula",e)):(t=cv.io.ajaxLoad("service/date/getDateByMember",{
catalog:this.report.catalog,cube:this.report.cube,level:this.parent.attribute,
member:e},!0),cv.util.parseAjaxMsg(t)?(a=("0"+((l=new Date).getMonth()+1)
).slice(-2),i=("0"+l.getDate()).slice(-2),l=l.getFullYear()+`-${a}-`+i,
this.displayError(cv.util.substituteParams(
cvCatalog.dlgDatePickerGetDateParseError,this.report.getFieldLabel(
this.parent.attribute),cv.util.parseMDXExpression(e,!0),l)),r.value=l):r.value=t
)},_lookupByDate(e){var t=cv.io.ajaxLoad("service/date/lookupDate",{
catalog:this.report.catalog,cube:this.report.cube,level:this.parent.attribute,
isoDate:e.value},!0),a=cv.util.parseAjaxMsg(t);return a?a.details:(
this.lastValidatedMember=l.parse(t),"1"===e.id.charAt((this.prefix+"range"
).length
)?this.validatedMember1=this.lastValidatedMember:this.validatedMember2=this.lastValidatedMember
,null)},show(){if(!this.templateCache){const t=this;a(
cv.contextPath+"service/templates/"+this.dlgTemplate,{handleAs:"text",
method:"POST",sync:!0}).then(e=>{cv.util.parseAjaxMsg(e)?alert(
"An error occurred loading dialog"):t.templateCache=e},()=>{alert(
"An error occurred loading dialog")})}this._initDialogWidget(this.templateCache)
var e=s.byId("dlgBtnSave2");e&&r(e,"click",this.save.bind(this)),r(s.byId(
"dlgBtnCancel2"),"click",this.cancel.bind(this)),this.init(),
this.dlgWidget.show(),this._centerDialog()}}));define("pentaho/analyzer/report/cv_rptDoc",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dojox/collections/Dictionary","dojox/xml/parser"
,"dojo/_base/array","./cv_rptLinkDlg"],(e,t,r,i,c,l,o)=>{
cv.ReportDocument=function(){this.reportRecord=null,this.status=null,
this.childTags={measures:"measure",columnAttributes:"attribute",
rowAttributes:"attribute",filters:"filter"};var e=cv.analyzerProperties[
"report.mdx.default.total.type"];this.attributes={measure:{showAggregate:""+(
"AGGREGATE"===e),showSum:""+("SUM"===e),showAverage:""+("AVG"===e),
showCount:""+("COUNT"===e),showMin:""+("MIN"===e),showMax:""+("MAX"===e),
measureTypeEnum:"VALUE",sortOrderEnum:"NONE"},attribute:{showSubtotal:"false",
sortOrderEnum:"ASC",wordWrap:"false"},filter:{viewFilterEnum:"NONE"}},
this.reportProps=["name","folder","description","cube","reportTypeEnum","update"
,"updatedBy","created","createdBy","title","subtitle"]},
cv.ReportDocument.prototype={initialize(e){this.reportRecord=cv.parseXML(e),
cv.setDomDefaultNamespace(this.reportRecord),this.status="reportOpenOK"},
getReportNode(){return this.getNode("cv:report")},getStorageNode(){
return this.getNode("cv:commonStorageAttributes")},getXml(){return l.innerXML(
this.reportRecord)},replaceReportNode(e){
this.reportRecord.documentElement.replaceChild(e.cloneNode(!0),
this.getReportNode())},replaceStorageNode(e){
this.reportRecord.documentElement.replaceChild(e.cloneNode(!0),
this.getStorageNode())},getReportProperty(e){let t=null;switch(e){case"catalog":
case"cube":case"reportTypeEnum":t=this.getReportNode().getAttribute(e);break;
case"title":t=this.getReportTitle();break;case"subtitle":
t=this.getReportSubtitle();break;case"name":case"folder":
t=this.getStoragePathNode().getAttribute(e);break;default:t=this.getStorageNode(
).getAttribute(e)}return t},setReportProperty(e,t){switch(e){case"catalog":
this.getReportNode().setAttribute(e,t);break;case"cube":case"reportTypeEnum":
this.getReportNode().setAttribute(e,t);break;case"title":this.setReportTitle(t);
break;case"subtitle":this.setReportSubtitle(t);break;case"name":case"folder":
this.getStoragePathNode().setAttribute(e,t);break;default:this.getStorageNode(
).setAttribute(e,t)}},getReportOptions(){return this.getReportNode().attributes
},getReportOption(e){return this.getReportNode().getAttribute(e)},
setReportOption(e,t){this.getReportNode().setAttribute(e,t)},getStoragePathNode(
){return this.getNode("cv:commonStorageAttributes/cv:path")},getReportTitle(){
var e=this.getNode("cv:report/cv:title");return e?l.textContent(e):null},
setReportTitle(e){let t=this.getNode("cv:report/cv:title");t||(
t=this.reportRecord.createElement("title"),this.getReportNode().appendChild(t)),
cv.textContent(t,e)},getReportSubtitle(){var e=this.getNode(
"cv:report/cv:subtitle");return e?l.textContent(e):null},setReportSubtitle(e){
let t=this.getNode("cv:report/cv:subtitle");t||(
t=this.reportRecord.createElement("subtitle"),this.getReportNode().appendChild(t
)),cv.textContent(t,e)},setChartOption(e,t){this.getChartOptions().setAttribute(
e,t)},getChartOption(e){return this.getChartOptions().getAttribute(e)},
getChartOptions(){return this.getNode("cv:report/cv:chartOptions")},
setPageSetup(e,t){this.getPageSetup().setAttribute(e,t)},getPageSetup(e){
var t=this.getNode("cv:report/cv:pageSetup");return e?.length?t.getAttribute(e
):t},getReplaced(){return this.getNode("cv:report/cv:attributeReplacement")},
setReplaced(e,t){let r=this.getReplaced();if(r){if(!t
)return void cv.util.removeNode(r);l.removeChildren(r)
}else r=this._createXmlNode("attributeReplacement"),this.getReportNode(
).appendChild(r);r.setAttribute("formula",e);for(const o of t){
var i=this._createXmlNode("replacementOption");cv.textContent(i,o),
r.appendChild(i)}},replaceAttribute(e){try{var t=this.getReplaced();if(t){
var r=t.getAttribute("formula");if(r!==e){t.setAttribute("formula",e);for(
const i of t.selectNodes("cv:replacementOption"))if(cv.textContent(i)===e){
cv.textContent(i,r);break}}}}catch(e){console.log(e)}},isNew(){
return!this.getStorageNode().getAttribute("created")},isEmpty(){
var e=this.getReportNode().selectNodes("cv:measures/cv:measure|*/cv:attribute");
return!e||0===e.length},getSortedMetric(){return this.getNode(
"cv:report/cv:measures/cv:measure[@sortOrderEnum!='NONE']")},createNode(e){let t
var r=this._createXmlNode(this.childTags[e.zoneId]);
return e.formula&&r.setAttribute("formula",e.formula),e.metricType&&(
-1<o.indexOf(["PCTOF","RSUM","PCTRSUM","RANK"],e.metricType)?(
t=this._createXmlNode("summaryFacet",{summaryAcrossEnum:e.sumAcross,
useNonVisualTotals:e.sumTotal}),"LABEL"===e.sumAcross&&t.setAttribute(
"breakAttributeFormula",e.sumBreakBy)):"EXPRESSION"===e.metricType?(
t=this._createXmlNode("expression"),cv.textContent(t,e.expression)
):"TREND"===e.metricType&&(t=this._createXmlNode("trendFacet",{
trendTypeEnum:e.trendType,trendDirectionEnum:e.trendDir,amount:e.trendAmount,
trendAttributeFormula:e.trendField})),r.setAttribute("measureTypeEnum",
e.metricType),t)&&r.appendChild(t),e.label&&(t=this._createXmlNode(
"displayLabels"),r.appendChild(t),t.appendChild(this._createXmlNode(
"displayLabel",{label:e.label,locale:e.locale}))),e.gembarId&&r.setAttribute(
"gembarId",e.gembarId),r},getNode(e,t){return(
t??this.reportRecord.documentElement).selectSingleNode(e)},getChildMembers(...r
){let i="";for(let e=0,t=r.length;e<t;++e){var o=r[e];0<e&&(i+=" | "),
i+=`cv:${o}/cv:`+this.childTags[o]}return this.getReportNode().selectNodes(i)},
getTimeAttributes(){var e=this.getReportNode().selectNodes("*/cv:attribute");
let t=null;if(0<e?.length)for(const i of e){var r=i.getAttribute("formula");
cv.getFieldHelp().isTimeAttribute(r)&&(t?t.push(r):t=[r])}return t},
getReportZoneNode(e){return this.reportRecord.documentElement.selectSingleNode(
"cv:report/cv:"+e)},getFirstMetricDependent(e){var t=this.getReportNode(
).selectNodes(
`cv:measures/cv:measure[@measureTypeEnum!='VALUE' and @id!='${e}']`);if(
!t?.length)return null;let r=null;for(const i of t)if(
"EXPRESSION"===i.getAttribute("measureTypeEnum")&&0<=cv.textContent(
i.selectSingleNode("cv:expression")).indexOf(e)||i.getAttribute("formula")===e){
r=i;break}return r},getMetrics(e){e=e?`[@measureTypeEnum="${e}"]`:"";
return this.getReportNode().selectNodes("cv:measures/cv:measure"+e)},
getNextMetricId(){let e=0;for(var t=this.getNode("cv:report/cv:measures"
);this.getNode(`cv:measure[@id="[MEASURE:${e}]"]`,t);)++e;return`[MEASURE:${e}]`
},getNumberFormat(e){let t,r="";return(t="string"==typeof e?this.getNode(
`cv:report/cv:measures/cv:measure[@formula="${e}"]/cv:numberFormat`
):e.selectSingleNode("cv:numberFormat"))&&(e=t.selectSingleNode(
"cv:formatExpression"))&&(r=cv.textContent(e)),t?{formatCategory:t.getAttribute(
"formatCategory"),formatScale:t.getAttribute("formatScale"),formatExpression:r,
formatShortcut:t.getAttribute("formatShortcut"),currencySymbol:t.getAttribute(
"currencySymbol"),measureDisplayUnits:t.getAttribute("measureDisplayUnits")
}:null},setNumberFormat(e,t){if(!(e="string"==typeof e?this.getNode(
`cv:report/cv:measures/cv:measure[@formula="${e}"]`):e))return!1;
let r=e.selectSingleNode("cv:numberFormat"),i=(r||(r=this._createXmlNode(
"numberFormat"),e.appendChild(r),r.setAttribute("formatShortcut","NONE"),
r.setAttribute("formatCategory","Default"),r.setAttribute("formatScale","0"),
r.setAttribute("currencySymbol",cv.analyzerProperties["renderer.currency.symbol"
]),r.setAttribute("measureDisplayUnits","UNITS_0")),
t.formatCategory&&r.setAttribute("formatCategory",t.formatCategory),
t.formatScale&&r.setAttribute("formatScale",t.formatScale),
t.formatShortcut&&r.setAttribute("formatShortcut",t.formatShortcut),
t.currencySymbol&&r.setAttribute("currencySymbol",t.currencySymbol),
t.measureDisplayUnits&&r.setAttribute("measureDisplayUnits",
t.measureDisplayUnits),r.selectSingleNode("cv:formatExpression"));i||(
i=this._createXmlNode("formatExpression"),r.appendChild(i)),
t.formatExpression&&cv.textContent(i,t.formatExpression)},updateDisplayLabel(e,t
,r,i){var o=!t&&!r;let l=null,s=e.selectSingleNode("cv:displayLabels");if(s
)l=s.selectSingleNode(i?`cv:displayLabel[locale='${i}']`:"cv:displayLabel"
);else{if(o)return;s=this._createXmlNode("displayLabels"),e.appendChild(s)}if(!l
){if(o)return;l=this._createXmlNode("displayLabel"),s.appendChild(l)}return o?(
s.removeChild(l),s.selectSingleNode("cv:displayLabel")||e.removeChild(s),null):(
l.setAttribute("label",t||""),l.setAttribute("labelPlural",r||""),
l.setAttribute("locale",i||""),l)},getFilter(e){return this.getNode(
`cv:report/cv:filters/cv:filter[@formula="${e}"]`)},getFilterPredicates(e){
return this.getNode(
`cv:report/cv:filters/cv:filter[@formula="${e}"]/cv:predicates`)},
getFilterConditions(e){return this.getNode(
`cv:report/cv:filters/cv:filter[@formula="${e}"]/cv:conditions`)},getFilters(e){
return e.getNode("cv:report/cv:filters")},getDefaultFiltersAvailable(e){
return this.getFilters(e).getAttribute("defaultFiltersAvailable")},
getFilterReport(e,t){return e.getNode(
`cv:report/cv:filters/cv:filter[@formula="${t}"]`)},getFilterProps(e){var t={
formula:e.getAttribute("formula"),viewFilterEnum:e.getAttribute("viewFilterEnum"
),predicates:null,isDefaultFilter:e.getAttribute("isDefaultFilter"),
isDefaultMetricFilter:e.getAttribute("isDefaultMetricFilter")},e=e.selectNodes(
"cv:predicates/cv:predicate");if(e&&0!==e.length){t.predicates=new c;let r;for(
const d of e){var i,o=d.getAttribute("ordinal"),l={ordinal:parseInt(o,10),
op:d.getAttribute("operatorEnum"),preset:d.getAttribute("preset"),
parameterName:d.getAttribute("parameterName"),op1:d.getAttribute("op1"),
op2:d.getAttribute("op2")};if("CONTAIN"===l.op||"NOT_CONTAIN"===l.op){
var s=d.selectNodes("cv:containsExpression");l.exp=[];for(let e=0,
t=s.length;e<t;++e)l.exp.push(cv.textContent(s[e]))}else{var a=d.selectNodes(
"cv:member");l.members=[];for(let e=0,t=a.length;e<t;++e){var n=a[e
].getAttribute("formula");n?l.members.push({formula:n,caption:a[e].getAttribute(
"caption")}):(l.members.push(parseInt(a[e].getAttribute("pos"),10)),
0<e?r+=","+a[e].getAttribute("pos"):r=a[e].getAttribute("pos"))}r&&(l.preset=r),
r=null}t.predicates.contains(o)?t.predicates.item(o).push(l):((i=[]).push(l),
t.predicates.add(o,i))}}return t},removeFilterPredicate(e,t){
var r=this.getFilterProps(e);if(!r)return e;r.predicates.remove(t);
e=this.updateFilter(r);return this.updateIsDefaultFilter(r.formula,!1,null),
e&&e.selectSingleNode("cv:predicates/cv:predicate")?e:null},
updateIsDefaultFilter(e,t,r){e=this.getFilter(e);e&&(null!=t&&e.setAttribute(
"isDefaultFilter",""+t),null!=r)&&e.setAttribute("isDefaultMetricFilter",""+r)},
updateFilter(e,t){if(!e.conditions&&!e.rank&&!e.predicates)return null;
let i=null;var r,o,l=this.getReportZoneNode("filters");if(
"FILTER_METRIC"===e.type?(e.old&&(i=this.getFilter(e.old))&&((r=this.getNode(
"cv:conditions",i))&&i.removeChild(r),(r=this.getNode("cv:topBottom",i)
)&&i.removeChild(r),e.old!==e.formula)&&0===i.childNodes.length&&l.removeChild(i
),e.old&&e.old===e.formula||(i=this.getFilter(e.formula))):(i=this.getFilter(
e.formula))&&cv.util.removeNode(this.getNode("cv:predicates",i)),i||(
i=this._createXmlNode("filter",{formula:e.formula,viewFilterEnum:"MULTIPLE"}),
this.getReportZoneNode("filters").appendChild(i)),void 0!==t&&i.setAttribute(
"forceAnd",String(t)),e.conditions){var s=this._createXmlNode("conditions");for(
const g of e.conditions)if(g){var a=this._createXmlNode("condition");for(
const v in g)g[v]&&a.setAttribute(v,g[v]);s.appendChild(a)}i.appendChild(s)}if(
e.rank){var n=this._createXmlNode("topBottom");for(const N in e.rank)e.rank[N
]&&n.setAttribute(N,e.rank[N]);i.appendChild(n)}if(0<e.predicates?.getKeyList(
)?.length){let t=[];for(const f of e.predicates.getKeyList()){var d=[],
c=e.predicates.item(f);if(0<c.length){var u=this.getOrderKey(c);if(0<t.length){
let e=t.length-1;for(;0<=e&&this.getOrderKey(t[e])>u;e--)d.push(t.pop());t.push(
c),0<d.length&&(t=t.concat(d.reverse()))}else t.push(c)}}let r=this.getNode(
"cv:predicates",i);r=r||this._createXmlNode("predicates");for(
let e=0;e<t.length;e++)if(o=t[e])for(const b of o)if(b){
var p=this._createXmlNode("predicate",{ordinal:e+1,operatorEnum:b.op});if(
b.preset){b.members=[];for(const A of b.preset.split(","))b.members.push(
parseInt(A,10))}for(const C of b.members??[]){var m=this._createXmlNode("member"
);cv.util.checkNumber(C)?m.setAttribute("pos",C):(m.setAttribute("pos","0"),
m.setAttribute("formula",C.formula),m.setAttribute("caption",C.caption)),
p.appendChild(m)}if(b.exp){for(const E of b.exp){var h=this._createXmlNode(
"containsExpression");h.appendChild(this.reportRecord.createTextNode(E)),
p.appendChild(h)}b.containsRegExp&&p.setAttribute("containsRegExp","true")}
b.parameterName&&p.setAttribute("parameterName",b.parameterName),
b.op1&&p.setAttribute("op1",b.op1),b.op2&&p.setAttribute("op2",b.op2),
r.appendChild(p)}i.appendChild(r)}return this.removeEmptyFilter(i)?null:(
e.viewFilterEnum&&i.setAttribute("viewFilterEnum",e.viewFilterEnum),i)},
getOrderKey(e){var t,r=new c;r.add("EQUAL",2),r.add("TIME_YAGO",2),r.add(
"TIME_RANGE_PREV",2),r.add("TIME_RANGE_NEXT",2),r.add("TIME_AGO",2),r.add(
"TIME_AHEAD",2),r.add("CONTAIN",3),r.add("BETWEEN",4),r.add("AFTER",5),r.add(
"BEFORE",6),r.add("NULL",7),r.add("NUMERIC_BETWEEN",8),r.add(
"NUMERIC_GREATER_THAN",8),r.add("NUMERIC_GREATER_THAN_EQUAL",8),r.add(
"NUMERIC_LESS_THAN",8),r.add("NUMERIC_LESS_THAN_EQUAL",8),r.add("NOT_EQUAL",9),
r.add("NOT_CONTAIN",10),r.add("NOT_NULL",11);let i;return i="EQUAL"===e[0].op?(
t=e[0].members,e[0].preset||cv.util.checkNumber(t[0])?2:1):r.item(e[0].op)},
getMetricFilter(){let e=null,t=null;var r=this.getNode(
"cv:report/cv:filters/cv:filter/cv:topBottom");if(r?(e=r.parentNode,
t=this.getNode("cv:conditions",e)):(t=this.getNode(
"cv:report/cv:filters/cv:filter/cv:conditions"))&&(e=t.parentNode),!e
)return null;var i={node:e,formula:e.getAttribute("formula"),conditions:null,
rank:null,isDefaultFilter:e.getAttribute("isDefaultFilter"),
isDefaultMetricFilter:e.getAttribute("isDefaultMetricFilter")};if(r){i.rank={};
for(const s of r.attributes)i.rank[s.name]=s.value}if(t){
var o=t.getElementsByTagName("condition");i.conditions=new Array(o.length);for(
let e=0;e<o.length;++e){var l=o[e]["attributes"];i.conditions[e]={};for(
const a of l)i.conditions[e][a.name]=a.value}}return i},getMetricFilterNode(){
var e=this.getNode(
"cv:report/cv:filters/cv:filter/cv:conditions | cv:report/cv:filters/cv:filter/cv:topBottom"
);return e?e.parentNode:null},isDefaultFilter(e,t){if(t){t=this.getMetricFilter(
);if(t)return"true"===t.isDefaultMetricFilter}else{t=this.getFilter(e);if(t
)return"true"===this.getFilterProps(t).isDefaultFilter}return!1},
isUsedByMetricFilter(e,t){var r=this.getMetricFilter();if(r){if(r.formula===e
)return!t||"RANK"===t&&r.rank||"CONDITIONS"===t&&r.conditions?r.node:null;if(
r.rank&&r.rank.formula===e&&(!t||"RANK"===t))return r.node;if(r.conditions&&(
!t||"CONDITIONS"===t))for(const i of r.conditions)if(i.formula===e)return r.node
}return null},removeFromMetricFilter(t){var r=this.isUsedByMetricFilter(t);if(!r
)return!1;var i=this.getNode("cv:conditions",r),e=this.getNode("cv:topBottom",r)
if(r.getAttribute("formula")===t)i&&r.removeChild(i),e&&r.removeChild(e);else{
if(i){var o=i.getElementsByTagName("condition");let e=o.length;for(const l of o
)l.getAttribute("formula")===t&&(i.removeChild(l),--e);0===e&&r.removeChild(i)}
e?.getAttribute("formula")===t&&r.removeChild(e)}return this.removeEmptyFilter(r
),!0},removeEmptyFilter(e){return!(e&&e.selectSingleNode(
"cv:conditions|cv:topBottom|cv:predicates/cv:predicate")||(cv.util.removeNode(e)
,0))},updateCalculateSubtotalsUsingFormula(e,t){return t.setAttribute(
"calculateSubtotalsUsingFormula",e)},addMemberProperty(e,t){
t=this._createXmlNode("property",{name:t});e.appendChild(t)},addLink(e,t,r){
var i=this._createXmlNode("link",t);if(r)for(const l in r){
var o=this._createXmlNode("linkParam",{name:l,value:r[l]});i.appendChild(o)}
e.appendChild(i)},addSelectionFilters(e,t){
"INCLUDE"===t&&this.removeSelectionFilters();let r=this.getNode(
"cv:report/cv:selectionFilters");r||(r=this._createXmlNode("selectionFilters"),
this.getReportNode().appendChild(r));for(const i of e)i.setAttribute("op",t),
r.appendChild(i)},addSelectionFilter(e){let t=this.getNode(
"cv:report/cv:selectionFilters");t||(t=this._createXmlNode("selectionFilters"),
this.getReportNode().appendChild(t));var r=this._createXmlNode("selectionItem");
r.setAttribute("op",e.op);for(const o of e.members){var i=this._createXmlNode(
"selectionMember");i.setAttribute("formula",o.formula),i.setAttribute("member",
o.member),r.appendChild(i)}t.appendChild(r)},getSelectionFilters(){
return this.getReportNode().selectNodes("cv:selectionFilters/cv:selectionItem")
},getSelectionFilterProps(e){var t={op:e.getAttribute("op"),members:[]},
e=e.selectNodes("cv:selectionMember");if(e&&0!==e.length)for(const r of e
)t.members.push({formula:r.getAttribute("formula"),member:r.getAttribute(
"member")});return t},removeSelectionFilters(){var e=this.getNode(
"cv:report/cv:selectionFilters");e&&cv.util.removeNode(e)},
replaceSelectionItems(e){var t=this.getNode("cv:report/cv:selectionItems");
t&&cv.util.removeNode(t),e&&this.getReportNode().appendChild(e)},
getSelectionItems(){return this.getReportNode().selectNodes(
"cv:selectionItems/cv:selectionItem")},getDrillColumns(){
return this.getReportNode().selectNodes("cv:drillColumns/cv:drillColumn")},
replaceDrillColumns(t){var r=this.getNode("cv:report/cv:drillColumns");
r&&cv.util.removeNode(r),r=this._createXmlNode("drillColumns");for(const i in t
){let e=null;e=!0===t[i]?this._createXmlNode("drillColumn"):this._createXmlNode(
"drillColumn",{hidden:!0}),cv.textContent(e,i),r.appendChild(e)}
this.getReportNode().appendChild(r)},getPluginDataJSON(){
return this._getXmlTextContentAsSanitizedJSON(this.getUIAttributes(
).selectSingleNode("cv:pluginData"))},setPluginDataJSON(e){
var t=this._getOrCreateXmlCvChildElement(this.getUIAttributes(),"pluginData");
this._setXmlCDATAContent(t,e||"")},getPluginViewDataJSON(){
return this._getXmlTextContentAsSanitizedJSON(this.getUIAttributes(
).selectSingleNode("cv:pluginViewData"))},setPluginViewDataJSON(e){
var t=this._getOrCreateXmlCvChildElement(this.getUIAttributes(),"pluginViewData"
);this._setXmlCDATAContent(t,e||"")},getUIAttributes(){
let e=this.reportRecord.documentElement.selectSingleNode("cv:uiAttributes");
var t;return e||(e=this._createXmlNode("uiAttributes",{showFieldList:"true",
showFieldLayout:"true",showFilterPanel:"false"}),
this.reportRecord.documentElement.appendChild(e)),e.selectSingleNode(
"cv:rowFieldWidths")||e.appendChild(this._createXmlNode("rowFieldWidths")),
e.selectSingleNode("cv:columnDataFieldWidths")||e.appendChild(
this._createXmlNode("columnDataFieldWidths")),e.selectSingleNode("cv:pluginData"
)||(t=this._createXmlNode("pluginData"),cv.textContent(t,"[]"),e.appendChild(t))
,e},_createXmlNode(e,t){var r=cv.createNode(this.reportRecord,e);let i;
var o=this.attributes[e];for(i in o)r.setAttribute(i,o[i]);for(i in t
)r.setAttribute(i,t[i]);return r},_getOrCreateXmlCvChildElement(e,t){
let r=e.selectSingleNode("cv:"+t);return null==r&&(r=this._createXmlNode(t),
e.appendChild(r)),r},_removeXmlChildNodes(e){for(;null!=e.firstChild;
)e.removeChild(e.firstChild)},_setXmlCDATAContent(e,t){
this._removeXmlChildNodes(e);t=this.reportRecord.createCDATASection(t);
e.appendChild(t)},_getXmlTextContentAsSanitizedJSON(e){
return e&&cv.util.sanitizeJSONString(l.textContent(e))||""}}});define("pentaho/analyzer/report/cv_rptDnd",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dijit/_base/popup","dojo/dnd/Source",
"dojo/dnd/Target","dojo/topic","dojo/dom-construct","dojo/dom-geometry",
"dojo/dnd/Manager","dojo/dom-class","dojo/_base/event","dojo/aspect",
"./cv_rptDoc"],(t,e,i,o,r,s,n,h,d,c,a,l,u,p)=>{const v=a.manager(),g={start:!1,
stop:!0,drop:!1};t("cv.ReportDropTarget",[n],{copyOnly:!0,selfAccept:!0,
constructor(t){this.node=t,this.curItem=null,this.dropIndicator=d.create("div",{
class:"dndDropIndicator"}),e(this.dropIndicator,"mouseover",o.hitch(this,
"_redirectMouseOver")),e(this.dropIndicator,"mouseup",o.hitch(this,
"_redirectMouseUp")),h.subscribe("/dnd/start",o.hitch(this,"dndStart")),
this._drop=this.dropIndicator,
this.dropIndicator.parentNode||document.body.appendChild(this.dropIndicator),
cv.util.hide(this.dropIndicator)},onDndStart(t){var e,i;
cv.api.event.isEventDisabled("dragAndDrop")?this._clearDropIndicator():(
g.start=!0,g.stop=!1,this.inherited(arguments),e=c.position(t.node),
i=c.position(this.node),
e.x<=i.x+i.w&&e.x>=i.x&&e.y<i.y+i.h&&e.y>i.y&&this.fireSyntheticOverEvent(),
this.report.emit("drag",t.anchor.getAttribute("formula")))},_createMouseEvent(t,
e){let i={view:window,bubbles:!0,cancelable:!0};return null!=e&&(i={...i,
screenX:e.screenX,screenY:e.screenY,clientX:e.clientX,clientY:e.clientY,
ctrlKey:e.ctrlKey,shiftKey:e.shiftKey,altKey:e.altKey,metaKey:e.metaKey}),
new MouseEvent(t,i)},fireSyntheticOverEvent(){var t=this._createMouseEvent(
"mouseover");this.node.dispatchEvent(t)},_redirectMouseOver(t){
this.fireSyntheticOverEvent(),this._getZoneIdForPivot(v.nodes[0]);var e,
i=this._getNodeUnderMouse(t),o=(this.position=this._getNodeUnderMouse(),
this.childBoxes[this.zoneId]);-1<i&&(e=this._createMouseEvent("mouseover",t),
this.node.dispatchEvent(e),o[i].node.dispatchEvent(e),e=this._createMouseEvent(
"mousemove",t),this.node.dispatchEvent(e),o[i].node.dispatchEvent(e))},
_redirectMouseUp(t){this._getZoneIdForPivot(v.nodes[0]);
var e=this._getNodeUnderMouse(t),i=(this.position=this._getNodeUnderMouse(),
this.childBoxes[this.zoneId]);-1<e&&(t=this._createMouseEvent("mouseup",t),i[e
].node.dispatchEvent(t))},onMouseOut(t){this.dropIndicator&&cv.util.overElement(
this.dropIndicator,t)?u.stop(t):this.inherited(arguments)},isReportFormatPivot(
){return"PIVOT"===this.reportFormat},init(t){this.reportFormat=t,
this.isReportFormatPivot()?(this.zones={measures:this.report.byClass(
"ZONE_measures"),rowAttributes:this.report.byClass("ZONE_rowAttributes"),
columnAttributes:this.report.byClass("ZONE_columnAttributes")},
0===this.zones.rowAttributes?.getElementsByTagName("TD")?.length&&(
this.zones.rowAttributes=this.report.byClass("pivotTableRowLabelHeaderContainer"
)),0===this.zones.columnAttributes?.getElementsByTagName("TR")?.length&&(
this.zones.columnAttributes=this.report.byClass("pivotTableColumnHeaderSection")
)):(this.zones=null,this.childBoxes=[],this.zoneId=null),
null==this.__dndCancelHandle&&(this.__dndCancelHandle=h.subscribe("/dnd/cancel",
o.hitch(this,"onDraggingOut")),h.subscribe("/dnd/drop",o.hitch(this,
"onDraggingOut")))},dndCancel(){this.onDraggingOut()},checkAcceptance(){return!(
this.report.isResizing||!this.report.history.isStateRefreshed()
)&&this.inherited(arguments)},accepted:!1,dndStart(){this.childBoxes=null,
this.accepted=this.checkAcceptance(v.source,v.nodes)},onMouseOver(){
v.source&&null==this.childBoxes&&this.calculateBoxes(),this.inherited(arguments)
},calculateBoxes(t){if(!this.isReportFormatPivot())return!0;if(
!this.report.isResizing){this.childBoxes={measures:[],rowAttributes:[],
columnAttributes:[]};let i,
o=this.zones.measures?this.zones.measures.getElementsByTagName("TD"):null;
var r=this.report.byClass("pivotTable");if(r){var s,n=c.position(r,!0);
n.x=n.y+c.position(r).y;let t=o?o.length:0;for(20<t&&(t=20),i=0;i<t;++i
)"measure"===o[i].getAttribute("type")&&(s=c.position(o[i],!0),
this.childBoxes.measures.push({top:n.y,bottom:n.x,left:s.x,right:s.x+c.position(
o[i]).w,node:o[i]}));
o=this.zones.rowAttributes?this.zones.rowAttributes.getElementsByTagName("TD"
):null;let e=null;for(i=0;i<o?.length;++i){var h=c.position(o[i],!0);o[i
].getAttribute("formula")===e?this.childBoxes.rowAttributes[
this.childBoxes.rowAttributes.length-1].right=h.x+c.position(o[i]
).w:this.childBoxes.rowAttributes.push({top:n.y,bottom:n.x,left:h.x,
right:h.x+c.position(o[i]).w,node:o[i]}),e=o[i].getAttribute("formula")}for(
o=this.zones.columnAttributes?this.zones.columnAttributes.getElementsByTagName(
"TR"):null,e=null,i=0;i<o?.length;++i){var d=o[i].firstChild;if(
!d||"attribute"!==d.getAttribute("type")&&"prop"!==d.getAttribute("type"))break;
var a=c.position(o[i],!0);d.getAttribute("formula"
)===e?this.childBoxes.columnAttributes[this.childBoxes.columnAttributes.length-1
].bottom=a.y+a.h:this.childBoxes.columnAttributes.push({top:a.y,bottom:a.y+a.h,
left:a.x,right:a.x+a.w,node:d}),e=d.getAttribute("formula")}}
return t||cv.util.show(this.dropIndicator),!0}this.onDraggingOut(),
cv.util.stopDrag()},onMouseMove(t){var e;this.lastDragEvent=t,
v.nodes.length<1||!this.accepted||this.isReportFormatPivot()&&(
this.report.isResizing?(this.onDraggingOut(),cv.util.stopDrag()):(
null==this.childBoxes&&this.calculateBoxes(t),e=v.nodes[0].getAttribute("type"),
this._showDropIndicator(t,e)))},_showDropIndicator(t,e){this._setZoneIdForPivot(
e),this.position=this._getNodeUnderMouse();e=this.childBoxes[this.zoneId];
let i=!0;this.position<0?e.length&&(i=cv.util.gravity(e[0].node,t)&this.gravity
):i=cv.util.gravity(e[this.position].node,t)&this.gravity,
this.isReportFormatPivot()&&cv.util.show(this.dropIndicator),
this.placeIndicator(t,v.nodes,this.position,i)},_clearDropIndicator(){
this.isReportFormatPivot()&&this.dropIndicator&&cv.util.hide(this.dropIndicator)
,this.hoverMetric&&(l.remove(this.hoverMetric,"metricHover"),
this.hoverMetric=null)},onDraggingOut(){this._clearDropIndicator()},onMouseUp(){
this.inherited(arguments),g.start&&this.onDrop(v.source,v.nodes,v.copy)},onDrop(
t,e){if(g.start){g.start=!1,g.stop=!0;try{var i,o,r,s;this.onDraggingOut(),
null!=t&&(i=e[0],o=cv.util.getAttribute(i,"formula"),0!==(r=t.getItem(i.id).type
).length)&&(s=r[0],this._onDrop(o,s,i))}catch(t){alert(t)}}},_onDrop(t,e,i){if(
!this.isReportFormatPivot()
)return e===cvConst.dndTypes.gemFromFieldList&&this.report.appendGem(t);let o,r,
s,n,h=!0;var d=cv.getFieldHelp().isAttribute(t)?"attribute":"measure";
this._setZoneIdForPivot(d);let a;try{this.position=this._getNodeUnderMouse(),
a=this.childBoxes[this.zoneId]}catch(c){return!1}if(!a)return!1;
var c=this.lastDragEvent;if(this.position<0?a.length?cv.util.gravity(a[0].node,c
)&this.gravity?(o=this.report.getGemFromDomNode(a[0].node))&&(r=o,s="before"):(
o=this.report.getGemFromDomNode(a[a.length-1].node))&&(r=o,s="after"):(
r=this.zoneId,s="append"):(d=a[this.position]["node"],(
o=this.report.getGemFromDomNode(d))&&(r=o,s=cv.util.gravity(d,c
)&this.gravity?"before":"after")),!s)return!1;if(
e===cvConst.dndTypes.gemFromFieldList){if(!(h=(h=(
h=this.report.checkDuplicateGem(t))&&this.report.checkGemHierarchy(this.zoneId,t
,this.report.getFieldLabel(t)))&&this.report.checkColumnSelectionFilters(
this.zoneId)))return!1;n=this.report.createGem({zoneId:this.zoneId,formula:t}),
this.curItem=n,this.actionStr=n.getHistoryActionCode("Add")}else{if(
n=this.report.getGemFromDomNode(i),!(h=this.report.checkGemHierarchy(this.zoneId
,t,this.report.getFieldLabel(i),{refId:"append"===s?r:r.getId(),pos:s}))
)return!0;if(!this.report.checkColumnSelectionFilters(this.zoneId))return!1;
n.setZone(o?o.zone:r),this.curItem=n,this.actionStr=n.getHistoryActionCode(
"Move")}return h=this.insert(r,s),this.curItem=null,this.report.emit("drop",t,
this.declaredClass.replace("cv.","")),h},_getNodeUnderMouse(){
var e=this.childBoxes[this.zoneId];for(let t=0;t<e?.length;++t){var i=e[t];if(
this.lastDragEvent.clientX>=i.left&&this.lastDragEvent.clientX<=i.right&&this.lastDragEvent.clientY>=i.top&&this.lastDragEvent.clientY<=i.bottom
)return t}return-1},_getZoneIdForPivot(t){!this.isReportFormatPivot()&&t&&(
t=t.getAttribute("type"),this._setZoneIdForPivot(t))},_setZoneIdForPivot(t){
this.isReportFormatPivot()&&(this.gravity=cv.util.gravity.WEST,
"measure"===t?this.zoneId="measures":(
!this.zones.rowAttributes||!cv.util.overElement(this.zones.rowAttributes,
this.lastDragEvent))&&this.zones.columnAttributes&&cv.util.overElement(
this.zones.columnAttributes,this.lastDragEvent)?(this.zoneId="columnAttributes",
this.gravity=cv.util.gravity.NORTH):this.zoneId="rowAttributes")},
placeIndicator(t,e,i,o){if(this.zoneId){var r=this.dropIndicator["style"],
s=this.childBoxes[this.zoneId],n=s.length;let e=this.zones[this.zoneId];if(
e=e||this.node,this.gravity===cv.util.gravity.NORTH){let t;
var h=c.getContentBox(this.node).w;t=i<0?n?o?s[0].top:s[n-1].bottom:c.position(e
,!0).y:o?s[i].top:s[i].bottom,r.width=h+15+"px",r.height="28px",
r.left=c.position(this.node,!0).x-14+"px",r.top=t-14+"px",r.position="absolute",
r.zIndex=2e3,
this.dropIndicator.innerHTML=`<div class="dnd-indicator-horizontal-left"></div><div class="dnd-indicator-horizontal-line" style="width:${h-18}px;"></div><div class="dnd-indicator-horizontal-right"></div>`
}else{let t;h=c.getContentBox(this.node).h;"measures"===this.zoneId&&n&&((
i<0||n<=i)&&(i=o?0:n-1),this.hoverMetric&&this.hoverMetric!==s[i
].node&&l.remove(this.hoverMetric,"metricHover"),this.hoverMetric=s[i].node,
l.add(this.hoverMetric,"metricHover")),t=i<0?n?o?s[0].left:s[n-1].right:(
"measures"===this.zoneId&&this.zones.columnAttributes&&(
e=this.zones.columnAttributes),c.position(e,!0).x):o?s[i].left:s[i].right,
r.left=t-14+"px",r.height=h+10+"px",r.width="28px",r.position="absolute",
r.zIndex=2e3,r.top=c.position(this.node,!0).y-7+"px",
this.dropIndicator.innerHTML=`<div class="dnd-indicator-vertical-top"></div><div class="dnd-indicator-vertical-line" style="height:${h-22}px;"></div><div class="dnd-indicator-vertical-bottom"></div>`
}}},insert(t,e){return t!==this.curItem&&this.report.insertGem(
this.curItem.getId(),"string"==typeof t?t:t.getId(),e,!1,this.actionStr)}}),t(
"cv.FilterPaneDropTarget",[n],{constructor(t){this.curItem=null,
this.filterPane=t,this.autoSync=!0,p.after(this,"onDrop",o.hitch(this,
"afterDrop"))},onDraggingOver(){if(!this.report.isResizing&&!(v.nodes.length<1
)&&this.checkAcceptance(v.source,v.nodes))return this._showDropIndicator(),
this.inherited(arguments)},onDragMove(){},onDraggingOut(){
return this._clearDropIndicator(),this.inherited(arguments)},onDrop(t){[
this.curItem]=v.nodes,this._clearDropIndicator(),this.report.emitDropEvent(
t.anchor.getAttribute("formula"),this.declaredClass.replace("cv.",""))},
_showDropIndicator(){cv.util.setDivActive(this.filterPane,!0)},
_clearDropIndicator(){cv.util.setDivActive(this.filterPane,!1)},
createDropIndicator(){},afterDrop(){let t;this.curItem&&(
t=this.curItem.getAttribute("formula")),this._afterDrop(t)},_afterDrop(t){var e,
i,o,r;t&&({banner:e,reportDoc:i,filterDlg:o}=this.report,
r="NUMBER"===cv.getFieldHelp().get(t,"type")||"string"==typeof t&&!t.indexOf(
"[MEASURE:"),i.isDefaultFilter(t,r)&&(
e.fixedMessage=cvCatalog.bannerEditDefaultFilter),o.show(t)),this.curItem=null},
insert(){return!0}}),t("cv.TrashAreaDropTarget",[n],{constructor(t){this.node=t,
l.contains(this.node,"trashcan")&&(p.after(v,"onMouseMove",o.hitch(this,
"_onMouseMove"),!0),p.after(v,"onMouseUp",o.hitch(this,"_onMouseUp"),!0))},
onDraggingOver(){if(!this.report.isResizing&&!(v.nodes.length<1
)&&this.checkAcceptance(v.source,v.nodes))return this.childBoxes=[],l.add(
this.node,"trashActive"),!0},onDragMove(){},onDraggingOut(){return l.remove(
this.node,"trashActive"),!0},createDropIndicator(){},onDrop(t){var e=v.nodes[0][
"id"];return 0===e.indexOf("filter_")?this.report.removeFilter(e
):this.report.removeCurrentGem(v.nodes[0]),l.remove(this.node,"trashActive"),
this.node.focus(),this.report.emitDropEvent(t.anchor.getAttribute("formula"),
this.declaredClass.replace("cv.","")),!0},_onMouseMove(){
this.report.isResizing||cv.api.event.isEventDisabled("dragAndDrop")||(r.close(),
v.nodes.length<1)||!this.checkAcceptance(v.source,v.nodes)||cv.util.show(
this.node)},_onMouseUp(){cv.util.isHidden(this.node)||cv.util.hide(this.node)}})
});define("pentaho/analyzer/report/cv_rptFieldHelp",["dojo/_base/declare","dojo/on"
,"dojo/query","dojo/_base/lang","dojox/xml/parser","dijit/_base/popup",
"dojo/dnd/Source","dojo/_base/array","dojo/html","dijit/registry",
"dojo/dom-class","dojo/dom-style","dojo/regexp","dojo/_base/event","dojo/dom",
"dojo/dom-geometry","common-ui/util/_focus","./cv_rptConst","./cv_rptDnd",
"common-ui/jquery"],(e,s,t,F,i,r,l,d,n,o,b,M,a,h,u,c,p)=>e("cv.FieldHelp",null,{
constructor(e,t,i){this.doc=cv.parseXML(e),cv.setDomDefaultNamespace(this.doc),
this.manager=t,this.fieldListItems=null,this.fieldListTree=null,
this.fieldListNodes=null,this.groups=null,this.selectedField=null,
this.selectedMenuField=null,this.searchField=null,this.viewOptions={
CMDVIEWCATEGORY:"businessGroup",CMDVIEWNAME:"displayLabel",CMDVIEWTYPE:"type",
CMDVIEWSCHEMA:"schema"},this.showHiddenFields=!1,
this.currentView=cv.prefs.fieldListView,this.handles=[],this.isDrill=i,
this.drillFields={},this.groupIsOpen=!cv.analyzerProperties[
"report.field.list.collapse"],this.disableInlineModeling=!1,u.byId(
"disableInlineModeling")&&(this.disableInlineModeling="true"===u.byId(
"disableInlineModeling").value)},_on(e,t,i){return s(e,t,i)},destroy(){if(
this.fieldListItems=null,this.fieldListTree){if(this.fieldListNodes)for(let e=0,
t=this.fieldListNodes.length;e<t;++e)this.fieldListNodes[e].dndObj&&(
this.fieldListNodes[e].dndObj=null);d.forEach(this.handles,e=>{e.remove()}),
this.doc=null,this.fieldListTree=null,this.fieldListNodes=null,this.groups=null,
this.selectedField=null,this.selectedMenuField=null,this.searchField=null}},
_getFieldListItems(){var e=[];for(
const t of this.doc.documentElement.selectNodes(
"cv:attributeHelp|cv:measureHelp"))this.isDrill&&"true"===t.getAttribute(
"calculated")||e.push(t);return e},_getFieldListItemCount(){return(
cv.api.util._hasInlineModelingPermission(
)&&!this.disableInlineModeling?this.fieldListItems:this.fieldListItems.filter(
e=>!this.isHidden(e.getAttribute("formula")))).length},byId(e){
return this.isDrill?u.byId(e+"Drill"):u.byId(e)},init(e){if(
this.fieldListItems=this._getFieldListItems(),
this.fieldCount=this.fieldListItems.length,this.isDrill){var t={...e};if(!(
0<Object.keys(t).length))for(const i of this.fieldListItems)t[i.getAttribute(
"formula")]=!this.isHidden(i);this.drillFields=t}this.fieldListTree=this.byId(
"fieldListTree"),this.fieldListTree&&(this.fieldListTreeContent=this.byId(
"fieldListTreeContent"),this.searchField=this.byId("searchField"),
this.searchField.value="",this.clearSearchField=this.byId("clearSearchField"),
cv.util.getDojoWidget("fieldViewMenu"),this.sortFields(cv.prefs.fieldListView),
this.handles.push(this._on(this.searchField,"keyup",F.hitch(this,"searchFields")
)),this.handles.push(this._on(this.clearSearchField,"click",F.hitch(this,
"onClearSearch"))),this.isDrill||(this.byId("fieldCount"
).innerHTML=this._getFieldListItemCount(),this.handles.push(this._on(
this.fieldListTree,"mouseover",F.hitch(this,"onMouseOver"))),this.handles.push(
this._on(this.fieldListTree,"mouseout",F.hitch(this,"onMouseOut"))),
this.handles.push(this._on(this.fieldListTree,"mousedown",F.hitch(this,
"onMouseDown"))),this.handles.push(this._on(this.fieldListTree,"click",F.hitch(
this,"onMouseDown"))),this.handles.push(this._on(this.fieldListTree,"dblclick",
F.hitch(this,"onDblClick"))),this.handles.push(this._on(this.fieldListTree,
"contextmenu",F.hitch(this,"onContextMenu"))),this.handles.push(this._on(
this.fieldListTree,"keydown",F.hitch(this,"onKeyDownFieldListTree")))),
this.handles.push(this._on(this.byId("viewFieldOptions"),"click",F.hitch(this,
"onViewFieldOptions"))),this.handles.push(this._on(this.byId("viewFieldOptions")
,"keypress",F.hitch(this,"onViewFieldOptionsAccessibility"))))},get(e,t,i){
e=this._getNode(e);return e&&t?(t=this._getAttribute(e,t)
)&&i?cv.util.escapeHtml(t):t:e},_getNode(e){
return"string"!=typeof e?e:this.doc.documentElement.selectSingleNode(
`*[@formula="${e}"]`)},_getAttribute(e,t){var i=e.selectSingleNode(
"cv:presentationFieldHelp");switch(t){case"currentDateMember":
case"useDateLookup":case"dataType":case"duration":case"formula":case"hierarchy":
case"hyperlink":case"calculated":case"measureName":case"dateFilterStart":
case"dateFilterEnd":case"dateFilterDefaultStart":case"dateFilterDefaultEnd":
return e.getAttribute(t);case"type":
return"measureHelp"===e.tagName?"NUMBER":i.getAttribute("type");
case"displayLabel":return(i?i.getAttribute(t):null)??"";
case"displayLabelOriginal":if(i){var s=i.selectSingleNode(
"cv:originalPresentationFieldHelp");if(s)return s.getAttribute("displayLabel")}
return"";case"format":return{formatCategory:"Default",formatScale:"0",
formatExpression:"",formatShortcut:"NONE"};default:return i?i.getAttribute(t
):null}},getAttributeList(){return this.doc.documentElement.selectNodes(
"cv:attributeHelp")},getMeasureList(){
return this.doc.documentElement.selectNodes("cv:measureHelp")},getDirectChild(e
){e=this.getChildLevels(e);return 0<e.length?e[0]:null},getChildLevels(t){
var i=[],s=this.getHierarchy(t);if(null!=s){let e=!1;for(const l of s)e&&i.push(
l),l===t&&(e=!0)}return i},getHierarchy(e,t,i){var s=this.get(e)?.getAttribute(
"hierarchy");if(!s)return null;var l=[];for(
const d of this.doc.documentElement.selectNodes(
`cv:hierarchyInfo[@formula="${s}"]/cv:levelInfo`)){var r=d.getAttribute(
"formula");if(!t&&this.isHidden(r)||l.push(r),i&&r===e)break}return l},
getHierarchyName(e){e=this.get(e);return e?e.getAttribute("hierarchy"):null},
getHierarchyOrdinal(t){var e=this.getHierarchyName(t);if(e){
var i=this.doc.documentElement.selectNodes(
`cv:hierarchyInfo[@formula="${e}"]/cv:levelInfo`);for(let e=0;e<i.length;++e)if(
i[e].getAttribute("formula")===t)return e}return null},getHierarchyLevels(e){
return this.doc.documentElement.selectNodes(
`cv:attributeHelp[@hierarchy='${e}']`)},getProperties(e){var t=[];for(
const i of this.doc.documentElement.selectNodes(
`cv:attributeHelp[@formula="${e}"]/cv:presentationFieldHelp/cv:property`)
)t.push(i.getAttribute("name"));return t},getModelInfoValue(e,t){
e=this.doc.documentElement.selectSingleNode(
`*[@formula="${e}"]/cv:presentationFieldHelp/cv:modelInfo[@name="${t}"]`);
return e?cv.textContent(e):null},getDatabaseInfo(e){var t={columnName:null,
tableName:null,dataType:null,tableSchema:null,tableType:null,isFactTable(){
return"FACT_TABLE"===this.tableType}},
e=this.doc.documentElement.selectSingleNode(
`*[@formula="${e}"]/cv:presentationFieldHelp/cv:dbColumn`);return e&&(
t.columnName=e.getAttribute("name"),t.dataType=e.getAttribute("dataType"),
e=e.selectSingleNode("cv:table"))&&(t.tableName=e.getAttribute("name"),
t.tableType=e.getAttribute("tableType"),t.tableSchema=e.getAttribute("schema")),
t},getCustomActions(e){var t=[];for(
const i of this.doc.documentElement.selectNodes(
`*[@formula="${e}"]/cv:presentationFieldHelp/cv:customAction`))t.push({
label:i.getAttribute("label"),fn:i.getAttribute("fn")});return t},isHidden(e){
return"true"===this.get(e,"hidden")},isAttribute(e){e=this.get(e);
return!!e&&"attributeHelp"===e.tagName},isNumberAttribute(e){var e=this.get(e);
return!(!e||!(e=this.get(e,"dataType"))||"Numeric"!==e&&"Integer"!==e)},
isTimeAttribute(e){var t=this.get(e);if(!t)return!1;switch(this.get(t,"type")){
case"TIME_YEAR":case"TIME_QUARTER":case"TIME_MONTH":case"TIME_WEEK":
case"TIME_DATE":case"TIME_HALFYEAR":case"TIME_HOUR":case"TIME_MINUTE":
case"TIME_SECOND":return"attributeHelp"===t.tagName;default:return!1}},
hasStartDateTimeKey(e){var e=this.get(e);return!!e&&!!(e=this.get(e,"duration")
)&&"ordinal"!==e},hasNumberKey(e){var e=this.get(e);return!!e&&!!(e=this.get(e,
"duration"))&&"ordinal"===e},searchFields(l){var r=this._hasFocus(),
d=this._captureFocusTargetState();if(this.selectedField&&b.remove(
this.selectedField,"selectedField"),13===l?.keyCode
)1===this.fieldCount&&this.selectedField&&this.manager.report.appendGem(
this.selectedField.getAttribute("formula"));else{
l=l&&"string"==typeof l?l:this.searchField.value;this.fieldCount=0;let e=null,
t=(l?(e=new RegExp(a.escapeString(l),"i"),cv.util.isHidden(this.clearSearchField
)&&cv.util.show(this.clearSearchField)):cv.util.hide(this.clearSearchField),!1),
i=null,s=null;for(const n of this.fieldListNodes)i!==n.groupHeader&&(
i=n.groupHeader,t=!1,i)&&cv.util.hide(i),b.contains(n,"hiddenField")||(
!e||0<=n.textContent.search(e)?(cv.util.show(n),b.contains(n,"hidden")||(
this.fieldCount+=1,s=s||n,!t&&i&&(cv.util.show(i),t=!0))):cv.util.isHidden(n
)||cv.util.hide(n));this._restoreFocusTarget(d,r),1===this.fieldCount?(
this.selectedField=s,b.add(this.selectedField,"selectedField")
):this.selectedField&&(b.remove(this.selectedField,"selectedField"),
this.selectedField=null),this.setGroupState(!!l||this.groupIsOpen)}},showDlg(e){
this.manager.report.rptDlg.show("show","fieldHelp",e)},sortFields(t){let a;
var h=this._hasFocus(),u=this._captureFocusTargetState();if(this.fieldListTree){
this.currentView&&cv.util.setMenuItem(this.currentView,"none"),
this.currentView=t,cv.util.setMenuItem(this.currentView,"checked");let e,i=!0,
s=this.viewOptions[t];var c=t;switch(s){case"displayLabel":i=!1,e=(e,t
)=>this._sortByName(e,t);break;case"schema":e=null,
this.fieldListItems=this._getFieldListItems(),s="businessGroup";break;
case"type":e=(e,t)=>{var i,s;return this.isTimeAttribute(e
)&&this.isTimeAttribute(t)||(i=this.get(e,"type"))===(s=this.get(t,"type")
)?this._sortByName(e,t):"NUMBER"===i||"NUMBER"!==s&&"ATTRIBUTE"===i?-1:1};break;
case"businessGroup":e=(e,t)=>{var i=this.get(e,"businessGroup"),s=this.get(t,
"businessGroup");return i||s?i?s?s<i?1:i<s?-1:this._sortByHierarchy(e,t
):-1:1:this._sortByHierarchy(e,t)};break;default:return}if(
e&&this.fieldListItems.sort(e),this.fieldListNodes)for(let e=0,
t=this.fieldListNodes.length;e<t;++e)this.fieldListNodes[e].dndObj&&(
this.fieldListNodes[e].dndObj=null);this.fieldListNodes=[],this.groups=[],
this.fieldListTreeContent.innerHTML="";var p=this.fieldListItems.length;
let l="!@#$",r=null,d=null,n=!1,o=0;for(let t=0;t<p;++t){var m,
g=this.fieldListItems[t];g.getAttribute("formula");if(i){let t;if((
t="type"===s&&this.isTimeAttribute(g)?"TIME":this.get(g,s))!==l){l=t;let e;
switch(s){case"schema":e=l||cvCatalog.fieldGroupNoValue;break;case"type":
e=cvCatalog["fieldTypeLabels_"+(l||"NUMBER")];break;case"businessGroup":
e=l||cvCatalog.fieldGroupNoValue;break;default:e=cvCatalog.fieldGroupNoValue}(
r=document.createElement("DIV")).innerHTML=cv.util.escapeHtml(e),r.id="GROUP"+o,
b.add(r,"folder hidden uncommon"),n=!1,this.fieldListTreeContent.appendChild(r),
(d=document.createElement("DIV")).id=`GROUP${o}DIV`,b.add(d,
"folderContent uncommon"),this.fieldListTreeContent.appendChild(d),
this.groups.push(this._makeCollapsible(r,d,this.groupIsOpen)),o+=1,
a=this._makeSource(d,{}),F.mixin(a,{onDrop(){}}),r.setAttribute("businessGroup",
e),r.setAttribute("tabindex","-1"),
r.dataset.penUiKey=`pen-ana-field-list-group-${c}-`+e;
var f=this.doc.documentElement.selectSingleNode(
`cv:businessGroupInfo[@businessGroup="${e}"]`);this._setTitle(e,
f?f.getAttribute("description"):null,r)}}f=document.createElement("DIV");
m=g.getAttribute("formula");let e=this.get(g,"displayLabel",!0);
var v=this.getProperties(m),v=(!this.isDrill&&0<v?.length&&(e+=` (${v.length})`)
,f.innerHTML=e||"&nbsp;",f.setAttribute("formula",m),
f.dataset.penUiKey="pen-ana-field-list-field-"+m,f.groupHeader=r,this.get(m,
"displayDescription",!0)),v=(this._setTitle(e,v,f),"NUMBER"===this.get(g,"type")
);f.setAttribute("type",v?"measure":"attribute"),this.isDrill?(b.add(f,
v?"fieldDrill measure":"fieldDrill attribute"),
f.innerHTML=`<input type='checkbox' ${this.drillFields[m
]?"checked":""} />`+f.innerHTML):(b.add(f,v?"field measure":"field attribute"),
b.add(f,"dojoDndItem")),"true"!==this.get(g,"isDefaultFavorite")?b.add(f,
"uncommon"):r&&b.contains(r,"uncommon")&&(b.remove(r,"uncommon"),b.remove(d,
"uncommon"));"true"===this.getModelInfoValue(m,"InlineCreatedInline")?.trim(
)&&b.add(f,"inlineCalcMeasure"),this.isHidden(g)&&b.add(f,
this.showHiddenFields?"disabled":"hiddenField"),this.fieldListNodes.push(f),(
d||this.fieldListTreeContent).appendChild(f),r&&!n&&(cv.isMobile(
)&&"none"!==f.style.display||"none"!==M.get(f,"display"))&&(cv.util.show(r),n=!0
),f.setAttribute("tabindex","-1"),m=f.getAttribute("formula");v=this.get(m);
v&&cv.util.disableTextSelection(f),f.setAttribute("dndType",
cvConst.dndTypes.gemFromFieldList),d&&a.sync()}n||(this.fieldListDnDSource||(
this.fieldListDnDSource=this._makeSource(this.fieldListTreeContent,{}),F.mixin(
this.fieldListDnDSource,{onDrop(){}})),this.fieldListDnDSource.sync()),
this._restoreFocusTarget(u,h),this.searchField.value&&this.searchFields();
t=this.byId("fieldCount");t&&(t.innerHTML=this._getFieldListItemCount())}},
_getCurrentFocusTarget(){return this.fieldListTreeContent.querySelector(
'[tabindex="0"]')},_captureFocusTargetState(){var e=this._getCurrentFocusTarget(
);return null==e?null:p.captureState(e,{root:this.fieldListTreeContent,
focusable:!0})},_restoreFocusTarget(e,t){e=e?.closest();return null==(
e=this._setCurrentFocusTarget(e,t))&&t&&document.querySelector(
"#viewFieldOptions").focus(),e},_getDefaultFocusTarget(){var e={
root:this.fieldListTreeContent,focusable:!0};return p.firstTabbable(e.root,e)},
_setCurrentFocusTarget(e,t){var i=this._getCurrentFocusTarget(),
e=null==e?this._getDefaultFocusTarget():e;return null==e?null:(e!==i&&(
null!=i&&i.setAttribute("tabindex","-1"),e.setAttribute("tabindex","0")),
t&&e.focus(),e)},_hasFocus(){return p.containsFocus(this.fieldListTreeContent)},
_setTitle(e,t,i){let s;s=0<t?.length?$("<div/>").html(t).text():e&&$("<div/>"
).html(e).text(),i.setAttribute("title",s)},_makeCollapsible(e,t,i,s,l){
return new cv.Collapsible(e,t,i,s,l)},_makeSource(e,t){var i=this.manager[
"report"];return new l(e,{...t,postDrop:{scope:i,f:i.emitDropEvent}})},
_sortByName(e,t){e=this.get(e,"displayLabel"),t=this.get(t,"displayLabel");
return t<e?1:e<t?-1:0},_sortByHierarchy(e,t){var i=this.get(e,"hierarchy"),
s=this.get(t,"hierarchy");if(i||s){if(!i)return-1;if(!s)return 1;if(i!==s
)return i<s?-1:1;var l=this.doc.documentElement.selectNodes(
`cv:hierarchyInfo[@formula="${i}"]/cv:levelInfo`),i=this.get(e,"formula"),
s=this.get(t,"formula");for(const d of l){var r=d.getAttribute("formula");if(
r===i)return-1;if(r===s)return 1}}return this._sortByName(e,t)},onClearSearch(){
this.searchField.value&&(this.searchField.value="",this.searchFields(),
this.setGroupState(this.groupIsOpen),this.searchField.focus()),cv.util.hide(
this.clearSearchField)},onMouseOver(e){var t,e=e.target;e&&b.contains(e,"field"
)&&this.selectedField!==e&&(this.selectedField&&b.remove(this.selectedField,
"fieldListItem-selected"),this.selectedField=e,b.add(this.selectedField,
"fieldListItem-selected"),b.contains(e,"field"))&&(b.add(this.selectedField,
"gem"),0===e.childElementCount)&&((t=document.createElement("div")
).className="gemMenuHandle scalable",this.handles.push(this._on(t,"click",
F.hitch(this,"onContextMenu"))),e.appendChild(t))},onMouseDown(e){e=e.target;
r.close(),this.fieldListTreeContent.contains(e)&&p.isTabbable(e,{focusable:!0}
)&&this._setCurrentFocusTarget(e,!0),(b.contains(e,"measure")||b.contains(e,
"gem"))&&b.add(this.selectedField,"gem")},onMouseOut(e){var t;
null!=this.selectedField&&(t=e.target,
null==e.relatedTarget||e.relatedTarget.parentNode!==t&&e.relatedTarget!==t.parentNode
)&&(b.contains(t,"gem")||t.parentNode&&b.contains(t.parentNode,"gem"))&&(
b.remove(this.selectedField,"gem"),0<this.selectedField.childNodes[0
].childNodes&&this.selectedField.removeChild(this.selectedField.childNodes[0
].childNodes[0]),b.remove(this.selectedField,"fieldListItem-selected"),
this.selectedField=null)},onDblClick(e){var t=this.selectedField.getAttribute(
"formula");e.target!==this.selectedField||this.isHidden(t
)||this.manager.report.appendGem(t)},onContextMenu(e){
var t=cv.util.getAncestorByClass(e.target,"field");t&&this.showContextMenu(e,t,
e.clientX,e.clientY)},onKeyDownFieldListTree(e){var t=e.target;if(
!t.classList.contains("folder"))switch(e.keyCode||e.which){
case cvConst.keyCodes.ENTER:this.onContextMenuAccessibility(e);break;
case cvConst.keyCodes.ARROW_UP:e.preventDefault(),cv.Collapsible.moveFocus(t,
"Up");break;case cvConst.keyCodes.ARROW_DOWN:e.preventDefault(),
cv.Collapsible.moveFocus(t,"Down")}},showContextMenu(e,t,i,s){b.add(t,
"selected-menu-field"),this.selectedMenuField=this.selectedField,
cv.util.popupSourceNode=t;var l=cv.util.getDojoWidget("fieldListMenu");
cv.util.disableMenuItems(l,this.selectedField),cv.util.showPopupMenu(l,i,s,t),
h.stop(e)},onContextMenuAccessibility(e){var t=e.target,i=(
this.selectedField&&b.remove(this.selectedField,"fieldListItem-selected"),
this.selectedField=t,b.add(this.selectedField,"fieldListItem-selected"),
b.contains(t,"field")&&(b.add(this.selectedField,"gem"),0===t.childElementCount
)&&((i=document.createElement("div")).className="gemMenuHandle scalable",
this.handles.push(this._on(i,"click",F.hitch(this,"onContextMenu"))),
t.appendChild(i)),c.position(this.selectedField.id));this.showContextMenu(e,t,
i.x+i.w,i.y+i.h)},onFieldEdit(){this.selectedMenuField&&(
this.manager.report.rptDlg.showCreateMeasureDlg(),r.close())},
onMeasureProperties(){this.selectedMenuField&&(
this.manager.report.rptDlg.showMeasurePropertiesDlg(),r.close())},
onAttributeProperties(){this.selectedMenuField&&(
this.manager.report.rptDlg.showAttributePropertiesDlg(),r.close())},
onCalculatedMeasureProperties(){var e,t;this.selectedMenuField&&(
e=cv.api.util._hasInlineModelingPermission()&&!this.disableInlineModeling,
t=cv.getFieldHelp().selectedMenuField.getAttribute("formula"),
t=this.getModelInfoValue(t,"InlineCreatedInline"),e&&"true"===t?.trim(
)?this.manager.report.rptDlg.showEditCalculatedMeasureDlg(
):this.onMeasureProperties(),r.close())},onCreateCalculatedMeasure(){
this.selectedMenuField&&(
this.manager.report.rptDlg.showCreateCalculatedMeasureDlg(),r.close())},
onRemoveMeasure(){this.selectedMenuField&&(
this.manager.report.rptDlg.showRemoveMeasureDlg(),r.close())},onFieldAdd(){
this.selectedMenuField&&(this.manager.report.appendGem(
this.selectedMenuField.getAttribute("formula")),r.close(),cv.util.restoreFocus()
)},onFieldFilter(){var e,t,i,s,l;this.selectedMenuField&&(
e=this.selectedMenuField.getAttribute("formula"),t="NUMBER"===cv.getFieldHelp(
).get(e,"type")||"string"==typeof e&&!e.indexOf("[MEASURE:"),{banner:i,rptDlg:s,
reportDoc:l}=this.manager["report"],l.isDefaultFilter(e,t)&&(
i.fixedMessage=cvCatalog.bannerEditDefaultFilter),s.showFilterList(e),r.close())
},onFieldHelp(){this.selectedMenuField&&(this.showDlg(
this.selectedMenuField.getAttribute("formula")),r.close())},onViewCategory(){(
this.manager.report.drillDlg.fieldHelp||this).sortFields("CMDVIEWCATEGORY"),
cv.util.restoreFocus()},onViewName(){(
this.manager.report.drillDlg.fieldHelp||this).sortFields("CMDVIEWNAME"),
cv.util.restoreFocus()},onViewSchema(){(
this.manager.report.drillDlg.fieldHelp||this).sortFields("CMDVIEWSCHEMA"),
cv.util.restoreFocus()},onShowHideFields(){
this.manager.report.drillDlg.fieldHelp||(
this.showHiddenFields=!this.showHiddenFields,this.sortFields(this.currentView),
cv.util.restoreFocus())},onViewType(){(
this.manager.report.drillDlg.fieldHelp||this).sortFields("CMDVIEWTYPE"),
cv.util.restoreFocus()},onViewFieldOptionsAccessibility(e){var t,i;(
e.keyCode||e.which)===cvConst.keyCodes.ENTER&&(t=cv.util.getDojoWidget(
"fieldViewMenu"))&&(this.showMenuItems(),i=c.position(e.currentTarget.id),
cv.util.showPopupMenu(t,i.x+i.w,i.y+i.h,e.target),h.stop(e))},showMenuItems(){
cv.util.setMenuItem("CMDVIEWCATEGORY","none"),cv.util.setMenuItem("CMDVIEWTYPE",
"none"),cv.util.setMenuItem("CMDVIEWNAME","none"),cv.util.setMenuItem(
"CMDVIEWSCHEMA","none"),cv.util.setMenuItem(this.currentView,"checked"),
cv.util.setMenuItem("CMDSHOWHIDEFIELDS",this.showHiddenFields?"checked":"none"),
this.isDrill&&(this.drillFields=this.getSelectedFields()),
this.isDrill||!cv.api.util._hasInlineModelingPermission(
)||this.disableInlineModeling?(b.add("CMDSHOWHIDEFIELDS","hidden"),b.add(
"showHideSeparator","hidden")):(b.remove("CMDSHOWHIDEFIELDS","hidden"),b.remove(
"showHideSeparator","hidden"))},onViewFieldOptions(e){
var t=cv.util.getDojoWidget("fieldViewMenu");t&&(this.showMenuItems(),
cv.util.showPopupMenu(t,e.pageX,e.pageY,e.target),h.stop(e))},getSelectedFields(
){var e={};for(const i of this.fieldListNodes){var[t]=i.getElementsByTagName(
"input");t.checked&&(t=-1<i.className?.indexOf("hiddenField"),e[i.getAttribute(
"formula")]=!t)}return e},selectAll(e){this.onClearSearch();var i={};if(e)for(
let e=0,t=this.fieldListNodes.length;e<t;++e)i[this.fieldListNodes[e
].getAttribute("formula")]=!0;this.drillFields=i,this.sortFields(
this.currentView)},resetToDefaultDrillFields(e){this.onClearSearch();var t={};
if(e)for(const s of this.fieldListNodes){var i=s.getAttribute("formula");t[i
]=!0===e[i]}this.drillFields=t,this.sortFields(this.currentView)},updateXml(e){
this.doc=cv.parseXML(e),cv.setDomDefaultNamespace(this.doc),
this.fieldListItems=this._getFieldListItems(),
this.fieldCount=this.fieldListItems.length,this.sortFields(this.currentView)},
onShowHideField(){this.selectedMenuField&&cv.util.createShowHideFieldAnnotation(
this.selectedMenuField)},setGroupState(e){for(const t of this.groups
)t.isOpen!==e&&t.onClickHeader()}}));define("pentaho/analyzer/report/cv_rptResize",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","./cv_rptFieldHelp","dojo/_base/array","dojo/has"
,"dojo/sniff"],function(e,s,t,i,r,o,a){cv.ReportResizer=function(e){
this.report=e,this.previousPageX=-1,this.resizeObj=null,this.resizeData=null,
this.page=null,this.handles=[]},cv.ReportResizer.prototype={destroy:function(){
this.page=null,this.resizeData=null,this.resizeobj=null},gainedFocus:function(e
){var t=e.target;if(t){for(this._updateCursorLook(e);"DIV"!=t.tagName;
)t=t.childNodes[0];this.handles.push(s(t,"mousemove",i.hitch(this,
"_updateCursorLook"))),this.handles.push(s(t,"click",i.hitch(this,"_showMenu")))
,this.handles.push(s(t,"mousedown",i.hitch(this,"_beginResize"))),
this.handles.push(s(t,"mouseout",i.hitch(this,"_lostFocus")))}},
_lostFocus:function(e){for(var t=e.target;"DIV"!=t.tagName;)t=t.childNodes[0];
this.handles=o.filter(this.handles,function(e){return e.remove(),!1})},
_beginResize:function(e){if(this._isInResizeZone(e)){this.report.resizing=!0,
this.previousPageX=e.pageX;for(var t=e.target;"DIV"!=t.tagName;)t=t.childNodes[0
];for(this.resizeObj=t,this.resizeData=this.report.reportHeaders.getDataColumn(
this.resizeObj.offsetParent),this.page=this.resizeObj;this.page.offsetParent;
)this.page=this.page.offsetParent;this.resizeHandles=[s(this.page,"mousemove",
i.hitch(this,"_resize")),s(this.page,"mouseup",i.hitch(this,"_endResize"))]}},
_endResize:function(e){this.report.reportHeaders.updateLayout(),o.forEach(
this.resizeHandles,function(e){e.remove()});for(var t=this._getWidth(
this.resizeObj),s=0;s<this.resizeData.length;s++)this.resizeData[s].childNodes[0
].style.width=t+1+"px";this.report.resizing=!1},_resize:function(e){for(
var t=this._getParentHeaders(this.resizeObj),s=0;s<t.length;s++)this._resizeObj(
t[s],e);this.previousPageX=e.pageX},_resizeObj:function(e,t){
var s=this._getWidth(e),t=(s+=t.pageX-this.previousPageX,
+e.offsetParent.getAttribute("colspan"));e.style.width=(s=s<10*t?10*t:s)+"px"},
_getParentHeaders:function(e){var e=e.parentNode,
t=e.parentNode.parentNode.getElementsByTagName("TR"),e=+e.getAttribute(
"colindex");return this.getParentHeaders(t,e)},getParentHeaders:function(e,t){
for(var s=new Array,i=0;i<e.length;i++)for(var r=e[i].childNodes,
o=0;o<r.length;o++){var a=r[o],n=+a.getAttribute("colspan"),h=+a.getAttribute(
"rowspan"),u=+a.getAttribute("colindex");if(u<=t&&t<u+n){s.push(a.childNodes[0])
,i+=h-1;break}}return s},_updateCursorLook:function(e){for(
var t=e.target;"DIV"!=t.tagName;)t=t.childNodes[0];
e.target.style&&e.target.style.cursor&&(this._isInResizeZone(e
)?t.offsetParent.style.cursor="e-resize":t.offsetParent.style.cursor="")},
_showMenu:function(e){this._isInResizeZone(e
)||this.report.toggleInReportPopupMenu(e)},_isInResizeZone:function(e){for(
var t=e.target;"DIV"!=t.tagName;)t=t.childNodes[0];var e=e.pageX,
s=this._findLeft(t)+t.offsetWidth;return s-10<e&&e<s},_findLeft:function(e){
var t=0;if(e.offsetParent)for(;e.offsetParent;)t+=e.offsetLeft-e.scrollLeft,
e=e.offsetParent;else e.x&&(t+=e.x);return a("ie")||(
t-=this.report.reportHeaders.getHorzScrollAmount()),t},_getWidth:function(e){
return parseInt(e.style.width.substring(0,e.style.width.length-2))}}});define("pentaho/analyzer/ResizeHandle",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dojox/layout/ResizeHandle","dojo/dom-class",
"dojo/dom-style","dojo/has","dojo/sniff","dojo/dom-geometry","dojo/_base/window"
,"dojo/_base/array","dojo/NodeList-traverse","common-ui/jquery"],function(e,t,i,
r,s,o,n,d,h,a,l,p){s=e([s],{
templateString:'<div class="resizeHandle" style="right: 0"><div></div></div>',
INITIAL_WIDTH:0,MINIMAL_WIDTH:10,postCreate:function(){
this.domNode.id="CVResizeHandle_"+this.resizeNodeId,this.handles=[t(this.domNode
,"mousedown",r.hitch(this,"_beginSizing")),t(this.domNode,"dblclick",r.hitch(
this,"_revert"))]},destroy:function(){this.inherited(arguments),
this.handles.forEach(function(e){e.remove()})},_revert:function(e){if(
"Label"===this.targetType)this.reportHeader.report.rowFieldWidths[
this.resizeIndex]=0;else if("Column"===this.targetType)for(
var t=+this.targetDomNode.parentNode.getAttribute("colspan"),
i=0;i<this.reportHeader.report.columnDataFieldWidths.length;i++
)i>=this.resizeIndex&&i<this.resizeIndex+t&&(
this.reportHeader.report.columnDataFieldWidths[i]=0);
this.reportHeader.updateLayout(),this.reportHeader.report.history.add(
new cv.ReportState("Reset Column")),
this.reportHeader.report.history.setRefreshed(!0)},_drawLine:function(e){e={
left:e+"px"};d("ie")&&(e.top="2px"),n.set(this.line,e),
this.reportHeader.rowLabelSection.appendChild(this.line)},_showLine:function(){
null!=this.line&&n.set(this.line,{visibility:""})},_hideLine:function(){
null!=this.line&&n.set(this.line,{visibility:"hidden"})},
_createLineOnCursorPosition:function(e){var t=a.position(
this.reportHeader.rowLabelSection,!0),e=e.clientX-t.x+this.INITIAL_WIDTH;
null==this.line&&(this.line=document.createElement("div"),o.add(this.line,
"resizeIndicator"),this._drawLine(e))},_moveLineToCursorPosition:function(e){
var t,i,r=a.position(this.reportHeader.rowLabelSection,!0),
s=e.clientX-r.x+this.INITIAL_WIDTH;void 0!==this.currentWidth&&(t=1,
"Column"===this.targetType&&(t=+this.targetDomNode.parentNode.getAttribute(
"colspan")),(i=parseInt(this.currentWidth))-this.dx<this.MINIMAL_WIDTH*t)&&(
s=this.startPoint.x-(i-this.MINIMAL_WIDTH*t)-r.x+this.INITIAL_WIDTH,d("ie"
)?this.changeSizingHandle.remove():e.offsetX=s,this.dx=i-this.MINIMAL_WIDTH*t),
this._showLine(),this._drawLine(s)},_getCurrentColumnWidth:function(){
this.currentWidth=0;var e=[];if("Label"===this.targetType
)e=this.reportHeader.rowLabelHeaderContainer.getElementsByTagName("COL"),
this.currentWidth=e[this.resizeIndex].width;else if("Column"===this.targetType
)for(var e=this.reportHeader.columnHeaderContainer.getElementsByTagName("COL"),
t=+this.targetDomNode.parentNode.getAttribute("colspan"),i=0;i<e.length;i++
)i>=this.resizeIndex&&i<this.resizeIndex+t&&(this.currentWidth+=+e[i].width)},
_beginSizing:function(e){this.reportHeader.report.isResizing=!0,
this.resizeIndex=+this.targetDomNode.attributes.resizeIndex.value,
this._getCurrentColumnWidth(),this.dx=0,this.startPoint={x:e.clientX,y:e.clientY
},this._createLineOnCursorPosition(e),this.sizingHandles=[t(this.line,"dblclick"
,r.hitch(this,"_revert")),t(document,"mouseup",r.hitch(this,"_endSizing"))],
this.changeSizingHandle=t(document,"mousemove",r.hitch(this,"_changeSizing")),
e.preventDefault(),this.maxDx=$(this.domNode.parentElement).width()},
_changeSizing:function(e){try{cv.util.stopDrag()}catch(e){}try{if(
!e.clientX||!e.clientY)return}catch(e){return}e.preventDefault(),
this.dx=this.startPoint.x-e.clientX,
this.dx<this.maxDx&&this._moveLineToCursorPosition(e)},_endSizing:function(e){
this.inherited("_endSizing",[e]),this._hideLine(),this.dx=this.dx||0,
this.dx>this.maxDx&&(this.dx=this.maxDx);var t,e=new cv.ReportState(
"Column Resize");"Label"===this.targetType?(this.reportHeader.updateLayout(
this.resizeIndex,this.dx),e.resizeData={index:this.resizeIndex,dx:this.dx}
):"Column"===this.targetType&&(t=+this.targetDomNode.parentNode.getAttribute(
"colspan"),this.reportHeader.updateLayout(this.resizeIndex,this.dx,t),
e.resizeData={index:this.resizeIndex,dx:this.dx,colspan:t}),
this.reportHeader.report.resizeRows(),this.reportHeader.report.history.add(e),
this.reportHeader.report.history.setRefreshed(!0),
this.reportHeader.report.isResizing=!1,p.forEach(this.sizingHandles,function(e){
e.remove()}),this.changeSizingHandle.remove(),null==d("ie")&&d("trident"
)&&dojo.query(this.domNode).closest("td").removeClass("dojoDndItem")}});
return e("analyzer.BeforeResizeHandle",[s],{
templateString:'<div class="resizeHandle" style="left: 0"><div></div></div>',
postCreate:function(){this.domNode.id="CVResizeHandle_"+this.resizeNodeId,
this.handles=[t(this.domNode,"mousedown",r.hitch(this,"_beginSizing")),t(
this.domNode,"dblclick",r.hitch(this,"_revert"))]},
_getCurrentColumnWidth:function(){this.currentWidth=0;var e=[];if(
"Label"===this.targetType
)e=this.reportHeader.rowLabelHeaderContainer.getElementsByTagName("COL"),
this.currentWidth=e[this.resizeIndex-1].width;else if("Column"===this.targetType
)if(0==this.resizeIndex){
var t=this.reportHeader.rowLabelHeaderContainer.getElementsByTagName("COL"
).length-1;
this.currentWidth=this.reportHeader.rowLabelHeaderContainer.getElementsByTagName(
"COL")[t].width}else for(
var e=this.reportHeader.columnHeaderContainer.getElementsByTagName("COL"),
i=+this.targetDomNode.parentNode.getAttribute("colspan"),r=this.resizeIndex-i,
s=0;s<e.length;s++)r<=s&&s<r+i&&(this.currentWidth+=+e[s].width)},
_revert:function(e){if("Label"===this.targetType
)this.reportHeader.report.rowFieldWidths[this.resizeIndex-1]=0;else if(
"Column"===this.targetType)if(0==this.resizeIndex){
var t=this.reportHeader.rowLabelHeaderContainer.getElementsByTagName("COL"
).length-1;this.reportHeader.report.rowFieldWidths[t]=0}else for(
var i=+this.targetDomNode.parentNode.getAttribute("colspan"),
r=this.resizeIndex-i,
s=0;s<this.reportHeader.report.columnDataFieldWidths.length;s++)r<=s&&s<r+i&&(
this.reportHeader.report.columnDataFieldWidths[s]=0);
this.reportHeader.updateLayout(),this.reportHeader.report.history.add(
new cv.ReportState("Reset Column")),
this.reportHeader.report.history.setRefreshed(!0)},_endSizing:function(e){
this._hideLine(),this.dx=this.dx||0;var t,i=new cv.ReportState("Column Resize",
"");"Label"===this.targetType?(this.reportHeader.updateLayout(this.resizeIndex-1
,this.dx),i.resizeData={index:this.resizeIndex-1,dx:this.dx}
):"Column"===this.targetType&&(0==this.resizeIndex?(
t=this.reportHeader.rowLabelHeaderContainer.getElementsByTagName("COL").length-1
,this.reportHeader.updateLayout(t,this.dx),i.resizeData={index:t,dx:this.dx}):(
t=+this.targetDomNode.parentNode.getAttribute("colspan"),
this.reportHeader.updateLayout(this.resizeIndex-t,this.dx,t),i.resizeData={
index:this.resizeIndex-t,dx:this.dx,colspan:t})),
this.reportHeader.report.resizeRows(),this.reportHeader.report.history.add(i),
this.reportHeader.report.history.setRefreshed(!0),
this.reportHeader.report.isResizing=!1,p.forEach(this.sizingHandles,
dojo.disconnect),this.changeSizingHandle.remove(),null==d("ie")&&d("trident"
)&&dojo.query(this.domNode).closest("td").removeClass("dojoDndItem")}}),s});define("pentaho/analyzer/report/cv_rptHeaders",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dojo/dnd/Source","../ResizeHandle",
"./cv_rptFieldHelp","dojo/_base/array","dojo/dom-style","dojo/dom-geometry",
"dojo/dom-class","dojo/has","dojo/sniff"],function(t,g,b,f,s,o,e,i,h,m,a,T){
cv.ReportHeaders=function(t,e){this.report=t,this.tableArea=t.nodeReportArea,
this.pivotTable=b(" > div:first-of-type",t.nodeReportArea)[0],
this.rowLabelHeaderSection=cv.util.getFirstChildByClass(this.pivotTable,
"pivotTableRowLabelHeaderSection"),
this.rowLabelHeaderContainer=cv.util.getFirstChildByClass(this.pivotTable,
"pivotTableRowLabelHeaderContainer"),
this.rowLabelSection=cv.util.getFirstChildByClass(this.pivotTable,
"pivotTableRowLabelSection"),
this.rowLabelContainer=cv.util.getFirstChildByClass(this.pivotTable,
"pivotTableRowLabelContainer"),
this.columnHeaderSection=cv.util.getFirstChildByClass(this.pivotTable,
"pivotTableColumnHeaderSection"),
this.columnHeaderContainer=cv.util.getFirstChildByClass(this.pivotTable,
"pivotTableColumnHeaderContainer"),
this.columnHeaderTable=cv.util.getFirstChildByClass(this.columnHeaderContainer,
"ZONE_columnAttributes"),this.rowHeaderTable=cv.util.getFirstChildByClass(
this.rowLabelHeaderSection,"ZONE_rowAttributes"),
this.measureHeaderTable=cv.util.getFirstChildByClass(this.columnHeaderTable,
"ZONE_measures"),this.dataSection=cv.util.getFirstChildByClass(this.pivotTable,
"pivotTableDataSection"),this.dataContainer=cv.util.getFirstChildByClass(
this.pivotTable,"pivotTableDataContainer"),
this.content=cv.util.getFirstChildByClass(this.pivotTable,"pivotTableContent"),
this.scrollbarArea=cv.util.getFirstChildByClass(this.pivotTable,
"pivotTableScrollbars"),this.scrollbarAreaDiv=b(" > div:first-of-type",
this.scrollbarArea)[0],this.truncateType=this.pivotTable.truncateType,
this.dragNodes=[],this.handles=[],this.tempDragHandles=[];for(
var i=this.rowLabelContainer.firstChild;"TABLE"!=i.tagName;)i=i.nextSibling;
this.rowLabelTable=i;for(i=this.dataContainer.firstChild;"TABLE"!=i.tagName;
)i=i.nextSibling;this.colLabelTable=i;for(
i=this.content.firstChild;"TABLE"!=i.tagName;)i=i.nextSibling;
this.contentTable=i,"ROW"!=this.truncateType&&"BOTH"!=this.truncateType||(
t.byId("RowTruncateMsg").innerHTML=this.pivotTable.rowMsg),
"COL"!=this.truncateType&&"BOTH"!=this.truncateType||(t.byId("ColTruncateMsg"
).innerHTML=this.pivotTable.colMsg),cv.util.hide(this.report.nodeColTruncate,
this.report.nodeRowTruncate,this.report.nodeTransTruncate),
this._refreshRowLabelHeaders(),
this.labelRows=this.rowLabelSection.getElementsByTagName("TR");var s=null;if(
this.rowLabels=null,0<this.labelRows.length){for(var s=[],
a=this.report.reportDoc.getChildMembers("rowAttributes"),r=0;r<a.length;r++){
s.push(b("td[colspan='1'][type='member'][formula=\""+a[r].getAttribute("formula"
)+'"]',this.rowLabelSection)[0]);for(var o=a[r].selectNodes("cv:property"
).length,l=s[r].nextSibling,n=0;n<o;n++)s.push(l),l=l.nextSibling}
this.rowLabels=this.rowLabelSection.getElementsByTagName("COLGROUP")[0
].childNodes}t=this.columnHeaderSection.getElementsByTagName("TR");if(
this.columnHeaders=t.length?t[t.length-1].childNodes:null,
null!=this.columnHeaders&&(T("ie")||T("trident"))&&1==t.length)for(
var h=this.columnHeaderSection.getElementsByTagName("COLGROUP")[0].childNodes,
r=0;r<h.length;r++)h[r].width=+h[r].width-1;
this.dataColumns=this.dataSection.getElementsByTagName("TR"),
this.connectScrollbar(),this.previousPageX=-1,this.previousPageY=-1,
this._setUpDrag(),T("mozilla"
)?this.pivotTable.addEventListener&&this.pivotTable.addEventListener(
"DOMMouseScroll",f.hitch(this,"_mouseScroll"),!1):(this.mouseWheelHandle=g(
this.pivotTable,"mousewheel",f.hitch(this,"_mouseScroll")),this.handles.push(
this.mouseWheelHandle),this.handles.push(g(this.pivotTable,"mousemove",f.hitch(
this,"_clearSelection")))),this.handles.push(g(this.pivotTable,"mousedown",
f.hitch(this,"_mouseDown"))),this.widths=new Array,this.initialWidths=new Array,
this.columnWidths=new Array,this.initialColumnWidths=new Array,
this.DEFAULT_COLUMN_WIDTH=120,this.MINIMAL_WIDTH=10,this.resizeLabels=new Array,
this.resizeColumns=new Array,this._refreshRowLabelHeaders();for(var c,d,
r=0;r<this.rowLabelHeaders.length;r++){var u=0,p=(null!=this.rowLabels&&(
u=m.getContentBox(s[r]).w),m.getContentBox(this.rowLabelHeaders[r]).w);
this.isTooLongOrHasSpace(this.rowLabelHeaders[r].title)&&(p=1.1*p/2),
this.widths[r]=Math.min(u,210),this.widths[r]=Math.max(this.widths[r],80),
this.widths[r]=Math.max(this.widths[r],p),this.initialWidths[r]=this.widths[r]}(
T("ie")||T("trident"))&&(c=this.dataContainer.childNodes[0].childNodes[0
].childNodes,null!=this.columnHeaders
)&&0<this.columnHeaders.length&&0<c.length&&((d=c[0]).width=+d.width+1,(d=c[
c.length-1]).width=+d.width-(1==t.length?2:1))},cv.ReportHeaders.prototype={
disconnect:function(){this._tearDownDrag();for(
var t=0;t<this.dragNodes.length;++t)this.dragNodes[t].dndObj=null;i.forEach(
this.handles,function(t){t.remove()}),this.pivotTable=null,
this.rowLabelHeaderSection=null,this.rowLabelHeaderContainer=null,
this.rowLabelSection=null,this.rowLabelContainer=null,
this.columnHeaderSection=null,this.columnHeaderContainer=null,
this.dataSection=null,this.dataContainer=null,this.tableArea=null,
this.content=null,this.scrollbarArea=null,this.rowLabelHeaders=null,
this.rowLabels=null,this.labelRows=null,this.columnHeaders=null,
this.dataColumns=null,this.dragNodes=null},connectScrollbar:function(){
this.scrollHandle=g(this.scrollbarArea,"scroll",f.hitch(this,"_scroll")),
this.handles.push(this.scrollHandle)},isTooLongOrHasSpace:function(t){
return 30<t.length||-1<t.indexOf(" ")},attachResizeNode:function(t,e,i,s){var a,
r;null!=t&&(a=document.createElement("div"),"after"==i?(r=new o({resizeNodeId:s,
reportHeader:this,targetType:e,targetDomNode:t},a),t.appendChild(r.domNode)):(
r=new analyzer.BeforeResizeHandle({resizeNodeId:s,reportHeader:this,
targetType:e,targetDomNode:t},a),t.insertBefore(r.domNode,t.firstChild)))},
_sumOf:function(t){for(var e=0,i=0;i<t.length;i++)e+=t[i];return e},
_computeRowLabelWidths:function(){for(var t=new Array,
e=0;e<this.widths.length;e++)t[e]=this.widths[e];var i=this._sumOf(t),
s=.67*this.pivotTableWidth;if(0<i&&0<s)for(;s<i;){for(var a=new Array,r=0,o=0,
e=0;e<t.length;e++)t[e]==r?a[a.length]=e:t[e]>r&&(r=t[(a=new Array)[0]=e]);for(
e=0;e<t.length;e++)t[e]>o&&t[e]<r&&(o=t[e]);for(var l=Math.max(1,Math.min(
Math.ceil((i-s)/a.length),r-o)),e=0;e<a.length;e++)t[a[e]]-=l;i=this._sumOf(t)}
return t},_adjustRowLabelWidths:function(t,e,i){var s=[],a=Math.max(h.get(
this.rowLabelContainer,"padding"),h.get(this.rowLabelHeaderContainer,"padding"))
,r=a,o=(this.rowLabelContainer.childNodes[0].style.tableLayout="fixed",
this.rowLabelContainer.childNodes[0].style.width="0px",
this.rowLabelHeaderContainer.getElementsByTagName("COL"));
this.rowLabelHeaderContainer.childNodes[0].style.tableLayout="fixed",
this.rowLabelHeaderContainer.childNodes[0].style.width="0px";for(
var l=0;l<t.length;l++){var n=this.widths[l];null!=this.report.rowFieldWidths[l
]&&(n-=this.report.rowFieldWidths[l]),n<this.MINIMAL_WIDTH&&(
n=this.MINIMAL_WIDTH),void 0!==e&&l==e&&(this.report.isReportPropsDirty=!0,(n-=i
)<this.MINIMAL_WIDTH&&(n=this.MINIMAL_WIDTH),
void 0===this.report.rowFieldWidths[l]?this.report.rowFieldWidths[l
]=i:this.report.rowFieldWidths[l]+=i),this._refreshRowLabelHeaders(),
this.rowLabelHeaders[l].childNodes[0].style.whiteSpace="normal",o[l
].width=n+"px",s.push(n),null!=this.rowLabels&&(this.rowLabels[l].width=n+"px"),
a+=n}return this.rowLabelHeaderSection.setAttribute("width",a-=r),
this.rowLabelSection.setAttribute("width",a),0<a&&(
this.rowLabelHeaderContainer.style.width=a+"px"),
this.report.actualRowFieldWidths=s,a},_refreshRowLabelHeaders:function(){
this.rowLabelHeaders=this.rowLabelHeaderContainer.getElementsByTagName("TD")},
_adjustColumnWidths:function(t,e,i){for(var s=[],a=new Array,
r=this.columnHeaderContainer.getElementsByTagName("COL"),o=0;o<r.length;o++
)void 0!==this.report.columnDataFieldWidths[o]?a[o
]=this.DEFAULT_COLUMN_WIDTH-this.report.columnDataFieldWidths[o]:a[o
]=this.DEFAULT_COLUMN_WIDTH;for(o=0;o<a.length;o++
)void 0!==t&&void 0!==i&&t<=o&&o<t+i&&(this.report.isReportPropsDirty=!0,a[o
]-=e/i);for(var l=0,o=0;o<a.length;++o)l+=a[o];(T("ie")||T("trident"))&&(l+=1),
this.columnHeaderSection.style.width=l+"px",
this.columnHeaderContainer.style.width=l+"px",
this.columnHeaderSection.setAttribute("width",l),
this.columnHeaderContainer.setAttribute("width",l);for(
var n=this.dataContainer.getElementsByTagName("COL"),o=0;o<a.length;o++){
var h=a[o]<this.MINIMAL_WIDTH?this.MINIMAL_WIDTH:a[o];n[o].width=h,r[o].width=h,
s.push(h)}for(o=0;o<a.length;o++)this.report.columnDataFieldWidths[o
]=this.DEFAULT_COLUMN_WIDTH-a[o];cv.util.getFirstChildByClass(
this.columnHeaderContainer,"ZONE_columnAttributes").style.width=l+"px",
this.dataContainer.setAttribute("width",l),this.dataContainer.style.width=l+"px"
,this.dataContainer.getElementsByTagName("table")[0].setAttribute("width",l),
this.report.actualColumnFieldWidths=s},_adjustCellsHeight:function(){if(
null!=this.labelRows&&0<this.labelRows.length&&null!=this.dataColumns&&0<this.dataColumns.length
){var t=this.labelRows.length;if(t===this.dataColumns.length){for(var e=[],
i=0;i<t;i++){var s,a,r=-1;(this._containsSpecialCharacters(this.labelRows[i
].textContent)||this._containsSpecialCharacters(this.dataColumns[i].textContent)
)&&(s=m.getContentBox(this.labelRows[i]).h)!==(a=m.getContentBox(
this.dataColumns[i]).h)&&(r=Math.max(s,a)),e.push(r)}for(i=0;i<t;i++)-1<e[i]&&(
this.labelRows[i].style.height=e[i]+"px",this.dataColumns[i].style.height=e[i
]+"px")}}},_containsSpecialCharacters:function(t){if(t&&0<t.length)for(
var e=0;e<t.length;e++)if(1792<t.charCodeAt(e))return!0;return!1},
_adjustHeadersHeight:function(){if(this._refreshRowLabelHeaders(),
null!=this.rowLabelHeaders&&0<this.rowLabelHeaders.length&&null!=this.columnHeaders&&0<this.columnHeaders.length
){for(var t=m.getContentBox(this.columnHeaders[0]).h,e=m.getContentBox(
this.rowLabelHeaders[0]).h,i=Math.max(t,e),s=0;s<this.rowLabelHeaders.length;s++
)this.rowLabelHeaders[s].style.height=i+"px";for(
s=0;s<this.columnHeaders.length;s++)this.columnHeaders[s].style.height=i+"px"}},
_hideEmptyContainers:function(){m.getContentBox(this.columnHeaderTable).h<=1&&(
this.columnHeaderTable.style.display="none")},_adjustContainer:function(t){
var e=Math.max(m.position(this.columnHeaderContainer.childNodes[0]).h,
m.position(this.rowLabelHeaderContainer.childNodes[0]).h),e=(
this.rowLabelHeaderSection.setAttribute("height",e),
this.rowLabelHeaderContainer.style.height=e+"px",
this.columnHeaderSection.setAttribute("height",e),
this.dataAreaWidth=this.scrollbarArea.clientWidth-t-2,
this.scrollbarArea.clientHeight-e),i=this.rowLabelContainer.childNodes[0
].offsetHeight*this.scrollbarArea.clientHeight/e,
t=t+ +this.columnHeaderSection.getAttribute("width");
this.scrollbarAreaDiv.style.height=Math.max(e,i)+"px",
this.scrollbarAreaDiv.style.width=Math.max(this.dataAreaWidth,t)+"px",
this.content.style.width=this.scrollbarArea.clientWidth+"px",
this.content.style.height=this.scrollbarArea.clientHeight+"px",
this.dataContainer.scrollLeft=0,this.dataContainer.scrollTop=0},
_clearHeaderHeightStyle:function(){if(this._refreshRowLabelHeaders(),
null!=this.rowLabelHeaders)for(var t=0;t<this.rowLabelHeaders.length;t++
)this.rowLabelHeaders[t].style.height="";if(null!=this.columnHeaders)for(
t=0;t<this.columnHeaders.length;t++)this.columnHeaders[t].style.height=""},
_updateHeaderTdClasses:function(){dojo.query("tr",this.columnHeaderContainer
).forEach(function(t){a.add(t.childNodes[t.childNodes.length-1],"last")})},
_updateRowLabelSectionClasses:function(){0==dojo.query("table tr",
this.rowLabelContainer).length&&a.add(this.rowLabelSection,"empty")},
updateLayout:function(t,e,i){this.pivotTableHeight=this.report.reportHeight-10,
this.pivotTableWidth=this.report.reportWidth-10,
this.scrollbarArea.style.height=this.pivotTableHeight+"px",
this.scrollbarArea.style.width=this.pivotTableWidth+"px",
this.pivotTable.style.height=this.pivotTableHeight+"px",
this.pivotTable.style.width=this.pivotTableWidth+"px",
this.content.style.marginTop="-"+this.pivotTableHeight+"px";
var s=this._computeRowLabelWidths(),a=(this._clearHeaderHeightStyle(),0),
a=void 0!==i?this._adjustRowLabelWidths(s):this._adjustRowLabelWidths(s,t,e);if(
this._adjustColumnWidths(t,e,i),this._adjustCellsHeight(),
this._adjustHeadersHeight(),this._adjustContainer(a),this._hideEmptyContainers()
,T("ie")||T("trident")){for(var r=b(".resize",this.columnHeaderContainer),
o=0;o<r.length;++o)h.set(r[o],"top","0px"),h.set(r[o],"position","static"),
h.set(r[o],"position","relative");for(o=0;o<this.resizeLabels.length;++o)h.set(
this.resizeLabels[o],"top","0px"),h.set(this.resizeLabels[o],"position","static"
),h.set(this.resizeLabels[o],"position","relative")}this._updateHeaderTdClasses(
),this._updateRowLabelSectionClasses(),this._scroll(null)},
getDataColumn:function(t){for(var e=0;e<this.columnHeaders.length;e++)if(
this.columnHeaders[e]==t){for(var i=new Array,s=0;s<this.dataColumns.length;s++
)i[s]=this.dataColumns[s].childNodes[e];return i}return null},_scroll:function(t
){var e=cv.getActiveReport().reportDoc,e="true"==e.getReportOption(
"freezeColumns")&&"true"==e.getReportOption("freezeRows"
)?this.XYLockedScrollStrategy:"true"==e.getReportOption("freezeColumns"
)?this.YLockedScrollStrategy:"true"==e.getReportOption("freezeRows"
)?this.XLockedScrollStrategy:this.UnlockedScrollStrategy;try{
var i=-this.scrollbarArea.scrollLeft/(this.scrollbarArea.clientWidth-parseInt(
this.scrollbarAreaDiv.clientWidth)),s=-this.scrollbarArea.scrollTop/(
this.scrollbarArea.clientHeight-parseInt(this.scrollbarAreaDiv.clientHeight)),
i=i||0,s=s||0,a=Math.round(e.getMaxXOffset(this)*i),r=Math.round(
e.getMaxYOffset(this)*s);e.scroll(this,a,r),this._checkTruncate(i,s)}catch(t){
throw alert(t),t}},_clearSelection:function(t){},_mouseScroll:function(t){
this.mouseWheelHandle&&this.mouseWheelHandle.remove();var e=0;
"number"==typeof t.wheelDelta?e=t.wheelDelta:"number"==typeof t.detail&&(
e=40*-t.detail),this._scrollByAmount(0,e),this.mouseWheelHandle=g(
this.pivotTable,T("mozilla")?"DOMMouseScroll":"mousewheel",f.hitch(this,
"_mouseScroll"))},_mouseDown:function(t){var e,i=cv.util.getAncestorByTag(
t.target,"td");!i||"measure"!==(e=i.getAttribute("type")
)&&"attribute"!==e||i.dndObj||(e=cvConst.dndTypes.gemFromReportArea,a.add(i,
"dojoDndItem"),i.setAttribute("dndType",e),i.dndObj=new s(i.parentNode,{}),
i.dndObj.onMouseOver(t),i.dndObj.onMouseDown(t),this.dragNodes.push(i))},
keyPress:function(t){33==t?this._scrollByAmount(0,250
):34==t?this._scrollByAmount(0,-250):38==t?this._scrollByAmount(0,10
):40==t?this._scrollByAmount(0,-10):37==t?this._scrollByAmount(10,0
):39==t&&this._scrollByAmount(-10,0)},_setUpDrag:function(){this.dragHandle=g(
this.dataContainer,"mousedown",f.hitch(this,"_startDrag"))},
_tearDownDrag:function(){this.dragHandle.remove()},_startDrag:function(t){
this.scrollHandle.remove(),this.previousPageX=t.pageX,this.previousPageY=t.pageY
,this.changeIndex=0,this.previousXChanges=new Array,
this.previousYChanges=new Array;for(var e=0;e<9;e++)this.previousXChanges[e]=0,
this.previousYChanges[e]=0;for(var i=t.target;i.offsetParent;)i=i.offsetParent;
this.tempDragHandles.push(g(i,"mouseup",f.hitch(this,"_stopDrag"))),
this.tempDragHandles.push(g(document,"mouseup",f.hitch(this,"_stopDrag"))),
this.tempDragHandles.push(g(i,"mousemove",f.hitch(this,"_drag"))),
this.tempDragHandles.push(g(document,"mousemove",f.hitch(this,"_drag")))},
_stopDrag:function(t){for(var e=t.target;e.offsetParent;)e=e.offsetParent;
i.forEach(this.tempDragHandles,function(t){t.remove()}),this.connectScrollbar()
},_drag:function(t){if(t.button<0||2<t.button)this._stopDrag();else{for(
var e=t.pageX-this.previousPageX,i=t.pageY-this.previousPageY,s=(
this.previousXChanges[this.changeIndex]=e,this.previousYChanges[this.changeIndex
]=i,0),a=0,r=0;r<9;r++)s+=this.previousXChanges[r],a+=this.previousYChanges[r];
Math.abs(s),Math.abs(a),Math.abs(a),Math.abs(s),this.changeIndex=(
this.changeIndex+1)%9,this.previousPageY=t.pageY,this.previousPageX=t.pageX,
this._scrollByAmount(e,i)}},_scrollByAmount:function(t,e){var i,s,a;
0==t&&0==e||(t=(i="true"==(i=cv.getActiveReport().reportDoc).getReportOption(
"freezeColumns")&&"true"==i.getReportOption("freezeRows"
)?this.XYLockedScrollStrategy:"true"==i.getReportOption("freezeColumns"
)?this.YLockedScrollStrategy:"true"==i.getReportOption("freezeRows"
)?this.XLockedScrollStrategy:this.UnlockedScrollStrategy).getXOffset(this,t),
e=i.getYOffset(this,e),s=i.getMaxXOffset(this),a=i.getMaxYOffset(this),i.scroll(
this,t,e),this.updateScrollbars(Math.min(1,t/s),Math.min(1,e/a)),
this._checkTruncate(t/s,e/a))},updateScrollbars:function(t,e){
this.scrollbarArea.scrollLeft=-Math.round((
this.scrollbarArea.clientWidth-this.scrollbarAreaDiv.clientWidth)*t),
this.scrollbarArea.scrollTop=-Math.round((
this.scrollbarArea.clientHeight-this.scrollbarAreaDiv.clientHeight)*e)},
UnlockedScrollStrategy:{getXOffset:function(t,e){
return t.contentTable.style.marginLeft?parseInt(t.contentTable.style.marginLeft
)+e:e},getMaxXOffset:function(t){
return t.content.clientWidth-t.contentTable.scrollWidth},getYOffset:function(t,e
){return t.contentTable.style.marginTop?parseInt(t.contentTable.style.marginTop
)+e:e},getMaxYOffset:function(t){
return t.content.clientHeight-t.contentTable.scrollHeight},scroll:function(t,e,i
){e=Math.min(Math.max(e,this.getMaxXOffset(t)),0),i=Math.min(Math.max(i,
this.getMaxYOffset(t)),0);t.contentTable.style.marginLeft=e+"px",
t.contentTable.style.marginTop=i+"px"}},XLockedScrollStrategy:{
getXOffset:function(t,e){return t.columnHeaderTable.style.left?parseInt(
t.columnHeaderTable.style.left)+e:e},getMaxXOffset:function(t){
return t.content.clientWidth-t.contentTable.scrollWidth},getYOffset:function(t,e
){return t.contentTable.style.marginTop?parseInt(t.contentTable.style.marginTop
)+e:e},getMaxYOffset:function(t){
return t.content.clientHeight-t.contentTable.scrollHeight},scroll:function(t,e,i
){e=Math.min(Math.max(e,this.getMaxXOffset(t)),0),i=Math.min(Math.max(i,
this.getMaxYOffset(t)),0);t.colLabelTable.style.left=e+"px",
t.columnHeaderTable.style.left=e+"px",t.contentTable.style.marginTop=i+"px"}},
YLockedScrollStrategy:{getXOffset:function(t,e){
return t.contentTable.style.marginLeft?parseInt(t.contentTable.style.marginLeft
)+e:e},getMaxXOffset:function(t){
return t.content.clientWidth-t.contentTable.scrollWidth},getYOffset:function(t,e
){return t.rowLabelTable.style.top?parseInt(t.rowLabelTable.style.top)+e:e},
getMaxYOffset:function(t){
return t.content.clientHeight-t.contentTable.scrollHeight},scroll:function(t,e,i
){e=Math.min(Math.max(e,this.getMaxXOffset(t)),0),i=Math.min(Math.max(i,
this.getMaxYOffset(t)),0);t.contentTable.style.marginLeft=e+"px",
t.colLabelTable.style.top=i+"px",t.rowLabelTable.style.top=i+"px"}},
XYLockedScrollStrategy:{getXOffset:function(t,e){
return t.columnHeaderTable.style.left?parseInt(t.columnHeaderTable.style.left
)+e:e},getMaxXOffset:function(t){
return t.content.clientWidth-t.contentTable.scrollWidth},getYOffset:function(t,e
){return t.rowLabelTable.style.top?parseInt(t.rowLabelTable.style.top)+e:e},
getMaxYOffset:function(t){
return t.content.clientHeight-t.contentTable.scrollHeight},scroll:function(t,e,i
){e=Math.min(Math.max(e,this.getMaxXOffset(t)),0),i=Math.min(Math.max(i,
this.getMaxYOffset(t)),0);t.colLabelTable.style.left=e+"px",
t.columnHeaderTable.style.left=e+"px",t.rowLabelTable.style.top=i+"px",
t.colLabelTable.style.top=i+"px"}},_checkTruncate:function(t,e){
"BothClose"!=this.report.closeTruncateStatus&&(
cv.api.ui.isFromTransformation?"ROW"==this.truncateType||"COL"==this.truncateType||"BOTH"==this.truncateType?cv.util.show(
this.report.nodeTransTruncate):cv.util.hide(this.report.nodeTransTruncate):(
"COL"!=this.truncateType&&"BOTH"!=this.truncateType||"ColClose"==this.report.closeTruncateStatus||(
1<=t||this.scrollbarArea.clientWidth>=this.scrollbarAreaDiv.clientWidth?(
cv.util.show(this.report.nodeColTruncate),
this.report.nodeColTruncate.style.left=this.tableArea.clientWidth-m.getContentBox(
this.report.nodeColTruncate).w-35+"px",
this.report.nodeColTruncate.style.top=this.tableArea.offsetTop+10+"px"
):cv.util.hide(this.report.nodeColTruncate)),(
"ROW"==this.truncateType||"BOTH"==this.truncateType&&"RowClose"!=this.report.closeTruncateStatus
)&&(1<=e||this.scrollbarArea.clientHeight>=this.scrollbarAreaDiv.clientHeight?(
cv.util.show(this.report.nodeRowTruncate),
this.report.nodeRowTruncate.style.top=this.tableArea.offsetTop+this.tableArea.clientHeight-m.position(
this.report.nodeRowTruncate).h-28+"px"):cv.util.hide(this.report.nodeRowTruncate
))))}}});define("pentaho/analyzer/report/cv_pentaho",["dojo/_base/declare","dojo/on",
"dojo/query","dojo/_base/lang","dojo/dom","common-ui/util/URLEncoder",
"../common"],(e,t,n,o,w,d)=>(window.pentahoLoad=()=>{enableSaveButtons(),
lowerEditButton(),enableEditButton()},window.pentahoViewerLoad=()=>{
disableSaveButtons(),resetEditButton(),enableEditButton()},
window.editContentToggled=e=>{if(console_enabled){const n=window.location["href"
];function t(){document.location.replace(n.replace(/\/editor\b/g,"/viewer"))}
e&&n.includes("/viewer")?document.location.replace(n.replace(/\/viewer\b/g,
"/editor")):!e&&n.includes("/editor")&&(hasUnsavedChanges()?cv.getActiveReport(
).rptDlg.showConfirm(cvCatalog.promptDirtyReport,null,{srcFunc:t},{
srcFunc:lowerEditButton}):t())}},window.enableEditButton=()=>{
console_enabled&&window.parent.enableContentEdit&&window.parent.canEdit(
)&&window.parent.enableContentEdit(!0)},window.disableEditButton=()=>{
console_enabled&&window.parent.enableContentEdit&&window.parent.enableContentEdit(
!1)},window.lowerEditButton=()=>{
console_enabled&&window.parent.setContentEditSelected&&window.parent.setContentEditSelected(
!0)},window.resetEditButton=()=>{
console_enabled&&window.parent.setContentEditSelected&&window.parent.setContentEditSelected(
!1)},window.enableSaveButtons=()=>{
console_enabled&&window.parent.enableSave&&window.parent.enableSaveForFrame(
window.frameElement.id,!0)},window.disableSaveButtons=()=>{
console_enabled&&window.parent.enableSave&&window.parent.enableSaveForFrame(
window.frameElement.id,!1)},window.refreshBrowsePanel=()=>{
console_enabled&&window.parent.mantle_refreshRepository&&window.parent.mantle_refreshRepository(
)},window.getPossibleFileExtensions=()=>[".xanalyzer"],
window.hasUnsavedChanges=()=>{var e=window.location["href"];return!e.includes(
"/viewer")&&cv.getActiveReport().isDirty()},window.linkReport=e=>{e=JSON.parse(
cv.util.sanitizeJSONString(e));cv.getActiveReport().linkDlg.performAction(e)},
window.handle_puc_save=(e,t,n,o,a)=>{let i=a,r=t,l=e;void 0!==i&&null!=i||(i=!1)
var a=r.search(/\.xanalyzer$/),t=(-1!==a&&(r=r.substring(0,a)),a=l.search(
/\/[^/]*\.xanalyzer$/),l=`${l=-1!==a?l.substring(0,a):l}/${r}.xanalyzer`,
cv.util.saveReport(cv.getActiveReport(),"saveAs",r,l,o,i));return!0===t&&(
e=d.encode("{0}",d.encodeRepositoryPath(l)),(a=new URL(window.location.href)
).pathname.includes(e)||(a.searchParams.delete("cube"),a.searchParams.delete(
"catalog"),a.pathname=a.pathname.replace(/(\/repos\/)(.*)(\/editor)/g,`$1${e}$3`
),document.location.replace(a.href)),window.refreshBrowsePanel()),d.encode("{0}"
,l)},window.drill=(e,t,n)=>{let o=!1;try{window.parent.PentahoMobile&&(o=!0)
}catch(e){}var a="drillpopup"+(new Date).getTime(),i=w.byId("drillForm"),n=(
i.setAttribute("action",cv.contextPath+"service/drill"+(n?"CSV":"")),
cv.getActiveReport()),r=(w.byId("drillForm_annotations")&&(r=w.byId(
"drillForm_annotations")).parentNode.removeChild(r),
n.modelAnnotations&&n.modelAnnotations.length&&((r=document.createElement(
"input")).type="text",r.name="annotations",r.id="drillForm_annotations",
r.value=n.getModelAnnotationsJson(),i.appendChild(r)),o?(
r=window.parent.PentahoMobile.openUrl("about:blank","Drill Results"),i.target=r
):(window.open("",a,
"scrollbars=no,menubar=no,height=550,width=800,resizable=yes,toolbar=no,status=no"
),i.setAttribute("target",a)),cv.getActiveReport().reportDoc.getDrillColumns());
if(0===r.length){var l=[],a=new cv.FieldHelp(w.byId("fieldHelpXML").value,
n.manager,!0),d=(
n.modelAnnotations&&n.modelAnnotations.length&&cv.util.updateCatalog(!0,n,a,
n.getModelAnnotationsJson()),a._getFieldListItems());if(0<d.length){for(let e=0,
t=d.length;e<t;++e)cv.FieldHelp().isHidden(d[e])?l[d[e].getAttribute("formula")
]=!1:l[d[e].getAttribute("formula")]=!0;cv.getActiveReport(
).reportDoc.replaceDrillColumns(l)}}let s=w.byId("drillForm_reportXML");
s.setAttribute("value",cv.getActiveReport().getReportXml()),(s=w.byId(
"drillForm_colIndex")).setAttribute("value",e),(s=w.byId("drillForm_rowIndex")
).setAttribute("value",t),i.submit()},e([])));define("pentaho/analyzer/report/report",["../common","./cv_rptConst",
"./cv_rptIO","./cv_rptReport","./cv_rptReport.viz","./cv_rptReport2",
"./cv_rptReport3","./cv_rptGem","./cv_rptDlg","./cv_rptLinkDlg",
"./cv_rptDrillDlg","./cv_rptChartOptionsDlg","./cv_rptPageSetupDlg",
"./cv_rptFilterDlg","./cv_rptArithNumberDlg","./cv_rptCreateMeasureDlg",
"./cv_rptRemoveMeasureDlg","./cv_rptMeasurePropertiesDlg",
"./cv_rptAttributePropertiesDlg","./cv_rptFilterMetricDlg",
"./cv_rptDatePickerDlg","./cv_rptDoc","./cv_rptDnd","./cv_rptFieldHelp",
"./cv_rptResize","./cv_rptHeaders","./cv_pentaho"],function(){});define("pentaho/analyzer/main",["./oss-module","./common","./report/report"],
function(){});define("pentaho/analyzer/report/editor.js.uncompressed",["dojo/_base/declare",
"dojo/on","dojo/query","dojo/_base/lang","dijit/Menu","dojox/fx","dojo/dom",
"pentaho/common/propertiesPanel/Configuration","../LayoutPanel","dojo/fx/easing"
,"./report","dojo/html","dijit/registry","dijit/popup","dojo/dom-class",
"dojo/_base/array","dojo/request","dojo/dom-geometry","dojo/_base/event",
"dijit/MenuSeparator","dijit/PopupMenuItem","dojo/aspect","dojo/string",
"pentaho/common/Messages","pentaho/environment","common-ui/util/_a11y",
"pentaho/util/arg"],(e,s,t,d,i,o,n,r,a,l,c,h,p,u,m,g,v,w,y,b,R,P,M,f,C,A,F)=>{
const S="xanalyzer";e=e("cv.ReportEditor",null,{constructor(){this.report=null,
this.fieldHelp=null,this.isShowingFieldList=!1,this.isInitialModelAnnotations=!0
,this.handles=[]},own(...e){return this.handles.push(...e),e},
MIN_REPORT_HEIGHT:100,init(){this.isAdministrator="true"===n.byId(
"isAdministrator").value,this.applyReportContextInFilterDialog="true"===n.byId(
"applyReportContextInFilterDialog").value,
this.disableDrillLinks="true"===n.byId("disableDrillLinks").value;
const r=0<=window.location.search.indexOf("area="
)||0<=window.location.search.indexOf("command=new");var e=n.byId("reportXML"
).value;if(!e){var t=cv.util.getURLQueryValue("path");if(t
)return cv.util.alertErrorOnPageOpen(cv.util.substituteParams(
cvCatalog.errorBadReport,t),"../")}window.name="cvviewrpt",
cv.contentMinWidth=600;t=n.byId("reportContainer");this.report=new cv.Report({
id:"RPT001",mode:"EDIT",catalog:n.byId("REPORT_catalog").value,cube:n.byId(
"REPORT_cube").value,reportXml:e,containerNode:t,manager:this,
uiController:"updateEditCmds",api:cv.api});let i=cv.util.getURLQueryValue(
"fieldListView");return"CMDVIEWCATEGORY"!==(i=i&&i.toUpperCase()
)&&"CMDVIEWNAME"!==i&&"CMDVIEWTYPE"!==i&&"CMDVIEWSCHEMA"!==i&&(
e=this.report.reportDoc.getUIAttributes(),i=e.getAttribute("fieldListView")),
cv.prefs.fieldListView=i,this.fieldHelp=new cv.FieldHelp(n.byId("fieldHelpXML"
).value,this,!1),this.report.init().then(()=>{
this.report.dropTargets.fieldListTrashcan=new cv.TrashAreaDropTarget(n.byId(
"fieldListTrashcan"),{accept:cvConst.dndAcceptedTypes.trashcan,
report:this.report}),cv.popupMenus={fieldViewMenu:[{id:"CMDVIEWCATEGORY",
src:this.fieldHelp,handler:"onViewCategory"},{id:"CMDVIEWSCHEMA",
src:this.fieldHelp,handler:"onViewSchema"},{id:"CMDVIEWTYPE",src:this.fieldHelp,
handler:"onViewType"},{id:"CMDVIEWNAME",src:this.fieldHelp,handler:"onViewName"}
,{id:"CMDSHOWHIDEFIELDS",src:this.fieldHelp,handler:"onShowHideFields"}],
fieldListMenu:[{id:"cmdFieldEdit",src:this.fieldHelp,handler:"onFieldEdit"},{
id:"cmdCreateCalculatedMeasure",src:this.fieldHelp,
handler:"onCreateCalculatedMeasure"},{id:"cmdRemoveMeasure",src:this.fieldHelp,
handler:"onRemoveMeasure"},{id:"cmdMeasureProperties",src:this.fieldHelp,
handler:"onMeasureProperties"},{id:"cmdAttributeProperties",src:this.fieldHelp,
handler:"onAttributeProperties"},{id:"cmdCalculatedMeasureProperties",
src:this.fieldHelp,handler:"onCalculatedMeasureProperties"},{id:"cmdFieldAdd",
src:this.fieldHelp,handler:"onFieldAdd"},{id:"cmdFieldFilter",
src:this.fieldHelp,handler:"onFieldFilter"},{id:"cmdFieldAbout",
src:this.fieldHelp,handler:"onFieldHelp"},{id:"cmdHideField",src:this.fieldHelp,
handler:"onShowHideField"}],exportMenu:[{id:"cmdPDF",
src:this.report.pageSetupDlg,handler:"showPDF"},{id:"cmdExcel",
src:this.report.pageSetupDlg,handler:"showExcel"},{id:"cmdCSV",
src:this.report.pageSetupDlg,handler:"showCSV"}],preFiltersMenu:[{
id:"cmdPreFilterSet",handler:"onSetDefaultFilter"},{id:"cmdPreFilterReset",
handler:"onResetDefaultFilter"},{id:"cmdPreFilterRemove",
handler:"onRemoveDefaultFilter"}],adminMenu:[{id:"cmdReportXml",
src:this.report.rptDlg,handler:"showReportDefinition"},{id:"cmdAdminLog",
src:this,handler:"openQueryLog"},{id:"cmdAdminMDX",src:this,
handler:"openMDXEditor"},{id:"cmdClearCache",src:this,handler:"clearCache"}],
moreActionsMenu:[{id:"cmdProps",src:this.report.rptDlg,handler:"showReportProps"
},{id:"cmdOptions",src:this.report.rptDlg,handler:"showReportOptions"},{
id:"cmdChartProps",src:this.report.chartOptionsDlg,handler:"show"},{
id:"cmdResetReport",src:this.report,handler:"onResetReport"},{
id:"cmdResetColumnSize",handler:"onResetColumnSize"},{id:"cmdReportWordWrap",
handler:"onToggleWordWrap"}],attributePopMenu:[{id:"PM:attrEdit",
src:this.report.rptDlg,handler:"showEditColumn"},{id:"PM:hyperlink",
src:this.report.linkDlg,handler:"show"},{id:"PM:attrSortAZ",
handler:"onGemSortAsc"},{id:"PM:attrSortZA",handler:"onGemSortDesc"},{
id:"PM:attrShowSub",handler:"onGemToggleSubtotal"},{id:"PM:attrFilter",
src:this.report,handler:"showFilterDlg"},{id:"PM:attrFilterRank",
src:this.report,handler:"showFilterDlgRank"},{id:"PM:helpAttr",src:this.report,
handler:"showHelpDlg"},{id:"PM:removeAttr",src:this.report,
handler:"removeCurrentGem"},{id:"PM:wordWrap",handler:"onGemToggleWordWrap"}],
propPopMenu:[{id:"PM:helpProp",src:this.report,handler:"showPropHelpDlg"},{
id:"PM:removeProp",src:this.report,handler:"removeCurrentProp"}],
condFormatMenu:[{id:"PM:condFormat_COLOR_SCALE_G_Y_R",src:this.report,
handler:"onGemConditionalFormatting"},{id:"PM:condFormat_COLOR_SCALE_R_Y_G",
src:this.report,handler:"onGemConditionalFormatting"},{
id:"PM:condFormat_COLOR_SCALE_B_Y_R",src:this.report,
handler:"onGemConditionalFormatting"},{id:"PM:condFormat_COLOR_SCALE_R_Y_B",
src:this.report,handler:"onGemConditionalFormatting"},{
id:"PM:condFormat_DATA_BAR_RED",src:this.report,
handler:"onGemConditionalFormatting"},{id:"PM:condFormat_DATA_BAR_GREEN",
src:this.report,handler:"onGemConditionalFormatting"},{
id:"PM:condFormat_DATA_BAR_BLUE",src:this.report,
handler:"onGemConditionalFormatting"},{id:"PM:condFormat_TREND_ARROW_GR",
src:this.report,handler:"onGemConditionalFormatting"},{
id:"PM:condFormat_TREND_ARROW_RG",src:this.report,
handler:"onGemConditionalFormatting"}],newNumberMenu:[{
id:"PM:editMeasureSummary",src:this.report.rptDlg,
handler:"showEditSummaryMeasure"},{id:"PM:editMeasureArith",
src:this.report.rptDlg,handler:"showEditArithMeasure"},{
id:"PM:editMeasureTrend",src:this.report.rptDlg,handler:"showEditTrendMeasure"},
{id:"PM:summaryMetrics",src:this.report.rptDlg,handler:"showNewSummaryOptions"},
{id:"PM:arithNumber",src:this.report.rptDlg,handler:"showNewArithBuilder"},{
id:"PM:trendNumber",src:this.report.rptDlg,handler:"showNewTrendNumber"}],
measurePopMenu:[{id:"PM:measEdit",src:this.report.rptDlg,
handler:"showEditColumn"},{id:"PM:measSortHiLow",handler:"onGemSortDesc"},{
id:"PM:measSortLowHi",handler:"onGemSortAsc"},{id:"PM:measFilterCond",
src:this.report,handler:"showFilterDlgCondition"},{id:"PM:measFilterRank",
src:this.report,handler:"showFilterDlgRank"},{id:"PM:measSubtotals",
src:this.report.rptDlg,handler:"showSubtotals"},{id:"PM:helpMetric",
src:this.report,handler:"showHelpDlg"},{id:"PM:inChartHideMetric",
handler:"onGemToggleInChart"},{id:"PM:removeMetric",src:this.report,
handler:"removeCurrentGem"},{id:"PM:addCalcMeasureToDataSource",src:this.report,
handler:"addCalcMeasureToDataSource"}],filterPopMenu:[{id:"PM:editFilter",
src:this.report,handler:"showFilterDlg"},{id:"PM:removeFilter",src:this.report,
handler:"removeCurrentGem"},{id:"PM:addFilter",src:this.report,
handler:"showNewFilterDlg"}],grandTotalPopMenu:[{id:"PM:totalNonVisual",
handler:"onRptNonVisualTotal"},{id:"PM:totalHide",handler:"onRptHideGrandTotal"}
]},cv.analyzerProperties["report.mdx.ui.logging"]||p.byId("cmdAdminLog").attr(
"disabled",!0);try{cv.isMobile()&&window.top.PentahoMobile&&p.byId(
"exportMenuItem").setDisabled(!0)}catch(e){}cv.util.initDojoWidget=e=>{switch(
e.declaredClass){case"dijit.Menu":case"analyzer.LeftSidePopupMenu":
"chartTypeMenu"===e.id?cv.util.addChartMenuItems(e).forEach(e=>{
e.onSelectChartType=()=>{u.close(),
this.report.history.updateReportUsingPreviousChartTypeState(this.report,e.id),
this.report._initDisplay("JSON","CUSTOM",e.id),this.report.history.add(
new cv.ReportState("actionChartType")),this.report.refreshReport(),
cv.util.restoreFocus()},this.own(s(e,"Click",d.hitch(e,"onSelectChartType")))}
):this.own(cv.util.connectPopupMenu(this.report,cv.popupMenus[e.id]));break;
case"FloatingPane":"progressPane"===e.id&&this.own(s(n.byId("progressPaneCancel"
),"click",d.hitch(this.report,"cancelReport")))}},this.fieldHelp.init(),
cv.getFieldHelp=()=>this.fieldHelp,cv.getActiveReport=()=>this.report;
cv.api.util._hasInlineModelingPermission()&&!cv.getFieldHelp(
).disableInlineModeling||(n.byId("cmdCreateCalculatedMeasure"
).style.display="none",n.byId("cmdHideField").style.display="none",n.byId(
"fieldListMenuSeparator").style.display="none");var e=cv.util.getURLQueryValue(
"showRepositoryButtons");try{("false"===e||!cv.isMobile(
)&&"true"!==e||window.parent&&window.parent.PentahoMobile&&"true"!==e
)&&cv.api.ui.showRepositoryButtons(!1)}catch(e){}this.cmdNew=n.byId("cmdNew"),
this.cmdOpen=n.byId("cmdOpen"),this.cmdSave=n.byId("cmdSave"),
this.cmdSaveAs=n.byId("cmdSaveAs"),this.cmdBookmark=n.byId("cmdBookmark"),
this.cmdFields=n.byId("cmdFields"),this.cmdFilters=n.byId("cmdFilters"),
this.cmdLayout=n.byId("cmdLayout"),this.cmdShowPivot=n.byId("cmdShowPivot"),
this.cmdShowChart=n.byId("cmdShowChart"),this.cmdSelectChartType=n.byId(
"cmdSelectChartType"),this.cmdToggleRefresh=n.byId("cmdToggleRefresh"),
this.cmdMoreActions=n.byId("cmdMoreActions"),this.cmdUndo=n.byId("cmdUndo"),
this.cmdRedo=n.byId("cmdRedo"),this.fieldList=n.byId("fieldList"),
this.fieldListContent=n.byId("fieldListContent"),this.fieldListWrapper=n.byId(
"fieldListWrapper"),this.mainBorderContainer=p.byId("borderContainer"),
this.reportBorderContainer=p.byId("reportContainerWrapper"),cv.isMobile()&&(
e=p.byId("reportContainerWrapper"),t=p.byId("borderContainer"),i=p.byId(
"reportBtns"),e.removeChild(i),t.addChild(i),g.forEach(["cmdBack","cmdNew",
"cmdOpen","cmdSave","cmdSaveAs","cmdUndo","cmdRedo","cmdFields","cmdFilters",
"cmdLayout","cmdToggleRefresh","cmdMoreActions","cmdShowChart","cmdShowPivot",
"cmdSelectChartType"],e=>{(e=n.byId(e).firstChild)&&m.add(e,"mobile")})),
this.prevShowFieldList=null,this.own(cv.util.initDivButton(this.cmdFields,this,
"onToggleReportPane"),cv.util.initDivButton(this.cmdFilters,this,
"onToggleReportPane"),cv.util.initDivButton(this.cmdLayout,this,
"onToggleReportPane"),cv.util.initDivButton(this.cmdMoreActions,this,
"_toggleMoreActionsMenu"),cv.util.initDivButton(this.cmdUndo,this.report.history
,"undo"),cv.util.initDivButton(this.cmdRedo,this.report.history,"redo"),
cv.util.initDivButton(this.cmdToggleRefresh,this,"onToggleAutoRefresh"),s(
this.cmdShowPivot,"click",d.hitch(this.report,"toggleReportFormat")),s(
this.cmdShowChart,"click",d.hitch(this.report,"toggleReportFormat")),s(
this.cmdSelectChartType,"click",d.hitch(this.report,"toggleChartTypePopupMenu"))
),A.makeAccessibleToggleButton(this.cmdFields,"true"),
A.makeAccessibleToggleButton(this.cmdFilters,"false"),
A.makeAccessibleToggleButton(this.cmdLayout,"true"),
A.makeAccessibleActionButton(this.cmdMoreActions),A.makeAccessibleActionButton(
this.cmdUndo),A.makeAccessibleActionButton(this.cmdRedo),
A.makeAccessibleToggleButton(this.cmdToggleRefresh,"false"),
A.makeAccessibleToggleButton(this.cmdShowPivot,"true"),
A.makeAccessibleToggleButton(this.cmdShowChart,"false"),
A.makeAccessibleActionButton(this.cmdSelectChartType);cv.util.getURLQueryValue(
"showBackButton")&&(e=n.byId("cmdBack"),cv.util.show(e),this.own(
cv.util.initDivButton(e,this,"back")),A.makeAccessibleActionButton(e),
cv.util.show(n.byId("cmdBackSeparator"))),m.contains(this.cmdNew,"hidden")||(
this.own(cv.util.initDivButton(this.cmdNew,this,"newReport"),
cv.util.initDivButton(this.cmdOpen,this,"openReport"),cv.util.initDivButton(
this.cmdSave,this,"gwtSaveReport"),cv.util.initDivButton(this.cmdSaveAs,this,
"gwtSaveAsReport")),A.makeAccessibleActionButton(this.cmdNew),
A.makeAccessibleActionButton(this.cmdOpen),A.makeAccessibleActionButton(
this.cmdSave),A.makeAccessibleActionButton(this.cmdSaveAs)),this.own(
A.makeAccessibleToolbar(n.byId("reportBtns"),{itemFilter:cv.util.isEnabled}),s(
window,"resize",d.hitch(this,"onWindowResize")),s(document,"keydown",d.hitch(
this,"onKey"))),this._updateCmdButtons(),window.onbeforeunload=()=>{try{if(
this.report.isDirty()&&window.top===window.self&&!cv.prefs.skipDirtyAlert
)return cvCatalog.promptDirtyReport}catch(e){}return null},
window.onunload=d.hitch(this,"_onWindowUnload"),
console_enabled&&window.top.mantle_addHandler&&(
this._mantleEventHandle=window.top.mantle_addHandler("GenericEvent",d.hitch(this
,"_onMantleTabCloseEvent")));var t=n.byId("pageLoading");if(
t&&t.parentNode.removeChild(t),this.reportHeight=-1,this.reportWidth=-1,
r?this._updateCmdButtons():this.resize(),this.report.postCreate(),pentahoLoad(),
this.initReportPane(),this.layoutPanel=new analyzer.LayoutPanel,
this.layoutPanel.updatePanel(this.report),cv.isMobile(
)&&window.addEventListener("orientationchange",()=>{this.onWindowResize(),
u.close()}),this.own(P.after(this.reportBorderContainer,"layout",d.hitch(this,
"onResize"))),this.onWindowResize(),this.onResize(),
isRunningIFrameInSameOrigin&&window.inMobile){var i=window.parent.PentahoMobile[
"addToToolbar"];i("left","Save",`css/${window.parent.THEME}/images/ico-save.png`
,()=>{cv.rptEditor.gwtSaveReport()}),i("left","Save As",
`css/${window.parent.THEME}/images/ico-save-as.png`,()=>{
cv.rptEditor.gwtSaveAsReport()}),h.byId("borderContainer").setAttribute(
"data-dojo-props","gutters:false, liveSplitters:false"),h.byId(
"layoutPanelWrapper").setAttribute("data-dojo-props",
"region:'left', layoutPriority:2, splitter:false"),h.byId("fieldListWrapper"
).setAttribute("data-dojo-props",
"region: 'left', layoutPriority:1, gutters:false, liveSplitters:false, splitter:false"
);const o=this.mainBorderContainer;setInterval(()=>{try{for(
const r of window.parent.document.getElementsByTagName("IFRAME"))if(!(
r.contentWindow===window)){var e=parseInt(r.getAttribute("width"),10
)||r.clientWidth,t=parseInt(r.getAttribute("height"),10)||r.clientHeight,
i=parseInt(o.domNode.style.width,10);5<Math.abs(i-e)&&(o.domNode.setAttribute(
"style",`width:${e}px !important; height : ${t}px !important`),o.layout());break
}}catch(e){alert(e)}},400)}})},onWindowResize(){if(cv.isMobile(
)&&window.inMobile)try{var e,t;for(
const i of window.parent.document.getElementsByTagName("IFRAME")
)i.contentWindow===window&&(e=(e=parseInt(i.getAttribute("width"),10)
)||i.clientWidth,t=(t=parseInt(i.getAttribute("height"),10))||i.clientHeight,
this.mainBorderContainer.domNode.setAttribute("style",
`width:${e}px !important; height : ${t}px !important`),
this.mainBorderContainer.layout())}catch(e){}},_onMantleTabCloseEvent(e){
"tabClosing"===e.eventSubType&&e.stringParam===window.frameElement.id&&this.destroy(
)},_onWindowUnload(){this.destroy()},destroy(){this.report.destroyReport(),
this.report.destroy(),this.layoutPanel.destroy(),this.fieldHelp.destroy(),
window.onbeforeunload=null,(window.onunload=null)!=this._mantleEventHandle&&(
window.top.mantle_removeHandler(this._mantleEventHandle),
this._mantleEventHandle=null)},saveReport(e,t,i,r,o){return cv.util.saveReport(
this.report,e,t,i,r,o)},clearCache(){cv.util.clearCache(this.report)},resize(){
return this.report.resize()},updateEditCmds(){var e=this.report["history"];
this.cmdUndo&&(e.hasUndo()?(cv.util.setButtonDisabled(this.cmdUndo,!1),
this.cmdUndo.title=cv.util.substituteParams(cvCatalog.actionUndo,e.current(
).label)):(cv.util.setButtonDisabled(this.cmdUndo,!0),
this.cmdUndo.title=cv.util.substituteParams(cvCatalog.actionUndo," "))),
this.cmdRedo&&(e.hasRedo()?(cv.util.setButtonDisabled(this.cmdRedo,!1),
this.cmdRedo.title=cv.util.substituteParams(cvCatalog.actionRedo,e.next().label)
):(cv.util.setButtonDisabled(this.cmdRedo,!0),
this.cmdRedo.title=cv.util.substituteParams(cvCatalog.actionRedo," ")))},
_toggleButtonMenu(e,t){var i,r,t=cv.util.getDojoWidget(t);t&&e.target&&(
i=cv.util.getAncestorByClass(e.target,"reportBtn"),r=w.position(i,!0),
cv.util.showPopupMenu(t,r.x+r.w,r.y+r.h,i),y.stop(e))},_toggleMoreActionsMenu(e
){var t,i,r,o,s;cv.util.getDojoWidget("exportMenu")&&cv.util.getDojoWidget(
"preFiltersMenu")&&(t=n.byId("cmdPreFilterRemove"),i=n.byId("cmdPreFilterSet"),
r=n.byId("preFilterSeparator"),this.isAdministrator?(o=cv.util.getDojoWidget(
"adminMenu"),(s=cv.util.getDojoWidget("moreActionsMenu")).getChildren(
).length<13&&(o=new R({label:cvCatalog.popupMenuActionAdmin,popup:o}),
s.addChild(new b),s.addChild(o))):(cv.util.hide(i),cv.util.hide(t),cv.util.hide(
r)),this.report.isDefaultFiltersAvailable()?(cv.util.setMenuItem(
"cmdPreFilterReset","none","enabled"),cv.util.setMenuItem("cmdPreFilterRemove",
"none","enabled")):(cv.util.setMenuItem("cmdPreFilterReset","none","disabled"),
cv.util.setMenuItem("cmdPreFilterRemove","none","disabled")),
0===this.report.getFiltersSummary(this.report.nodeFilters
).length?cv.util.setMenuItem("cmdPreFilterSet","none","disabled"
):cv.util.setMenuItem("cmdPreFilterSet","none","enabled"),
this._toggleButtonMenu(e,"moreActionsMenu"),this.report.isReportFormatPivot()?(
cv.util.setMenuItem("cmdResetColumnSize","none","enabled"),
s=this.report.wordWrap?"checked":"none",cv.util.setMenuItem("cmdReportWordWrap",
s,"enabled")):(cv.util.setMenuItem("cmdResetColumnSize","none","disabled"),
cv.util.setMenuItem("cmdReportWordWrap","none","disabled")))},_togglePanel(e){
e=p.byId(e);""===e.domNode.style.display?(e.domNode.style.display="none",
e._splitterWidget&&(e._splitterWidget.domNode.style.display="none")):(
e.domNode.style.display="",e._splitterWidget&&(
e._splitterWidget.domNode.style.display="")),p.byId("borderContainer").layout(),
this._updateCmdButtons()},_toggleReportPane(e,t,i,r){t?(cv.util.show(e),
i&&o.fadeIn({duration:cv.prefs.fadeTime,node:e}).play(),r&&this.onResize()):i?(
t=o.fadeOut({duration:cv.prefs.fadeTime,node:e}),s(t,"End",e=>{cv.util.hide(e),
r&&this.onResize()}),t.play()):(cv.util.hide(e),r&&this.onResize())},isShowing(e
){return cv.util.isShowing(e)},_updateCmdButtons(){var e;n.byId("reportBtns")&&(
e=this.report["topPaneId"],this.isShowing("fieldListWrapper")?(
this.cmdFields.title=cvCatalog.btnTitleHideFields,m.add(this.cmdFields,
"btnPressed"),this.cmdFields.setAttribute("aria-pressed","true")):(
this.cmdFields.title=cvCatalog.btnTitleShowFields,m.remove(this.cmdFields,
"btnPressed"),this.cmdFields.setAttribute("aria-pressed","false")),
this.cmdFilters&&("filterPane"===e?(
this.cmdFilters.title=cvCatalog.btnTitleHideFilters,m.add(this.cmdFilters,
"btnPressed"),this.cmdFilters.setAttribute("aria-pressed","true")):(
this.cmdFilters.title=cvCatalog.btnTitleShowFilters,m.remove(this.cmdFilters,
"btnPressed"),this.cmdFilters.setAttribute("aria-pressed","false"))),
this.isShowing("layoutPanelWrapper")?(
this.cmdLayout.title=cvCatalog.btnTitleHideLayout,m.add(this.cmdLayout,
"btnPressed"),this.cmdLayout.setAttribute("aria-pressed","true")):(
this.cmdLayout.title=cvCatalog.btnTitleShowLayout,m.remove(this.cmdLayout,
"btnPressed"),this.cmdLayout.setAttribute("aria-pressed","false")),
cv.prefs.autoRefresh?(
this.cmdToggleRefresh.firstChild.title=cvCatalog.disableAutoRefresh,m.remove(
this.cmdToggleRefresh,"btnPressed"),this.cmdToggleRefresh.setAttribute(
"aria-pressed","true")):(
this.cmdToggleRefresh.firstChild.title=cvCatalog.enableAutoRefresh,m.add(
this.cmdToggleRefresh,"btnPressed"),this.cmdToggleRefresh.setAttribute(
"aria-pressed","false")))},onKey(e){if(!(
cv.dlgWidget&&cv.dlgWidget.open||cv.dlgWidget2&&cv.dlgWidget2.open)){
var t=this.report;if(
!e.target||"INPUT"!==e.target.tagName&&"TEXTAREA"!==e.target.tagName){if(
e.ctrlKey||e.altKey){if(e.ctrlKey&&!e.altKey)switch(e.keyCode){case 90:
t.history.undo();break;case 89:t.history.redo();break;case 81:t.onResetReport();
break;default:return}else if(e.ctrlKey&&e.altKey)switch(e.keyCode){case 67:
t.toggleReportFormat();break;case 70:this.toggleReportPane("cmdFields");break;
case 84:this.toggleReportPane("cmdFilters");break;case 89:this.toggleReportPane(
"cmdLayout");break;default:return}else if(!e.ctrlKey&&e.altKey)return
}else switch(e.keyCode){case 33:case 34:case 38:case 40:case 37:case 39:if(
null==t.reportHeaders)return;t.reportHeaders.keyPress(e.key);break;default:
return}y.stop(e)}}},onResize(){this.resize()},initReportPane(){let e=!0,t=!0;
var i,r=this.report.reportDoc.getReportProperty("name");r&&("false"===(
i=this.report.reportDoc.getUIAttributes()).getAttribute("showFieldList")&&(e=!1)
,"false"===i.getAttribute("showFieldLayout"))&&(t=!1),cv.isMobile()&&(
e=r?t=!1:t=!0),cv.util.getURLQueryValue("showFieldList"
)||e||this.toggleReportPane("cmdFields"),cv.util.getURLQueryValue(
"showFieldLayout")||t||this.toggleReportPane("cmdLayout"),
this._updateCmdButtons()},onToggleAutoRefresh(){var e=!cv.prefs.autoRefresh;
this.report.setAutoRefresh(e),e&&!this.report.history.isStateRefreshed(
)&&this.report.refreshReport(!0),this._updateCmdButtons()},onToggleReportPane(e
){let t=e.target;for(;!t.id;)t=t.parentNode;if(this.toggleReportPane(t.id,{
restoreFocus:!0}))return!1},toggleReportPane(e,t){var i=F.optional(t,
"restoreFocus",!1);switch(e){case"cmdFields":this._togglePanel(
"fieldListWrapper"),i&&this.cmdFields.focus();break;case"cmdFilters":
case"FilterPaneToggle":case"FilterPaneTitle":case"FilterCountLabel":
case"ReportSummary":case"HideFilterPane":var r=this.report.byId(
"FilterPaneToggle");r&&(
"filterPane"===this.report.topPaneId||"HideFilterPane"===e?(
this.report.topPaneId="",m.remove(r,"hide"),this._toggleReportPane(
this.report.nodeFilter,!1,!0,!0)):(this.report.topPaneId="filterPane",m.add(r,
"hide"),this._toggleReportPane(this.report.nodeFilter,!0,!0,!0)),i)&&(
"cmdFilters"===e?this.cmdFilters:r).focus();break;case"cmdLayout":
this._togglePanel("layoutPanelWrapper"),i&&this.cmdLayout.focus();break;default:
return!1}return this._updateCmdButtons(),!0},openQueryLog(){window.open(
"service/admin/log")},openMDXEditor(){
var e=`service/admin/mdx?catalog=${this.report.reportDoc.getReportOption(
"catalog")}&cube=`+this.report.reportDoc.getReportOption("cube");window.open(e)
},back(){window.history.back()},newReport(){
var e=/showRepositoryButtons=true/.test(window.location.href);
window.location.href=`../${S}/service/selectSchema`+(
e?"?showRepositoryButtons=true":"")},openReport(){openFileChooserDialog({
fileSelected(e,t,i){i.indexOf(S)<0?alert(
"You can currently only open Analyzer files"):(i=t.replace(/\//g,":"),
t=/showRepositoryButtons=true/.test(window.location.href),
window.location.href=`${window.CONTEXT_PATH}api/repos/${encodeURIComponent(i
)}/editor`+(t?"?showRepositoryButtons=true":""))},dialogCanceled(){}})},
saveModifiedModel(){console.log("saveModifiedModel");var e,t=this.report[
"catalog"],i=this.report["cube"];return null!=t&&((e={}).catalog=t,e.cube=i,
e.annotations=this.report.getModelAnnotationsJson(),e.overwrite=!0,(
t=cv.util.parseAjaxMsg(cv.io.ajaxLoad("service/modeling/save",e,!0,null,!0))
)&&"error"===t.type?void cv.Dialog().showError(f.getString(
"errorSavingModelChanges")):(this.report.modelAnnotations=[],
this.report.history.undoStack.clear(),this.report.history.add(
new cv.ReportState("")),cv.getActiveReport().manager.saveReport(
this.report.pendingSaveParams.reportAction,
this.report.pendingSaveParams.reportName,
this.report.pendingSaveParams.reportPath,
this.report.pendingSaveParams.reportErrorCallback,
this.report.pendingSaveParams.suppressSuccessNotification),
this.report.pendingSaveParams={},!0))},gwtSaveAsReport(e){if(!this.saveAsOpen){
this.saveAsOpen=!0;e=null!=e&&e?saveFileChooserDialog:saveAsFileChooserDialog;
const s=this;e({fileSelected(e,t,i){let r=t,o=(-1!==t.indexOf("."+S)&&t.indexOf(
"."+S)===t.length-10&&(r=t.substring(0,t.lastIndexOf("/"))),i);-1!==i.indexOf(
"."+S)&&i.indexOf("."+S)===i.length-10&&(o=i.substr(0,i.length-10)),
cv.getActiveReport().reportDoc.setReportProperty("name",unescape(o.replace("+",
"%20")));t=`${r}/${o}.`+S,cv.getActiveReport().reportDoc.setReportProperty(
"folder",unescape(t.replace("+","%20"))),i=cv.util.saveReport(
cv.getActiveReport(),"saveAs",o,t,()=>{cv.util.showStatus("errorSaveReport",
"ERROR")},!0);if(!0===i){refreshBrowsePanel();try{if(
window.parent.PentahoMobile.refreshBrowser(),window.parent.PentahoMobile){
window.parent.PentahoMobile.updateTitleOfCurrentItem(myFilename,
`${mySolution+myPath}/${myFilename}.`+S);let e=window.location.href;
e=`${e.substring(0,e.indexOf("editor?")
)}editor?command=open&solution=${encodeURIComponent(mySolution
)}&path=${encodeURIComponent(myPath)}&action=${encodeURIComponent(myFilename
)}.`+S,window.parent.PentahoMobile.setLocationOfCurrentItem(e),
window.parent.PentahoMobile.setPathOfCurrentItem("/"+t),
window.parent.PentahoMobile.updateFavoriteofCurrentItem()}}catch(e){}}
s.saveAsOpen=!1},dialogCanceled(){s.saveAsOpen=!1}},C.user.home)}},
gwtSaveReport(){var e,t=cv.getActiveReport().reportDoc.getReportProperty("name")
t?(e=cv.getActiveReport().reportDoc.getReportProperty("folder"),
cv.util.saveReport(cv.getActiveReport(),"saveAs",t,e,()=>{cv.util.showStatus(
"errorSaveReport","ERROR")},!0)):this.gwtSaveAsReport(!0)},updateCatalog(e){
var t=this.report.getModelAnnotationsJson(),e=cv.util.updateCatalog(e,
this.report,this.fieldHelp,t);return void 0===e&&(n.byId("analysisArea"
).innerHTML=this.report.cube),
this.report.modelAnnotations.length&&t&&this.isInitialModelAnnotations&&void 0===e&&(
this.isInitialModelAnnotations=!1,cv.util.showStatus("notificationModelChange",
"INFO")),e}});return cv.rptEditor=new cv.ReportEditor,e});define("pentaho/analyzer/analyzer-editor",["require",
"pentaho/i18n!./resources/messages","pentaho/common/Messages","./main",
"./report/editor.js.uncompressed","./viz-plugins"],function(e,o,n){n.addBundle(
"analyzer",o.source),document.getElementById("borderContainer").style.display=""
,e(["dojo/parser","dojo/ready","dojo/_base/window","dojo/on","dojo/dom"],
function(e,o,n){e.parse().then(function(){o(function(){cv.rptEditor.init().then(
function(){dojoConfig.isDebug=!0,cv.prefs.isDebug=!0,
n.doc.documentElement.style.overflow="hidden"})})})})});