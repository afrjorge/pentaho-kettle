define("pentaho/analyzer/cv_api_report_util",["dojo/_base/lang"],function(n){
return function(a){var r={_BasicOptionType:function(e){this.type=e,
this.validateValue=function(e,t){t&&typeof t===this.type.toLowerCase(
)||a.log.error(p._errors.INVALID_OPTION_VALUE_TYPE(e,t,this.type),!0)}},
_StringOptionType:function(){this.base=r._BasicOptionType,this.base("String")},
_BooleanOptionType:function(){this.type="Boolean",this.validateValue=function(e,
t){"boolean"!=typeof t&&"true"!==t&&"false"!==t&&a.log.error(
p._errors.INVALID_OPTION_VALUE_TYPE(e,t,this.type),!0)}},
_DoubleOptionType:function(){this.type="Double",this.validateValue=function(e,t
){/^\-?(\d+|\d+\.\d*|\.\d+)$/.test(t)||a.log.error(
p._errors.INVALID_OPTION_VALUE_TYPE(e,t,this.type),!0)}},
_IntegerOptionType:function(){this.type="Integer",this.validateValue=function(e,
t){/^\d+$/.test(t)||a.log.error(p._errors.INVALID_OPTION_VALUE_TYPE(e,t,
this.type),!0)}},_HexOptionType:function(){this.type="Hex",
this.validateValue=function(e,t){/(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(t
)||a.log.error(p._errors.INVALID_OPTION_VALUE_TYPE(e,t,this.type),!0)}},
_ArrayOptionType:function(){this.type="Array",this.validateValue=function(e,t){
Array.isArray||(Array.isArray=function(e){
return"[object Array]"===Object.prototype.toString.call(e)}),Array.isArray(t
)||a.log.error(p._errors.INVALID_OPTION_VALUE_TYPE(e,t,this.type),!0)}},
_FunctionOptionType:function(){this.type="Function",this.validateValue=function(
e,t){n.isFunction(t)||a.log.error(p._errors.INVALID_OPTION_VALUE_TYPE(e,t,
this.type),!0)}},_BasicOption:function(e){this.name=e.name,this.type=e.type,
this.expectedValues=e.expectedValues,
this.postValidateAction=e.postValidateAction,
this.validateValue=void 0!==e.validateValue?e.validateValue:function(e){
return this.expectedValues&&-1==this.expectedValues.indexOf(e)?a.log.error(
p._errors.INVALID_OPTION_VALUE(this.name,e,this.expectedValues),!0
):!this.expectedValues&&this.type&&this.type.validateValue(this.name,e),
this.postValidateAction?this.postValidateAction(e):e}},_FieldOption:function(e){
this.base=r._BasicOption,this.base(e),this.appliedTo=e.appliedTo,
this.getFieldOptionHandler=void 0!==e.getFieldOptionHandler?e.getFieldOptionHandler:function(
e,t,n){var o=null,e=e.getNode(t);return e?o=e.getAttribute(this.name
):a.log.warn(p._errors.NODE_NOT_FOUND(n)),o},
this.setFieldOptionHandler=void 0!==e.setFieldOptionHandler?e.setFieldOptionHandler:function(
e,t,n,o){e=e.getNode(t);e?e.setAttribute(this.name,o):a.log.warn(
p._errors.NODE_NOT_FOUND(n))}},_FormatFieldOption:function(e){
e.appliedTo="measure",e.setFieldOptionHandler=function(e,t,n,o){var i,
t=e.getNode(t);t?((i={})[this.name]=o,e.setNumberFormat(t,i)):a.log.warn(
p._errors.NODE_NOT_FOUND(n))},this.base=r._FieldOption,this.base(e)},
_MeasureBooleanFieldOption:function(e){e.type=new r._BooleanOptionType,
e.appliedTo="measure",this.base=r._FieldOption,this.base(e)},
_ReportOption:function(e){e.type||(e.type=new r._BooleanOptionType),
this.base=r._BasicOption,this.base(e),
this.getReportOptionHandler=void 0!==e.getReportOptionHandler?e.getReportOptionHandler:function(
e){return e.reportDoc.getReportOption(this.name)},
this.setReportOptionHandler=void 0!==e.setReportOptionHandler?e.setReportOptionHandler:function(
e,t){e.reportDoc.setReportOption(this.name,t)}},_ChartOption:function(e){
this.base=r._BasicOption,this.base(e),
this.getChartOptionHandler=void 0!==e.getChartOptionHandler?e.getChartOptionHandler:function(
e){return e.reportDoc.getChartOption(this.name)},
this.setChartOptionHandler=void 0!==e.setChartOptionHandler?e.setChartOptionHandler:function(
e,t){e.reportDoc.setChartOption(this.name,t)}}},p={_errors:{
INVALID_OPTION_NAME:function(e,t){
return"Unexpected option '"+e+"'. One of the following are acceptable values: "+t
},INVALID_OPTION_VALUE:function(e,t,n){
return"Unexpected value '"+t+"' for option '"+e+"'. One of the following are acceptable values: "+n
},INVALID_OPTION_VALUE_TYPE:function(e,t,n){
return"Unexpected value '"+t+"' for option '"+e+"'. Must be type "+n},
NODE_NOT_FOUND:function(e){return"Node was not found for formula '"+e+"'."},
WRONG_NESTED_OBJECT:"Nested object must have 'name' property."},_fieldOptions:{
label:new r._FieldOption({name:"label",type:new r._StringOptionType,
setFieldOptionHandler:function(e,t,n,o){t=e.getNode(t);t?e.updateDisplayLabel(t,
o):a.log.warn(p._errors.NODE_NOT_FOUND(n))}}),sortOrderEnum:new r._FieldOption({
name:"sortOrderEnum",expectedValues:["NONE","ASC","DESC"]}),
showAggregate:new r._MeasureBooleanFieldOption({name:"showAggregate"}),
showSum:new r._MeasureBooleanFieldOption({name:"showSum"}),
showAverage:new r._MeasureBooleanFieldOption({name:"showAverage"}),
showMin:new r._MeasureBooleanFieldOption({name:"showMin"}),
showMax:new r._MeasureBooleanFieldOption({name:"showMax"}),
formatShortcut:new r._FormatFieldOption({name:"formatShortcut",expectedValues:[
"NONE","COLOR_SCALE_G_Y_R","COLOR_SCALE_R_Y_G","COLOR_SCALE_B_Y_R",
"COLOR_SCALE_R_Y_B","TREND_ARROW_GR","TREND_ARROW_RG","DATA_BAR_RED",
"DATA_BAR_GREEN","DATA_BAR_BLUE"]}),formatCategory:new r._FormatFieldOption({
name:"formatCategory",expectedValues:["Default","General Number","Currency ($)",
"Percentage (%)","Expression"]}),formatScale:new r._FormatFieldOption({
name:"formatScale",expectedValues:["0","1","2","3","4","5","6","7","8","9","10"]
}),formatExpression:new r._FormatFieldOption({name:"formatExpression",
type:new r._StringOptionType}),currencySymbol:new r._FormatFieldOption({
name:"currencySymbol",type:new r._StringOptionType}),
showSubtotal:new r._FieldOption({name:"showSubtotal",appliedTo:"attribute",
type:new r._BooleanOptionType}),wordWrap:new r._FieldOption({name:"wordWrap",
appliedTo:"attribute",type:new r._BooleanOptionType})},_reportOptions:{
showRowGrandTotal:new r._ReportOption({name:"showRowGrandTotal"}),
showColumnGrandTotal:new r._ReportOption({name:"showColumnGrandTotal"}),
useNonVisualTotals:new r._ReportOption({name:"useNonVisualTotals"}),
showEmptyCells:new r._ReportOption({name:"showEmptyCells"}),
showEmptyEnum:new r._ReportOption({name:"showEmptyEnum",
type:new r._StringOptionType,expectedValues:["SHOW_MEASURE",
"SHOW_CALCULATED_MEASURE","SHOW_EMPTY"]}),showDrillLinks:new r._ReportOption({
name:"showDrillLinks"}),autoRefresh:new r._ReportOption({name:"autoRefresh",
setReportOptionHandler:function(e,t){(!0===t||"true"===t
)!==cv.prefs.autoRefresh&&e.manager.onToggleAutoRefresh()}}),
freezeColumns:new r._ReportOption({name:"freezeColumns"}),
freezeRows:new r._ReportOption({name:"freezeRows"}),catalog:new r._ReportOption(
{name:"catalog",type:new r._StringOptionType}),cube:new r._ReportOption({
name:"cube",type:new r._StringOptionType}),cellLimit:new r._ReportOption({
name:"cellLimit",type:new r._IntegerOptionType})},_chartOptions:{
legendPosition:new r._ChartOption({name:"legendPosition",expectedValues:["TOP",
"RIGHT","BOTTOM","LEFT"]}),showLegend:new r._ChartOption({name:"showLegend",
type:new r._BooleanOptionType}),autoRange:new r._ChartOption({name:"autoRange",
type:new r._BooleanOptionType}),valueAxisLowerLimit:new r._ChartOption({
name:"valueAxisLowerLimit",type:new r._DoubleOptionType}),
valueAxisUpperLimit:new r._ChartOption({name:"valueAxisUpperLimit",
type:new r._DoubleOptionType}),displayUnits:new r._ChartOption({
name:"displayUnits",expectedValues:["UNITS_0","UNITS_2","UNITS_3","UNITS_4",
"UNITS_5","UNITS_6"]}),autoRangeSecondary:new r._ChartOption({
name:"autoRangeSecondary",type:new r._BooleanOptionType}),
valueAxisLowerLimitSecondary:new r._ChartOption({
name:"valueAxisLowerLimitSecondary",type:new r._DoubleOptionType}),
valueAxisUpperLimitSecondary:new r._ChartOption({
name:"valueAxisUpperLimitSecondary",type:new r._DoubleOptionType}),
displayUnitsSecondary:new r._ChartOption({name:"displayUnitsSecondary",
expectedValues:["UNITS_0","UNITS_2","UNITS_3","UNITS_4","UNITS_5","UNITS_6"]}),
maxValues:new r._ChartOption({name:"maxValues",type:new r._IntegerOptionType,
postValidateAction:function(e){var t=a.report._getReport(
)._getVizApplicationSpec().maxValues;return a.util._findClosestValueFromArray(t,
e)}}),backgroundColor:new r._ChartOption({name:"backgroundColor",
type:new r._HexOptionType}),labelColor:new r._ChartOption({name:"labelColor",
type:new r._HexOptionType}),labelSize:new r._ChartOption({name:"labelSize",
type:new r._IntegerOptionType,postValidateAction:function(e){
return a.util._findClosestValueFromArray([7,8,9,10,11,12,14,16,18,20,24,28,32,36
,40],e)}}),backgroundFill:new r._ChartOption({name:"backgroundFill",
expectedValues:["NONE","SOLID","GRADIENT"]}),maxChartsPerRow:new r._ChartOption(
{name:"maxChartsPerRow",type:new r._IntegerOptionType,
postValidateAction:function(e){return a.util._findClosestValueFromArray([1,2,3,4
,5],e)}}),multiChartMax:new r._ChartOption({name:"multiChartMax",
type:new r._IntegerOptionType,postValidateAction:function(e){
var t=a.report._getReport().getVizMultiChartMaxList();
return a.util._findClosestValueFromArray(t,e)}}),
multiChartRangeScope:new r._ChartOption({name:"multiChartRangeScope",
expectedValues:["GLOBAL","CELL"]}),emptyCellMode:new r._ChartOption({
name:"emptyCellMode",expectedValues:["GAP","ZERO","LINEAR"]}),
sizeByNegativesMode:new r._ChartOption({name:"sizeByNegativesMode",
expectedValues:["NEG_LOWEST","USE_ABS"]}),backgroundColorEnd:new r._ChartOption(
{name:"backgroundColorEnd",type:new r._HexOptionType}),
labelStyle:new r._ChartOption({name:"labelStyle",expectedValues:["PLAIN","BOLD",
"ITALIC"]}),legendBackgroundColor:new r._ChartOption({
name:"legendBackgroundColor",type:new r._HexOptionType}),
legendSize:new r._ChartOption({name:"legendSize",type:new r._IntegerOptionType,
postValidateAction:function(e){return a.util._findClosestValueFromArray([7,8,9,
10,11,12,14,16,18,20,24,28,32,36,40],e)}}),legendColor:new r._ChartOption({
name:"legendColor",type:new r._HexOptionType}),legendStyle:new r._ChartOption({
name:"legendStyle",expectedValues:["PLAIN","BOLD","ITALIC"]}),
labelFontFamily:new r._ChartOption({name:"labelFontFamily",
type:new r._StringOptionType}),legendFontFamily:new r._ChartOption({
name:"legendFontFamily",type:new r._StringOptionType})}},e={
_getNestedObjectByName:function(e,t){(new r._StringOptionType).validateValue(
"name",t);var n,o=[];for(n in e){var i=e[n];if(i.name||a.log.error(
p._errors.WRONG_NESTED_OBJECT,!0),i.name==t)return i;o.push(i.name)}a.log.error(
p._errors.INVALID_OPTION_NAME(t,o),!0)},_addHistory:function(e,t){t.history.add(
new cv.ReportState(e)),t.setReportPropsDirty(!0)}};this.types=r,this.constants=p
,this.utilities=e}});define("pentaho/analyzer/cv_api_report",["dojox/collections/Dictionary",
"dojox/xml/parser","dojo/query","dojo/dom-construct","dojo/_base/event",
"./cv_api_report_util"],function(u,t,r,h,d,e){return function(c,t){
this._apiReportUtil=new e(c),this._attachedReport=t,this._query=function(t,e){
return r(t,e)},this._isValidGembarId=function(t){var e=c.ui.listGembarIds(),
r=-1<e.indexOf(t);return r||c.log.error(this._errors.INVALID_GEMBARID(t,e),!0),r
},this._isValidGembarType=function(t,e){var r=!1,i=cv.getFieldHelp(),
o="NUMBER"===i.get(e,"type"),a=!o,i=a&&i.hasStartDateTimeKey(e),
e=this._getReport(),n=e.vizModelAdapter,t=n.$type.get(t,!0);
return r=null!==t&&n.$type.isVisualRole(t)&&(
a&&t.hasAnyCategoricalModes||o&&t.hasAnyModes({isContinuous:!0,
elementDataType:"number"})||i&&t.hasAnyModes({isContinuous:!0,
elementDataType:"date"}))?e.findGemsByGembarId(t.name
).length<t.fields.countRangeOn(n,{ignoreCurrentMode:!0}).max:r},
this._isValidField=function(t,e){return this._isValidGembarType(t,e
)&&this._getReport().validateField(e)&&this._getReport().checkDuplicateGem(e,!0)
},this._insertFieldFromFormula=function(t,e,r,i){this._isValidField(t,e
)?this._getReport().insertField(t,r,void 0===i?-1:i,{formula:e},!0):c.log.error(
this._errors.INVALID_FORMULA(t,e))},this._isValidVizId=function(t){var e,r;
return"pivot"===t||((r=-1<(e=c.ui.listVizIds()).indexOf(t))||c.log.error(
this._errors.INVALID_VIZ_ID(t,e),!0),r)},this._errors={
INVALID_GEMBARID:function(t,e){
return"'"+t+"' is an invalid gembarId. Valid values for current visualization are "+e
},
INVALID_GEMBAR_ORDINAL:"Gembar Ordinal must be a number and greater than or equal to -1",
NO_REPORT_SET:"There is no valid report set to the report editor",
INVALID_FORMULAS_TYPE_ARRAY:"'formulas' must be an Array. e.g. ['[TYPE].[VALUE1]', '[TYPE].[VALUE2]']",
INVALID_FORMULA:function(t,e){
return"'"+e+"' is an invalid formula for gembar '"+t+"'"},
INVALID_VIZ_ID:function(t,e){
return"'"+t+"' is not a registered visualization id. Valid values for are "+e},
INVALID_CATALOG_OR_CUBE:function(t,e){
return"Catalog: '"+t+"' or Cube: '"+e+"' is invalid."},INVALID_FIELD:function(t
){return"'"+t+"' is an invalid formula."},EMPTY_CELLS_FOR_LINK:function(t){
return"The cells are not present in the page to have the field link set on them for formula '"+t+"'."
},
INVALID_VIZ_FOR_SETTING_LINK:"The API 'setFieldLink' is available for only 'pivot' vizualization.",
INVALID_OPER_REPORT_ATTACHED:"The API object is already attached to another report instance.",
DEPRECATED_SHOW_EMPTY:"'showEmptyCells' report option is being deprecated for 'showEmptyEnum'. Please refer to Analyzer's API documentation for further explanation."
},this._attachReport=function(t){if(this._attachedReport){if(
this._attachedReport!==t)throw new Error(
this._errors.INVALID_OPER_REPORT_ATTACHED)}else this._attachedReport=t},
this._getReport=function(){var t=this._attachedReport;return(
t=void 0===t?"undefined"==typeof cv?t:cv.getActiveReport():t)||c.log.warn(
this._errors.NO_REPORT_SET),t},this._validateParamsForSetFieldLink=function(t,e,
r){var i=!0;return(new this._apiReportUtil.types._StringOptionType
).validateValue("formula",t),r.validateField(t)||c.log.error(
this._errors.INVALID_FIELD(t),!0),(
new this._apiReportUtil.types._FunctionOptionType).validateValue("callback",e),
"pivot"!==this.getVizId()&&(c.log.warn(this._errors.INVALID_VIZ_FOR_SETTING_LINK
),i=!1),i},this.getLayoutFields=function(t){var e=[],r=this._getReport();
return r&&this._isValidGembarId(t)&&r.findGemsByGembarId(t).forEach(function(t){
e.push(t.getFormula())}),e},this.setLayoutFields=function(e,t){
var r=this._getReport();if(r&&this._isValidGembarId(e)&&((
new this._apiReportUtil.types._ArrayOptionType).validateValue("formulas",t),
0<t.length)){var i=r.findGemsByGembarId(e);i.forEach(function(t){r.removeGem(t,
!0,null,!0)},this);for(var o=0;o<t.length;++o)this._insertFieldFromFormula(e,t[o
],0,-1);r.findGemsByGembarId(e).length<=0&&i.forEach(function(t){
this._insertFieldFromFormula(e,t.getFormula(),0,-1)},this)}},
this.addLayoutField=function(t,e,r){var i=this._getReport();if(
i&&this._isValidGembarId(t)){for(var o=i.findGemsByGembarId(t),a=(
"number"!=typeof r||r<-1?c.log.error(this._errors.INVALID_GEMBAR_ORDINAL,!0):(
-1===r||r>o.length)&&(r=o.length),-1),n=0;n<o.length;n++)o[n].getFormula(
)===e&&(a=n);this._insertFieldFromFormula(t,e,r,a)}},
this.removeLayoutField=function(t,e){var r=this._getReport();
r&&this._isValidGembarId(t)&&r.findGemsByGembarId(t).forEach(function(t){
t.getFormula()===e&&r.removeGem(t,!0,null,!0)})},this.getName=function(){
var t=null,e=this._getReport();
return t=e&&e.reportDoc?e.reportDoc.getReportProperty("name"):t},
this.getPath=function(){var t=null,e=this._getReport();
return t=e&&e.reportDoc?e.reportDoc.getReportProperty("folder"):t},
this.getNumericFilters=function(){var t={filters:{}},e=this._getReport();if(e){
e=e.reportDoc;if(e){var r=e.getMetricFilter();if(r&&r.conditions&&r.formula){
var i=r.formula;t.filters[i]=[],r.rank&&((a={}).count=r.rank.count,
a.formula=r.rank.formula,a.operator=r.rank.type,t.filters[i].push(a));for(
var o=0;o<r.conditions.length;o++){var a={},n=r.conditions[o];
a.operator=n.operator,a.formula=n.formula,a.op1=n.op1,a.op2=n.op2,t.filters[i
].push(a)}}}}return t},this.setNumericFilters=function(t,e){
var r=this._getReport();if(r){var i=r.reportDoc;if(i){(
new this._apiReportUtil.types._StringOptionType).validateValue("level",t);(
new this._apiReportUtil.types._ArrayOptionType).validateValue("filterItems",e);
var o={type:"FILTER_METRIC"};o.conditions=[],o.formula=t;for(
var a=0;a<e.length;a++){var n=e[a],s=n.operator;
"TOP"==s||"BOTTOM"==s||"TOP_BOTTOM"==s?(o.rank={},o.rank.type=s,
o.rank.formula=n.formula,o.rank.count=n.count):((s={}).formula=n.formula,
s.op1=n.op1,s.op2=n.op2,s.operator=n.operator,o.conditions.push(s))}
var l=i.getMetricFilter();o.old=l?l.formula:t,i.updateFilter(o),
r.populateFilters(),this._apiReportUtil.utilities._addHistory(
"API numeric filter on "+t,r)}}},this.getSelectionFilters=function(){var t={
selectionFilters:[]},e=this._getReport();if(e){var r=e.reportDoc;if(r){for(
var i=r.getSelectionFilters(),o=[],a=0;a<i.length;a++){
var n=r.getSelectionFilterProps(i[a]);o.push(n)}for(a=0;a<o.length;a++){var s=o[
a].op,l=[],p=o[a].members;if(p){for(var u=0;u<p.length;u++){var c={formula:p[u
].formula,member:p[u].member};l.push(c)}n={operator:s,members:l};
t.selectionFilters.push(n)}}}}return t},this.addSelectionFilter=function(t){
var e=this._getReport();if(e){var r=e.reportDoc;if(r){for(var i={op:t.operator,
members:[]},o="",a=0;a<t.members.length;a++){var n=t.members[a],n=(
a<t.members.length-1?o+=n.formula+", ":o+=n.formula,{formula:n.formula,
member:n.member});i.members.push(n)}r.addSelectionFilter(i),
this._apiReportUtil.utilities._addHistory(o,e)}}},
this.addSelectionFilters=function(t){var e=this._getReport();if(e&&e.reportDoc
)for(var r=0;r<t.length;r++)this.addSelectionFilter(t[r])},
this.removeSelectionFilters=function(t){var e=this._getReport();e&&(
e.removeSelectionFilters(t),this._apiReportUtil.utilities._addHistory(
"API remove selection filters",e))},this.getFilters=function(){var t={filters:{}
},e=this._getReport();if(e){var r=e.reportDoc;if(r){for(var i={},
o=r.getChildMembers("filters"),a=[],n=0;n<o.length;n++){var s=r.getFilterProps(
o[n]);a.push(s)}for(n=0;n<a.length;n++){var l=a[n].formula,p=[];if(a[n
].predicates)for(var u=a[n].predicates.getValueList(),c=0;c<u.length;c++){for(
var h=0;h<u[c].length;h++){var d=[],_={},m=u[c][h].op,f=u[c][h].op1,v=u[c][h
].op2;_.operator=m,f&&(_.op1=f),v&&(_.op2=v),u[c][h].parameterName&&(
_.parameterName=u[c][h].parameterName),d="CONTAIN"==m||"NOT_CONTAIN"==m?u[c][h
].exp:u[c][h].members,_.members=d,p.push(_)}i[l]=p}}t.filters=i}}return t},
this.setFilters=function(t,e,r){var i=this._getReport();if(i){var o=i.reportDoc;
if(o){(new this._apiReportUtil.types._StringOptionType).validateValue("level",t)
;(new this._apiReportUtil.types._ArrayOptionType).validateValue("filterItems",e)
for(var a={formula:t,predicates:new u},n="",s=0;s<e.length;s++){var l=e[s],p=(
s<e.length-1?n+=l.parameterName+", ":n+=l.parameterName,{op:l.operator,
members:l.members,parameterName:l.parameterName});l.op1&&(p.op1=l.op1),l.op2&&(
p.op2=l.op2),"CONTAIN"!=p.op&&"NOT_CONTAIN"!=p.op||(p.exp=l.members,
p.containsRegExp=l.containsRegExp,delete p.members),a.predicates.add(s,[p])}
o.updateFilter(a,r),i.populateFilters(),
this._apiReportUtil.utilities._addHistory(n,i)}}},this.removeFilters=function(t
){var e=this._getReport();e&&(e.removeFilter("filter_"+t+"_99",!0),
this._apiReportUtil.utilities._addHistory("API remove filter on "+t,e))},
this.removeNumericFilters=function(){var t=this._getReport();t&&(t.removeFilter(
"filter_metric_0",!0),this._apiReportUtil.utilities._addHistory(
"API remove filter",t))},this.getVizId=function(){var t=this._getReport();if(t
)return"PIVOT"==t.getReportFormat()?"pivot":t.reportDoc.getChartOption(
"customChartType")},this.setVizId=function(t){c.util._validateModeForAPI(
arguments.callee);var e=this._getReport();e&&this._isValidVizId(t)&&(
"pivot"===t?e._initDisplay("PIVOT"):e._initDisplay("JSON","CUSTOM",t))},
this.getFieldOption=function(t,e){var r=null,i=this._getReport();if(
i&&i.reportDoc){var o=new this._apiReportUtil.types._StringOptionType,a=(
o.validateValue("formula",t),o.validateValue("name",e),
this._apiReportUtil.utilities._getNestedObjectByName(
this._apiReportUtil.constants._fieldOptions,e));switch(e){case"label":
r=a.getFieldOptionHandler(i.reportDoc,
'cv:report//*[@formula="'+t+'"]/cv:displayLabels/cv:displayLabel',t);break;
case"formatCategory":case"formatScale":case"formatShortcut":
case"currencySymbol":r=a.getFieldOptionHandler(i.reportDoc,
'cv:report//*[@formula="'+t+'"]/cv:numberFormat',t);break;
case"formatExpression":r=a.getFieldOptionHandler(i.reportDoc,
'cv:report//*[@formula="'+t+'"]/cv:numberFormat/cv:formatExpression',t);break;
default:r=a.getFieldOptionHandler(i.reportDoc,'cv:report//*[@formula="'+t+'"]',t
)}}return r},this.setFieldOption=function(t,e,r){var i=this._getReport();if(
i&&i.reportDoc){var o=new this._apiReportUtil.types._StringOptionType,a=(
o.validateValue("formula",t),o.validateValue("name",e),
this._apiReportUtil.utilities._getNestedObjectByName(
this._apiReportUtil.constants._fieldOptions,e)),n=a.validateValue(r);switch(
a.appliedTo){case"measure":a.setFieldOptionHandler(i.reportDoc,
'cv:report/cv:measures/cv:measure[@formula="'+t+'"]',t,n);break;case"attribute":
a.setFieldOptionHandler(i.reportDoc,'cv:report//cv:attribute[@formula="'+t+'"]',
t,n);break;default:a.setFieldOptionHandler(i.reportDoc,
'cv:report//*[@formula="'+t+'"]',t,n)}}},this.isDirty=function(){
var t=this._getReport();if(t)return t.isDirty()},this.isNew=function(){
var t=this._getReport();if(t&&t.reportDoc)return t.reportDoc.isNew()},
this.getReportOption=function(t){var e=this._getReport();if(e&&e.reportDoc
)return this._apiReportUtil.utilities._getNestedObjectByName(
this._apiReportUtil.constants._reportOptions,t).getReportOptionHandler(e)},
this.setReportOption=function(t,e){var r,i,o=this._getReport();o&&o.reportDoc&&(
"showEmptyCells"===t&&(c.log.warn(this._errors.DEPRECATED_SHOW_EMPTY),
t="showEmptyEnum",e=!0===e||"true"===e.toLowerCase()?"SHOW_EMPTY":"SHOW_MEASURE"
),c.util._validateModeForAPI(arguments.callee),i=(
r=this._apiReportUtil.utilities._getNestedObjectByName(
this._apiReportUtil.constants._reportOptions,t)).validateValue(e),
r.setReportOptionHandler(o,i))},this.getChartOption=function(t){
var e=this._getReport();if(e&&e.reportDoc
)return this._apiReportUtil.utilities._getNestedObjectByName(
this._apiReportUtil.constants._chartOptions,t).getChartOptionHandler(e)},
this.setChartOption=function(t,e){var r,i,o=this._getReport();o&&o.reportDoc&&(
c.util._validateModeForAPI(arguments.callee),i=(
r=this._apiReportUtil.utilities._getNestedObjectByName(
this._apiReportUtil.constants._chartOptions,t)).validateValue(e),
r.setChartOptionHandler(o,i))},this.setDatasource=function(t,e){var r,
i=this._getReport();i&&i.reportDoc&&(i.catalog!=t||i.cube!=e)&&(i.catalog=t,
i.cube=e,void 0!==(r=i.manager.updateCatalog(!0))&&(
i.catalog=this.getReportOption("catalog"),i.cube=this.getReportOption("cube"),
0==r.length&&(r=this._errors.INVALID_CATALOG_OR_CUBE(t,e)),c.log.error(r,!0)),
this.setReportOption("cube",i.cube),this.setReportOption("catalog",i.catalog),
i.openReport(void 0,!0))},this.setFieldLink=function(t,s){var l,e,i,o,a,r,n,p,
u=this._getReport();u&&this._validateParamsForSetFieldLink(t,s,u)&&(p=!0,
u.byClass("pivotTable")&&(l=u.buildFilterActionContext(),e=function(t){var e,r,
i=this._query("a",t);if(0<i.length)e=i[0];else for(var o,
a=t.firstChild.childNodes,n=0;o=a[n];n++)if("#text"==o.nodeName){e=o;break}e&&(
i=h.create("a",{innerHTML:e.textContent||e.innerText||e.nodeValue,
href:"javascript:;"}),h.place(i,e,"replace"),r=u.buildCellActionContext(t),
c.event._eventListenerUtil.addEventListener(i,"click",function(t){s(cv.api,r,l),
d.stop(t)},!1))},p=0<(i=this._query('td[type="measure"][ctx*="'+t+'"]',
u.reportHeaders.columnHeaderContainer)).length?(o=i[0].parentNode,a="",
i.forEach(function(t,e,r){t=[].indexOf.call(o.children,t);
a+='td[type="cell"][colindex="'+t+'"]',e!==i.length-1&&(a+=",")}),i.forEach(e,
this),this._query(a,u.reportHeaders.dataContainer).forEach(e,this),!1):(
a='td[type="member"][ctx*="'+t+'"]',(r=this._query(a,
u.reportHeaders.rowLabelContainer)).forEach(e,this),(n=this._query(a,
u.reportHeaders.columnHeaderContainer)).forEach(e,this),
0===r.length&&0===n.length)),p)&&c.log.warn(this._errors.EMPTY_CELLS_FOR_LINK(t)
)},this.buildFilterActionContext=function(){var t={},e=this._getReport();
return t=e?e.buildFilterActionContext():t},this.buildCellActionContext=function(
t){var e={},r=this._getReport();return e=r?r.buildCellActionContext(t):e}}});define("pentaho/analyzer/cv_api_operation",["./cv_api_report_util"],function(r){
return function(g){this._apiReportUtil=new r(g),this._cutStrByRegexp=function(r,
t){t=r.search(t);return r=-1!=t?r.substring(0,t):r},this.refreshReport=function(
){var r=g.report._getReport();r&&(r.refreshReport(!0),r.populateFilters())},
this.getDropTarget=function(r,t,o){var e=g.report._getReport();if(void 0!==e){
this.filterCountLabel||(this.filterCountLabel=e.byId("FilterCountLabel")),
this.filterPaneToggle||(this.filterPaneToggle=e.byId("FilterPaneToggle"));
function n(r,t){return{dropTarget:r,domNodes:t,onGet:function(){},
onShowDropIndicator:function(r){this.dropTarget._showDropIndicator()},
onClearDropIndicator:function(r){this.dropTarget._clearDropIndicator()},
onDrop:function(r){var t=i(r);this.dropTarget.onDrop(t),
this.dropTarget._afterDrop(r.formula)}}}var i=function(r){return{clientX:r.x,
clientY:r.y,anchor:{getAttribute:function(){return r.formula}}}},a={reportArea:{
dropTarget:e.dropTargets.reportArea,domNodes:[e.dropTargets.reportArea.node],
_setDragEvent:function(r){this.dropTarget.lastDragEvent=i(r)},
onShowDropIndicator:function(r){this._setDragEvent(r),
this.dropTarget.calculateBoxes();r=e.manager.fieldHelp.isAttribute(r.formula
)?"attribute":"measure";this.dropTarget._showDropIndicator(
this.dropTarget.lastDragEvent,r)},onClearDropIndicator:function(r){
this.dropTarget._clearDropIndicator()},onGet:function(){
this.dropTarget.calculateBoxes(!0)},onDrop:function(r){this._setDragEvent(r);
var t=e.manager.fieldHelp.isAttribute(r.formula)?"attribute":"measure";
this.dropTarget._onDrop(r.formula,t)}},filters:n(e.dropTargets.filters,[
e.dropTargets.filters.filterPane]),filterPaneTitle:n(
e.dropTargets.filterPaneTitle,[e.dropTargets.filterPaneTitle.filterPane,
this.filterCountLabel,this.filterPaneToggle])},p=dijit.byId("layoutPanel");if(p
)for(var s in p.propUIs){s=p.propUIs[s];s.dropZone&&(a[s.id]={
dropTarget:s.dropZone,domNodes:[s.domNode],onGet:function(){this.dropInfo=null},
onShowDropIndicator:function(r){this.dropTarget.accept[
cvConst.dndTypes.gemFromFieldList]&&(this.dropTarget.gemBar._showOver(),r=i(r),
r=this.dropTarget._showDropIndicator(r))&&(this.dropInfo=r)},
onClearDropIndicator:function(r){this.dropTarget.gemBar._hideOver(),
this.dropTarget._hideDropIndicator()},onDrop:function(r){this.dropInfo||(
this.dropInfo={before:!1,anchor:null});var t={scope:e,f:e.emitDropEvent};
this.dropTarget._onDrop(r.formula,cvConst.dndTypes.gemFromFieldList,r.formula,
this.dropTarget.gemBar,this.dropInfo.before,this.dropInfo.anchor,
this.dropTarget.node,t)}})}var d,c={source:{formula:o,x:r,y:t},target:null};for(
d in a){var l,u=a[d],f=u.domNodes;for(l in f){var h=f[l];if(g.ui._withinDomNode(
r,t,h))return(c.target=u).onGet(c.source),c}}}return null},
this.completeDrop=function(r){r.target.onDrop(r.source)},
this.showDropTargetIndicator=function(r){r.target.onShowDropIndicator(r.source)}
,this.clearDropTargetIndicator=function(r){r.target.onClearDropIndicator(
r.source)},this.clearCache=function(r,t,o){var e=g.report._getReport();
e&&cv.util.clearCache(e,r,t,o)},this.undo=function(){var r=g.report._getReport()
r&&r.history.undo()},this.redo=function(){var r=g.report._getReport();
r&&r.history.redo()},this.resetReport=function(){var r,t=g.report._getReport();
t&&(r=t.history.getSaved(),t.history.setTo(r),t.history.current().back())},
this.saveReport=function(r,t,o,e,n){var i,a=g.report._getReport();a&&((
i=new this._apiReportUtil.types._StringOptionType).validateValue("name",r),
i.validateValue("path",t),r=this._cutStrByRegexp(r,/\.xanalyzer$/),
t=this._cutStrByRegexp(t,/\/[^\/]*\.xanalyzer$/)+"/"+r+".xanalyzer",
cv.util.saveReport(a,"saveAs",r,t,{success:function(){
"function"==typeof o&&o.apply(arguments)},error:function(){
"function"==typeof e&&e.apply(arguments)}},!!n))}}});define("pentaho/analyzer/AnalyzerEvented",["dojo/Evented","dojo/_base/declare"],
function(t,e){return e([t],{constructor:function(t){
this.stopImmediatePropagation=!1,this.preventDefault=!1,this.config=t,
this.disabledEvents={}},_on:function(t,e,i){var n;
this.stopImmediatePropagation?this.config&&this.config.onPropagationStopped&&this.config.onPropagationStopped(
e,t):this.isEventDisabled(e)||(t.stopPropagation||(t.stopPropagation=function(){
console.log(
"Stop Propagation is not implemented by dojo unless you implement a parent/child structure."
)}),n=this,t.stopImmediatePropagation||(t.stopImmediatePropagation=function(){
n.stopImmediatePropagation=!0}),t.preventDefault||(t.preventDefault=function(){
n.preventDefault=!0}),i.call(this,t),
this.config&&this.config.onListenerExecuted&&this.config.onListenerExecuted(e,t)
)},on:function(e,t){var i=this,n=t;return arguments[1]=function(t){i._on.call(i,
t,e,n)},this.inherited(arguments)},emit:function(t,e){
return this.stopImmediatePropagation=!1,this.preventDefault=!1,this.inherited(
arguments),!this.preventDefault&&e},isEventDisabled:function(t){return!(
!this.disabledEvents||!t)&&(!(
!0!==this.disabledEvents.tableDoubleClick||!t.match(/doubleclick|dblclick/i)
)||void 0!==this.disabledEvents[t]&&this.disabledEvents[t])}})});define("pentaho/analyzer/EventListenerUtil",[],function(){return function(){
var B="capturing",m="bubbling";function i(e,p,n,t){var r="on"+p,L=e;
L._listener=L._listener||{},L._listener[p]=L._listener[p]||v(),0==L._listener[p
][B].length&&0==L._listener[p][m].length&&(L._listener[r]=function(e){var n,t={}
,r=e.srcElement;for(n in e)t[n]=e[n];t.currentTarget=L,t.target=r,
t.nativeEvent=e,t.preventDefault=function(){this.nativeEvent.returnValue=!1},
t.stopPropagation=function(){this.nativeEvent.cancelBubble=!0};for(var i=[];r;
)i.unshift(r),r=r.parentNode;for(var l,s=L,a=p,v=i,c=e,o=t,u=0;(l=v[u]
)&&!c.cancelBubble;u++)y(s,a,B,l,c,o);for(var f,_=L,h=p,b=i,E=e,g=t,
d=b.length-1;(f=b[d])&&!E.cancelBubble;d--)y(_,h,m,f,E,g);e.cancelBubble=!0},
L.attachEvent(r,L._listener[r])),L._listener[p][t?B:m].push(n)}function v(){
var e={};return e[B]=[],e[m]=[],e}function y(e,n,t,r,i,l){if(
r._listener&&r._listener[n])for(var s,a=0;(s=r._listener[n][t][a]
)&&!i.cancelBubble;a++)s.call(e,l)}this.addEventListener=function(e,n,t,r){
e.addEventListener?e.addEventListener(n,t,r):i(e,n,t,r)},
this.removeEventListener=function(e,n,t,r){if(e.removeEventListener
)e.removeEventListener(n,t,r);else{for(var i,l=t,t=r,r="on"+n,s=(
e._listener=e._listener||{},e._listener[n]=e._listener[n]||v(),e._listener[n][
t?B:m]),a=s.length-1;i=s[a];a--)i===l&&s.splice(a,1);0==e._listener[n][B
].length&&0==e._listener[n][m].length&&e.detachEvent(r,e._listener[r])}}}});define("pentaho/analyzer/cv_api_event",["./AnalyzerEvented",
"./EventListenerUtil"],function(e,t){return function(r){var i=this;
this._eventListenerUtil=new t,this._eventedHelper=new e({
onPropagationStopped:function(e,t){r.log.info(i._infoMsgs.EVENT_SKIPPED(e))}}),
this._availableActions=["actionAddLevel","actionAddMeasure","actionMoveLevel",
"actionMoveMeasure","actionRemoveLevel","actionRemoveMeasure"],this._infoMsgs={
EVENT_REGISTERED:function(e){return"["+e+"] event registered"},
EVENT_EXECUTED:function(e){return"["+e+"] event executed"},
EVENT_SKIPPED:function(e){
return"["+e+"] event skipped by stopImmediatePropagation"}},
this._availableMenuIds=["fieldViewMenu","fieldListMenu","moreActionsMenu",
"attributePopMenu","propPopMenu","measurePopMenu","filterPopMenu",
"grandTotalPopMenu","actionsMenu","memberPopMenu","cellPopMenu"],
this._on=function(t,n){var e=this._eventedHelper.on(t,function(e){e.args[0
].hasOwnProperty("args")&&e.args[0].hasOwnProperty("bubbles")?e.args[0
]=e:e.args.unshift(e);try{n.apply(i._eventedHelper,e.args),r.log.info(
i._infoMsgs.EVENT_EXECUTED(t))}catch(e){r.log.error(e)}});return r.log.info(
this._infoMsgs.EVENT_REGISTERED(t)),e},this._emit=function(e){
return this._eventedHelper.emit(e,{bubbles:!0,cancelable:!0,
args:Array.prototype.slice.call(arguments,1)})},
this.registerInitListener=function(e){return this._on("init",e)},
this.registerTableClickListener=function(e){return this._on("tableClick",e)},
this.registerTableContextMenuListener=function(e){return this._on(
"tableContextMenu",e)},this.registerRenderListener=function(e){return this._on(
"render",e)},this.registerActionEventListener=function(e){return this._on(
"actionEvent",e)},this.registerDropEventListener=function(e){return this._on(
"drop",e)},this._emitActionEvent=function(e){var t=!0;
return t=-1<this._availableActions.indexOf(e.action)?this._emit("actionEvent",r,
e.action,e.actionCtx):t},this.registerChartSelectItemsListener=function(e){
return this._on("chartSelectItems",e)},
this.registerChartDoubleClickListener=function(e){return this._on(
"chartDoubleClick",e)},this.registerTableDoubleClickListener=function(e){
return this._on("tableDoubleClick",e)},
this.registerTableMouseOverListener=function(e){return this._on("tableMouseOver"
,e)},this.registerTableMouseMoveListener=function(e){return this._on(
"tableMouseMove",e)},this.registerBuildMenuListener=function(e){return this._on(
"buildMenu",e)},this._emitBuildMenu=function(e,t,n){var i=!0;
return i=-1<this._availableMenuIds.indexOf(e.id)?this._emit("buildMenu",r,e.id,e
,t,n):i},this.registerDragEventListener=function(e){return this._on("drag",e)},
this.registerPreExecutionListener=function(e){return this._on("preExecution",e)}
,this.registerPostExecutionListener=function(e){return this._on("postExecution",
e)},this.disableDragAndDrop=function(e){
this._eventedHelper.disabledEvents.dragAndDrop=JSON.parse(e)},
this.disableTableDoubleClick=function(e){
this._eventedHelper.disabledEvents.tableDoubleClick=JSON.parse(e),
this._showDisabledEventTitle(this._eventedHelper.disabledEvents.tableDoubleClick
,'td[type="member"] div[enabledeventtitle]'),this._showDisabledEventTitle(
this._eventedHelper.disabledEvents.tableDoubleClick,
'td[type="member"][enabledeventtitle]')},this.disableTableContextMenu=function(e
){this._eventedHelper.disabledEvents.tableContextMenu=JSON.parse(e)},
this.isEventDisabled=function(e){return this._eventedHelper.isEventDisabled(e)},
this._showDisabledEventTitle=function(e,t){for(var n=document.querySelectorAll(t
),i=0;i<n.length;i++){var r=n[i];e&&r.hasAttribute("disabledeventtitle"
)?r.setAttribute("title",r.getAttribute("disabledeventtitle")
):!e&&r.hasAttribute("enabledEventTitle")&&r.setAttribute("title",
r.getAttribute("enabledeventtitle"))}}}});define("pentaho/analyzer/cv_api_util",["./cv_api_report_util","dojo/request"],
function(e,r){return function(l){this._apiReportUtil=new e(l),
this._validateUrlParamItem=function(e,a){
var r=void 0!==a.urlParams&&0<a.urlParams.length;
return!r||a.handler&&a.handlerScope?r&&"function"!=typeof a.handler&&(
l.log.warn(this._errorMessages.INVALID_HANDLER_FOR_URL_PARAM(e)),r=!1):(
l.log.warn(this._errorMessages.INVALID_PARAM_HANDLER(e)),r=!1),r},
this._errorMessages={INVALID_PARAM_HANDLER:function(e){
return"Function handler is not set for API '"+e+"'."},
INVALID_HANDLER_FOR_URL_PARAM:function(e){
return"API '"+e+"' has an invalid function handler."},
INVALID_URL_PARAM_FOR_MODE:function(e,a,r){
return"API '"+e+"' is not allowed for the current report mode '"+a+"'. The valid mode is '"+r+"'."
}},this._functions={setVizId:{urlParams:[{name:"vizId"}],
handler:l.report.setVizId,handlerScope:l.report},setReportOption:{urlParams:[{
name:"showRowGrandTotal",args:["showRowGrandTotal"]},{
name:"showColumnGrandTotal",args:["showColumnGrandTotal"]},{
name:"useNonVisualTotals",args:["useNonVisualTotals"]},{name:"showEmptyCells",
args:["showEmptyCells"]},{name:"showDrillLinks",args:["showDrillLinks"]},{
name:"autoRefresh",args:["autoRefresh"]},{name:"freezeColumns",args:[
"freezeColumns"]},{name:"freezeRows",args:["freezeRows"]}],
handler:l.report.setReportOption,handlerScope:l.report},setChartOption:{
urlParams:[{name:"legendPosition",args:["legendPosition"]},{name:"showLegend",
args:["showLegend"]},{name:"autoRange",args:["autoRange"]},{
name:"valueAxisLowerLimit",args:["valueAxisLowerLimit"]},{
name:"valueAxisUpperLimit",args:["valueAxisUpperLimit"]},{name:"displayUnits",
args:["displayUnits"]},{name:"autoRangeSecondary",args:["autoRangeSecondary"]},{
name:"valueAxisLowerLimitSecondary",args:["valueAxisLowerLimitSecondary"]},{
name:"valueAxisUpperLimitSecondary",args:["valueAxisUpperLimitSecondary"]},{
name:"displayUnitsSecondary",args:["displayUnitsSecondary"]},{name:"maxValues",
args:["maxValues"]},{name:"backgroundColor",args:["backgroundColor"]},{
name:"labelColor",args:["labelColor"]},{name:"labelSize",args:["labelSize"]},{
name:"backgroundFill",args:["backgroundFill"]},{name:"maxChartsPerRow",args:[
"maxChartsPerRow"]},{name:"multiChartMax",args:["multiChartMax"]},{
name:"multiChartRangeScope",args:["multiChartRangeScope"]},{
name:"emptyCellMode",args:["emptyCellMode"]},{name:"sizeByNegativesMode",args:[
"sizeByNegativesMode"]},{name:"backgroundColorEnd",args:["backgroundColorEnd"]},
{name:"labelStyle",args:["labelStyle"]},{name:"legendBackgroundColor",args:[
"legendBackgroundColor"]},{name:"legendSize",args:["legendSize"]},{
name:"legendColor",args:["legendColor"]},{name:"legendStyle",args:["legendStyle"
]},{name:"labelFontFamily",args:["labelFontFamily"]},{name:"legendFontFamily",
args:["legendFontFamily"]}],handler:l.report.setChartOption,
handlerScope:l.report},showFieldList:{urlParams:[{name:"showFieldList"}],
handler:l.ui.showFieldList,handlerScope:l.ui,mode:"EDIT"},showFieldLayout:{
urlParams:[{name:"showFieldLayout"}],handler:l.ui.showFieldLayout,
handlerScope:l.ui,mode:"EDIT"},removeHeaderBar:{urlParams:[{
name:"removeHeaderBar",checkParent:!0}],handler:l.ui.removeHeaderBar,
handlerScope:l.ui},disableFilterPanel:{urlParams:[{name:"disableFilterPanel",
checkParent:!0}],handler:l.ui.disableFilterPanel,handlerScope:l.ui},
showFilterPanel:{urlParams:[{name:"showFilterPanel"}],
handler:l.ui.showFilterPanel,handlerScope:l.ui},removeFieldList:{urlParams:[{
name:"removeFieldList"}],handler:l.ui.removeFieldList,handlerScope:l.ui,
mode:"EDIT"},removeFieldLayout:{urlParams:[{name:"removeFieldLayout"}],
handler:l.ui.removeFieldLayout,handlerScope:l.ui,mode:"EDIT"},setFieldListView:{
urlParams:[{name:"fieldListView"}],handler:l.ui.setFieldListView,
handlerScope:l.ui,mode:"EDIT"},showRepositoryButtons:{urlParams:[{
name:"showRepositoryButtons"}],handler:l.ui.showRepositoryButtons,
handlerScope:l.ui,mode:"EDIT"},removeUndoButton:{urlParams:[{
name:"removeUndoButton",checkParent:!0}],handler:l.ui.removeUndoButton,
handlerScope:l.ui},removeRedoButton:{urlParams:[{name:"removeRedoButton",
checkParent:!0}],handler:l.ui.removeRedoButton,handlerScope:l.ui},
removeMainToolbar:{urlParams:[{name:"removeMainToolbar"}],
handler:l.ui.removeMainToolbar,handlerScope:l.ui,mode:"EDIT"},
removeReportActions:{urlParams:[{name:"removeReportActions",checkParent:!0}],
handler:l.ui.removeReportActions,handlerScope:l.ui,mode:"VIEW"},
disableTableDoubleClick:{urlParams:[{name:"disableTableDoubleClick"}],
handler:l.event.disableTableDoubleClick,handlerScope:l.event},
disableTableContextMenu:{urlParams:[{name:"disableTableContextMenu"}],
handler:l.event.disableTableContextMenu,handlerScope:l.event},
disableDragAndDrop:{urlParams:[{name:"disableDragAndDrop"}],
handler:l.event.disableDragAndDrop,handlerScope:l.event},isFromTransformation:{
urlParams:[{name:"isFromTransformation"}],handler:l.ui.setIsFromTransformation,
handlerScope:l.ui}},this.parseMDXExpression=function(e,a){return(
new this._apiReportUtil.types._StringOptionType).validateValue("formula",e),
cv.util.parseMDXExpression(e,a)},this._applyUrlParameters=function(e){for(
param in this._functions)if(!e||-1!==e.indexOf(param)){var a=this._functions[
param];try{if(this._validateUrlParamItem(param,a))for(var r,n=0;r=a.urlParams[n
];n++){var o,i=cv.util.getURLQueryValue(r.name,r.checkParent);i&&((o=r.args||[]
).push(i),a.handler.apply(a.handlerScope,o))}}catch(e){l.log.error(e)}}},
this._validateModeForAPI=function(e){var a=!0,r=l.ui.getMode();for(
param in this._functions){var n=this._functions[param];if(n.handler===e){(
a=void 0===n.mode||n.mode===r)||l.log.error(
this._errorMessages.INVALID_URL_PARAM_FOR_MODE(param,r,n.mode),!0);break}}
return a},this._findClosestValueFromArray=function(e,a){var r=a;if(e){
var n=Math.max.apply(null,e);n<a&&(n=a);for(var o=0;o<e.length;o++){
var i=Math.abs(a-e[o]);i<n&&(n=i,r=e[o])}}return r},
this._hasInlineModelingPermission=function(){
return"false"!==cv.util.getURLQueryValue("hasInlineModelingPermission")&&(
void 0===cv.hasManageDatasourcePermission&&(
cv.hasManageDatasourcePermission=this._hasManageDatasourcePermission()),
cv.hasManageDatasourcePermission)},this._hasManageDatasourcePermission=function(
){var e={},a=null;return e.time=(new Date).getTime(),r(
CONTEXT_PATH+"api/authorization/action/isauthorized?authAction=org.pentaho.platform.dataaccess.datasource.security.manage"
,{data:e,sync:!0,headers:{"Content-Type":"application/json"},method:"GET",
preventCache:!0}).then(function(e){a=e},function(e){}),"true"===a}}});define("pentaho/analyzer/visual/registry.legacy",["pentaho/module/metaService",
"pentaho/util/object","pentaho/visual/KeyTypes","dojo/_base/lang"],function(u,g,
o,s){"use strict";var a="pentaho/visual/models/legacy/";return{toId:d,
create:function(e){return s.clone(e.type.v2Spec)},isLegacyViz:function(e){
return-1!==e.type.id.indexOf(a)},importLegacyVisualizations:function(r,e,i){
var l;return e?((e=e.map(function(e){e.menuOrdinal||(e.menuOrdinal=1e4);var a=i,
n=s.clone(e),t=((e=a["viz."+n.id+".maxValues"])&&(e=function(e){
return e?e.split(/\s*,\s*/).map(function(e){return parseInt(e,10)}):[100,150,200
,250]}(e),n.maxValues=e),n.maxValues||(n.maxValues=[100,150,200,250]),n.args||(
n.args={}),"viz."+n.id+".args."),e=(g.eachOwn(a,function(e,a){-1!==a.indexOf(t
)&&(a=a.substr(t.length),n.args[a]=e)}),+a["filter.selection.max.count"]||500);
return n.args["filter.selection.max.count"]=e,n})).sort(function(e,a){
return e.menuOrdinal-a.menuOrdinal}),l=null,e=e.map(function(e){
return l&&!0!==e.menuSeparator||(l=e.type),e._category=l,a=r,t=c(e=e,n=i),e=p(e,
n),(n={})[t.id]={base:a.type.id,annotations:{"pentaho/analyzer/visual/Options":e
},value:function(e){return a.extend({$type:t}).configure({$type:e.config})}},
u.configure(n).get(t.id).loadAsync();var a,n,t}),Promise.all(e)
):Promise.resolve()},_convertLegacyVisualization:c,_getOptionsAnnotationSpec:p,
_convertLegacyDataReq:y};function d(e){return e&&e.indexOf("/")<0?a+e:e}
function p(e,a){var n={},t=e.dataReqs&&e.dataReqs[0];
return n.showOptionsButton=t&&0<t.reqs.filter(function(e){return!(
!e.ui||"button"!==e.ui.type)&&"optionsBtn"===e.id}).length,
n.selectionMaxCount=+a["filter.selection.max.count"]||500,e.maxValues&&(
n.maxValues=e.maxValues),t&&(t.drillOrder&&(n.drillOrder=t.drillOrder),
t.hyperlinkOrder)&&(n.hyperlinkOrder=t.hyperlinkOrder),e.keepLevelOnDrilldown&&(
n.keepLevelOnDrilldown=e.keepLevelOnDrilldown),n}function c(e,a){var n=d(e.id),
t=e.dataReqs&&e.dataReqs[0],r=e.args||{},i={index:-1,name:"",ordinal:0},l=!1,
t=t&&t.reqs.filter(function(e){return!(e.ui&&"button"===e.ui.type)}).map(
function(e,a){a=y(e,r,i,a);return!l&&e.dataStructure&&function(e){switch(
e.modes.length){case 0:return;case 1:var a=e.modes[0].dataType;
return"list"===a||"element"===a;default:return 1}}(a)&&(l=!0),a}),
u=e.visualKeyType||(l?o.dataOrdinal:o.dataKey);return{id:n,v2Spec:e,v2Id:e.id,
label:e.name||e.id,category:e._category,description:e.name||e.id,
ordinal:e.menuOrdinal||1e4,visualKeyType:u,props:t||[]}}function y(e,a,n,t){
var r,i,l;if(e.dataStructure)return t=t,l=[],d=(r=e).dataTypeAllowMultiple,
p=null==r.allowMultiple||!!r.allowMultiple,m=r.dataType||"string",
c=/\bstring\b/.test(m),m=/\bnumber\b/.test(m),d?(!c&&m||(i=g.getOwn(d,"string",p
),l.push(i?{dataType:["string"]}:{dataType:"string"})),m&&(i=g.getOwn(d,"number"
,p),l.push(i?{dataType:["number"]}:{dataType:"number"}))):(i=p,c&&m?l.push(i?{
dataType:"list"}:{dataType:"element"}):c||!m?l.push(i?{dataType:["string"]}:{
dataType:"string"}):m&&l.push(i?{dataType:["number"]}:{dataType:"number"})),{
name:r.id,label:r.caption,ordinal:t,base:"pentaho/visual/role/Property",modes:l,
fields:{isRequired:!!r.required},v2Spec:r};var u,o,s=e,d=a,p=n,c=s.ui||{};
switch(void 0===(d=d[s.id])&&void 0===(d=s.value)&&(d=null),s.dataType){
case"string":case"number":case"boolean":case"date":u=s.dataType;break;default:
u="string"}var y,m=s.values;return m&&(y=c.labels,o=m.map(function(e,a){return{
v:e,f:y&&a<y.length?y[a]:String(e)}})),(p.index<0||s.ui.seperator)&&(
p.name="category"+ ++p.index),p.ordinal++,m={name:s.id,label:c.caption,
category:p.name,ordinal:p.ordinal,valueType:u,defaultValue:d,v2Spec:s},
"checkbox"===c.type&&(m.application={checkedLabel:null!=c.caption?c.label:null})
,o&&(m.domain=o),m}});define("pentaho/analyzer/visual/dataFilterUtils",["pentaho/data/filter/False"],
function(o){"use strict";return{toAnalyzerSelectionFormat:function(r){if(!r
)return[];var e=[];switch((r=r.toDnf()).kind){case"false":break;case"or":
r.operands.each(function(r){e.push(a(r))});break;default:e.push(a(r))}return e},
restrictFilter:function(r,e){if(null==e)return r;var n=o.instance;if(
0===e.length)return n;var t={};return e.forEach(function(r){t[r]=1}),(
function e(r,n){if(r.isTerminal)return r.isProperty&&!u(n,r.property)?null:r;{
var t;if("not"===r.kind)return(t=e(r.operand,n))?t.negate():null}var o=[];
r.operands.each(function(r){r=e(r,n);r&&o.push(r)});
return o.length?new r.constructor({operands:o}):null}(r,t)||n).toDnf()},
limitSelection:function(r,e,n,t){if(-1!==r){var o=e.toDnf();if("or"===o.kind){
var a=o.operands,u=a.count;if(r<u){for(var i=t||0,l=[],p=0,c=[],s=0,
f=0;f!==u;++f){var d=a.at(f),h=d.$contentKey;if(0<i&&null!=n[h]?(l.push(d),++p,
--i):(c.push(d),++s),r<=p||0===i&&r<=p+s)break}t=l;return p<r&&t.push.apply(l,
c.slice(0,r-p)),o.$type.create({operands:t})}}}return e}};function a(r){var e,n,
t;switch(r.kind){case"isEqual":return{type:"row",rowId:[r.property],rowItem:[
r.value]};case"and":return e={type:"row",rowId:null==n?[]:[n],rowItem:null==t?[
]:[t]},r.operands.each(function(r){r=a(r);r&&(e.rowId.push.apply(e.rowId,r.rowId
),e.rowItem.push.apply(e.rowItem,r.rowItem))}),e;default:throw new Error(
"Not Implemented")}}function u(r,e){return Object.prototype.hasOwnProperty.call(
r,e)}});define("pentaho/analyzer/visual/Application",["pentaho/module!_",
"pentaho/visual/Application","./dataFilterUtils"],function(t,e,i){"use strict";
return e.extend({$type:{id:t.id},constructor:function(t){this.base(t),
this.cv=t&&t.cv},getDoubleClickTooltip:function(t){
var e=this.cv.getActiveReport(),t=e._vizModelAdapter._convertFilterToExternal(t)
,t=e._restrictFilterToDrillOrder(t),t=i.toAnalyzerSelectionFormat(t);
return e.getDoubleClickTooltip(t&&t[0])}}).configure({$type:t.config})});define("pentaho/analyzer/visual/OptionsAnnotation",["module",
"pentaho/module/Annotation"],function(t,e){"use strict";var i=e.extend(t.id,{
constructor:function(t,e){this.base(t),this._init(e||{})},__maxValues:[100,150,
200,250],get maxValues(){return this.__maxValues},__hyperlinkOrder:null,
get hyperlinkOrder(){return this.__hyperlinkOrder},__drillOrder:null,
get drillOrder(){return this.__drillOrder},__keepLevelOnDrilldown:null,
get keepLevelOnDrilldown(){return this.__keepLevelOnDrilldown},
__showOptionsButton:null,get showOptionsButton(){return this.__showOptionsButton
},__filterSelectionMaxCount:500,get filterSelectionMaxCount(){
return this.__filterSelectionMaxCount},__selectionRestriction:null,
get selectionRestriction(){return this.__selectionRestriction},
__generateOptionsFromAnalyzerState:null,get generateOptionsFromAnalyzerState(){
return this.__generateOptionsFromAnalyzerState},__getMultiChartMaxList:null,
get getMultiChartMaxList(){return this.__getMultiChartMaxList},
__willOverflow:null,get willOverflow(){return this.__willOverflow},
__isStockVisualization:!1,get isStockVisualization(){
return this.__isStockVisualization},_init:function(t){null!=t.maxValues&&(
this.__maxValues=t.maxValues),null!=t.hyperlinkOrder&&(
this.__hyperlinkOrder=t.hyperlinkOrder),null!=t.drillOrder&&(
this.__drillOrder=t.drillOrder),null!=t.keepLevelOnDrilldown&&(
this.__keepLevelOnDrilldown=t.keepLevelOnDrilldown),null!=t.showOptionsButton&&(
this.__showOptionsButton=t.showOptionsButton),null!=t.filterSelectionMaxCount&&(
this.__filterSelectionMaxCount=t.filterSelectionMaxCount),
null!=t.selectionRestriction&&(
this.__selectionRestriction=t.selectionRestriction),
null!=t.generateOptionsFromAnalyzerState&&(
this.__generateOptionsFromAnalyzerState=t.generateOptionsFromAnalyzerState),
null!=t.getMultiChartMaxList&&(
this.__getMultiChartMaxList=t.getMultiChartMaxList),null!=t.willOverflow&&(
this.__willOverflow=t.willOverflow),null!=t.isStockVisualization&&(
this.__isStockVisualization=t.isStockVisualization)}},{get id(){return t.id},
createAsync:function(e,n){var t=e.ancestor||null;
return null!==t&&t.hasAnnotation(i,{inherit:!0})?t.getAnnotationAsync(i,{
inherit:!0}).then(function(t){t=Object.create(t);return i.call(t,e,n),t}
):Promise.resolve(new i(e,n))}});return i});define("pentaho/analyzer/visual/utils",["pentaho/module/metaService",
"./OptionsAnnotation","pentaho/visual/role/util","pentaho/util/object"],
function(n,r,o,i){var s={stringAttribute:function(t,e,n){return{name:t,
type:"string",isKey:!0,hierarchyName:e,hierarchyOrdinal:n}},
dateAttribute:function(t,e,n){return{name:t,type:"string",isKey:!0,
hierarchyName:e,hierarchyOrdinal:n,p:{EntityWithTimeIntervalKey:{
duration:"month",isStartDateTimeProvided:!0}}}},numberAttribute:function(t,e,n){
return{name:t,type:"string",isKey:!0,hierarchyName:e,hierarchyOrdinal:n,p:{
EntityWithNumberKey:{isNumberProvided:!0}}}},numberMeasure:function(t){return{
name:t,type:"number",isKey:!1}}};return{testAddKnownFieldKinds:function(t,e,n){
var r=o.getRoleFirstHierarchy(e,n),i=r&&o.getHierarchyNextOrdinal(e,r),a=l(t,e,n
,"stringAttribute",r,i,!1),u=l(t,e,n,"dateAttribute",r,i,!0),r=l(t,e,n,
"numberAttribute",r,i,!0);return{stringAttribute:a,dateAttribute:u,
numberAttribute:r,attribute:a||r||u,numberMeasure:l(t,e,n,"numberMeasure",null,
null,null)}},getVizOptionsAnnotation:function(t,e){if(t)return t=n.get(t,{
createIfUndefined:!0}),e=i.assignOwn({inherit:!0},e),t.getAnnotation(r,e);
throw error.argRequired("vizTypeId")}};function l(t,e,n,r,i,a,u){r=(0,s[r])(
function(t){var e=0,n="__field_temp";for(;t.gemList.contains(n+e);)e++;
return n+e}(t),i,a),i=t.createSchemaDataTable(r),a=i.model.attributes,t=a[
a.length-1].name,r=o.testAddFieldAtAutoPosition(e,n,t,{alternateData:i});
return null!==r&&(null==u||r.mode.isContinuous===u)}});define("pentaho/analyzer/visual/registry",["pentaho/lang/Base",
"pentaho/environment","pentaho/module/service","pentaho/module/metaService",
"pentaho/config/service","pentaho/util/object","pentaho/util/fun",
"pentaho/util/requireJS","./registry.legacy","./Application","./utils"],
function(e,d,t,o,n,c,a,i,p){"use strict";var h="pentaho/analyzer/visual/Options"
,y="pentaho/visual/Model",r="analyzer_PIVOT",s=[100,150,200,250],
f=/^viz\.(.+?)\.args.(.+?)$/,_=/^viz\.(.+?)\.maxValues$/;return e.extend({
constructor:function(){this._isLoaded=!1,this.__loadedPromise=null,
this.__allModels=null,this.__allModelsById=null},loadAsync:function(){
var e=this.__loadedPromise;return null===e&&(this._createConfiguration(
cv.analyzerProperties),this.__loadedPromise=e=this.__getModelsAsync().then(
this.__setModules.bind(this))),e},__getModelsAsync:function(){return i.promise(y
).then(function(e){return Promise.all([i.promise("pentaho/visual/ModelAdapter"),
this._registerPivotTableAsync(e,cvCatalog),p.importLegacyVisualizations(e,
cv.pentahoVisualizations,cv.analyzerProperties)])}.bind(this)).then(function(){
return t.getSubtypesOfAsync(y)})},__setModules:function(e){
var t=this.__allModelsById=Object.create(null);return this.__allModels=e.filter(
function(e){return!e.type.isAbstract&&(t[e.type.id]=e,!0)}),this._isLoaded=!0,
this},get isLoaded(){return this._isLoaded},_assertLoaded:function(){if(
!this.isLoaded)throw new Error("Visualization registry is not yet loaded")},
isLegacyViz:function(e){return p.isLegacyViz(e)},get:function(e){
return this._assertLoaded(),e=p.toId(e),c.getOwn(this.__allModelsById,e,null)},
create:function(e,t){return this.isLegacyViz(e)?p.create(e):new e(t)},
getAll:function(){return this._assertLoaded(),this.__allModels.slice()},
getAllByCategory:function(){var e=this.getAll(),i={},t=(e.forEach(function(e){
var t,n=e.type;n.isBrowsable&&(n=n.category,(t=c.getOwn(i,n))||(i[n]=t={
category:n,models:[]}),t.models.push(e))}),c.eachOwn(i,function(e){
e.models.sort(l)}),[]),n={};return c.eachOwn(i,function(e){n[e.category
]=e.models.reduce(function(e,t){t=t.type.ordinal;return null==t||e<t?e:t},1/0),
t.push(e)}),t.sort(function(e,t){e=n[e.category],t=n[t.category];
return a.compare(e,t)}),t},_registerPivotTableAsync:function(t,n){var e=p.toId(r
),i={};return i[e]={base:y,annotations:{"pentaho/analyzer/visual/Options":{
showOptionsButton:!0}},value:function(e){return t.extend({$type:{id:e.id,
v2Spec:{},v2Id:r,label:"Pivot Table",category:"pivot",
description:"Analyzer Pivot Table",ordinal:1e4,isBrowsable:!1,props:[{
name:"rows",ordinal:1,label:n.dropZoneLabels_PIVOT_ROW,
base:"pentaho/visual/role/Property",modes:[{dataType:["string"]}],fields:{
isRequired:u}},{name:"columns",ordinal:2,label:n.dropZoneLabels_PIVOT_COL,
base:"pentaho/visual/role/Property",modes:[{dataType:["string"]}],fields:{
isRequired:u}},{name:"measures",ordinal:3,label:n.dropZoneLabels_PIVOT_NUM,
base:"pentaho/visual/role/Property",modes:[{dataType:["number"]}],fields:{
isRequired:u}}]}}).configure({$type:e.config})}},o.configure(i).get(e
).loadAsync()},_createConfiguration:function(e){var t,n,i,o={},a=[],
r=d.application,s=u(y).apply,l=(s.maxValues=g(),s.filterSelectionMaxCount=+e[
"filter.selection.max.count"]||500,e["chart.options.keepLevelOnDrilldown"]);for(
i in"string"==typeof l&&(l="true"===l),s.keepLevelOnDrilldown=!!l,e)c.hasOwn(e,i
)&&(t=e[i],(n=f.exec(i))?function(e){e=p.toId(e);var t=c.getOwn(o,e);t||(o[e
]=t=v(e,r),a.push(t));return t}(n[1]).apply.props[n[2]]={defaultValue:t}:(
n=_.exec(i))&&(u(n[1]).apply.maxValues=g(t)));function u(e){var t=(e=p.toId(e)
)+"-"+h,n=c.getOwn(o,t);return n||(o[t]=n=function(e,t){e=v(e,t);
return e.select.annotation=h,e}(e,r),a.push(n)),n}this._addConfiguration({
rules:a})},_addConfiguration:function(e){n.add(e)}});function l(e,t){e=e.type,
t=t.type;return a.compare(e.ordinal||1/0,t.ordinal||1/0)||a.compare(e.label,
t.label)}function g(e){return e?e.split(/\s*,\s*/).map(function(e){
return parseInt(e,10)}):s.slice()}function v(e,t){return{priority:-1,select:{
application:t,module:e},apply:{props:{}}}}function u(){
return!this.rows.hasFields&&!this.columns.hasFields&&!this.measures.hasFields}}
);define("pentaho/analyzer/cv_api_ui",["dojo/dom-construct","dijit/registry",
"dojo/dom-class","dojo/dom","dojo/query","dojo/dom-geometry",
"./cv_api_report_util","./visual/registry"],function(t,i,r,s,a,l,e,n){
return function(o){this._visualRegistry=new n,this._apiReportUtil=new e(o),
this._msgs={UNSUPPORTED_VIEW:function(e){
return"View: '"+e+"' is not a supported field list view"}},this._query=function(
e,t){return a(e,t)},this._makeVisible=function(e){var t=e;return(
new this._apiReportUtil.types._BooleanOptionType).validateValue("makeVisible",t)
,t="string"==typeof e?"true"===t:t},
this._destroyWidgetsAndRefreshLayout=function(e){e.forEach(t.destroy);e=i.byId(
"borderContainer");e&&e.layout(),o.report._getReport().resize()},
this._destroySeparatorIfEmptyPanel=function(e){e=s.byId(e);e&&0==this._query(
".reportBtn",e).length&&this._query(".separator",e).forEach(t.destroy)},
this._isRemovable=function(e){return void 0===e||!0===e||"true"===e},
this._withinDomNode=function(e,t,i){i=l.position(i);
return e>=i.x&&t>=i.y&&e<=i.x+i.w&&t<=i.y+i.h},this.isFromTransformation=!1,
this.getMode=function(){var e=o.report._getReport();if(e)return e.mode},
this.showFieldLayout=function(e){var t=o.report._getReport();t&&(
o.util._validateModeForAPI(arguments.callee),e=this._makeVisible(e),
cv.util.isShowing("layoutPanelWrapper")!=e)&&t.toggleReportPane("cmdLayout")},
this.showFilterPanel=function(e){var t=o.report._getReport();t&&(
o.util._validateModeForAPI(arguments.callee),e=this._makeVisible(e),
cv.util.isShowing(t.id+"Filter")!=e)&&t.toggleReportPane("cmdFilters")},
this.listVizIds=function(){for(var e=["pivot"],t=this._visualRegistry.getAll(),
i=0;o=t[i];i++){var o=o.type;
"pentaho/visual/models/legacy/analyzer_PIVOT"!==o.id&&e.push(
o.v2Spec?o.v2Id:o.id)}return e},this.listGembarIds=function(){var t=[],
e=o.report._getReport();
return e&&null!==e._vizModelAdapter&&e._vizModelAdapter.$type.eachVisualRole(
function(e){t.push(e.name)}),t},this.removeFieldList=function(e){
o.util._validateModeForAPI(arguments.callee),this._isRemovable(e)&&(
this._destroyWidgetsAndRefreshLayout(["fieldListWrapper",
"fieldListWrapper_splitter","cmdFields"]),this._destroySeparatorIfEmptyPanel(
"layoutButtonsPanel"))},this.removeHeaderBar=function(e){var t,
i=o.report._getReport();i&&this._isRemovable(e)&&(e=s.byId(i.id+"ReportMain"),
t=s.byId("progressPane"),e.insertBefore(t,e.firstChild),r.add(t,
"progressPaneDivWithoutHeaderBar"),"EDIT"==this.getMode(
)?this._destroyWidgetsAndRefreshLayout([i.id+"Filter",i.id+"ReportSummary",
"cmdFilters"]):"VIEW"==this.getMode()&&this._destroyWidgetsAndRefreshLayout([
i.id+"Filter",i.id+"ReportSummary",i.id+"CmdActions",i.id+"ReportName"]))},
this.disableFilterPanel=function(e){var t=o.report._getReport();t&&(
o.util._validateModeForAPI(arguments.callee),this._isRemovable(e))&&(
this._destroyWidgetsAndRefreshLayout([t.id+"Filter",t.id+"FilterPaneTitle",
"cmdFilters"]),this._destroySeparatorIfEmptyPanel("layoutButtonsPanel"))},
this.removeUndoButton=function(e){o.util._validateModeForAPI(arguments.callee),
this._isRemovable(e)&&(this._destroyWidgetsAndRefreshLayout(["cmdUndoPanel"]),
this._destroySeparatorIfEmptyPanel("historyButtonsPanel"))},
this.removeFieldLayout=function(e){var t;o.util._validateModeForAPI(
arguments.callee),this._isRemovable(e)&&(this._destroyWidgetsAndRefreshLayout([
"layoutPanelWrapper","layoutPanelWrapper_splitter","cmdLayout"]),
this._destroySeparatorIfEmptyPanel("layoutButtonsPanel"),t=o.report._getReport()
)&&t.manager.layoutPanel.topic.remove()},this.removeRedoButton=function(e){
o.util._validateModeForAPI(arguments.callee),this._isRemovable(e)&&(
this._destroyWidgetsAndRefreshLayout(["cmdRedoPanel"]),
this._destroySeparatorIfEmptyPanel("historyButtonsPanel"))},
this.removeMainToolbar=function(e){o.util._validateModeForAPI(arguments.callee),
this._isRemovable(e)&&this._destroyWidgetsAndRefreshLayout(["reportBtns"])},
this.setFieldListView=function(e){var t,i=o.report._getReport();i&&(
o.util._validateModeForAPI(arguments.callee),(t={CATEGORY:"CMDVIEWCATEGORY",
NAME:"CMDVIEWNAME",TYPE:"CMDVIEWTYPE",SCHEMA:"CMDVIEWSCHEMA"}).hasOwnProperty(e
)||o.log.error(this._msgs.UNSUPPORTED_VIEW(e),!0),
i.manager.fieldHelp.sortFields(t[e]))},this.showRepositoryButtons=function(e){
var t,i;o.report._getReport()&&(o.util._validateModeForAPI(arguments.callee),
e=this._makeVisible(e),t=s.byId(i="repositoryButtonsPanel"),i=cv.util.isShowing(
i),t)&&i!=e&&r.toggle(t,"hidden")},this.removeReportActions=function(e){
var t=o.report._getReport();t&&(o.util._validateModeForAPI(arguments.callee),
this._isRemovable(e))&&(t=t.id+"ReportFormatCmdDiv",
this._destroyWidgetsAndRefreshLayout([t]))},this.showFieldList=function(e){
var t=o.report._getReport();t&&(o.util._validateModeForAPI(arguments.callee),
e=this._makeVisible(e),cv.util.isShowing("fieldListWrapper")!=e
)&&t.toggleReportPane("cmdFields")},this.setIsFromTransformation=function(e){
this.isFromTransformation=e}}});define("pentaho/analyzer/API",["./cv_api_report","./cv_api_operation",
"./cv_api_event","./cv_api_util","./cv_api_ui"],function(e,i,n,s,o){
return function(t){this.report=new e(this,t),this.ui=new o(this),
this.operation=new i(this),this.properties={},this.event=new n(this),
this.util=new s(this);this.log={_showStatus:function(t,e){cv.util.showStatus(t,e
)},info:function(t,e){e&&this._showStatus(t,"INFO"),console.log("INFO: "+t)},
warn:function(t,e){e&&this._showStatus(t,"WARNING"),console.log("WARNING: "+t)},
error:function(t,e,i){if(i&&this._showStatus(t,"ERROR"),e)throw t;console.log(
"ERROR: "+t)}},this.event.registerRenderListener(function(t,e,i){
e.event._showDisabledEventTitle(e.event.isEventDisabled("tableDoubleClick"),
'td[type="member"] div[enabledeventtitle]'),e.event._showDisabledEventTitle(
e.event.isEventDisabled("tableDoubleClick"),
'td[type="member"][enabledeventtitle]')})}});