define("pentaho/analyzer/cv_base",["dojo/_base/declare","dojo/on","dojo/query",
"dijit/Menu","dijit/Dialog","dojo/ready","dojo/_base/lang","dojo/html",
"dojo/dom"],function(e,o,n,t,d,i,a,s,l){a.mixin(window.cv,{prefs:{
suppressMsg:{},fadeTime:250,wipeTime:250,isDebug:0,skipDirtyAlert:!1},
defaultNS:"http://www.pentaho.com",contextPath:"",dojoWidgets:{},helpTopics:{},
helpWin:null,securityToken:null,nsResolver:function(e){
return"http://www.pentaho.com"},getFieldHelp:null,getActiveReport:null,
init:function(){var e=!1;try{e=window.parent&&window.parent.PentahoMobile}catch(
e){}console_enabled||e||document.getElementsByTagName("body")[0].classList.add(
"pentaho-page-background")}}),cv.extension=cv.extension||{},i(cv.init),
dojoConfig.bindEncoding="utf8";a=window.cvConst={dndObjectTypes:{gem:"G"},
dndSourceTypes:{fieldList:"F",layoutPanel:"B",reportArea:"R"}};a.dndTypes={
gemFromFieldList:a.dndObjectTypes.gem+a.dndSourceTypes.fieldList,
gemFromLayoutPanel:a.dndObjectTypes.gem+a.dndSourceTypes.layoutPanel,
gemFromReportArea:a.dndObjectTypes.gem+a.dndSourceTypes.reportArea}});define("pentaho/analyzer/cv_util",["dojo/_base/declare","dojo/_base/array",
"dojo/on","dojo/query","dojo/_base/lang","dijit/popup","dojo/dom-class",
"dojo/window","dojo/dom-style","dijit/registry","dojo/html","dojo/dom",
"dojo/topic","dojo/parser","dojox/fx","dojo/dnd/Manager","dojo/dnd/common",
"dojo/dom-geometry","dojox/xml/parser","dijit/MenuItem","dijit/MenuSeparator",
"dojo/dnd/Avatar","dijit/BackgroundIframe","dojo/has","dojo/sniff",
"dijit/PopupMenuItem","dijit/Tooltip","dijit/layout/TabController","dojo/cache",
"dojo/regexp","dijit/layout/_TabContainerBase","dijit/layout/TabContainer",
"dijit/DialogUnderlay","./visual/utils","pentaho/visual/util","dojo/string",
"dojo/request","pentaho/common/Messages","pentaho/csrf/service",
"common-ui/util/_a11y","common-ui/util/_focus","./cv_base"],(e,s,l,n,a,d,c,u,p,i
,t,h,r,o,g,v,m,f,b,y,C,A,w,N,S,k,P,F,W,I,E,L,B,R,T,x,D,H,_,M,j)=>{let O=null;
cv.util={initDojoWidget:null,getRestoreFocus(){return j.refreshElement(O)},
setRestoreFocus(e){O=e},bindRestoreFocus(t,e){const i="string"==typeof e?t[e]:e;
return(...e)=>(j.suspendFocusRing(),cv.util.restoreFocus(),i.apply(t,e))},
restoreFocus(){var e=this.getRestoreFocus();null!=e&&(e.focus(),O=null)},
createCompositeHandle(){const t=[];return{add(e){return t.push.apply(t,arguments
),this},remove(){return t.forEach(e=>{e.remove()}),t.length=0,this}}},
alertErrorOnPageOpen(e,t){alert(e),t&&(window.location=t)},delayThese(e,t,i,r){
e.length?(void 0===i&&"number"==typeof t?(i=t,t=()=>{}):t||(t=()=>{},i=i||0),
setTimeout(()=>{e.shift()(),t(),cv.util.delayThese(e,t,i,r)},i)
):"function"==typeof r&&r()},checkNumber(e){return""!==e&&!isNaN(Number(e))},
isValidInteractionEvent(e){var t=e.keyCode||e.which;
return"click"===e.type||t===cvConst.keyCodes.SPACE||t===cvConst.keyCodes.ENTER},
checkPositiveInteger(e){var t;return!!cv.util.checkNumber(e)&&0<(t=parseInt(e,10
))&&t===parseFloat(e)},escapeHtml(e,t){let i=e.replace(/&/gm,"&amp;").replace(
/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
return i=t?i:i.replace(/'/gm,"&#39;")},escapeJavaScript(e){return e.replace(
/(["'\f\b\n\t\r])/gm,"\\$1")},getAttribute(e,t){return e.getAttribute(t)},
isValidElementName(i,r,o){var t=['"',"\\"];if(void 0===r&&(r=!1),
null==i||void 0===i)return H.getString("dlgPropertiesBlankNameError");
var e=i=i.toLowerCase();if(""===(i=i.trim()))return H.getString(
"dlgPropertiesBlankNameError");i=e;e=cv.getFieldHelp();let n;if(
e.selectedMenuField&&(n=e.selectedMenuField.textContent.toLowerCase()),
0<o.length)for(let t=0;t<=o.length-1;t++){var s=o[t].getElementsByTagName(
"presentationFieldHelp")[0].getAttribute("displayLabel"),a=s.toLowerCase();
let e=o[t].getAttribute("measureName");var l=e;if(e=e&&e.toLowerCase(),(
i===a||i===e)&&(r||a!==n))return(a=o[t].getElementsByTagName(
"presentationFieldHelp")[0].getAttribute("hidden").toLowerCase()
)&&"true"===a?i===e?H.getString("dlgPropertiesHiddenDuplicateNameRenamedError",[
l,s]):H.getString("dlgPropertiesHiddenDuplicateNameError"):i===e?H.getString(
"dlgPropertiesDuplicateNameRenamedError",[l,s]):H.getString(
"dlgPropertiesDuplicateNameError")}for(let e=0;e<=i.length;e++)for(const d in t
)if(i.charAt(e)===t[d])return H.getString("dlgPropertiesInvalidCharacters");
return!0},isValidMeasureName(e,t){var i=cv.getFieldHelp();
return this.isValidElementName(e,t,i.getMeasureList())},isValidAttributeName(e,t
){var i=cv.getFieldHelp(),r=i.selectedMenuField.getAttribute("formula"),r=i.get(
r).getAttribute("hierarchy"),i=i.getHierarchyLevels(r);
return this.isValidElementName(e,t,i)},convertReportCalcMeasureToModel(t,e){
var i=`[Measures].[${e}]`,r=cv.getFieldHelp().manager["report"],o=r["reportDoc"]
for(const s of o.getMetrics("EXPRESSION"))if(s.getAttribute("id")===t){
let e="measures";null!==s.getAttribute("gembarId")&&(e=s.getAttribute("gembarId"
));var n=r.api.report.getLayoutFields(e).indexOf(t);-1!==n&&(
r.api.report.removeLayoutField(e,t),r.api.report.addLayoutField(e,i,n))}
this.updateMeasureReferences(t,e)},updateMeasureReferences(t,i){
i=`[Measures].[${i}]`;if(t!==i){var r=cv.getFieldHelp().manager["report"];
let e=b.innerXML(r.reportDoc.getReportNode());e=e.replace(new RegExp(
I.escapeString(t),"g"),i);t=cv.parseXML(e);try{r.openReport(t.documentElement)
}catch(e){r.history.current().exec(!0)}}},xmlToJson(t){var i={};if(
t.nodeType===Node.ELEMENT_NODE){if(0<t.attributes.length){i.attributes={};for(
let e=0;e<t.attributes.length;e++){var r=t.attributes.item(e);i.attributes[
r.nodeName]=r.nodeValue}}for(let e=0;e<t.childNodes.length;e++){var o,
n=t.childNodes.item(e),s=n["nodeName"];"#text"!==s?void 0===i[s]?i[s
]=this.xmlToJson(n):(Array.isArray(i[s])||(o=i[s],i[s]=[],i[s].push(o)),i[s
].push(this.xmlToJson(n))):i._text=n.textContent.trim()}}return i},
createCalcMeasureAnnotation(e,t,i,r,o,n,s){
this._createGenericCalcMeasureAnnotation({name:e,caption:i,description:r,
formatCategory:o,formatScale:n,calculateSubtotals:s,formula:t,
dimension:"Measures",createdInline:!0},"CREATE_CALCULATED_MEMBER")},
createUpdateCalcMeasureAnnotation(e,t,i,r,o,n,s,a){
this._createGenericCalcMeasureAnnotation({originalName:e,name:t,caption:r,
description:o,formatCategory:n,formatScale:s,calculateSubtotals:a,formula:i,
dimension:"Measures",createdInline:!0},"UPDATE_CALCULATED_MEMBER")},
_findNextNonHiddenSibling(e){e=e.nextSibling;return e&&this._isHiddenChild(e
)?this._findNextNonHiddenSibling(e):e},_findPreviousNonHiddenSibling(e){
e=e.previousSibling;return e&&this._isHiddenChild(e
)?this._findPreviousNonHiddenSibling(e):e},_findNextNonHiddenHeader(e){
e=e&&e.nextSibling;return e&&this._isHiddenHeader(e
)?this._findNextNonHiddenHeader(e.nextSibling):e},_findPreviousNonHiddenHeader(e
){e=e&&e.previousSibling;return e&&this._isHiddenHeader(e
)?this._findPreviousNonHiddenHeader(e.previousSibling):e},_isHiddenHeader(e){
return e.classList.contains("hidden")},_isHiddenChild(e){
return this._isHiddenHeader(e)||e.classList.contains("hiddenField")},
_createGenericCalcMeasureAnnotation(e,t){var i=cv.getFieldHelp().manager[
"report"],e={properties:e,source:{cube:i.cube},type:t};i.modelAnnotations.push(e
)},createShowHideFieldAnnotation(t){var i=cv.getFieldHelp().manager["report"],
r=!this.isHiddenField(t),e=t.getAttribute("formula"),t=cv.getFieldHelp().get(e),
o=i.api.util.parseMDXExpression(e);let n;if("attributeHelp"===t.nodeName){
let e=t.getAttribute("hierarchy").replace(/[[\]]/g,"");t=t.getAttribute(
"dimension").replace(/[[\]]/g,"");0===e.indexOf(t+".")&&(e=e.substring(
t.length+1)),n={properties:{name:o,visible:!r,hierarchy:e,dimension:t},source:{
cube:i.cube},type:"SHOW_HIDE_ATTRIBUTE"}}else n={properties:{name:o,visible:!r},
source:{cube:i.cube},type:"SHOW_HIDE_MEASURE"};i.modelAnnotations.push(n);
t=i.manager.updateCatalog(!0);if(void 0!==t)i.modelAnnotations.pop(),
console.log(t);else{var s=[];for(const l of cv.getActiveReport(
).reportDoc.getDrillColumns()){var a=cv.textContent(l);s[a
]=a!==e?"true"!==cv.util.getAttribute(l,"hidden"):!r}cv.getActiveReport(
).reportDoc.replaceDrillColumns(s),r?(null!==(o=this.findContainingGemBar(i,e)
)&&i.api.report.removeLayoutField(o,e),i.history.add(new cv.ReportState(
"actionHideField",e))):i.history.add(new cv.ReportState("actionShowField",e)),
i.api.operation.refreshReport()}},substituteParams(e,t){
const i="object"==typeof t?t:cv.util.toArray(arguments,1);return e.replace(
/%\{(\w+)}/g,(e,t)=>{if(void 0!==i[t]&&null!=i[t])return i[t];
throw"Substitution not found: "+t})},toArray(t,i){var r=[];for(
let e=i||0;e<t.length;e++)r.push(t[e]);return r},summary(e,t){var i;
return!t||e.length<=t?e:(i=new RegExp(`\\.{1,${t}}$`),e.substring(0,t).replace(i
,"")+"...")},sanitizeJSONString(e){if(!e)return null;let t=e;return t=t.replace(
/\/\*[\s\S]*\*\//,"")},connectPopupMenu(r,e){const o=[];
return null!=e&&e.forEach(e=>{var t,i=this.getDojoWidget(e.id);i&&(
t=cv.util.bindRestoreFocus(e.src||r,e.handler),o.push(l(i,"click",t)),o.push(l(i
,"click",()=>{d.close()})),e.disabled)&&i.setDisabled(!0)}),{remove(){o.forEach(
e=>{e.remove()})}}},showPopupMenu(e,t,i,r){t+=7,i+=7;var o=u.getBox()["h"];if(
cv.api.event._emitBuildMenu(e,t,i)){const n=O,s=(O=r||null,d.open({popup:e,x:t,
y:i}),i+e.domNode.offsetHeight>o&&(i=o-e.domNode.offsetHeight-30,d.open({
popup:e,x:t,y:i})),l(e,"keypress",e=>{e=e.keyCode||e.which;
e!==cvConst.keyCodes.ESCAPE&&e!==cvConst.keyCodes.TAB||(d.close(),s.remove(),
r&&r.focus(),O=n)})),a=l(e,"blur",()=>{r&&c.remove(r,"selected-menu-field"),
d.close(),a.remove(),O=n});e.focus()}},disableMenuItems(e,t){
this.resetContextMenuItems(e);var i=cv.getFieldHelp(),r=t.getAttribute("formula"
),o=this.isHiddenField(t);let n=e.getChildren();for(let e=0;e<n.length;e++){var{
[e]:{id:s}}=n;"cmdHideField"===s?cv.util.setMenuItem(n[e],o?"checked":"none"
):"cmdFieldAbout"!==s&&o?cv.util.setMenuItem(n[e],null,"disabled"
):cv.util.setMenuItem(n[e],null,"active")}let a=i.getModelInfoValue(r,
"InlineCreatedInline");if(a=a&&"true"===a.trim(),t.classList.contains("measure")
){var l="true"===i.get(r,"calculated");n=e.getChildren();for(
let e=0;e<n.length;e++){var{[e]:{id:d}}=n;l?this._doesMenuItemApply(n[e],[
"calculated measure"])||this.hide(d):a||this._doesMenuItemApply(n[e],["measure"]
)||this.hide(d)}}else for(const c of n=e.getChildren())this._doesMenuItemApply(c
,["level"])||this.hide(c.id)},_doesMenuItemApply(e,t){let i=!1;if(e&&e.appliesTo
){t.push("all");for(const r in t)i=i||0<=s.indexOf(e.appliesTo,t[r])}return i},
resetContextMenuItems(e){for(const t of e.getChildren())this.show(t.domNode)},
destroyDojoWidgets(){for(const e in cv.dojoWidgets)try{cv.dojoWidgets[e
]&&cv.dojoWidgets[e].destroy(!0)}catch(e){}},disconnectPopupMenu(e,t){if(null!=t
)for(const i of t)this.getDojoWidget(i.id)},displayWidget(e,t){
this.getDojoWidget(e)&&(e=this.getDojoWidget(e).domNode)&&(t?p.set(e,"display",
""):p.set(e,"display","none"))},getAncestorByClass(e,t){for(;e&&!c.contains(e,t
);)e=e.parentNode;return e},getFirstChildByClass(e,t){t=n(" ."+t,e);if(
void 0!==t&&0<t.length)return t[0]},getAncestorByTag(e,t){for(t=t.toLowerCase(
);e;){if(e.tagName&&e.tagName.toLowerCase()===t)return e;e=e.parentNode}
return null},getDojoWidget(e){if(cv.dojoWidgets[e])return cv.dojoWidgets[e];
let t=i.byId(e);if(!t){if(!(t=h.byId(e)))return null;t=(t=o.instantiate([t])
)&&0<t.length?t[0]:null}return t&&(this.initDojoWidget&&this.initDojoWidget(t),
cv.dojoWidgets[e]=t,p.set(t.domNode,{zIndex:1002})),t},stopDrag(){c.remove(
win.body(),["dojoDndCopy","dojoDndMove"]),s.forEach(this.events,e=>{e.remove()})
,this.events=[],this.avatar&&this.avatar.destroy(),this.avatar=null,
this.source=this.target=null,this.nodes=[],r.publish("/dnd/cancel")},
helpdialog:null,getHelp(e){var t;(e=a.isObject(e)&&e.target?e.target.id:e
)&&"null"!==e?e.indexOf(".html")<0&&(e=cv.helpTopics&&cv.helpTopics[e
]?cv.helpTopics[e]:""):e="",e=cv.contextPath+"help/topic.html?"+e,
window.location.search&&-1<window.location.search.indexOf("embeddedHelp=true")?(
null==this.helpDialog&&(this.helpDialog=new cv.HelpDialog,this.helpDialog.init()
),this.helpDialog.showDlg(e)):(t=u.getBox(),
cv.helpWin&&!cv.helpWin.closed&&cv.helpWin.close(),(e=window.open(e,"helpWnd",
`height=${.8*t.h},width=${.8*t.w},menubar=0,status=0,toolbar=0,location=0,resizable=1`
))&&(cv.helpWin=e).focus())},getSelectionList(e){var t=e.getElementsByTagName(
"INPUT");let i=[];var r=t.length;for(let e=0;e<r;++e)t[e].checked&&i.push(t[e
].name);return i=0===i.length?null:i},check(e,t){("string"==typeof e?h.byId(e):e
).checked=t},hide(){for(const e of arguments)c.add(h.byId(e),"hidden")},
disableTextSelection(e){e.onselectstart=()=>!1,p.set(e,{
"-moz-user-select":"-moz-none","-khtml-user-select":"none",
"-webkit-user-select":"none","user-select":"none"})},initDivButton(e,t,i){if(!(
e="string"==typeof e?h.byId(e):e))return{remove(){}};const r=[l(e,"mouseover",
a.hitch(this,"_divButtonActive")),l(e,"mousedown",a.hitch(this,
"_divButtonPressed")),l(e,"mouseout",a.hitch(this,"_divButtonInactive")),l(e,
"click",a.hitch(this,"_divButtonInactive"))];return t?r.push(l(e,"click",
a.hitch(t,i))):i&&r.push(l(e,"click",i)),cv.util.disableTextSelection(e),{
remove(){r.forEach(e=>{e.remove()})}}},isHidden(e){return c.contains(h.byId(e),
"hidden")},isHiddenField(e){return c.contains(e,"hiddenField")||c.contains(e,
"disabled")},gravity(e,t){e=h.byId(e);const i=t.clientY,r=t.clientX;
var t=f.position(e),e=t.x+t.w/2,t=t.y+t.h/2,o=cv.util.gravity;return(
r<e?o.WEST:o.EAST)|(i<t?o.NORTH:o.SOUTH)},overElement(e,t){if(!e)return!1;let i;
switch(t.type){case"mouseout":case"mouseleave":if(t.target==e)return!1;break;
default:if(t.target==e)return!0}"AREA"===e.tagName&&"RECT"===e.getAttribute(
"shape").toUpperCase()?(o=e.coords.split(","),r=n(
`img[usemap='#${e.parentNode.getAttribute("name")}']`)[0],(i=f.position(r,!0)
).x+=parseInt(o[0],10),i.y+=parseInt(o[1],10),i.h+=parseInt(o[4],10)-parseInt(o[
1],10),i.w+=parseInt(o[3],10)-parseInt(o[0],10)):i=f.position(e,!0);
var r=t.clientX,o=t.clientY;return!(r>i.x+i.w||r<i.x||o>i.y+i.h||o<i.y)},
setButtonDisabled(e,t){var i;e&&t!=e.disabled&&("IMG"===e.tagName?(
i=-1<e.src.indexOf(".png")?".png":".gif",e.src=t?e.src.replace(i,"_disabled"+i
):e.src.replace("_disabled"+i,i)):t?c.add(e,"disabled"):c.remove(e,"disabled"),
e.setAttribute("tabindex",t?"-1":"0"),e.disabled=t)},isDisabled(e){
return Array.from(e.classList).some(e=>e.includes("disabled"))},isEnabled(e){
return!cv.util.isDisabled(e)},_divButtonActive(e){e.target.disabled||c.add(
this.getAncestorByClass(e.target,"reportBtn"),"btnActive")},_divButtonInactive(e
){e=this.getAncestorByClass(e.target,"reportBtn");c.remove(e,"btnActive")},
_divButtonPressed(e){},onToggleSectionCheckbox(e){(e.target.checked?g.wipeIn({
duration:cv.prefs.wipeTime,node:e.target.id+"DIV"}):g.wipeOut({
duration:cv.prefs.wipeTime,node:e.target.id+"DIV"})).play()},parseMDXExpression(
e,t){var i=e.lastIndexOf("].[");if(-1===i)return"";e=e.substring(i);
i=/\]\.\[(.+)\]$/.exec(e);if(!i)return"";let r=i[1];return"#null"===(
r=r.replace("]]","]"))?cvCatalog.attributeNullValue:r.search(/\S/
)<0?cvCatalog.attributeBlankValue:t?cv.util.escapeHtml(r):r},parseAjaxMsg(t){if(
"string"==typeof t){if(0<t.indexOf('<form name="login"')){if(
console_enabled&&window.parent.authenticate)return window.parent.authenticate({
loginCallback(){cv.getActiveReport()&&cv.getActiveReport().refreshReport()}}),
"sessionExpired";cv.getActiveReport()&&(cv.getActiveReport(
).setReportPropsDirty(!1),cv.getActiveReport().history.setSaved()),
window.location.reload()}var i=t.indexOf("<message");if(i<0)return;
let e=t.indexOf("</message>");if(e<0){if((e=t.indexOf("/>",i))<0)return;e+=2
}else e+=10;t=cv.parseXML(t.substring(i,e)),cv.setDomDefaultNamespace(t)}if(
a.isObject(t)&&t.documentElement&&"message"===t.documentElement.tagName){
var r=t.documentElement.attributes,o={};for(let e=0;e<r.length;++e){
var n=r.item(e);n.name&&(o[n.name]=n.value)}
i=t.documentElement.selectSingleNode("cv:selectionItems");
return null!=i&&cv.getActiveReport().reportDoc.replaceSelectionItems(
i.cloneNode(!0)),o}return null},_findKeyInQuery(e,t){if(0!==n.length)for(
const r of t.substring(1).split("&")){var i=r.indexOf("=");if(0<i)if(
r.substring(0,i)===e)return decodeURIComponent(r.substring(i+1).replace(/\+/g,
" "))}return null},getURLQueryValue(e,t){var i=this._findKeyInQuery(e,
window.location.search);
return i||""===i?i:t&&window.parent?this._findKeyInQuery(e,
window.parent.location.search):null},removeNode(e){
e&&e.parentNode&&e.parentNode.removeChild(e)},setCommonMsgTooltip(e){var t;e&&(
t=this.getDojoWidget("commonMsgTooltip"))&&(t.domNode.innerHTML=e)},
setDivActive(e,t){t?c.add(e,"active"):c.remove(e,"active")},setHelpTopics(t){
for(let e=0;e<t.length;++e){var i="string"==typeof t[e]?h.byId(t[e]):t[e];i&&(l(
i,"click",a.hitch(this,"getHelp")),M.makeAccessibleActionButton(i),
cv.helpTopics[t[e]]=t[++e])}},setMenuItem(e,t,i,r){var o;(
e="string"==typeof e?this.getDojoWidget(e):e)&&(t&&(o=e["iconNode"],
"checked"===t?(c.remove(o,"dijitNoIcon unchecked"),c.add(o,"checked")):(
c.remove(o,"dijitNoIcon checked"),c.add(o,"unchecked"))),
i&&e.setDisabled&&e.set("disabled","disabled"==i),r)&&(e.domNode.title=r)},
setVizMenuItemSelected(e,t){(e="string"==typeof e?this.getDojoWidget(e):e)&&(
e=e["domNode"],t?c.add(e,"selected"):c.remove(e,"selected"))},
setSectionCollapsed(e){let t=!0;var i=h.byId(e);i&&(
"checkbox"===i.type?i.checked=!1:"IMG"===i.tagName&&(this.hide(i.id+"DIV"),
i.name="closed",i.src=i.src.replace(/opened\./,"closed."),t=!1)),
t&&dojox.fx.wipeOut({duration:0,node:h.byId(e+"DIV")}).play()},show(){for(
const e of arguments)e.tagName?c.remove(e,"hidden"):c.remove(h.byId(e),"hidden")
},updateMenuItemCaption(e,t,i){e=this.getDojoWidget(e);e&&(t=cvCatalog[t],i&&(
t=cv.util.substituteParams(t,i)),e.setLabel(t))},TRACE(e){if(!(
cv.prefs.isDebug<2))try{var t;"_INIT"===e?(this.TRACEWIN=window.open("",
"cvtrace","resizable=1,scrollbars=1"),this.TRACEWIN.document.open(),
this.TRACEWIN.document.writeln("<b>INITIALIZE ClearView JS Trace</b><p>")
):"_EXIT"===e?(this.TRACEWIN.document.writeln("<b>EXIT ClearView JS Trace</b>"),
this.TRACEWIN.document.close(),this.TRACEWIN.close()):"_START"===e?(
this.TSBASE=this.TSSTART=new Date,this.TRACEWIN.document.writeln(
`<b>Start Profiling at: ${this.TSSTART}</b><br>`)
):"_END"===e?this.TRACEWIN.document.writeln(
`<b>Finish Profiling - Total: ${new Date-this.TSSTART} ms</b><p>`
):"_CLEAR"===e?this.TRACEWIN.document.clear():(t=new Date,
this.TRACEWIN.document.writeln(
`&nbsp;&nbsp;&nbsp;&nbsp;${e}: ${t-this.TSBASE} ms<br>`),this.TSBASE=new Date)
}catch(e){}},createEvent(e){return{target:e,clientX:0,clientY:0,stopPropagation(
){},preventDefault(){}}},convertStringtoDate(e){return new Date(Date.parse(e))},
formatDateString(e){var e=this.convertStringtoDate(e),t=["Jan","Feb","Mar","Apr"
,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][e.getMonth()],i=e.getDate(),
r=e.getFullYear();let o=e.toLocaleTimeString();return t+` ${i}, ${r} `+(
o=0===o.indexOf("0")?o.substring(1):o)},goToURL(e){try{var t=e.href.lastIndexOf(
"#");-1!==t&&(e.href=e.href.substring(0,t)),window.location=e}catch(e){if(!(N(
"ie")&&-1<e.message.indexOf("Unspecified error")))throw e}},selectByValue(t,i){
for(let e=0;e<t.length;e++)t.options[e].selected=t.options[e].value==i},
addChartMenuItems(s){const a=this;
var e=cv.api.ui._visualRegistry.getAllByCategory();const l=cv["vizApiVersion"],
d=[];let t=0;return e.forEach(e=>{e=e.models;0<t&&0<e.length&&s.addChild(new C({
id:"menu-item100000"+t})),t++,e.forEach(e=>{var e=e.type,t=null!=e.v2Spec,
i=R.getVizOptionsAnnotation(e.id),i=i&&i.isStockVisualization,r=t&&2===l,
o=!t&&3<=l,n=""+(t?e.v2Id:e.id),t=t?n.toUpperCase():T.getCssClasses(n),
e=""+e.label;!r&&!o&&i||d.push(a._createChartMenuItem(s,t,n,e))})}),d},
_createChartMenuItem(e,t,i,r){t+=" component-icon-menu",i=new y({id:i,label:r,
customType:!0});return c.remove(i.iconNode,"dijitNoIcon"),c.add(i.iconNode,t),
e.addChild(i),i},clearCache(e,t,i,r){const o=this;
var n=cv.contextPath+"service/ajax/clearCache",s={},n=_.getToken(n);null!==n&&(
s[n.header]=n.token),D(cv.contextPath+"service/ajax/clearCache",{method:"POST",
data:{catalog:h.byId("REPORT_catalog").value,time:(new Date).getTime()},sync:!0,
headers:s}).then(e=>{"true"===e?(r||o.showStatus("infoCacheCleared","INFO"),
t&&t()):(r||o.showStatus("errorClearCache","ERROR"),i&&i())},()=>{
r||o.showStatus("errorClearCache","ERROR"),i&&i()},()=>{})},showStatus(e,t){
var i=cv.getActiveReport();let r=cvCatalog[e],o=(r=r||e,t);
"ERROR"===t?o=cvCatalog.dlgTitleError:"INFO"===t?o=cvCatalog.dlgTitleInfo:"WARNING"===t&&(
o=cvCatalog.dlgTitleWarning),cv.isMobile()?i.rptDlg.showConfirm(r
):console_enabled&&window.parent.mantle_showMessage?window.parent.mantle_showMessage(
o,r):("ERROR"===t?i.rptDlg.showError(r):"WARNING"===t?i.rptDlg.showWarning(r
):i.rptDlg.showConfirm(r),i.rptDlg.noHide=!0)},isShowing(e){e=h.byId(e);
return!!e&&!(0===parseInt(e.style.width,10
)||"none"===e.style.display||"none"===p.getComputedStyle(e).display)},
_sendRequest(e,t){return D(e,t)},saveReport(t,e,i,r,o,n){if(
void 0!==n&&null!=n||(n=!1),t.modelAnnotations.length
)return t.pendingSaveParams.reportAction=e,t.pendingSaveParams.reportName=i,
t.pendingSaveParams.reportPath=r,t.pendingSaveParams.reportErrorCallback=o,
t.pendingSaveParams.suppressSuccessNotification=n,
cv.rptEditor.saveModifiedModel(),!1;console.log("now saving report");let s=!0;
var e={action:e,name:x.trim(i),path:r},i=(t.saveUIAttributes(),
t.reportDoc.getUIAttributes()),r=(i.setAttribute("showFieldList",this.isShowing(
"fieldListWrapper")?"true":"false"),i.setAttribute("showFieldLayout",
this.isShowing("layoutPanelWrapper")?"true":"false"),i.setAttribute(
"showFilterPanel","filterPane"===t.topPaneId?"true":"false"),i.setAttribute(
"fieldListView",t.manager.fieldHelp.currentView),e.reportXML=t.getReportXml(),
e.time=(new Date).getTime(),cv.contextPath+"service/ajax/saveReport"),i={},
a=_.getToken(r);return null!==a&&(i[a.header]=a.token),this._sendRequest(r,{
data:e,sync:!0,headers:i,method:"POST"}).then(e=>{e=cv.parseXML(e),
cv.setDomDefaultNamespace(e);var e=e.documentElement;"success"!==e.getAttribute(
"type")?(s=!1,"function"==typeof o?o():"object"==typeof o&&o.error()):(
t.reportDoc.replaceStorageNode(e.selectSingleNode("cv:commonStorageAttributes"))
,e=t.reportDoc.getReportProperty("name"),t.setReportName(e),document.title=e,
t.setReportPropsDirty(!1),t.history.setSaved(),
console_enabled&&window.parent.mantle_showMessage||n||cv.util.showStatus(
"successSaveReport","INFO"),"object"==typeof o&&o.success())},()=>{
cv.util.showStatus("errorSaveReport","ERROR")},()=>{}),s},updateCatalog(e,t,i,r
){let o=cv.io.getFieldHelpXml(t.catalog,t.cube,r);try{o=dojo.fromJson(o)}catch(e
){o={status:"EXCEPTION"}}if("SUCCESS"!==o.status)return e||this.showStatus(
o.message,"ERROR"),null==o.message?"":o.message;i.updateXml(o.fieldHelpXml)},
onToggleAutoRefresh(e,t,i){e&&!cv.util.isValidInteractionEvent(e)||(
e=!cv.prefs.autoRefresh,t.setAutoRefresh(e,i),e&&!t.history.isStateRefreshed(
)&&t.refreshReport(!0))},findContainingGemBar(e,t){var i=e.api.ui.listGembarIds(
);for(const n in i){var r=i[n],o=e.api.report.getLayoutFields(r);if(
-1!==s.indexOf(o,t))return r}return null},safeHtmlTemplate(e){
return e?.length?e.trim().replace(/>(?:\n\s*)?(.*?)(?:\n\s*)?<(\/?\w+)/g,
">$1<$2"):""}},cv.util.gravity.NORTH=1,cv.util.gravity.SOUTH=2,
cv.util.gravity.EAST=4,cv.util.gravity.WEST=8,e("cv.Collapsible",null,{
constructor(e,t,i,r,o){this.header=e,this.body=t,this.cssOpen=r||"folderClose",
this.cssClose=o||"folderOpen",this.isOpen=!0===i,this.setState(this.isOpen,!0),
cv.util.disableTextSelection(e),l(e,"click",a.hitch(this,"onClickHeader")),l(e,
"keydown",a.hitch(this,"onKeydownHeader"))},onClickHeader(e){
this.animation&&"playing"===this.animation.status()||(this.isOpen=!this.isOpen,
this.setState(this.isOpen,!0)),e&&e.stopPropagation()},onKeydownHeader(i){
var e=i.keyCode||i.which;if(e===cvConst.keyCodes.ARROW_DOWN){i.preventDefault();
let e;if(this.isOpen){var r=this.body["children"];for(const t of r)if(
!cv.util._isHiddenChild(t)){e=t;break}}this.header.setAttribute("tabindex","-1")
,e?(e.setAttribute("tabindex","0"),e.focus()):(
r=cv.util._findNextNonHiddenHeader(this.header.nextSibling))&&(r.setAttribute(
"tabindex","0"),r.focus())}else if(e===cvConst.keyCodes.ARROW_UP){
i.preventDefault();r=this.header["previousSibling"];if(r&&r.previousSibling){
let t;i=cv.util._findPreviousNonHiddenHeader(r);if(i.classList.contains(
"folderOpen")){var o=i.nextSibling["children"];for(let e=o.length-1;-1<e;e--)if(
!cv.util._isHiddenChild(o[e])){t=o[e];break}}this.header.setAttribute("tabindex"
,"-1"),(t?(t.setAttribute("tabindex","0"),t):(i.setAttribute("tabindex","0"),i)
).focus()}}else e===cvConst.keyCodes.ARROW_LEFT?(this.isOpen=!1,this.setState(
this.isOpen,!1)):e===cvConst.keyCodes.ARROW_RIGHT&&(this.isOpen=!0,
this.setState(this.isOpen,!0))},setState(e,t){e?(c.remove(this.header,
this.cssOpen),c.add(this.header,this.cssClose),t?(
this.body.style.display="block",this.animation=null):this.animation=g.wipeIn({
duration:cv.prefs.wipeTime,node:this.body}).play()):(c.remove(this.header,
this.cssClose),c.add(this.header,this.cssOpen),t?(this.body.style.display="none"
,this.animation=null):this.animation=g.wipeOut({duration:cv.prefs.wipeTime,
node:this.body}).play())}}),cv.Collapsible.moveFocus=(e,t)=>{var i,r;"Up"===t?(
i=cv.util._findPreviousNonHiddenSibling(e),r=e.parentNode.previousSibling,i?(
i.setAttribute("tabindex","0"),e.setAttribute("tabindex","-1"),i.focus()):r&&(
r.setAttribute("tabindex","0"),e.setAttribute("tabindex","-1"),r.focus())
):"Down"===t&&((i=cv.util._findNextNonHiddenSibling(e))?(i.setAttribute(
"tabindex","0"),e.setAttribute("tabindex","-1"),i.focus()):(
r=cv.util._findNextNonHiddenHeader(e.parentNode))&&(r.setAttribute("tabindex",
"0"),e.setAttribute("tabindex","-1"),r.focus()))},e("cv.dnd.Avatar",[A],{
constructor(e,t){this.manager=e,this.node=t},update(){}}),e("cv.dnd.Manager",[v]
,{opacity:.8,startDrag(e,t,i){!t||0===t.length||cv.util.isHiddenField(t[0]
)||cv.getActiveReport().isResizing||cv.api.event.isEventDisabled("dragAndDrop"
)||cv.getActiveReport().isEditDisabled()||this.inherited(arguments)},makeAvatar(
){var t=this.nodes[0].getAttribute("formula");let i;if(t){
i=document.createElement("DIV");let e;c.contains(this.nodes[0],"filterItem"
)||c.contains(this.nodes[0],"filterGroup")?(e="filterDragObject",0===this.nodes[
0].id.indexOf("filter_metric")?i.innerHTML=cvCatalog.filterMetric:(r=this.nodes[
0].getElementsByTagName("span"),i.innerHTML=cv.textContent(r[0])),
i.setAttribute("formula",this.nodes[0].id)):(e=cv.getFieldHelp().isAttribute(t
)?"attributeDragObject":"metricDragObject",i.innerHTML=cv.util.escapeHtml(
cv.textContent(this.nodes[0])),i.setAttribute("formula",t)),c.add(i,
"commonDragObject"),e&&c.add(i,e),this.opacity<1&&p.set(i,"opacity",this.opacity
)}else if("DB"===this.type){i=document.createElement("DIV");var r=f.position(
this.nodes[0]);p.set(i,{border:"2px dashed black",height:r.h+"px",
width:r.w+"px",backgroundColor:"silver"}),this.opacity<1&&p.set(i,"opacity",
this.opacity)}else{i=this.nodes[0].cloneNode(!0),this.dragClass&&c.add(i,
this.dragClass),this.opacity<1&&p.set(i,"opacity",this.opacity);
var t=i.tagName.toLowerCase(),r="tr"===t;if(r||"tbody"===t){var t=this.nodes[0
].ownerDocument,e=t.createElement("table"),t=((r?(t=t.createElement("tbody"),
e.appendChild(t),t):e).appendChild(i),r?i:i.firstChild),o=tdp.childNodes,
n=t.childNodes;for(let e=0;e<o.length;e++){var{[e]:s}=n;s&&s.style&&(
s.style.width=f.getContentBox(o[e]).w+"px")}i=e}}return N("ie"
)<7&&this.createIframe&&(p.set(i,{top:"0px",left:"0px"}),(
r=document.createElement("div")).appendChild(i),this.bgIframe=new w(r),
r.appendChild(this.bgIframe.iframe),i=r),i.style.zIndex=999,
i.style.position="absolute",new cv.dnd.Avatar(m._manager,i)}}),
m._manager=new cv.dnd.Manager,a.extend(y,{onClick(){d.close()}}),a.extend(E,{
_setupChild(e){this.inherited("_setupChild",arguments)}})});define("pentaho/analyzer/cv_history",["dojo/_base/declare","dijit/_Widget",
"dijit/_Templated","dojo/on","dojo/query","dojox/collections/Stack",
"dojo/_base/lang","dojo/aspect","dojo/sniff","./cv_base","./cv_util"],function(t
,e,r,i,o,n,s,a,d){return t("cv.History",null,{constructor:function(t,e,r){
this.owner=t,this.undoStack=new n,this.redoStack=new n,this.savedState=null,
this.originalState=null,this.refreshedState=new Array,e&&r&&(a.after(this,"add",
s.hitch(e,r)),a.after(this,"undo",s.hitch(e,r)),a.after(this,"redo",s.hitch(e,r)
),a.after(this,"rewindTo",s.hitch(e,r)),a.after(this,"forwardTo",s.hitch(e,r)),
a.after(this,"setTo",s.hitch(e,r)),a.after(this,"setSaved",s.hitch(e,r)),
a.after(this,"setRefreshed",s.hitch(e,r)))},add:function(t){this.endCurrent(),
t.init(this.owner),this.originalState||0!=this.undoStack.count||(
this.originalState=t),this.undoStack.push(t),this.redoStack.clear(),
cv.api.event._emitActionEvent(t)||this.undo()},current:function(){
return this.undoStack.peek()},next:function(){return this.redoStack.peek()},
undo:function(){var t;this.hasUndo()&&(this.current().setPluginDataJSON(
cv.getActiveReport().getPluginDataJSON()),t=this.undoStack.pop())&&(
this.redoStack.push(t),(
t=this.owner.mode&&"VIEW"==this.owner.mode||this.owner.manager.cmdUndo.title.indexOf(
"Column Resize")<0?this.current():t).back())},redo:function(){var t;
this.hasRedo()&&(this.current().setPluginDataJSON(cv.getActiveReport(
).getPluginDataJSON()),t=this.redoStack.pop())&&(this.undoStack.push(t),
t.forward())},rewindTo:function(t,e){for(;this.hasUndo()&&(t!=this.current(
)||null==t);)this.redoStack.push(this.undoStack.pop());return this.hasUndo()?(
e&&this.current().back(),this.current()):null},forwardTo:function(t,e){for(
;this.hasRedo()&&t!=this.next();)this.undoStack.push(this.redoStack.pop());
return this.hasRedo()?(this.undoStack.push(this.redoStack.pop()),
e&&this.current().forward(),this.current()):null},setTo:function(t){if(!t
)return!1;if(this.undoStack.contains(t))for(;t!=this.current();
)this.redoStack.push(this.undoStack.pop());else{if(!this.redoStack.contains(t)
)return!1;for(;t!=this.next();)this.undoStack.push(this.redoStack.pop());
this.undoStack.push(this.redoStack.pop())}return!0},hasUndo:function(){
return 1<this.undoStack.count},hasRedo:function(){return 0<this.redoStack.count
},setSaved:function(){this.savedState=this.current()},getSaved:function(){
return this.savedState},setRefreshed:function(t){t||(
this.refreshedState=new Array),this.refreshedState[this.refreshedState.length
]=this.current()},isStateDirty:function(){return this.savedState!=this.current()
},isStateRefreshed:function(){for(var t=0;t<this.refreshedState.length;t++)if(
this.refreshedState[t]==this.current())return!0;return!1},isEmpty:function(){
return this.undoStack.count<=1&&this.redoStack.count<=0},endCurrent:function(){
var t=this.current();t&&t.end()},
updateReportUsingPreviousChartTypeState:function(t,e){this.endCurrent();for(
var r,i=this.undoStack.toArray(),o=i.length-1;0<=o;o--)if(i[o
].customChartType==e&&"JSON"==i[o].reportTypeEnum){r=i[o];break}if(r){
t.savePluginDataToXML(r.pluginDataJSON);var n,s=cv.parseXML(r.reportXml
).documentElement,a={};dojo.isIE||(n=navigator.userAgent.toLowerCase(),
n=/(msie\s|trident.*rv:)([\w.]+)/.exec(n),dojo.isIE=n?+n[2]:void 0);for(var u=d(
"ie")||"11"==dojo.isIE?s.selectNodes(
"//columnAttributes//attribute | //rowAttributes//attribute"):s.selectNodes(
"cv:columnAttributes/cv:attribute | cv:rowAttributes/cv:attribute"),
h=0;h<u.length;h++)u[h].getAttribute("gembarId")&&(a[u[h].getAttribute("formula"
)]=[u[h].getAttribute("gembarId"),u[h].getAttribute("gembarOrdinal")]);u=d("ie"
)||"11"==dojo.isIE?s.selectNodes("//measures//measure"):s.selectNodes(
"cv:measures/cv:measure");for(h=0;h<u.length;h++)u[h].getAttribute("gembarId"
)&&(a[u[h].getAttribute("id")]=[u[h].getAttribute("gembarId"),u[h].getAttribute(
"gembarOrdinal")]);u=t.reportDoc.getChildMembers("rowAttributes",
"columnAttributes");for(h=0;h<u.length;h++)(c=a[u[h].getAttribute("formula")])?(
u[h].setAttribute("gembarId",c[0]),u[h].setAttribute("gembarOrdinal",c[1])):(u[h
].removeAttribute("gembarId"),u[h].removeAttribute("gembarOrdinal"));
u=t.reportDoc.getChildMembers(["measures"]);for(var c,h=0;h<u.length;h++
)"true"!=u[h].getAttribute("hideInChart")&&((c=a[u[h].getAttribute("id")])?(u[h
].setAttribute("gembarId",c[0]),u[h].setAttribute("gembarOrdinal",c[1])):(u[h
].removeAttribute("gembarId"),u[h].removeAttribute("gembarOrdinal")));
t.reportDoc.setReportOption("reportTypeEnum",r.reportTypeEnum),
t.reportDoc.setChartOption("chartType",r.chartType),t.reportDoc.setChartOption(
"customChartType",r.customChartType),t._clearClientViz()}}})});define("pentaho/analyzer/cv_browser",["dojo/_base/declare","dojo/dom-style",
"dojo/on","dojo/query","dojo/html","dojox/xml/parser","./cv_base","./cv_util",
"./cv_history","dojo/has","dojo/sniff","dojo/_base/lang","dojo/dnd/Manager"],
function(e,t,n,o,i,a,r,s,d,c,u,h){function l(e,t,n,o){var t=t.changedTouches,
i=t[0].clientX,t=t[0].clientY,a=document.createEvent("MouseEvent");
a.initMouseEvent(e,!0,!0,window,1,i,t,i,t,!1,!1,!1,!1,0,void 0!==o?o:null),
n.dispatchEvent(a)}var m,w;cv.setDomDefaultNamespace=function(e){
"setProperty"in e&&e.setProperty("SelectionNamespaces",
"xmlns:cv='"+cv.defaultNS+"'")},cv.parseXML=function(e){var t;return c("ie")||c(
"trident")?((t=new ActiveXObject("Microsoft.XMLDOM")).async=!1,t.loadXML(e),t
):a.parse(e)},c("ie")?(Array.prototype.indexOf||(
Array.prototype.indexOf=function(e){"use strict";if(null==this
)throw new TypeError;var t=Object(this),n=t.length>>>0;if(0!=n){var o=0;if(
0<arguments.length&&((o=Number(arguments[1]))!=o?o=0:0!==o&&o!==1/0&&o!==-1/0&&(
o=(0<o||-1)*Math.floor(Math.abs(o)))),!(n<=o))for(var i=0<=o?o:Math.max(
n-Math.abs(o),0);i<n;i++)if(i in t&&t[i]===e)return i}return-1}),
cv.textContent=function(e,t){return null==t?a.textContent(e
):1!=e.nodeType?a.textContent(e,t):void(e.text=t)},cv.createNode=function(e,t,n
){return e.createNode(1,t,n||cv.defaultNS)},cv.addOption=function(e,t){e.add(t)}
,dojo.html.BackgroundIframe=function(e){this.iframe=dojo.doc().createElement(
"<iframe src=\"javascript:'<html><head></head><body></body></html>'\" style='position: absolute; left: 0px; top: 0px; width: 100%; height: 100%;z-index: -1; filter:Alpha(Opacity=\"0\");'>"
),this.iframe.tabIndex=-1,e?(e.appendChild(this.iframe),this.domNode=e):(
dojo.body().appendChild(this.iframe),this.iframe.style.display="none")},
h.extend(dojo.html.BackgroundIframe,{iframe:null,onResized:function(){var e;
this.iframe&&this.domNode&&this.domNode.parentNode&&(0==(e=dojo.marginBox(
this.domNode)).w||0==e.h?setTimeout(h.hitch(this,this.onResized),100):(
this.iframe.style.width=e.width+"px",this.iframe.style.height=e.height+"px"))},
size:function(e){this.iframe&&(e=geometry.position(e,!0),t.set(this.iframe,{
width:e.w+"px",height:e.h+"px",left:e.l+"px",top:e.t+"px"}))},
setZIndex:function(e){this.iframe&&(dojo.dom.isNode(e
)?this.iframe.style.zIndex=dojo.style(e,"z-index")-1:isNaN(e)||(
this.iframe.style.zIndex=e))},show:function(){this.iframe&&(
this.iframe.style.display="block")},hide:function(){this.iframe&&(
this.iframe.style.display="none")},remove:function(){this.iframe&&(
this.iframe.parentNode.removeChild(this.iframe),delete this.iframe,
this.iframe=null)}}),cv.contentMinWidth=750,cv.setMinWidth=function(){
var e=dojo.window.getBox().w;e<=cv.contentMinWidth?(
document.body.style.width=cv.contentMinWidth+"px",this.xScrolling=!0):(
document.body.style.width=e+"px",this.xScrolling=!1)}):(
Element.prototype.selectNodes=function(e){var t=this.ownerDocument.evaluate(e,
this,cv.nsResolver,XPathResult.ORDERED_NODE_ITERATOR_TYPE,null),n=[];if(t)for(
var o=t.iterateNext();o;)n.push(o),o=t.iterateNext();return n},
Element.prototype.selectSingleNode=function(e){e=this.ownerDocument.evaluate(e,
this,cv.nsResolver,XPathResult.FIRST_ORDERED_NODE_TYPE,null);
return e?e.singleNodeValue:null},cv.textContent=function(e,t){
return null==t?a.textContent(e):a.textContent(e,t)},cv.createNode=function(e,t,n
){return e.createElementNS?e.createElementNS(n||cv.defaultNS,t):e.createNode(1,t
,n||cv.defaultNS)},cv.addOption=function(e,t){e.appendChild(t)}),
cv.isMobile=function(){return cv.isMobileSafari()||void 0!==window.orientation},
cv.isMobileSafari=function(){return null!=navigator.userAgent.match(
/(iPad|iPod|iPhone)/)},cv.isMobile()&&(window.touchstartTime=0,
window.lastTouchstartTime=0,window.hasMoved=!1,m=function(e){try{if(
1<e.touches.length||1<e.changedTouches.length)window.contextMenuInPlay=!1;else{
var t=ManagerClass.manager(),n=e.changedTouches[0].target;if(
"INPUT"!=n.nodeName&&"BUTTON"!=n.nodeName&&"TEXTAREA"!=n.nodeName){
var o=e.changedTouches,i=o[0].screenX,a=o[0].screenY;switch(e.type){
case"touchstart":(new Date).getTime()-window.lastTouchstartTime<350?(l(
"dblclick",e,n),e.preventDefault(),window.hasMoved=!0):(
window.contextMenuInPlay=!0,window.touchstartTime=(new Date).getTime(),
window.touchstartX=e.changedTouches[0].screenX,
window.touchstartY=e.changedTouches[0].screenY,window.lastMoveEvent=e,
window.lastTouchstartTime=window.touchstartTime,l("mouseover",e,
window.lastOver=n),l("mousedown",e,n),e.preventDefault());break;case"touchmove":
window.hasMoved=!0,window.lastMoveEvent=e,
!t.source&&1!=e.touches.length||e.preventDefault(),l("mousemove",e,
n=document.elementFromPoint(i-cv.getOriginAdjustment().x,
a-cv.getOriginAdjustment().y)),window.lastOver&&n!=window.lastOver&&l("mouseout"
,e,window.lastOver,n),l("mouseover",e,n,window.lastOver),window.lastOver=n;break
case"touchend":
0<e.touches||!window.contextMenuInPlay||window.lastWasMultiTouch||((
!window.hasMoved||Math.abs(window.lastMoveEvent.changedTouches[0
].screenX-window.touchstartX)<10&&Math.abs(window.lastMoveEvent.changedTouches[0
].screenY-window.touchstartY)<10)&&200<(new Date).getTime(
)-window.touchstartTime?(l("contextmenu",e,n),e.preventDefault()):(l("mouseup",e
,computedTarget=document.elementFromPoint(i-cv.getOriginAdjustment().x,
a-cv.getOriginAdjustment().y)),l("click",e,computedTarget),n!=computedTarget&&(
l("mouseup",e,n),l("click",e,n))),window.lastOver&&l("mouseout",e,
window.lastOver,n),window.hasMoved=!1,window.lastMoveEvent=null);break;default:
return}}}}catch(e){console.log("error in touch handler: "+e)}},
document.addEventListener("touchstart",m,!0),document.addEventListener(
"touchmove",m,!0),document.addEventListener("touchend",m,!0),
cv.getOriginAdjustment=(window.addEventListener("orientationchange",function(){
w=null}),function(){return window.inMobile?w=w||getMyOriginOffset():{x:0,y:0}}))
});define("pentaho/analyzer/analyzer-selectSchema",["./cv_base","./cv_util",
"./cv_browser"],function(){});